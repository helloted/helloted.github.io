#!/bin/sh

sudo rm /usr/local/bin/xcodegen /usr/local/bin/smart_svn_add /usr/local/bin/smart_svn_del_missing
sudo rm -rf /usr/local/share/xcodegen
