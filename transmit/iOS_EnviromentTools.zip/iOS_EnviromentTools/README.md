# 脚本说明

该脚本主要实现助手开发环境的统一，脚本会完成：
1. cocoapods安装
2. 私有pods参考索引添加并统一spec的名称
3. 安装xcodegen
4. 拷贝smart_svn_add、smart_svn_del_missing两个工具到/usr/local/bin下，方便操作svn（经常出现大量新增文件，使用smart_svn_add可以快速将新增文件添加到svn）

# 安装方法

切换到项目目录并执行：

```
./install.sh
```



