#!/bin/sh

chmod 777 bible_install_pods.sh
sudo sh bible_install_pods.sh

pod repo add bible_specs http://git.code.oa.com/bible_team/iOS_Specs.git

chmod 777 xcodegen/install.sh
sudo xcodegen/install.sh 

chmod 777 install_commands.sh
sudo sh install_commands.sh

