#!/bin/sh

#移除Pod组件目录/Users/username/.cocoapods/repos
#sudo rm -rf ~/.cocoapods/repos/master
#移除Cocoapods程序包
for i in $( gem list --local --no-version | grep cocoapods );
do
    sudo gem uninstall $i;
done

echo "========== GEM LIST =========="
sudo gem list --local | grep cocoapods

#安装cocoapods，统一1.2.0
#sudo gem install cocoapods -v 1.2.0
# sudo gem install --http-proxy https://dev-proxy.oa.com:8080 cocoapods -v 1.5.3
sudo gem install --http-proxy https://web-proxy.oa.com:8080 --source http://rubygems.org cocoapods -v 1.6.1 -n /usr/local/bin
# 
#安装svn插件
#sudo gem install cocoapods-repo-svn
# sudo gem install --http-proxy https://dev-proxy.oa.com:8080 cocoapods-repo-svn

