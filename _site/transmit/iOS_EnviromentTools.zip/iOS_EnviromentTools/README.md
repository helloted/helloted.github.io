# 脚本说明

该脚本主要实现助手开发环境的统一，脚本会完成：
1. cocoapods安装
2. 私有pods参考索引添加并统一spec的名称
3. 安装xcodegen
4. 拷贝smart_svn_add、smart_svn_del_missing两个工具到/usr/local/bin下，方便操作svn（经常出现大量新增文件，使用smart_svn_add可以快速将新增文件添加到svn）

# 安装方法

切换到项目目录并执行：

```
./install.sh
```



## 脚本使用说明

### 1. bible_gen_project_file

该命令主要用于在修改了project.yml需要重新生成工程文件时使用，命令会先执行`xcode genernate`更新工程文件，然后再执行`bible_pod_install`更新pod相关内容。

### 2. bible_pod_install

该命令会在执行pod install之前主动更新一次我们私有仓库的pods索引http://git.code.oa.com/bible_team/iOS_Specs.git

### 3. bible_pod_publish

该命令主要用于我们pods组件的发布，命令会直接读取podspec的配置并发布到http://git.code.oa.com/bible_team/iOS_Specs.git

### 4. bible_pod_lint

该命令主要用于pods组件发布前的校验，相当于预发布，如果校验成功后执行bible_pod_publish也会成功，这样可以避免由于执行bible_pod_publish失败后导致打了过多无用的tag及增加了很多无用的提交记录。

### 5. bible_pod_force_publish

该命令主要用于某些时候发布校验会不通过，而此时解决校验不通过的成本又过大，但是实际运行中并不会出错，此时我们可以使用这个命令来绕过校验而直接往 http://git.code.oa.com/bible_team/iOS_Specs.git 上添加索引文件， **如果不是特殊情况请不要使用此命令，还是需要解决校验失败的问题。**

## 工具更新

我们的命令可能偶尔会去更新，更新后我们只需要更新http://git.code.oa.com/bible_team/iOS_EnviromentTools.git 代码，然后执行目录下的install_commands.sh即可。