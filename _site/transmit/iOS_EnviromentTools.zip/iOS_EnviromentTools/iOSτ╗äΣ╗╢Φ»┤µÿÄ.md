# 组件及模块的开发调试

hugozhong 创建于2019-02-20 , 

编辑  

目前助手工程里已经部分实现了模块化开发，模块化主要通过pod来实现，由于模块需要发布出去提供给多个工程使用，所以开发模式相较于以前有较大的不同，这里先通过下图介绍下模块化后的关系图

![图片描述](http://tapd.oa.com/tfl/captures/2019-02/tapd_20383062_base64_1550658872_94.png)

其中模块化的代码已经从我们的助手工程中抽取出来并放到了git上，每个模块都有一个自己对应的仓库，下面介绍下模块化后的开发调试方法：

## 环境要求

下面的步骤要求我们先安装一些命令行工具，http://tapd.oa.com/gamehelper_client_doc/markdown_wikis/view/#1020383062008522579 ，之前已经安装过的请重新更新代码并执行install_commands.sh脚本。

## 新建模块

新建模块参考 http://tapd.oa.com/gamehelper_client_doc/markdown_wikis/#1020383062008522553

## 已有组件（模块）代码修改

目前所有的组件代码都放在了[BibleTeam](https://git.code.oa.com/groups/bible_team) 及 [GameHelperTeam](https://git.code.oa.com/groups/GameHelperTeam)下，前者是跟业务无关的组件，后者是业务相关的组件及模块。

### 1.找到模块代码

可以在https://git.code.oa.com/dashboard/projects下进行搜索，如需要找Biz.Moment的代码，则在输入框中搜索Biz.Moment

![图片描述](http://tapd.oa.com/tfl/captures/2019-02/tapd_20383062_base64_1550658587_1.png)

其中下面的Biz.Moment.Protocol是该模块对外提供的接口（相关protocol文件，用于模块间调用）

### 2.clone代码到本地

点击进入上面步骤找到的模块，并将里面的git url拷贝下来，以Biz.Moment为例，如下图：

![图片描述](http://tapd.oa.com/tfl/captures/2019-02/tapd_20383062_base64_1550658597_57.png)

这里的url是http://git.code.oa.com/GameHelperTeam/Biz.Moment.git ，在命令行切换到模块需要存放的文件夹，如 /iPhone/workspace/GameHelperModules，接着执行

```
git clone http://git.code.oa.com/GameHelperTeam/Biz.Moment.git
```

### 3.拉取分支

如果是业务模块（尤其是Biz.Moment、Biz.Chat及Biz.ModuleProtocols）新版本开发的话建议拉取分支开发，一是可以减少组件发布的次数从而提升效率，二是尽量减少对其他项目的影响（开发中未测试的代码提交到了主干），但是如果你需要修改一些基础组件库并且能够保证接口的兼容性也可以不拉分支修改。

这里以Biz.Moment为例，命令行切换到Biz.Moment代码所在目录，执行如下命令：

```
    git checkout -b cf3.2
```

其中cf3.2是分支名称，当然你也可以通过命令指定拉取分支的节点或者从git.code.oa.com上拉取分支。

## 组件调试

上面我们已经将模块的代码clone到了本地，但是代码修改及调试并不是很方便，我们需要通过一些脚本及配置将刚才检出代码跟我们需要开发的工程关联上，如上面的Biz.Moment，原来我们的工程里关联的是远程的Biz.Moment pods库，现在我们通过脚本及配置将其更改为指向我们上面clone下来的代码的本地pods库，这样就能直接在我们原来的工程里修改代码并调试了，pods库调试的原理可以参考下图：

![图片描述](http://tapd.oa.com/tfl/captures/2019-02/tapd_20383062_base64_1550658614_15.png)

以上为远程pods关联的方式，即pods里的代码为通过pods索引关联到了git上的代码（最后也是下载到了本地）。

![图片描述](http://tapd.oa.com/tfl/captures/2019-02/tapd_20383062_base64_1550658630_44.png)

而打开调试后则将组件改为了执行本地的代码。

具体需要执行哪些脚本及修改哪些配置可以根据如下步骤来进行：

### 1.全局pod_options文件说明

pod_options是控制本地调试的一个配置文件，该文件存放于HOME/.bible/ios下，其中HOME为mac里当前用户的目录（如/Users/hugozhong/.bible/ios），具体配置内容如下：

```
{    "workspace_dirs" => {        "bible_components" => "/iphone/workspace/BibleComponents",        "gamehelper_modules" => "/iphone/workspace/GameHelperModules"    },    "mapping" => {        "Legom" => "{bible_components}/iOS_Legom"    }}
```

##### 1.1 workspace_dirs

workspace_dirs即我们的工作空间目录，这里分了两个工作空间：

- 

  bible_components

  业务无关的即[BibleTeam](https://git.code.oa.com/groups/bible_team) 下相关的组件在本地的工作空间目录，这个目录并不是具体某个组件的目录，而是一组组件的父目录，如下图：

  

![图片描述](http://tapd.oa.com/tfl/captures/2019-02/tapd_20383062_base64_1550665092_39.png)

- 

  gamehelper_modules

  另外一个是业务相关的即[GameHelperTeam](https://git.code.oa.com/groups/GameHelperTeam)下面相关的组件及模块在本地的工作空间目录，同上这里是一组模块的父目录

  

当然这两个目录完全可以一样，这样两个值配置成一样即可。

##### 1.2 mapping

pod install时之所以能够关联本地代码，主要是通过读取workspace_dirs的路径来查找的，查找的依据是Podfile里声明的组件名称，如Biz.Moment，声明时是

```
pod Biz.Moment
```

那此时就会去两个目录查找名为Biz.Moment的目录，但是有些情况我们目录下的名称跟pod声明的名称是不一致的，例如上面配置中的Legom，我们声明的时候是

```
pod Legom
```

但是我们git上面的名称是iOS_Legom，clone出来默认目录名称也是iOS_Legom，此时如果想关联上这个组件就需要在mapping里进行配置了，其中key即为前面提到的pod里声明的名称，value即本地的绝对路径，为了方便维护我们增加了两个自定义变量{bible_components}及{gamehelper_modules}，这两个变量会自动替换为workspace_dirs里设置的对应的路径。

*实际上我们在Podfile里已经针对iOS开头的组件做了特殊处理，比如如果找不到Legom，会额外增加iOS前缀再查找一次，如果是其他不匹配的情况则必须在mapping里配置*

### 2.工程pod_options文件说明

工程pod_options目录主要是用来控制当前工程是否开启调试的一个配置，具体配置内容如下：

```
{    "enable_local_debug" => false,    "foo" => "foo"}
```

其中enable_local_debug为控制是否可以本地调试的开关，在执行pod install的时候会去读取这个配置决定是否将远程pods库改为指向本地代码的本地pods库

### 3.创建全局pod_options文件

全局pod_options可以通过如下两种方式来创建：

##### 3.1 命令行创建

如果bible_components及gamehelper_modules两个路径是一致的可以执行如下命令：

```
bible_pod_debug createPodOption /iphone/workspace/GameHelperModules
```

如果不一致可以通过--components_dir及--modules_dir来分别指定

```
bible_pod_debug createPodOption --components_dir /iphone/workspace/BibleComponents --modules_dir /iphone/workspace/GameHelperModules
```

##### 3.2 手动创建

也可以自己手工在HOME/.bible/ios目录（其中HOME为mac里当前用户的目录，如/Users/hugozhong/.bible/ios）下创建pod_options文件，并填入如下内容

```
{    "workspace_dirs" => {        "bible_components" => "/iphone/workspace/BibleComponents",        "gamehelper_modules" => "/iphone/workspace/GameHelperModules"    },    "enable_local_debug" => false,    "mapping" => {    }}
```

其中bible_components、gamehelper_modules需要修改为自己的路径

### 4.创建工程pod_options文件

工程pod_options文件并不需要自己手动创建，在执行bible_pod_start_debug、bible_pod_stop_debug、bible_pod_is_debug命令时会自动创建

### 5.修改Podfile

针对那些需要本地调试的组件我们需要将Podfile里的声明改为include_components，例如原来的Biz.Moment的依赖声明为

```
pod Biz.Moment
```

我们需要改为

```
include_components 'Biz.Moment' , '2.0.14', git:'http://git.code.oa.com/GameHelperTeam/Biz.Moment.git',branch:'cf3.2'
```

这里的branch也可以改为tag，这样对应的'cf3.2'也需要改为对应tag的名称，如果我们不需要拉取分支开发或者分支开发完合入主干后则可以去掉git相关的参数，如：

```
include_components 'Biz.Moment'
```

此修改主要是让pod在执行pod install的时候去读取我们的pod_options里的配置，根据debug开关及设置的workspace路径来将远程pods库改为指向本地代码的本地pods库。

无论是否需要调试都可以通过include_components来进行声明，所以在不本地调试的情况下这里无需还原，一个模块的调试也只需第一次进行修改即可。

### 6.打开调试开关

我们只需要在工程根目录下执行如下命令：

```
bible_pod_start_debug
```

该命令会自动帮我们打开pod_options里的调试开关，并执行一次pod install，执行完成后就可以看到我们的模块会从Pods目录编导Develpoment Pods目录了，接下来就可以开始开发调试了。

![图片描述](http://tapd.oa.com/tfl/captures/2019-02/tapd_20383062_base64_1550665801_77.png)

如上图，确保需要调试的组件已经在Develpoment Pods目录下才算真正的开启调试了。

### 7.组件代码提交

在组件开发调试完成后，可以将clone出来的组件代码进行提交，具体的提交命令可以自行参考git相关命令，或者下载SoureTree进行提交。

### 8.结束调试

由于我们调试是将远程pods库改为了执行本地的代码的本地pods，这样工程里的相关pod配置也改为了指向本地，如果此时提交代码，其他开发者进行 pod install时会出错，所以我们需要将在代码提交之前还原为远程pods的配置，执行如下命令即可：

```
bible_pod_stop_debug
```

### 9.提交工程代码

此时将工程里的相关修改以及Pod下的相关代码提交到svn即可。

注意：提交工程代码前必须调用bible_pod_stop_debug，如果不确定当前是否关闭了调试可以通过bible_pod_is_debug命令来判断，如果输出的值为false则是关闭状态。

![图片描述](http://tapd.oa.com/tfl/captures/2019-03/tapd_20383062_base64_1552983845_13.png)

## 组件发布

组件开发完并且版本发布后将版本代码（svn代码，如cf代码、大通版代码、dnf版本代码等）合入主干时需要对牵涉到的pod模块进行发布，具体步骤如下：

### 1.提交组件代码（分支代码合入master）

调试没问题后需要将本地修改的组件代码，如Biz.Moment的代码commit并push到远程git仓库，如果拉取了分支开发还需要将代码合入到master分支。

### 2.执行发布命令

虽然我们本地调试没问题了，但是我们本地调试时关联的是我们本地的代码，最终我们要做的是将组件关联到远程的组件代码，上面我们已经将代码提交了，接下来我们需要做的就是：

- 

  在远程用最新代码打一个新版本的tag

  

- 

  组件（如Biz.Moment）的podspec里版本号进行升级并执行pod repo push命令往私有仓库索引里添加索引并关联刚才新建的tag

  

以上步骤我们封装了脚本来自动完成，命令行切换到组件根目录，然后根据下面不同类型执行不同的命令

- 

  发布开发中版本

  

如果我们是正在开发中还没测试完毕，则通过此种方式进行发布alpha版本，可以执行如下命令

```
bible_pod_publish
```

或者

```
bible_pod_publish alpha
```

发布后对应的版本号会变成4段式，如1.2.5.alpha1，再次发布会变为1.2.5.alpha2，以此类推。

*开发中的版本也需要进行发布的原因是我们的代码虽然提交到了git，但是我们仓库里最新的索引还是老版本，所以需要往索引那更新新的版本cocoapod才能关联上*

- 

  发布正式版本

  

如果测试完毕没问题后，则可以根据如下情况进行发布：

- 

  修改大版本号发布

  

如果版本有较大改动需要升级大版本号可以使用如下命令进行发布：

```
bible_pod_publish main
```

或者

```
bible_pod_publish mainVersionRelease
```

正式版本的版本号为3段式，假设之前的版本号为1.2.5，发布后版本号会改为2.0.0，再次发布则改为3.0.0，以此类推。

- 

  修改特性版本号发布

  

如果版本有新特性修改需要升级特性版本号则可以使用如下命令进行发布：

```
bible_pod_publish feature
```

或者

```
bible_pod_publish featureVersionRelease
```

或者

```
bible_pod_publish featureRelease
```

假设之前的版本号为1.2.5，发布后版本号为1.3.0，再次发布改为1.4.0，以此类推。

- 

  修改补丁版本号发布

  

如果版本有bug或者小细节修改需要升级补丁版本号可以使用如下命令进行发布：

```
bible_pod_publish release
```

或者

```
bible_pod_publish patch
```

或者

```
bible_pod_publish patchRelease
```

或者

```
bible_pod_publish patchVersionRelease
```

假设之前的版本号为1.2.5，发布后版本号为1.2.6，再次发布则改为1.2.7，以此类推。

- 

  手工指定版本号

  某些情况下如果希望自己指定版本号则可以先自己修改podspec文件里的版本号，然后执行如下命令

  ```
  bible_pod_publish custom
  ```

  该命令不会去修改版本号，以podspec里的版本号为准

  

## 总结

总的来讲我们的开发流程如下图：

![图片描述](http://tapd.oa.com/tfl/captures/2019-03/tapd_20383062_base64_1552984592_57.png)

相较于模块化之前增加了

- 

  打开调试开关

  

- 

  模块化代码提交

  

- 

  关闭调试开关

  

- 

  模块发布

  

如果同时修改了多个模块则需要对多个模块进行代码提交及发布，然后再关闭调试开关并提交代码。

### 常见问题

##### 1. Xcode 10.2 发布失败

ERROR | [iOS] unknown: Encountered an unknown error (Could not find a `ios` simulator (valid values: com.apple.coresimulator.simruntime.ios-10-2, com.apple.coresimulator.simruntime.ios-12-2, com.apple.coresimulator.simruntime.ios-8-2, com.apple.coresimulator.simruntime.tvos-12-2, com.apple.coresimulator.simruntime.watchos-5-2). Ensure that Xcode -> Window -> Devices has at least one `ios` simulator listed or otherwise add one.

![图片描述](http://tapd.oa.com/tfl/captures/2019-05/tapd_20383062_base64_1558600680_41.png)

解决办法是升级cocoapods版本到1.6即可解决问题