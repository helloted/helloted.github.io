chmod 777 bible_pod_install
sudo cp bible_pod_install  /usr/local/bin

chmod 777 bible_gen_project_file
sudo cp bible_gen_project_file  /usr/local/bin

chmod 777 bible_pod_publish
sudo cp bible_pod_publish  /usr/local/bin

chmod 777 bible_pod_force_publish
sudo cp bible_pod_force_publish  /usr/local/bin

chmod 777 bible_pod_lint
sudo cp bible_pod_lint  /usr/local/bin

chmod 777 bible_pod_debug
sudo cp bible_pod_debug  /usr/local/bin

chmod 777 bible_pod_start_debug
sudo cp bible_pod_start_debug  /usr/local/bin

chmod 777 bible_pod_stop_debug
sudo cp bible_pod_stop_debug  /usr/local/bin

chmod 777 bible_pod_is_debug
sudo cp bible_pod_is_debug  /usr/local/bin

chmod 777 smart_svn_add
sudo cp smart_svn_add /usr/local/bin

chmod 777 smart_svn_del_missing
sudo cp smart_svn_del_missing  /usr/local/bin