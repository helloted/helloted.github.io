# 新建工程

### 1.相关appId申请

> \- 其中微信登录、信鸽、qq开放平台、腾讯视频appkey全部由产品/运营负责申请
>
> - 
>
>   开发负责申请rdm、mta、bugly
>
>   _bugly申请完后需要把以下qq加为管理员：47399938;913307780;1736926700;20174244;2471014000;2743203436;314078428;43740763;977937974;1225442192;223344918;337240552;540179965;1164044025;2753684;752777228;171647185;22399032;272782174;342604051;22178549;279706358；332797707；
>
>   
>
> - 
>
>   rdm申请步骤及证书申请
>
>   

### 2.需要准备的视觉素材

| 素材                      | 尺寸                                                         | 格式要求  | 命名规则                        |
| :------------------------ | :----------------------------------------------------------- | :-------- | :------------------------------ |
| app图标                   | 58x58、120x120、180x180、1024x1024（1024图不能带alpha通道,否则不能过审） | png       | 无                              |
| 分享图标                  | 200x200                                                      | png       | 游戏简写英文_app_share.png      |
| 接受用户协议用到的app图标 | 180x180                                                      | png       | app_logo_游戏id@2x.png          |
| 启动图                    | 640x1136、750x1334、1242x2208、1125x2436                     | png( <1M) | 无                              |
| 闪屏                      | 1125x2436                                                    | 无        | splash_screen_游戏简写英文.(jpg |
| 导航栏背景                | 720x128                                                      | png       | navigation_bg@2x.png            |
| 侧边栏背景                | 616x1334                                                     | png       | leftview_bg@2x.png              |
| 无数据提示图              | 300x300                                                      | png       | empty_image@2x.png              |
| 新版个人中心头图          | 750x391                                                      | png       | userHeaderBg@2x.png             |

*以下步骤统一使用gameId表示游戏id、gameName表示游戏英文名称缩写*

### 3.创建图标及启动页

在项目的Images.xcassets里新建{gameName}AppIcon、LaunchImage_{gameName}分别把appIcon及启动图放置进去

### 4.增加配置目录

在config下新建一个对应的游戏英文缩写目录

### 5.新增Info.plist文件

拷贝其他app的Info.plist到config/{gameName}下，并改名为{gameName}-Info.plist

### 6.新增entitlements文件

- 

  拷贝其他app的entitlements文件到config/{gameName}下，并改名为{gameName}.entitlements

  

- 

  打开{gameName}.entitlements，将aps-environment修改为gamehelper{gameName}

  

### 7.新增xcconfig文件

- 

  拷贝其他app的三个xcconfig到config/{gameName}下，并分别改名为{gameName}_base.xcconfig、{gameName}_debug.xcconfig、{gameName}_release.xcconfig

  

- 

  修改{gameName}_base.xcconfig

  该文件为不管debug还是release都要用到的配置，打开文件：

  

```
    * 修改INFOPLIST_FILE为config/{gameName}/{gameName}-Info.plist，该配置用于指定Info.plist文件路径    
    * 修改PRODUCT_BUNDLE_IDENTIFIER为com.tencent.gamehelper.{gameName}，该配置用于指定app的bundle id
    * 修改ASSETCATALOG_COMPILER_APPICON_NAME为{gameName}AppIcon，该配置用于指定src/GameApp/Main/Images.xcassets里为app配置的应用图标名称
    * 修改ASSETCATALOG_COMPILER_LAUNCHIMAGE_NAME为LaunchImage_{gameName}，该配置用于指定src/GameApp/Main/Images.xcassets里为app配置的启动图
```

- 

  修改{gameName}_debug.xcconfig

  该文件为debug时工程用到一些配置，打开文件：

  

```
    * 修改第一个include为#include "Pods/Target Support Files/Pods-{gameName}/Pods-{gameName}.debug.xcconfig"，因为pods也会生成一个xcconfig文件，而xcode里只能设置一个xcconfig，这就需要我们在这里把pod的include进来，否则pod install会失败
    * 修改第二个include为#include "{gameName}_base.xcconfig"
    * 修改GCC_PREPROCESSOR_DEFINITIONS配置，改配置主要是用于预编译的参数，如果工程不需要用到RN则可以加上DISABLE_RN=1，如设置为GCC_PREPROCESSOR_DEFINITIONS = $(inherited) DISABLE_RN=1，其中$(inherited)必须带上，当然如果没有什么特殊的设置也可以不配置，删掉即可
```

- 

  修改{gameName}_release.xcconfig

  该文件为release时工程用到的一些配置，打开文件：

  

```
    * 同上修改两个include及GCC_PREPROCESSOR_DEFINITIONS配置
    * 修改CODE_SIGN_ENTITLEMENTS为config/{gameName}/{gameName}.entitlements
    * 从rdm上找到发布证书栏下载对应的mobileprovision文件，如gamehelpercodol.mobileprovision，下载完后在mobileprovision目录执行如下命令：
    `security cms -D -i gamehelpercodol.mobileprovision `
    此时会输出一段xml描述，分别找到key为Name、TeamIdentifier、UUID的值，将其值分别在xcconfig里分别赋值给PROVISIONING_PROFILE_SPECIFIER、DEVELOPMENT_TEAM、PROVISIONING_PROFILE
```

![图片描述](http://tapd.oa.com/tfl/captures/2019-01/tapd_20383062_base64_1547814379_87.png)

### 8.创建定制化目录

在src/GameApp/Customization下新建{gameName}，后续针对改app的定制化代码都放在此处

### 9.增加xcodegen配置

编辑根目录的project.yml文件，在targets下新增{gameName}，并配置除公共代码以外需要包含的源码路径，同时指定对应的xcconfig，其中templates必须包含GameHelperTemplate，其他Template视情况自行添加，举例如下：

```
{gameName}:    configFiles:      Debug: config/{gameName}/{gameName}_debug.xcconfig      Release: config/{gameName}/{gameName}_release.xcconfig    templates: [GameHelperTemplate]    sources:      - path: src/GameApp/Resources/Bundle/{gameName}.bundle      - path: src/GameApp/Customization/{gameName}
```

### 10.增加Podfile配置

增加一个target的配置，同时指定下依赖的pods库，正常情况只需要添加

```
  shared_pods_for_all_targets  shared_pods_for_only_internal_targets
```

即可，如果使用到了rn增需要添加上`shared_pods_for_RN_targets`，同理如果有其他单独的依赖可以在里面加上，举例codol的配置如下：

```
target 'codol' do  shared_pods_for_all_targets  shared_pods_for_only_internal_targetsend
```

**注意：一般情况不要去拷贝common及gamehelper的配置，他们的配置依赖过多，新工程应该用不上**

### 11.生成工程文件

命令行切换到工程根目录执行如下两个命令：

```
bible_gen_project_file
```

或者

```
xcodegen generatepod install 
```

### 12.修改YYCustomConfig

打开GameHelper.xcworkspace，修改对应target里的Info->Custom iOS Target Properties->YYCustomConfig配置

> \- 修改mtaAppKey为mta申请的appKey，如果没有需要添加
>
> - 
>
>   修改buglyId为bugly申请到的appId，如果没有需要添加
>
>   
>
> - 
>
>   修改cGameId为后台分配的游戏id
>
>   

### 13.修改外部跳转的scheme配置

修改修改target里的Info->URL Types配置

> \- 修改quick_login为{gameName}gamehelper
>
> - 
>
>   修改weixinopenapi为微信申请的appId
>
>   
>
> - 
>
>   修改qqwallet为qw{qq开放平台申请的appId}
>
>   
>
> - 
>
>   修改tencent为tencent{qq开放平台申请的appId}
>
>   

### 14.修改游戏相关配置

- 

  在KnownGames.json里增加游戏的相关配置(注意修改时保证整个文件的json合法性，比如不要少逗号或多逗号)，例如：

  ```
      {     "id": 20005,     "stringId": "pubgm",      "name": "绝地求生手游社区"     }
  ```

  

*其中stringId代表当前游戏的英文名称缩写，这里的缩写跟上面的一些资源文件命名有关*

- 

  在BaseGame.h文件里定义一个当前游戏gameId的常量

  

### 15.创建Bundle

在工程里的Resource/Bundle目录下创建一个{gameName}.bundle的bundle文件，其中gameName是步骤11里定义的stringId，bundle的创建方法为New File -> iOS -> Resource -> Setting Bundle

> \- 在bundle里创建（或者从其他bundle中复制）color_theme.plist文件，该文件主要定义了项目中需要换肤的色值信息（如标题按钮之类的颜色）
>
> - 
>
>   在bundle里创建（或者从其他bundle中复制）value_theme.plist文件，该文件主要定义了一些项目配置的数值及部分功能的开关（如系统状态栏的颜色是否改为黑色等）
>
>   
>
> - 
>
>   拷贝资源文件到bundle里
>
>   

### 16.上传证书到云通信管理端

上传步骤可参考 ：

[http://code.oa.com/v2/svn/wiki/ied_pocket_rep/yoyo_ios_proj#%E4%B8%93%E7%89%88%E4%BB%8B%E7%BB%8D%E5%92%8C%E9%85%8D%E7%BD%AE%E7%BB%B4%E6%8A%A4](http://code.oa.com/v2/svn/wiki/ied_pocket_rep/yoyo_ios_proj#专版介绍和配置维护)

### 17.上传证书到信鸽管理端

上传步骤可参考 ：

[http://code.oa.com/v2/svn/wiki/ied_pocket_rep/yoyo_ios_proj#%E4%B8%93%E7%89%88%E4%BB%8B%E7%BB%8D%E5%92%8C%E9%85%8D%E7%BD%AE%E7%BB%B4%E6%8A%A4](http://code.oa.com/v2/svn/wiki/ied_pocket_rep/yoyo_ios_proj#专版介绍和配置维护)

### 18.修改Conifuration.json

将qqAppId、license url、tim_busiid(上传证书到云通信管理端后可获得)、xg_appId、腾讯视频appKey（debug可以不填）、quick_login_url_scheme（wtlogin 快速登录回调scheme）、wechat（微信的AppId）等加到Configuration.json文件

### 19.新建打包脚本

> \- 从build目录下拷贝一份build_pg.sh并修改脚本名称
>
> - 
>
>   修改PRODUCT_NAME，TARGET
>
>   
>
> - 
>
>   在build/rename_package.py文件添加到字典 global_app_name_dict
>
>   

### 20.创建rdm任务

> \- rdm上新建构建任务：
>
> 构建类型选Release Build
>
> 编译节点一般选ios_11.0（非IEG开头的）
>
> 脚本类型选shell
>
> 脚本填build/build_{gameName}.sh（为步骤19创建的文件）
>
> - 
>
>   上一步确认后重新选择任务进行编辑
>
>   在自定义参数里添加PUBLISH_FLAG=0（该参数主要控制打出来的包是否可以选环境，如果是打Release包则改为PUBLISH_FLAG=1）
>
>   在基本设置里勾上“企业证书重签”
>
>   

# 可选修改

### 1.修改slideTab（标题栏上的各个tab）选中的下标图

替换bundle里一个名为tabpager_bg_selected@2x.png的图即可

### 2.新版个人中心样式

修改个人中心样式为pg、pubgm、pubg类似的新样式

> \- 在UserViewController的isUsingNewProfileHeader方法里将新游戏的id加到gameIds数组
>
> - 
>
>   修改背景图(参考步骤2的素材名称并放到bndle里)
>
>   
>
> - 
>
>   修改昵称、底部各种数值的颜色（修改bundle里的color_theme.plist对应的user_header开头的相关值）
>
>   

### 3.修改进入到应用后状态栏改为黑色

在bundle里的value_theme.plist里增加statueBarBlack,设置类型为Boolean，值为YES

# 常见问题

### 1.分享失败的问题

> http://tapd.oa.com/10103691/bugtrace/bugs/view?bug_id=1010103691062424351
>
> http://tapd.oa.com/10103691/bugtrace/bugs/view?bug_id=1010103691062444063
>
> 找对应的运营（一般为dandanfang）确认开放平台上对应的ios是否已经申请了，同时确保是否已经获取了登录权限

### 2.合代码后数据库升级的sql未执行

> 检查下是否升级的sql文件没有加到对应的target里，导致没有打到包里去

### 3.证书出现问题，如下图：

![图片描述](http://tapd.oa.com/tfl/captures/2018-08/tapd_20383062_base64_1533721936_92.png)

> 找rdm人员（rdm小秘书）重新生成下证书，确保证书支持push
>
> 具体可以参考：
>
> https://doc.xuwenliang.com/docs/ios/1295
>
> http://www.cnblogs.com/BigFeng/p/6102102.html