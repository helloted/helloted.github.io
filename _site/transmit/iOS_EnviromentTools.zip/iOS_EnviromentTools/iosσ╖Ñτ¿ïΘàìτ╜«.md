# iOS工程配置说明

### 修改原因说明

- 

  工程文件冲突

  由于助手各个app代码都是复用的，为了实现一套代码产出多个app，之前助手的设计是通过target来实 现的，而xcode里每个target的配置都放在同一个工程文件里(GameApp.xcodeproj/project.pbxproj)，每增加一个公共的文件就要对所有target都增加至少一条配置，随着助手app的增多，工程文件已经达到了15w+行，每个分支的修改特别是一些优化跟新增app会导致后续合代码产生大量冲突，导致合代码浪费过多时间。

  

- 

  代码维护不便

  由于xcode每次新建文件都需要挨个去勾选这个文件需要包含在哪个target，经常我们开发的过程中会忽略其他target是否需要，可能会出现别的app不需要我们也添加上了，或者别的app需要我们又没有加上，经常出现的问题就是某个分支开发完合主干后，其他app就编译不过了（很多依赖的代码没有勾选上），仅仅是代码还比较容易解决，由于资源没有包含进去是不会报错的，往往会出现很多资源找不到在测试或者线上期间才发现。

  

### 新的方案

工程的配置采用了xcodegen工具来实现，原理为将所有的target相关的配置集中到project.yml中，通过路径+通配符等方式来描述所需要的代码及资源，工程相关的配置使用xcconfig来描述，这样后续工程文件有冲突的话通过配置重新生成工程文件即可，我们所需要的工作简化为修改工程配置文件的冲突，由于工程配置文件很小（目前只有200行），冲突的解决代价很小。

- 

  配置文件语法

  

请参考XcodeGen文档：https://github.com/yonaskolb/XcodeGen/blob/master/Docs/ProjectSpec.md

- 

  配置文件说明

  

配置文件将公共的配置都放到了名为GameHelperTemplate的模板中，每个app个性化的配置则放在了对应的target里，这里以绝地求生：刺激战场（pg）举例说明：

```
targets:
  pg:
    configFiles:
      Debug: config/pg/pg_debug.xcconfig
      Release: config/pg/pg_release.xcconfig
    templates: [GameHelperTemplate]
    sources:
      - path: src/GameApp/Resources/Bundle/pg.bundle
      - path: src/GameApp/Customization/CertainApps/BattleRoyale
        excludes:
          - "UserViewController/RoleCardViewController/Protocol/pb/*"
      - path: src/GameApp/Customization/CertainApps/BattleRoyale/UserViewController/RoleCardViewController/Protocol/pb
        compilerFlags:
          - "-fno-objc-arc"
      - path: src/GameApp/Features/Manager/RNManager
      - path: src/GameApp/Customization/pg
      - path: src/GameApp/Customization/CertainApps/GameMap
```

上述配置涉及到以下几点：

1.configFiles，即xcode的一些配置，如bundle identifier、证书、Info.plist、logo及启动图等一些配置，配置分为debug跟release两个配置，分别为pg_debug.xcconfig和pg_release.xcconfig，针对debug跟release公共的配置放在了pg_base.xcconfig并在debug跟release的配置中include进来，同样对于整个助手公共的配置也单独抽出了base.xcconfig、debug.xcconfig、release.xcconfig，关于xcconfig怎么填写可以参考文档末尾的常见问题。

2.templates，即使用名为GameHelperTemplate的模板，该模板包含了助手内公共代码及资源的配置（目前这些公共的代码还有很多是未解耦的，只是按原来的配置先迁移过来了）

3.sources，即代码及资源的相关配置，这里会增加pg自己的定制化代码及资源的配置，如加上pg.bundle，增加rn代码等

### 关于sdk的说明

如果仔细查看配置会发现GameHelperTemplate里并没有包含我们很多第三方的sdk，这是因为xcodegen暂时还不支持在dependencies里指定静态库的依赖，为了统一及方便版本号的管理，已经将所有第三方的静态库依赖改为了pods的依赖，如果sdk本身不支持pods则自己实现了pods，存放于import/sdk目录下。

***动态库可以不用改为pods库依赖，使用-framework来指定。***

### 目录结构调整说明

\* xcodeproj删除说明

之前工程文件及podfile都是放在xcodeproj下的，由于xcodegen配置如果不在根目录，或者路径使用了类似../src等相对路径时createIntermediateGroups参数会不起作用，导致整个工程下面显示的是各个目录的子目录（没有层级关系），显示的非常乱，所以讲工程文件及pods配置都改为放到了根目录

\* 工程结构目录调整

之前工程目录有部分地方并不跟实际文件路径一一对应，为了脚本的更好管理现在改为了跟实际目录一一对应了，**同时后续没用的代码必须物理删除掉，否则重新生成工程文件后可能又会包含进来**。

### 工程调整后的注意事项

- 

  无用代码及资源必须物理删除掉

  

目前代码及资源已经改为了通过目录来管理了，**不要再到xcode里去针对文件勾选是否包含到target**，如果有不用的代码跟资源必须物理删除掉

- 

  定制化代码需要放到src/GameApp/Customization对应目录下

  

- 

  工程的配置要通过修改project.yml或者xcconfig来实现，不要在xcode里直接修改（经测试，xcode里修改不会直接修改xccofing里的配置，而是记录在工程文件里，如果是Info.plist里的属性修改则会同时修改到Info.plist）

  

### 常见问题

- 

  xcconfig怎么填写？

  在xcode工程设置中修改完对应设置后再选中设置项，然后按command+c复制，如：

  

![图片描述](http://tapd.oa.com/tfl/captures/2019-01/tapd_20383062_base64_1548063347_56.png)

这里选中Preprocessor Macros复制后得到如下值：

```
//:configuration = DebugGCC_PREPROCESSOR_DEFINITIONS = $(inherited) COCOAPODS=1 APP_TARGET=22//:configuration = ReleaseGCC_PREPROCESSOR_DEFINITIONS = $(inherited) COCOAPODS=1 APP_TARGET=22//:completeSettings = someGCC_PREPROCESSOR_DEFINITIONS
```

将debug跟release的配置分别放到对应的xccofnig中即可。

- 

  证书配置怎么更新？

  

从rdm上找到发布证书栏下载对应的mobileprovision文件，如gamehelpercodol.mobileprovision，下载完后在mobileprovision目录执行如下命令：

```
security cms -D -i gamehelpercodol.mobileprovision
```

此时会输出一段xml描述，分别找到key为Name、TeamIdentifier、UUID的值，将其值分别在xcconfig里分别赋值给PROVISIONING_PROFILE_SPECIFIER、DEVELOPMENT_TEAM、PROVISIONING_PROFILE

![图片描述](http://tapd.oa.com/tfl/captures/2019-01/tapd_20383062_base64_1547814379_87.png)

- 

  怎么新建app？

  http://tapd.oa.com/gamehelper_client_doc/markdown_wikis/view/#1020383062008409733

  

- 

  'QMapKit/QMapKit.h' file not found

  

确认下import/sdk/QQMapSdk/Libs里的两个framework里面的Header是否是文件快捷方式，如果不是则有可能是在windows上操作过后导致出问题了，需要还原下，正确的framework应该如下：

![图片描述](http://tapd.oa.com/tfl/captures/2019-01/tapd_20383062_base64_1547814309_44.png)

错误截图如下：

![图片描述](http://tapd.oa.com/tfl/captures/2019-01/tapd_20383062_base64_1547814317_85.png)

- 

  pods-frameworks.sh:permission denied

  

![图片描述](http://tapd.oa.com/tfl/captures/2019-01/tapd_20383062_base64_1548049844_52.png)

这个问题主要是pods出现脏数据导致，删除Podfile.lock跟Pods文件夹，然后重新pod install即可