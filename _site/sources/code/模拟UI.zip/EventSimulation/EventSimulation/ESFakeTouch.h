//
//  ESFakeTouch.h
//  EventSimulation
//
//  Created by David.Dai on 2021/1/14.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ESFakeTouch : NSObject

/**
 模拟tap单击的UI事件行为
 
 @param point 坐标点
 */
+ (void)tapAtPoint:(CGPoint)point;

/**
 模拟长按的UI事件行为
 
 @param point 坐标点
 @param duration 按压时长
 */
+ (void)longPressAtPoint:(CGPoint)point duration:(NSTimeInterval)duration;

/**
 模拟长按的UI事件行为
 
 @param fromPoint  起始坐标点
 @param toPoint 结束坐标点
 */
+ (void)drag:(CGPoint)fromPoint toPoint:(CGPoint)toPoint;
@end

NS_ASSUME_NONNULL_END
