//
//  ViewController.m
//  EventSimulation
//
//  Created by David.Dai on 2021/1/14.
//

#import "ViewController.h"
#import "ESFakeTouch.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIButton *button;
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (weak, nonatomic) IBOutlet UIButton *longButton;
@property (weak, nonatomic) IBOutlet UIButton *uibutton;
@property (nonatomic, strong) NSTimer *timer;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.timer = [NSTimer scheduledTimerWithTimeInterval:1 repeats:YES block:^(NSTimer * _Nonnull timer) {
        [ESFakeTouch tapAtPoint:CGPointMake(100, 70)];
        [ESFakeTouch longPressAtPoint:CGPointMake(100, 150) duration:1.5];
        [ESFakeTouch drag:CGPointMake(100, 300) toPoint:CGPointMake(100, 1500)];
    }];
}

- (IBAction)actionButton:(UIButton *)sender {
    if (sender == self.button) {
        static NSInteger tapCount = 1;
        [self.button setTitle:[NSString stringWithFormat:@"单击次数:%ld", tapCount] forState:UIControlStateNormal];
        tapCount++;
    }
    
    if (sender == self.longButton) {
        static NSInteger longPressCount = 1;
        [sender setTitle:[NSString stringWithFormat:@"长按次数:%ld", longPressCount] forState:UIControlStateNormal];
        longPressCount++;
    }
    
    if (sender == self.uibutton) {
        static NSInteger uiPressCount = 1;
        [sender setTitle:[NSString stringWithFormat:@"自动化点击次数:%ld", uiPressCount] forState:UIControlStateNormal];
        uiPressCount++;
    }
}

@end
