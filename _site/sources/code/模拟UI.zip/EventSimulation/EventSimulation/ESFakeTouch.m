//
//  ESFakeTouch.m
//  EventSimulation
//
//  Created by David.Dai on 2021/1/14.
//

#import "ESFakeTouch.h"
#import "UIEvent+KIFAdditions.h"
#import "UITouch-KIFAdditions.h"
#import "UIApplication-KIFAdditions.h"

@interface ESFakeTouch()

@end

@implementation ESFakeTouch

+ (void)tapAtPoint:(CGPoint)point {
    UIWindow *topWindow = [[UIApplication sharedApplication].windows lastObject];
    
    // 定位触摸点位置并声明一个点击事件
    UITouch *touch = [[UITouch alloc] initAtPoint:point inWindow:topWindow];
    UIEvent *event = [self eventWithTouch:touch];

    // 发送事件：这个触摸下去
    [touch setLocationInWindow:point];
    [touch setPhaseAndUpdateTimestamp:UITouchPhaseBegan];
    [[UIApplication sharedApplication] sendEvent:event];
    
    // 发送事件：这个触摸离开
    [touch setPhaseAndUpdateTimestamp:UITouchPhaseEnded];
    [[UIApplication sharedApplication] sendEvent:event];
}

#define DRAG_TOUCH_DELAY 0.01
+ (void)longPressAtPoint:(CGPoint)point duration:(NSTimeInterval)duration {
    UIWindow *topWindow = [[UIApplication sharedApplication].windows lastObject];
    
    UITouch *touch = [[UITouch alloc] initAtPoint:point inWindow:topWindow];
    [touch setPhaseAndUpdateTimestamp:UITouchPhaseBegan];
    
    // 发送事件：这个触摸下去
    UIEvent *eventDown = [self eventWithTouch:touch];
    [[UIApplication sharedApplication] sendEvent:eventDown];
    
    // 发送事件：这个触摸保持状态
    CFRunLoopRunInMode(kCFRunLoopDefaultMode, DRAG_TOUCH_DELAY, false);
    for (NSTimeInterval timeSpent = DRAG_TOUCH_DELAY; timeSpent < duration; timeSpent += DRAG_TOUCH_DELAY) {
        [touch setPhaseAndUpdateTimestamp:UITouchPhaseStationary];
        UIEvent *eventStillDown = [self eventWithTouch:touch];
        [[UIApplication sharedApplication] sendEvent:eventStillDown];
        CFRunLoopRunInMode(kCFRunLoopDefaultMode, DRAG_TOUCH_DELAY, false);
    }
    
    // 发送事件：这个触摸离开
    [touch setPhaseAndUpdateTimestamp:UITouchPhaseEnded];
    UIEvent *eventUp = [self eventWithTouch:touch];
    [[UIApplication sharedApplication] sendEvent:eventUp];
}

+ (void)drag:(CGPoint)fromPoint toPoint:(CGPoint)toPoint {
    UIWindow *topWindow = [[UIApplication sharedApplication].windows lastObject];
    
    UITouch *touch = [[UITouch alloc] initAtPoint:fromPoint inWindow:topWindow];
    [touch setPhaseAndUpdateTimestamp:UITouchPhaseBegan];
    
    // 发送事件：这个触摸下去
    UIEvent *eventDown = [self eventWithTouch:touch];
    [[UIApplication sharedApplication] sendEvent:eventDown];
    
    // 发送事件：这个触摸位移
    [touch setLocationInWindow:toPoint];
    [touch setPhaseAndUpdateTimestamp:UITouchPhaseMoved];
    UIEvent *eventMove = [self eventWithTouch:touch];
    [[UIApplication sharedApplication] sendEvent:eventMove];
    
    // 发送事件：这个触摸离开
    [touch setPhaseAndUpdateTimestamp:UITouchPhaseEnded];
    UIEvent *eventUp = [self eventWithTouch:touch];
    [[UIApplication sharedApplication] sendEvent:eventUp];
}

#pragma mark -
+ (UIEvent *)eventWithTouch:(UITouch *)touch {
    NSArray *touches = touch ? @[touch] : nil;
    return [self eventWithTouches:touches];
}

+ (UIEvent *)eventWithTouches:(NSArray *)touches {
    UIEvent *event = [[UIApplication sharedApplication] _touchesEvent];
    [event _clearTouches];
    [event kif_setEventWithTouches:touches];
    for (UITouch *aTouch in touches) {
        [event _addTouch:aTouch forDelayedDelivery:NO];
    }

    return event;
}
@end
