//
//  SceneDelegate.h
//  EventSimulation
//
//  Created by David.Dai on 2021/1/14.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

