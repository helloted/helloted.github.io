//
//  EventSimulationUITests.m
//  EventSimulationUITests
//
//  Created by David.Dai on 2021/1/14.
//

#import <XCTest/XCTest.h>

@interface EventSimulationUITests : XCTestCase

@end

@implementation EventSimulationUITests

- (void)setUp {
    self.continueAfterFailure = NO;
}

- (void)tearDown {
    
}

- (void)testExample {
    XCUIApplication *app = [[XCUIApplication alloc] init];
    [app launch];
    [app.buttons[@"自动化测试按钮"] tap];
}

@end
