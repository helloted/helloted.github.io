# 参与CocoaHotReload的建设

### issues
通过issues为我们提供发现的问题和相关需求。

在提出issues前，可以参考已有issues，是否已有相同问题得到了解决。

关于所提交的问题尽量提供详尽的信息和发生场景等，以方便定位问题。

### Merge Request
欢迎各位同学发来MR，共同完善组件。

组件所包含的代码位于CocoaHotReload目录下，新添加的文件，请确保CocoaHotReload.podspec做了同步的修改。

也可以通过CocoaHotReload-macOS.xcodeproj示例工程进行测试和修改。

### License
通过为CocoaHotReload提供代码，代表您已同意其版权贵QQ支付团队我所有，其开源协议为[MIT](./LICENSE)。
