//
//  SceneDelegate.h
//  CocoaHotReloadExample-cmdTool
//
//  Created by mambaxie on 2020/7/29.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

