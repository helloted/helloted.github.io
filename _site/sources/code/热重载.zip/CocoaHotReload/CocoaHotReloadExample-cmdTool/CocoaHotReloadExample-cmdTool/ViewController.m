//
//  ViewController.m
//  CocoaHotReloadExample-cmdTool
//
//  Created by mambaxie on 2020/7/29.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = UIColor.greenColor;
}


@end
