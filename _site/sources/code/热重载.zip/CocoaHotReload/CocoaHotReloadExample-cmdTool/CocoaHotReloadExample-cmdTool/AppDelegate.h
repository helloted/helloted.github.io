//
//  AppDelegate.h
//  CocoaHotReloadExample-cmdTool
//
//  Created by mambaxie on 2020/7/29.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

