//
//  AppDelegate.m
//  CocoaHotReloadExample-cmdTool
//
//  Created by mambaxie on 2020/7/29.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import "AppDelegate.h"
#if DEBUG
#import <CocoaHotReload/CocoaHotReload.h>
#endif
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
#if DEBUG
    // 通过cmd产物文件夹进行热重载，只支持模拟器！！！
    // 1. 选择CocoaHotReload.xcodeproj，选择CocoaHotReload-cmdTool，然后Command+B编译
    // 2. 填写cmdProductsDir路径，Command+B编译本工程
    // 3. 修改ViewController.m文件夹
    // 4. 编译成功后打开命令行终端，根据命令指引输入如下命令
    // 命令指引： -p 工程路径 -e 可执行文件名字 -f 修改的文件路径 -o 产物输出文件夹路径
    // cocoahotreload -p /Users/mambaxie/Desktop/UnitTestDemo/UnitTestDemo.xcworkspace -e UnitTestDemo -f /Users/mambaxie/Documents/Git/CocoaHotReload/CocoaHotReloadExample-cmdTool/CocoaHotReloadExample-cmdTool/ViewController.m -o /Users/mambaxie/Documents/Git/CocoaHotReload/CocoaHotReloadExample-cmdTool/cmdProducts
    // 5. 选择Product->Perform Action->Run Without Building
    // 6. 程序运行后，检查热重载生效
    NSString *cmdProductsDir = @"Users/mambaxie/Documents/Git/CocoaHotReload/CocoaHotReloadExample-cmdTool/cmdProducts"; // 这里填写-o 参数路径
    [CocoaHotReload hotReloadWithDirectory:cmdProductsDir];
#endif
    // Override point for customization after application launch.
    return YES;
}


#pragma mark - UISceneSession lifecycle


- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
    // Called when a new scene session is being created.
    // Use this method to select a configuration to create the new scene with.
    return [[UISceneConfiguration alloc] initWithName:@"Default Configuration" sessionRole:connectingSceneSession.role];
}


- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
    // Called when the user discards a scene session.
    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
}


@end
