//
//  ViewController.m
//  RaftSample
//
//  Created by Goyoungs on 2020/9/27.
//

#import "ViewController.h"
#import "CocoaHotReload.h"

@interface ViewController ()
@property(nonatomic,strong) UILabel *connectLabel;
@property(nonatomic,strong) UILabel *addressLabel;
@property(nonatomic,strong) UILabel *tipLabel;

@property(nonatomic,strong) NSTimer *repeatTimer;
@end

@implementation ViewController

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _connectLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _connectLabel.font = [UIFont boldSystemFontOfSize:18];
    _connectLabel.textColor = UIColor.blackColor;
    [self.view addSubview:_connectLabel];
    
    _addressLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 0)];
    _addressLabel.numberOfLines = 0;
    _addressLabel.attributedText = [self getTitleAttributeStr:@"组件地址：https://git.code.oa.com/QQWallet-OpenSource-iOS/CocoaHotReload"];
    [_addressLabel sizeToFit];
    [self.view addSubview:_addressLabel];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(clickAddress)];
    _addressLabel.userInteractionEnabled = YES;
    [_addressLabel addGestureRecognizer:tap];
    
    _tipLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 0)];
    [self.view addSubview:_tipLabel];
    _tipLabel.numberOfLines = 0;
    _tipLabel.attributedText = [self getTitleAttributeStr:@"使用说明: \n 1、在podfile添加配置：pod 'CocoaHotReload', :git => 'http://git.code.oa.com/QQWallet-OpenSource-iOS/CocoaHotReloadExperience.git', :configurations => ['Debug'] \n 2、运行mac端工具, 选择iOS工程目录project文件 \n 3、iOS 工程添加  [CocoaHotReload run] 启动组件 \n 4、运行 iOS工程 \n 5、修改代码，点击mac工具热重载"];
     [self.tipLabel sizeToFit];
    
    CocoaHotReloadClientStatus status = [CocoaHotReload socketStatus];
    [self showConnectUI:status];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(recvConnectNotify:) name:kSocketConnectNotification object:nil];
}

- (void)recvConnectNotify:(NSNotification *)noti {
    NSDictionary *dict = noti.object;
    if (dict && [dict isKindOfClass:[NSDictionary class]]) {
        NSNumber *status = dict[@"status"];
       [self showConnectUI:(CocoaHotReloadClientStatus)[status intValue]];
    }
}

- (void)showConnectUI:(CocoaHotReloadClientStatus)status {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (status == CocoaHotReloadClientStatusDisConnect) {
            [self startTimer];
        }
        else {
            [self stopTimer];
            self.connectLabel.attributedText = [self getConnectAttributeStr:@"当前状态：连接mac端socket成功!" isConnect:YES];
        }
        [self updateLayout];
    });
}

- (void)startTimer {
    if (self.repeatTimer) {
        [self.repeatTimer invalidate];
        self.repeatTimer = nil;
    }
    self.repeatTimer = [NSTimer timerWithTimeInterval:1 target:self selector:@selector(repeatAction) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:self.repeatTimer forMode:NSRunLoopCommonModes];
    [self.repeatTimer fire];
}

- (void)stopTimer {
    if (self.repeatTimer) {
        [self.repeatTimer invalidate];
        self.repeatTimer = nil;
    }
}

- (void)repeatAction {
    dispatch_async(dispatch_get_main_queue(), ^{
        static int index = 0;
        index = index%4;
        NSString *suffix = [@"..." substringToIndex:index];
        suffix = [NSString stringWithFormat:@"当前状态：等待mac端socket连接%@",suffix];
        self.connectLabel.attributedText = [self getConnectAttributeStr:suffix isConnect:NO];
        [self updateLayout];
        index ++ ;
    });
}

- (void)updateLayout {
    [self.connectLabel sizeToFit];
    CGRect contentFrame = self.connectLabel.frame;
    contentFrame.origin.y = 100;
    self.connectLabel.frame = contentFrame;
    
    CGRect addressFrame = self.addressLabel.frame;
    addressFrame.origin.y = CGRectGetMaxY(self.connectLabel.frame) + 30;
    self.addressLabel.frame = addressFrame;
    
    CGRect frame = self.tipLabel.frame;
    frame.origin.y = CGRectGetMaxY(self.addressLabel.frame) + 30;
    self.tipLabel.frame = frame;
}

- (NSMutableAttributedString *)getConnectAttributeStr:(NSString *)str isConnect:(BOOL)isConnect {
    NSMutableAttributedString *attri = [[NSMutableAttributedString alloc] initWithString:str];
    [attri addAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:18],
                           NSForegroundColorAttributeName:isConnect ? [UIColor blueColor]:[UIColor redColor]}
                   range:NSMakeRange(5, str.length - 5)];
    
    [attri addAttributes:@{NSFontAttributeName: [UIFont boldSystemFontOfSize:18],
            NSForegroundColorAttributeName: [UIColor blackColor]}
    range:NSMakeRange(0, 5)];
    return attri;
}

- (NSMutableAttributedString *)getTitleAttributeStr:(NSString *)str {
    NSMutableAttributedString *attri = [[NSMutableAttributedString alloc] initWithString:str];
    [attri addAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:18],
                           NSForegroundColorAttributeName: [UIColor blackColor]}
                   range:NSMakeRange(5, str.length - 5)];
    
    [attri addAttributes:@{NSFontAttributeName: [UIFont boldSystemFontOfSize:18],
            NSForegroundColorAttributeName: [UIColor blackColor]}
    range:NSMakeRange(0, 5)];
    return attri;
}

- (void)clickAddress {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:@"https://git.code.oa.com/QQWallet-OpenSource-iOS/CocoaHotReload"]];

}

@end
