//
//  ViewController.m
//  CocoaHotReloadExample-MacCatalyst
//
//  Created by mambaxie on 2020/11/27.
//

#import "ViewController.h"
#import "CocoaHotReloadExample_MacCatalyst-Swift.h"
#import "ObjCViewController.h"
#import "StoryboardViewController.h"
#import "XibViewController.h"

@interface ViewController () <UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSArray<NSString *> *datas;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"CocoaHotReload";
    
    self.datas = @[@"ObjC file", @"Swift file", @"Storyboard file", @"Xib file"];
    
    _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    [self.view addSubview:_tableView];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.datas.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString * const kTableCellReusableIdentifier = @"kTableCellReusableIdentifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kTableCellReusableIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:kTableCellReusableIdentifier];
    }
    
    cell.textLabel.text = self.datas[indexPath.row];;
    
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    UIViewController *viewController;
    switch (indexPath.row) {
        case 0: // ObjC
        {
            viewController = [[ObjCViewController alloc] init];
            break;
        }
        case 1: // Swift
        {
            viewController = [[SwiftViewController alloc] init];
            break;
        }
        case 2: // Storyboard
        {
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:NSStringFromClass(StoryboardViewController.class) bundle:nil];
            viewController = [storyboard instantiateInitialViewController];
            break;
        }
        case 3: // Xib
        {
            viewController = [[XibViewController alloc] initWithNibName:NSStringFromClass(XibViewController.class) bundle:nil];
            break;
        }
            
        default:
            break;
    }
    
    if (viewController) {
        [self.navigationController pushViewController:viewController animated:YES];
    }
}



@end
