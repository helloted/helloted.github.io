//
//  XibViewController.m
//  CocoaHotReloadExample-MacCatalyst
//
//  Created by mambaxie on 2020/11/27.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "XibViewController.h"

@interface XibViewController ()

@end

@implementation XibViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"Xib file";
}

@end
