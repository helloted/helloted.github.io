//
//  SwiftViewController.swift
//  CocoaHotReloadExample-MacCatalyst
//
//  Created by mambaxie on 2020/11/27.
//

import UIKit

public class SwiftViewController: UIViewController {

    public override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Swift file"
        self.view.backgroundColor = .white
    }

    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        
        self.view.backgroundColor = .yellow
    }
    
}
