//
//  SceneDelegate.h
//  CocoaHotReloadExample-MacCatalyst
//
//  Created by mambaxie on 2020/11/27.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

