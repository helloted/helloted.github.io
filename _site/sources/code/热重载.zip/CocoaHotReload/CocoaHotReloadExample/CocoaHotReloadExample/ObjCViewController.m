//
//  ObjCViewController.m
//  CocoaHotReloadExample-CocoaPods
//
//  Created by mambaxie on 2020/8/3.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "ObjCViewController.h"

@interface ObjCViewController ()

@end

@implementation ObjCViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"ObjC file";
    self.view.backgroundColor = [UIColor whiteColor];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [super touchesBegan:touches withEvent:event];
    
    self.view.backgroundColor = [UIColor yellowColor];
}

@end
