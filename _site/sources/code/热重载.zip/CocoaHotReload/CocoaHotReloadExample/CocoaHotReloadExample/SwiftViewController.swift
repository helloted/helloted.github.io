//
//  SwiftViewController..swift
//  CocoaHotReloadExample-CocoaPods
//
//  Created by yuqingyuan on 2020/7/30.
//  Copyright © 2020 tencent. All rights reserved.
//

import UIKit

public class SwiftViewController: UIViewController {

    public override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Swift file"
        self.view.backgroundColor = .white
    }

    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        
        self.view.backgroundColor = .yellow
    }
    
}
