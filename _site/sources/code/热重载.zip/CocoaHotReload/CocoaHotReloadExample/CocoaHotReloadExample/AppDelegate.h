//
//  AppDelegate.h
//  CocoaHotReloadExample
//
//  Created by mambaxie on 2020/4/14.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;

@end

