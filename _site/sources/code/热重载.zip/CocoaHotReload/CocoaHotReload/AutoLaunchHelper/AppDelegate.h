//
//  AppDelegate.h
//  AutoLaunchHelper
//
//  Created by Goyoungs on 2020/7/10.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

