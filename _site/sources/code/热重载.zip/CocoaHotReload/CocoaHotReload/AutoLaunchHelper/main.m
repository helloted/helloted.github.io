//
//  main.m
//  AutoLaunchHelper
//
//  Created by Goyoungs on 2020/7/10.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // Setup code that might create autoreleased objects goes here.
    }
    return NSApplicationMain(argc, argv);
}
