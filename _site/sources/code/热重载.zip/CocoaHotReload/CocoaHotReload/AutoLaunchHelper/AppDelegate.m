//
//  AppDelegate.m
//  AutoLaunchHelper
//
//  Created by Goyoungs on 2020/7/10.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
    NSArray *applications = [NSWorkspace sharedWorkspace].runningApplications;
    for (NSRunningApplication *application in applications) {
        if ([application.bundleIdentifier isEqualToString:@"com.tencent.CocoaHotReload-macOS"]) {
            return;
        }
    }
    
    NSLog(@"applicationDidFinishLaunching 启动");
    NSArray *pathComponents = [[NSBundle mainBundle].bundlePath pathComponents];
    if(pathComponents.count >= 4) {
        pathComponents = [pathComponents subarrayWithRange:NSMakeRange(0, pathComponents.count - 4)];
        NSString *path = [NSString pathWithComponents:pathComponents];
        [[NSWorkspace sharedWorkspace] launchApplication:path];
    }
    [NSApp terminate:nil];
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}


@end
