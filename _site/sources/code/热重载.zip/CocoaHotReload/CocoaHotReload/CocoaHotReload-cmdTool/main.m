//
//  main.m
//  CocoaHotReload-cmdTool
//
//  Created by mambaxie on 2020/7/29.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CocoaHotReloadApplication.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
    }
    return [CocoaHotReloadApplication runWithAppName:@"Cocoa Hot Reload" version:@"v0.0.1"];
}
