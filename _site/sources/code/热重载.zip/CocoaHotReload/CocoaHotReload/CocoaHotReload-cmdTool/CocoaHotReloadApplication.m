//
//  CocoaHotReloadApplication.m
//  CocoaHotReload-cmdTool
//
//  Created by mambaxie on 2020/7/13.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import "CocoaHotReloadApplication.h"
#import "CocoaHotReloadTool.h"
#import "CocoaHotReloadManager.h"
#import "SocketServer.h"
#import "CocoaHotReloadServerDefine.h"
#import "CocoaHotReloadApplication.h"
#import <Cocoa/Cocoa.h>
#import "CocoaHotReloadSettings.h"
#import "CocoaHotReloadPreferences.h"
#import "CompileCommandManager.h"
#import "ProjectManager.h"
#import "SymbolManager.h"

@implementation CocoaHotReloadApplication

- (void)setup
{
    // project
    [self.arguments registerArgument:@"project"
                     signatureFormat:@"[-p --project]="
                          helpString:@"-p --project\t\t@Required\t\t\tThe file path of project. eg: xxx.xcodeproject|xxx.workspace"];
    // executable
    [self.arguments registerArgument:@"executable"
                     signatureFormat:@"[-e --executable]="
                          helpString:@"-e --executable\t\t@Required\t\t\tThe name of executable file."];
    // file
    [self.arguments registerArgument:@"file"
                     signatureFormat:@"[-f --file]="
                          helpString:@"-f --file\t\t\t@Required\t\t\tThe file paths of which to recompile. eg: xxx.m|xxx.h|xxx.mm"];
    // out
    [self.arguments registerArgument:@"output"
                   signatureFormat:@"[-o --output]="
                        helpString:@"-o --output\t\t\t@Required.\t\t\tThe directory path of output. eg: xxx/output"];
    // scheme
    [self.arguments registerArgument:@"scheme"
                     signatureFormat:@"[-s --scheme]="
                          helpString:@"-s --scheme\t\t\t@Required\t\t\tThe name of scheme."];
    
    // test
    [self.arguments registerArgument:@"testscheme"
                     signatureFormat:@"[-t --testscheme]="
                          helpString:@"-t --testscheme\t\t@Required \t\t\tThe name of test scheme."];
    
    // derived data
    [self.arguments registerArgument:@"derived"
                     signatureFormat:@"[-d --derived]="
                          helpString:@"-d --derived\t\t@Optional\t\t\tThe dirctory of derived data."];
    
    // arch
    [self.arguments registerArgument:@"arch"
                     signatureFormat:@"[-a --arch]="
                          helpString:@"-a --arch\t\t\t@Optional default is x86_64.\tThe ARCH. eg: x86_64|arm64"];
    
    // minimumOSVersion
    [self.arguments registerArgument:@"minimum"
                     signatureFormat:@"[-m --minimum]="
                          helpString:@"-m --minimum\t\t@Optional default is 7.0. \tThe minimum system version."];
    
    // dylibname
    [self.arguments registerArgument:@"dylibname"
                     signatureFormat:@"[-n --dylibname]="
                          helpString:@"-n --dylibname\t\t@Optional \t\t\tThe name of dylib."];
    
    // filelist
    [self.arguments registerArgument:@"filelist"
                     signatureFormat:@"[-l --filelist]="
                          helpString:@"-l --filelist\t\t@Optional \t\t\tThe File list path for swift."];
}

- (int)main
{
    NSString *projectFilePath = [[self arguments] firstObjectForArgument:@"project"];
//    projectFilePath = @"/Users/mambaxie/Documents/Git/microvision/microvision.xcworkspace";
    if (projectFilePath.length > 0) {
        if (![projectFilePath hasSuffix:@".xcodeproj"]
            && ![projectFilePath hasSuffix:@".xcworkspace"]) {
            HRLog(@"Project file path : %@", projectFilePath);
            ErrorLog("The project file name must be suffixed with .xcodeproj or .xcworkspace.");
        }
    } else {
        ErrorLog("Parameter -p or --project is required.");
    }
    
    NSString *executableName = [[self arguments] firstObjectForArgument:@"executable"];
//    executableName = @"microvision";
    if (executableName.length == 0) {
        ErrorLog("Parameter -e or --executable is required.");
    }
    
    NSString *targetName = [[self arguments] firstObjectForArgument:@"scheme"];
//    targetName = @"microvision";
    if (targetName.length == 0) {
        ErrorLog("Parameter -s or --scheme is required.");
    }
    
    NSString *testTargetName = [[self arguments] firstObjectForArgument:@"testscheme"];
//    testTargetName = @"microvisionUnitTests";
    if (testTargetName.length == 0) {
        ErrorLog("Parameter -t or --testscheme is required.");
    }
    
    NSArray<NSString *> *filePaths = [[self arguments] allObjectsForArgument:@"file"];
//    filePaths = @[ @"/Users/mambaxie/Documents/Git/microvision/microvision/Class/UI/Comment/FSFeedCommentListView.swift"];
    if (filePaths.count == 0) {
        ErrorLog("Parameter -f or --file is required.");
    }
    
    NSString *outputDirPath = [[self arguments] firstObjectForArgument:@"output"];
//    outputDirPath = @"/Users/mambaxie/Desktop/Tmp";
    if (outputDirPath.length == 0) {
        ErrorLog("Parameter -o or --output is required.");
    }
    
    // 默认添加产物文件夹
    outputDirPath = [outputDirPath stringByAppendingPathComponent:@"CocoaHotReloadCmdProducts"];
    
    NSError *error;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:outputDirPath]) {
        [fileManager removeItemAtPath:outputDirPath error:&error];
    }
    [fileManager createDirectoryAtPath:outputDirPath withIntermediateDirectories:NO attributes:nil error:&error];
    if (error) {
        ErrorLog("Create output's directory failed, direcrory path : %@, error: %@",  outputDirPath, error.localizedDescription);
    }
    
    NSTimeInterval begin = [[NSDate date] timeIntervalSince1970];
    NSApplication *app = [NSApplication sharedApplication];
    [ProjectSharedManager() setupSettings:^(CocoaHotReloadSettings * _Nonnull settings) {
        settings.projectFilePath = projectFilePath;
        settings.executableName = executableName;
        settings.cmdProductDir = outputDirPath;
        settings.customDylibName = [[self arguments] firstObjectForArgument:@"dylibname"];
        settings.arch = @"x86_64";
        settings.minimumOSVersion = @"7.0";
        settings.targetName = targetName;
        settings.testTargetName = testTargetName;
        settings.derivedDataPath = [[self arguments] firstObjectForArgument:@"derived"];
        settings.fileListPath = [[self arguments] firstObjectForArgument:@"filelist"];
        
        if ([settings.arch isEqualToString:@"x86_64"]) {
            settings.platformName = @"iphonesimulator";
        } else {
            settings.platformName = @"iphoneos";
        }
        settings.projectName = [settings.projectFilePath.lastPathComponent stringByDeletingPathExtension];
        settings.projectRunTimeInterval = [[NSDate date] timeIntervalSince1970];
    }];
    // 1. 项目初始化
    [ProjectSharedManager() doProjectInitWithCompletion:^{
        // 2. hot reload
        [ProjectSharedManager() recompileFilesForFilePaths:filePaths completion:^(NSDictionary * _Nonnull dylibInfo) {
            if (dylibInfo) {
                NSMutableDictionary *dicM = [dylibInfo mutableCopy];
                dicM[@"projectSwiftSymbols"] = [SymbolSharedManager() projectSwiftSymbols];
                NSTimeInterval end = [[NSDate date] timeIntervalSince1970];
                NSString *dylibInfoFilePath = [outputDirPath stringByAppendingPathComponent:@"info.plist"];
                HRLog(@"👏 生成dylib成功！%.2f seconds \n Output's directory : %@ \n Dylib info : %@", end - begin, outputDirPath, dicM);
                [dicM writeToFile:dylibInfoFilePath atomically:YES];
                // 返回信息
                exit(EXIT_SUCCESS);
            } else {
                // 返回信息
                exit(EXIT_FAILURE);
            }
        }];
    }];

    [app run];
    
    return 0;
}

@end
