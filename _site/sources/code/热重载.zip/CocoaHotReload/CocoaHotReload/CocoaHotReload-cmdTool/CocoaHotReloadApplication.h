//
//  CocoaHotReloadApplication.h
//  CocoaHotReload-cmdTool
//
//  Created by mambaxie on 2020/7/13.
//  Copyright © 2020 Tencent. All rights reserved.
//

#import "CLKApplication.h"

NS_ASSUME_NONNULL_BEGIN

@interface CocoaHotReloadApplication : CLKApplication

@end

NS_ASSUME_NONNULL_END
