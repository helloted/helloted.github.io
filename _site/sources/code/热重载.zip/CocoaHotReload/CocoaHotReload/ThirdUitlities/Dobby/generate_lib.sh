cd `dirname $0`
CURRENT_DIR=$(pwd)

git clone https://github.com/jmpews/Dobby.git

DOBBY_MASTER_DIR=$CURRENT_DIR/Dobby
cd $DOBBY_MASTER_DIR

rm -rf build_for_ios || true
mkdir build_for_ios
PRODUCT_DIR=$DOBBY_MASTER_DIR/build_for_ios

cd $PRODUCT_DIR
# build for armv7
mkdir $PRODUCT_DIR/build_for_armv7 && cd $PRODUCT_DIR/build_for_armv7
echo `pwd`
cmake ../.. \
-DCMAKE_TOOLCHAIN_FILE=cmake/ios.toolchain.cmake \
-DPLATFORM=OS -DARCHS="armv7" -DCMAKE_SYSTEM_PROCESSOR=arm \
-DENABLE_BITCODE=1 -DENABLE_ARC=0 -DENABLE_VISIBILITY=1 -DDEPLOYMENT_TARGET=9.3 -DCMAKE_BUILD_TYPE=Release -DDOBBY_DEBUG=OFF -DDOBBY_GENERATE_SHARED=OFF -DGenerateDarwinFramework=OFF

make -j4

# build for arm64
mkdir $PRODUCT_DIR/build_for_arm64 && cd $PRODUCT_DIR/build_for_arm64
cmake ../../ \
-DCMAKE_TOOLCHAIN_FILE=cmake/ios.toolchain.cmake \
-DPLATFORM=OS64 -DARCHS="arm64" -DCMAKE_SYSTEM_PROCESSOR=arm64 \
-DENABLE_BITCODE=1 -DENABLE_ARC=0 -DENABLE_VISIBILITY=1 -DDEPLOYMENT_TARGET=9.3 -DCMAKE_BUILD_TYPE=Release -DDOBBY_DEBUG=OFF -DDOBBY_GENERATE_SHARED=OFF -DGenerateDarwinFramework=OFF

make -j4

# build for i386
mkdir $PRODUCT_DIR/build_for_i386 && cd $PRODUCT_DIR/build_for_i386
cmake ../../ \
-DCMAKE_TOOLCHAIN_FILE=cmake/ios.toolchain.cmake \
-DPLATFORM=SIMULATOR -DARCHS="i386" -DCMAKE_SYSTEM_PROCESSOR=X86 \
-DENABLE_BITCODE=1 -DENABLE_ARC=0 -DENABLE_VISIBILITY=1 -DDEPLOYMENT_TARGET=9.3 -DCMAKE_BUILD_TYPE=Release -DDOBBY_DEBUG=OFF -DDOBBY_GENERATE_SHARED=OFF -DGenerateDarwinFramework=OFF

make -j4

# build for x86_64
mkdir $PRODUCT_DIR/build_for_x86_64 && cd $PRODUCT_DIR/build_for_x86_64
cmake ../../ \
-DCMAKE_TOOLCHAIN_FILE=cmake/ios.toolchain.cmake \
-DPLATFORM=SIMULATOR64 -DARCHS="x86_64" -DCMAKE_SYSTEM_PROCESSOR=X86_64 \
-DENABLE_BITCODE=1 -DENABLE_ARC=0 -DENABLE_VISIBILITY=1 -DDEPLOYMENT_TARGET=9.3 -DCMAKE_BUILD_TYPE=Release -DDOBBY_DEBUG=OFF -DDOBBY_GENERATE_SHARED=OFF -DGenerateDarwinFramework=OFF

make -j4

LIB_DIR=$CURRENT_DIR/lib

rm -rf $LIB_DIR || true
mkdir $LIB_DIR

# 生成static library
cp -R $DOBBY_MASTER_DIR/include $LIB_DIR/include
lipo -create $PRODUCT_DIR/build_for_i386/libdobby.a $PRODUCT_DIR/build_for_x86_64/libdobby.a $PRODUCT_DIR/build_for_armv7/libdobby.a $PRODUCT_DIR/build_for_arm64/libdobby.a -output $LIB_DIR/libdobby.a

# 移除dobby master
rm -rf $DOBBY_MASTER_DIR

open $CURRENT_DIR
