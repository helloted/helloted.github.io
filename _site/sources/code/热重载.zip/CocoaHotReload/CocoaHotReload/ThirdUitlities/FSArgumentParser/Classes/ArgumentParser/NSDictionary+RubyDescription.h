//
//  NSDictionary+RubyDescription.h
//  ArgumentParser
//
//  Created by Christopher Miller on 5/15/12.
//  Copyright (c) 2012 Christopher Miller. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (RubyDescription)
- (NSString *)fs_rubyHashDescription;
@end
