//
//  CPShiftAction.m
//  CoreParse
//
//  Created by Tom Davie on 20/08/2012.
//  Copyright (c) 2012 In The Beginning... All rights reserved.
//

#import "CPShiftAction.h"

@implementation CPShiftAction

@end
