//
//  FSFormatCtorTokeniserDelegate.h
//  ArgumentParser
//
//  Created by Christopher Miller on 5/18/12.
//  Copyright (c) 2012 Christopher Miller. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "CoreParse.h"

@interface FSFormatCtorTokeniserDelegate : NSObject < CPTokeniserDelegate >

@end
