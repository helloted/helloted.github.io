//
//  FSArgsKonstants.m
//  ArgumentParser
//
//  Created by Christopher Miller on 5/15/12.
//  Copyright (c) 2012 Christopher Miller. All rights reserved.
//

#import "FSArgsKonstants.h"

NSString * __fsargs_typeKey = @"type";
NSString * __fsargs_switch = @"switch";
NSString * __fsargs_unknown = @"unknown";
NSString * __fsargs_barrier = @"barrier";
NSString * __fsargs_value = @"value";
NSString * __fsargs_isValueCaptured = @"isValueCaptured?";
