//
//  FSArgsKonstants.h
//  ArgumentParser
//
//  Created by Christopher Miller on 5/15/12.
//  Copyright (c) 2012 Christopher Miller. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString * __fsargs_typeKey;
extern NSString * __fsargs_switch;
extern NSString * __fsargs_unknown;
extern NSString * __fsargs_barrier;
extern NSString * __fsargs_value;
extern NSString * __fsargs_isValueCaptured;
