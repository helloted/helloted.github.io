//
//  CoolToast.h
//  CoolToast
//
//  Created by mambaxie on 2020/5/23.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for CoolToast.
FOUNDATION_EXPORT double CoolToastVersionNumber;

//! Project version string for CoolToast.
FOUNDATION_EXPORT const unsigned char CoolToastVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CoolToast/PublicHeader.h>


