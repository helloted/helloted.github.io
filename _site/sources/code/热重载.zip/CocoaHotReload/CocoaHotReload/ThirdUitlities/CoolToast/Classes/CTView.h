//
//  CTView.h
//  CoolToast
//
//  Created by Socoolby on 2019/7/5.
//  Copyright © 2019 Socoolby. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface CTView : NSView

@end

NS_ASSUME_NONNULL_END
