//
//  SceneDelegate.h
//  IPAHotReload
//
//  Created by 谢培艺 on 2020/2/27.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

