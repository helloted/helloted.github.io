#!/bin/sh

#  resign_ipa.sh
#  CocoaHotReload-macOS
#
#  Created by 谢培艺 on 2020/2/27.
#  Copyright © 2020 tencent. All rights reserved.

#  参考IPAPatch实现：https://github.com/Naituw/IPAPatch/blob/master/Tools/patch.sh

# 1. 解压ipa文件
# 2. 替换ipa文件内容到.app文件中
# 3. 通过optool注入CocoaHotReload-iOS.framwork到.app二进制文件中
# 4. 移除 AppExtensions 和 Watch
# 5. 更新Info.plist信息
# 6. 重签名
# 7. 安装（Xcode自动安装app到手机中）

TARGET_ROOT_PATH="${SRCROOT}/${TARGET_NAME}"
TARGETIPA_DIR="${TARGET_ROOT_PATH}/ipa"
ZIP_IPA_PATH=""
TEMP_DIR="${TARGETIPA_DIR}/tmp"
UNZIP_IPA_DIR="${TEMP_DIR}/unzipIPA"

rm -rf $TEMP_DIR || true
mkdir $TEMP_DIR || true

# 1. 解压ipa文件
# 找到ipa包
for file in $(ls $TARGETIPA_DIR)
do
    if [ "${file##*.}" == "ipa" ]
        then
        ZIP_IPA_PATH="${TARGETIPA_DIR}/${file%.*}.zip"
        cp "${TARGETIPA_DIR}/${file}" "${ZIP_IPA_PATH}"
        break
    fi
done

if [ ! -f "${ZIP_IPA_PATH}" ]; then
echo "😭【IPAHotReload Error】No ipa file found !"
exit 0
fi

mkdir $UNZIP_IPA_DIR || true

# 1.解压ipa
unzip -q $ZIP_IPA_PATH -d $UNZIP_IPA_DIR
# 移除zip
rm $ZIP_IPA_PATH

# 2.替换app包内容
for file in $(ls "${UNZIP_IPA_DIR}/Payload")
do
    if [ "${file##*.}" == "app" ]; then
        TEMP_APP_PATH="$UNZIP_IPA_DIR/Payload/${file%.*}.app"
    fi
done

echo "TEMP_APP_PATH: $TEMP_APP_PATH"
TARGET_APP_PATH="$BUILT_PRODUCTS_DIR/$TARGET_NAME.app"

echo "TARGET_APP_PATH: $TARGET_APP_PATH"
rm -rf $TARGET_APP_PATH || true
mkdir $TARGET_APP_PATH || true
cp -rf "$TEMP_APP_PATH/" "$TARGET_APP_PATH/"

# 3.添加CocoaHotReload.framework到可执行文件中
APP_BINARY=`plutil -convert xml1 -o - $TARGET_APP_PATH/Info.plist|grep -A1 Exec|tail -n1|cut -f2 -d\>|cut -f1 -d\<`
chmod +x "$TARGET_APP_PATH/$APP_BINARY"

FRAMEWORKS_TO_INJECT_PATH=$BUILT_PRODUCTS_DIR
OPTOOL="${TARGET_ROOT_PATH}/Tools/optool"
TARGET_APP_FRAMEWORKS_PATH="$BUILT_PRODUCTS_DIR/$TARGET_NAME.app/Frameworks"
echo "Injecting Frameworks from $FRAMEWORKS_TO_INJECT_PATH"
for file in `ls -1 "${FRAMEWORKS_TO_INJECT_PATH}"`; do
    extension="${file##*.}"
    echo "$file 's extension is $extension"

    if [ "$extension" != "framework" ]
    then
        continue
    fi

    mkdir -p "$TARGET_APP_FRAMEWORKS_PATH"
    rsync -av --exclude=".*" "${FRAMEWORKS_TO_INJECT_PATH}/$file" "$TARGET_APP_FRAMEWORKS_PATH"
    filename="${file%.*}"

    echo -n '     '
    echo "Install Load: $file -> @executable_path/Frameworks/$file/$filename"

    "$OPTOOL" install -c load -p "@executable_path/Frameworks/$file/$filename" -t "$TARGET_APP_PATH/$APP_BINARY"
done

# 4. 移除 AppExtensions 和 Watch
echo "Removing AppExtensions"
rm -rf "$TARGET_APP_PATH/PlugIns" || true
rm -rf "$TARGET_APP_PATH/Watch" || true

# 5. 更新Info.plist信息
echo "Updating BundleID:$PRODUCT_BUNDLE_IDENTIFIER, DisplayName:$TARGET_DISPLAY_NAME"
TARGET_DISPLAY_NAME=$(/usr/libexec/PlistBuddy -c "Print CFBundleDisplayName"  "$TARGET_APP_PATH/Info.plist")
TARGET_DISPLAY_NAME="⚡️$TARGET_DISPLAY_NAME"

/usr/libexec/PlistBuddy -c "Set :CFBundleIdentifier $PRODUCT_BUNDLE_IDENTIFIER" "$TARGET_APP_PATH/Info.plist"
/usr/libexec/PlistBuddy -c "Set :CFBundleDisplayName $TARGET_DISPLAY_NAME" "$TARGET_APP_PATH/Info.plist"

# 6. 签名
echo "Code Signing Frameworks"
if [ -d "$TARGET_APP_FRAMEWORKS_PATH" ]; then
for FRAMEWORK in "$TARGET_APP_FRAMEWORKS_PATH/"*
do
    FILENAME=$(basename $FRAMEWORK)
    /usr/bin/codesign --force --sign "$EXPANDED_CODE_SIGN_IDENTITY" "$FRAMEWORK"
done
fi

echo "Code Signing App Binary"
/usr/bin/codesign --force --sign "$EXPANDED_CODE_SIGN_IDENTITY" --timestamp=none "$TARGET_APP_PATH/$APP_BINARY"

# 7. 安装
echo "Done"

# 移除临时目录
rm -rf $TEMP_DIR || true

