//
//  ViewController.m
//  IPAHotReload
//
//  Created by 谢培艺 on 2020/2/27.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
