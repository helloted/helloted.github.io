//
//  ViewController.h
//  CocoaHotReloadDemo
//
//  Created by mambaxie on 2020/4/14.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

