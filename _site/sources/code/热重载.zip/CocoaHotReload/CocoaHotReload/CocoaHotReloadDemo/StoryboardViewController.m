//
//  StoryboardViewController.m
//  CocoaHotReloadDemo
//
//  Created by mambaxie on 2020/8/3.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "StoryboardViewController.h"

@interface StoryboardViewController ()

@end

@implementation StoryboardViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.title = @"Storyboard file";
}

@end
