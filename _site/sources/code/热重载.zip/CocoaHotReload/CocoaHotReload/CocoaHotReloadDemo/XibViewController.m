//
//  XibViewController.m
//  CocoaHotReloadDemo
//
//  Created by mambaxie on 2020/8/3.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "XibViewController.h"

@interface XibViewController ()

@end

@implementation XibViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"Xib file";
}

@end
