//
//  AppDelegate.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2019/11/23.
//  Copyright © 2019 tencent. All rights reserved.
//

#import "AppDelegate.h"
#import "CocoaHotReloadManager.h"
#import <Carbon/Carbon.h>
#import "CocoaFileWatcher.h"
#import "CocoaFileTool.h"
#import "SocketServer.h"
#import "PreferencesWindowController.h"
#import "PTHotKeyCenter.h"
#import "PTHotKey.h"
#import "PTHotKey+ShortcutRecorder.h"
#import "CocoaHotReloadManager.h"
#import "CocoaHotReloadServerDefine.h"
#import "PbxprojFileTool.h"
#import "USBDeviceSocketManager.h"
#import "CocoaHotReloadReportService.h"
#import "ShortcutRecorder.h"
#import "CocoaHotReloadSettings.h"
#import "SocketServer.h"
#import "ProjectManager.h"

NSString * const kHotReloadKeyPath = @"values.hotReload";
NSString * const kShowOrHideLogKeyPath = @"values.showOrHideLog";

static NSString * const kDefaultHotKeyHasSetKey = @"kDefaultHotKeyHasSetKey";
static NSString * const kDefaultRecentSubMenuKey = @"kDefaultRecentSubMenuKey";
static NSString * const kDefaultDeviceSubMenuKey = @"kDefaultDeviceSubMenuKey";

@interface AppDelegate () <NSWindowDelegate, NSMenuDelegate> {
    PreferencesWindowController *_preferencesWindowController;
}

@property (nonatomic, strong) NSDictionary *hotKeyMap;

@property (nonatomic, assign) CocoaHotReloadStatus status;

@end

@implementation AppDelegate


- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    
    /// 运行
    [SocketServer run];
    
    /// Set up status item
    [self setupStatusItem];
    
    /// 注册全局键盘监听
    [self registerGlobalKeyboardMonitor];
    
    //自动选择工程文件
    [PbxprojFileTool checkAutoSelectProjectIfNeed];
    
    [[NSApplication sharedApplication] activateIgnoringOtherApps:YES];

    //开启自启动检测
    [PbxprojFileTool addReloadCompleteNotification];
    
    // 数据上报
    CocoaHotReloadReport(@"launch", 0, 0, nil, [NSString stringWithFormat:@"%d", [PbxprojFileTool isAutoLaunch]]);
    
    if ([PbxprojFileTool isAutoLaunch]) {
        [self hideLogWindow];
    }
}

- (void)registerGlobalKeyboardMonitor
{
    self.hotKeyMap = @{ kHotReloadKeyPath : @(MenuItemTypeHotReload),
                        kShowOrHideLogKeyPath : @(MenuItemTypeShowOrHideLog) };
    
    NSUserDefaultsController *defaults = [NSUserDefaultsController sharedUserDefaultsController];
    NSMenuItem *hotReloadItem = [self menuItemForType:MenuItemTypeHotReload];
    [hotReloadItem bind:@"keyEquivalent" toObject:defaults withKeyPath:kHotReloadKeyPath options:@{NSValueTransformerBindingOption: [SRKeyEquivalentTransformer new]}];
    [hotReloadItem bind:@"keyEquivalentModifierMask"
                 toObject:defaults
              withKeyPath:kHotReloadKeyPath
                  options:@{NSValueTransformerBindingOption: [SRKeyEquivalentModifierMaskTransformer new]}];
    NSMenuItem *showOrHideLogItem = [self menuItemForType:MenuItemTypeShowOrHideLog];
    
    [showOrHideLogItem bind:@"keyEquivalent" toObject:defaults withKeyPath:kShowOrHideLogKeyPath options:@{NSValueTransformerBindingOption: [SRKeyEquivalentTransformer new]}];
    [showOrHideLogItem bind:@"keyEquivalentModifierMask"
                 toObject:defaults
              withKeyPath:kShowOrHideLogKeyPath
                  options:@{NSValueTransformerBindingOption: [SRKeyEquivalentModifierMaskTransformer new]}];
    
    BOOL hasSet = [[NSUserDefaults standardUserDefaults] boolForKey:kDefaultHotKeyHasSetKey];
    if (!hasSet) {
        int h_keyCode = 4;
        NSString *h = @"h";
        NSEventModifierFlags flags = NSEventModifierFlagCommand | NSEventModifierFlagShift;
        NSDictionary *hotReloadInfo = @{
            SRShortcutKeyCode: @(h_keyCode),
            SRShortcutModifierFlagsKey: @(flags & SRCocoaModifierFlagsMask),
            SRShortcutCharacters: h,
            SRShortcutCharactersIgnoringModifiers: h.uppercaseString
        };

        [defaults setValue:hotReloadInfo forKeyPath:kHotReloadKeyPath];
        
        int l_keyCode = 37;
        NSString *l = @"l";
        NSDictionary *showOrHideLogInfo = @{
            SRShortcutKeyCode: @(l_keyCode),
            SRShortcutModifierFlagsKey: @(flags & SRCocoaModifierFlagsMask),
            SRShortcutCharacters: l,
            SRShortcutCharactersIgnoringModifiers: l.uppercaseString
        };

        [defaults setValue:showOrHideLogInfo forKeyPath:kShowOrHideLogKeyPath];
        
        [[NSUserDefaults standardUserDefaults] setBool:YES forKey:kDefaultHotKeyHasSetKey];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    
    [defaults addObserver:self forKeyPath:kHotReloadKeyPath options:NSKeyValueObservingOptionInitial context:NULL];
    [defaults addObserver:self forKeyPath:kShowOrHideLogKeyPath options:NSKeyValueObservingOptionInitial context:NULL];
}

- (void)observeValueForKeyPath:(NSString *)aKeyPath ofObject:(id)anObject change:(NSDictionary *)aChange context:(void *)aContext
{
    if ([self.hotKeyMap.allKeys containsObject:aKeyPath])
    {
        PTHotKeyCenter *hotKeyCenter = [PTHotKeyCenter sharedCenter];
        PTHotKey *oldHotKey = [hotKeyCenter hotKeyWithIdentifier:aKeyPath];
        [hotKeyCenter unregisterHotKey:oldHotKey];
        
        NSDictionary *newShortcut = [anObject valueForKeyPath:aKeyPath];
        
        if (newShortcut && (NSNull *)newShortcut != [NSNull null])
        {
            PTHotKey *newHotKey = [PTHotKey hotKeyWithIdentifier:aKeyPath
                                                        keyCombo:newShortcut
                                                          target:self
                                                          action:@selector(handleHotKeyPress:)];
            [hotKeyCenter registerHotKey:newHotKey];
        }
    }
    else
        [super observeValueForKeyPath:aKeyPath ofObject:anObject change:aChange context:aContext];
}

- (void)handleHotKeyPress:(PTHotKey *)sender
{
    MenuItemType type = [self.hotKeyMap[sender.identifier] intValue];
    [self handleMenuItemActionWithType:type];
}

- (CocoaHotReloadStatus)currentStatus
{
    return self.status;
}

- (void)setupStatusItem {
    
    //获取系统单例NSStatusBar对象
    NSStatusBar *statusBar = [NSStatusBar systemStatusBar];
    NSStatusItem *statusItem = [statusBar statusItemWithLength: NSSquareStatusItemLength];
    self.statusItem = statusItem;
    NSImage *logo = [NSImage imageNamed:@"status_error"];
    NSStatusBarButton *barButton = statusItem.button;
    [barButton setImage:logo];
    [barButton.cell setHighlighted:NO];
    
    NSString *actionMenuTitle = @"Action";
    NSMenu *actionMenu = [[NSMenu alloc] initWithTitle:actionMenuTitle];
    statusItem.menu = actionMenu;
    actionMenu.delegate = self;
    [actionMenu addItemWithTitle:@"Select Project" action:@selector(handleMenuITemActionWithItem:) keyEquivalent:@""];
    [actionMenu addItemWithTitle:@"Open Recent" action:@selector(handleMenuITemActionWithItem:) keyEquivalent:@""];
    [actionMenu addItemWithTitle:@"Hot Reload" action:@selector(handleMenuITemActionWithItem:) keyEquivalent:@""];
    [actionMenu addItemWithTitle:@"Stop Hot Reload" action:@selector(handleMenuITemActionWithItem:) keyEquivalent:@""];
    [actionMenu addItemWithTitle:@"Hide Log" action:@selector(handleMenuITemActionWithItem:) keyEquivalent:@"L"];
    [actionMenu addItemWithTitle:@"Select Device" action:@selector(handleMenuITemActionWithItem:) keyEquivalent:@""];
    [actionMenu addItemWithTitle:@"Preferences" action:@selector(handleMenuITemActionWithItem:) keyEquivalent:@""];
    [actionMenu addItemWithTitle:@"New Issue" action:@selector(handleMenuITemActionWithItem:) keyEquivalent:@""];
    [actionMenu addItemWithTitle:@"Quit" action:@selector(handleMenuITemActionWithItem:) keyEquivalent:@""];
    
    //add sub menu
    [self addSubMenuWithRecentMenu];
    [self addSubMenuWithDeviceMenu];
    actionMenu.autoenablesItems = NO;
    NSWindow *window = [[NSApplication sharedApplication] windows].firstObject;
    window.delegate = self;
    
    [self changeStopHotReloadItemEnableIfNeed];
}

- (void)addSubMenuWithRecentMenu {
    NSArray *pathAry = [PbxprojFileTool getRecentProjectPath];
    if (!pathAry || pathAry.count == 0) {
        return ;
    }
    
    NSMenuItem *recentMenu = [self menuItemForType:MenuItemTypeRecentProject];
    NSMenu * subMenu = [[NSMenu alloc]initWithTitle:kDefaultRecentSubMenuKey];
    subMenu.delegate = self;
    [pathAry enumerateObjectsUsingBlock:^(NSString *obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSMenuItem * item4 = [[NSMenuItem alloc]initWithTitle:obj action:@selector(clickRecentProjectPath:) keyEquivalent:@""];
        item4.target = self;
        [subMenu addItem:item4];
    }];

    [self.statusItem.menu setSubmenu:subMenu forItem:recentMenu];
}

- (void)addSubMenuWithDeviceMenu {
    NSMenuItem *deviceMenu = [self menuItemForType:MenuItemTypeSelectDevice];
    NSMenu * subMenu = [[NSMenu alloc] initWithTitle:kDefaultDeviceSubMenuKey];
    subMenu.delegate = self;
    [self.statusItem.menu setSubmenu:subMenu forItem:deviceMenu];
}

- (void)handleMenuItemActionWithType:(MenuItemType)type
{
    switch (type) {
        case MenuItemTypeSelectProject:
        {
            [CocoaHotReloadTool runOnMainThread:^{
                NSOpenPanel *panel = [NSOpenPanel openPanel];
                               [panel setAllowsMultipleSelection:NO];
                               [panel setCanChooseDirectories:NO];
                               [panel setCanChooseFiles:YES];
                               [panel setAllowedFileTypes:@[@"xcworkspace", @"xcodeproj"]];
                               [panel setPrompt:@"Select Project File"];
                               [panel setMessage:@"Please select .xcodeproj or .xcworkspace file"];
                               if ([panel runModal] == NSModalResponseOK) {
                                   NSURL *selectedURL = [[panel URLs] lastObject];
                                   if ([selectedURL.absoluteString hasSuffix:@".xcodeproj"] ||
                                       [selectedURL.absoluteString hasSuffix:@".xcworkspace"]) {
                                       [PbxprojFileTool saveProjectPath:[selectedURL path]];
                                       [self addSubMenuWithRecentMenu];
                                       [PbxprojFileTool selectProjectWithUrl:selectedURL];
                                   }
                               } else {
                                   if (!ProjectSharedManager().settings.projectFilePath) {
                                       ErrorLogWithoutToast(@"Please select project first!");
                                   }
                               }
            }];
            break;
        }
        case MenuItemTypeHotReload:
        {
            [self hotReload];
            break;
        }
        case MenuItemTypeSelectDevice: {
            [self addSubMenuWithDeviceMenu];
            break;
        }
        case MenuItemTypeStopHotReload: {
            [ProjectSharedManager() stopHotReload];
            break;
        }
        case MenuItemTypeShowOrHideLog:
        {
            [self hideOrShowLogWindow:[self menuItemForType:type]];
            break;
        }
        case MenuItemTypePreferences:
        {
            [self preference:[self menuItemForType:type]];
            break;
        }
        case MenuItemTypeRecentProject:
        {
            break;
        }
        case MenuItemTypeNewIssue:
        {
            NSURL *newIssueURL = [NSURL URLWithString:@"https://git.code.oa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/new"];
            [[NSWorkspace sharedWorkspace] openURL:newIssueURL];
            break;
        }
        case MenuItemTypeQuit:
        {
            [self quit];
            break;
        }
            
        default:
            break;
    }

}

- (void)handleMenuITemActionWithItem:(NSMenuItem *)item
{
    MenuItemType type = [self.statusItem.menu indexOfItem:item];
    [self handleMenuItemActionWithType:type];
}

- (NSMenuItem *)menuItemForType:(MenuItemType)type
{
    return [self.statusItem.menu itemAtIndex:type];
}

- (void)setStatusItemStatus:(CocoaHotReloadStatus)status
{
    self.status = status;
    
    NSString *imageName = @"status_idle";
    switch (status) {
        case CocoaHotReloadStatusBusy:
            imageName = @"status_busy";
            break;
        case CocoaHotReloadStatusError:
            imageName = @"status_error";
            [self showLogWindow];
            break;
            
        default:
            break;
    }
    
    [self changeStopHotReloadItemEnableIfNeed];
    
    [self.statusItem.button setImage:[NSImage imageNamed:imageName]];
}

#pragma mark - action
- (void)hotReload {
    [[SocketServer currentServer] postNotificationForSocketCommand:SocketCommandHotReload value:nil];
}

- (void)changeStopHotReloadItemEnableIfNeed
{
    NSMenuItem *item = [self.statusItem.menu itemAtIndex:MenuItemTypeStopHotReload];
    item.enabled = self.status == CocoaHotReloadStatusBusy;
}

- (void)preference:(NSMenuItem *)item
{
    if (!_preferencesWindowController) {
        _preferencesWindowController = [[PreferencesWindowController alloc] initWithWindowNibName:@"PreferencesWindowController"];
    }
    _preferencesWindowController.window.level = NSNormalWindowLevel;
    
    if (!_preferencesWindowController.window.visible) {
        [_preferencesWindowController.window setIsVisible:YES];
    }
    
    [[NSApplication sharedApplication] activateIgnoringOtherApps:YES];
}

- (void)hideOrShowLogWindow:(NSMenuItem *)item
{
    if ([self isLogWindowShowingOnTop]) {
        [self hideLogWindow];
    } else {
        [self showLogWindow];
    }
}

- (BOOL)isLogWindowShowingOnTop
{
    NSWindow *window = [[NSApplication sharedApplication] windows].firstObject;
    NSApplication *app = [NSApplication sharedApplication];
    return window.visible && app.active;
}

- (void)hideLogWindow {
    NSWindow *window = [[NSApplication sharedApplication] windows].firstObject;
    [window setIsVisible:NO];
    NSMenuItem *item = [self.statusItem.menu itemAtIndex:MenuItemTypeShowOrHideLog];
    [item setTitle:@"Show Log"];
}

- (void)showLogWindow
{
    NSWindow *window = [[NSApplication sharedApplication] windows].firstObject;
    if (![self isLogWindowShowingOnTop]) {
        [window setIsVisible:YES];
        NSMenuItem *item = [self.statusItem.menu itemAtIndex:MenuItemTypeShowOrHideLog];
        [item setTitle:@"Hide Log"];
    }
    
    [[NSApplication sharedApplication] activateIgnoringOtherApps:YES];
}

- (void)quit
{
    [[NSApplication sharedApplication] terminate:self];
}

#pragma mark - NSWindowDelegate
- (void)windowWillClose:(NSNotification *)notification
{
    /// hide or show log menu
    NSMenuItem *item = [self.statusItem.menu itemAtIndex:MenuItemTypeShowOrHideLog];
    [item setTitle:@"Show Log"];
}

#pragma mark - NSMenuDelegate
- (void)menuWillOpen:(NSMenu *)menu
{
    if ([menu.title isEqualToString:kDefaultRecentSubMenuKey]) {
        [self recentProjectMenuWillOpen:menu];
        return;
    }
    else if([menu.title isEqualToString:kDefaultDeviceSubMenuKey]) {
        [self deviceMenuWillShow:menu];
        return ;
    }
    
    NSApplication *app = [NSApplication sharedApplication];
    if (!app.active) {
        /// hide or show log menu
        NSMenuItem *item = [self.statusItem.menu itemAtIndex:MenuItemTypeShowOrHideLog];
        [item setTitle:@"Show Log"];
    }
}

#pragma mark - Recent Project

- (void)recentProjectMenuWillOpen:(NSMenu *)menu {
    [menu.itemArray enumerateObjectsUsingBlock:^(NSMenuItem * _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([ProjectSharedManager().settings.projectFilePath isEqualToString:obj.title]) {
            obj.state = NSControlStateValueOn;
        }
        else {
            obj.state = NSControlStateValueOff;
        }
    }];
}

- (void)clickRecentProjectPath:(NSMenuItem *)item {
    if ([[NSFileManager defaultManager] fileExistsAtPath:item.title]) {
        NSURL *fileUrl = [NSURL fileURLWithPath:item.title];
        [PbxprojFileTool selectProjectWithUrl:fileUrl];
        [PbxprojFileTool saveProjectPath:item.title];
    }
    else {
        HRLog(@"file no exist : %@", item.title);
    }
}

#pragma mark - select Device

- (void)deviceMenuWillShow:(NSMenu *)menu  {
    NSMenuItem *deviceMenu = [self menuItemForType:MenuItemTypeSelectDevice];
    NSArray *ary = [[USBDeviceSocketManager shareInstance] getAllConnetingSocketInfos];
    CHRChannel *curCha = [[USBDeviceSocketManager shareInstance] getCurrentConnectingChannel];
    [menu removeAllItems];
    
    [ary enumerateObjectsUsingBlock:^(USBSocketConnectInfo *obj, NSUInteger idx, BOOL * _Nonnull stop) {
        NSString *name = obj.targetName;
        if (!name) {
            name = obj.uuid;
        }
        if(obj.targetModel) {
            name = [NSString stringWithFormat:@"%@：%@",obj.targetModel,name];
        }
        
        NSMenuItem * item = [[NSMenuItem alloc]initWithTitle:name action:@selector(clickDevice:) keyEquivalent:@""];
        item.tag = idx;
        item.target = self;
        item.state = NSControlStateValueOff;
        if ([obj.connectChannel.userInfo intValue] == [curCha.userInfo intValue]) {
            item.state = NSControlStateValueOn;
        }
        [menu addItem:item];
      }];
      [self.statusItem.menu setSubmenu:menu forItem:deviceMenu];
}

- (void)clickDevice:(NSMenuItem *)item {
    NSArray *array = [[USBDeviceSocketManager shareInstance] getAllConnetingSocketInfos];

    USBSocketConnectInfo *info = nil;
    if (item.tag >= 0 && item.tag < array.count) {
        info = array[item.tag];
        [[USBDeviceSocketManager shareInstance] selectDeviceUuid:info.uuid notify:YES];
        
        if ([[USBDeviceSocketManager shareInstance] getCurrentConnectingChannel] && ProjectSharedManager().settings.projectFilePath.length > 0) {
            [CocoaHotReloadSharedManager() setHotReloadStatus:CocoaHotReloadStatusIdle];
            HRLog(@"Select %@ Device",item.title);
        }
    }
}

@end
