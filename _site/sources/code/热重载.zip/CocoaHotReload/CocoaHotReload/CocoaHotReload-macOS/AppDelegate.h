//
//  AppDelegate.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2019/11/23.
//  Copyright © 2019 tencent. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "CocoaHotReloadManager.h"

#define SHARED_APP_DELEAGTE ((AppDelegate *)[NSApplication sharedApplication].delegate)

extern NSString * const kHotReloadKeyPath;
extern NSString * const kShowOrHideLogKeyPath;

extern NSString * const kDefaultAutoSelectKey;
extern NSString * const kDefaultAutoLaunchKey;

typedef NS_ENUM(NSUInteger, MenuItemType) {
    MenuItemTypeSelectProject,
    MenuItemTypeRecentProject,
    MenuItemTypeHotReload,
    MenuItemTypeStopHotReload,
    MenuItemTypeShowOrHideLog,
    MenuItemTypeSelectDevice,
    MenuItemTypePreferences,
    MenuItemTypeNewIssue,
    MenuItemTypeQuit,
};

@interface AppDelegate : NSObject <NSApplicationDelegate>

/// 显示状态的item
@property (nonatomic,strong) NSStatusItem *statusItem;

/// 设置状态栏显示的状态
/// @param status 所要显示的状态（green/yellow/red）
- (void)setStatusItemStatus:(CocoaHotReloadStatus)status;

/// 获取指定类型的item
/// @param type item的类型
- (NSMenuItem *)menuItemForType:(MenuItemType)type;

/// 处理指定类型的item点击事件
/// @param type item的类型
- (void)handleMenuItemActionWithType:(MenuItemType)type;

/// 获取当前状态
- (CocoaHotReloadStatus)currentStatus;

@end

