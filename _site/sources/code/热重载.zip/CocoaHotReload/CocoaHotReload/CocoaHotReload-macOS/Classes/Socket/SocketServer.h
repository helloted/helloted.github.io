//
//  SocketServer.h
//  CocoaHotReloadTool
//
//  Created by mambaxie on 2019/11/20.
//  Copyright © 2019 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CocoaSocket.h"

NS_ASSUME_NONNULL_BEGIN

@interface SocketServer : CocoaSocket

/// 运行
+ (void)run;

/// 当前服务器
+ (SocketServer *)currentServer;

@end

NS_ASSUME_NONNULL_END
