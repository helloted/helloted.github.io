//
//  LogViewController.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2019/11/23.
//  Copyright © 2019 tencent. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface LogViewController : NSViewController

/// 输入指定日志
/// @param logStr 输出的内容
- (void)printLog:(NSString *)logStr;

/// 获取所有日志输出
- (NSString *)allLogString;

@end

