//
//  ProjectManager.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/12/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "ProjectManager.h"
#import "CocoaHotReloadManager.h"
#import "CocoaHotReloadSettings.h"
#import "CocoaHotReloadServerDefine.h"
#import "LibManager.h"
#import "SignManager.h"
#import "SymbolManager.h"
#import "FileManager.h"
#import "CocoaFileTool.h"
#import "CocoaHotReloadManager.h"
#import "CocoaHotReloadServerDefine.h"
#import "AppDelegate.h"
#import "ShellService.h"
#import "AppleScriptService.h"
#import "SocketServer.h"
#import "FullScreenMaskWindow.h"
#import "NSString+CHRRegular.h"
#import "CompileCommandManager.h"
#import "FileDependentManager.h"
#import "PreferencesWindowController.h"
#import "CocoaHotReloadReportService.h"
#import "CocoaHotReloadDefine.h"
#import "LogViewController.h"
#import "MMKVService.h"
#import "CocoaHotReloadPreferences.h"
#import "CocoaHotReloadServerDefine.h"
#import "FileManager.h"
#import "SymbolManager.h"
#import "SignManager.h"
#import "CocoaHotReloadSettings.h"
#import "FileChangeManager.h"

/// 开始热重载
NSString * const kHotReloadStartLog = @"🚧 Hot reload start...";
/// 项目初始化
NSString * const kProjectInitLog = @"🚧 项目初始化...";

// 已添加到client的lib路径
static NSString * const kCompiledExportedSymbolFilePath = @"kCompiledExportedSymbolFilePath";

// 存储gExportedLibFilePathSetM key
static NSString const *kCacheExportedLibPathsKey = @"kCacheExportedLibPathsKey";
// 存储gExportedSymbolSetM key
static NSString const *kCacheExportedSymbolsKey = @"kCacheExportedSymbolsKey";
// 存储gLibPrivateSymbolsDicM key
static NSString const *kCacheLibPrivateSymbolsMapKey = @"kCacheLibPrivateSymbolsMapKey";
// 存储gTargetLibFilePathsDicM key
static NSString const *kCacheTargetLibFilePathsMapKey = @"kCacheTargetLibFilePathsMapKey";
// 存储TargetProductPaths key
static NSString const *kCacheTargetProductPathsMapKey = @"kCacheTargetProductPathsMapKey";
// 存储gSigningIdentity key
static NSString const *kCacheSigningIdentityKey = @"kCacheSigningIdentityKey";
// 存储gThinLibFilePathDicM key
static NSString const *kCacheThinLibFilePathMapKey = @"kCacheThinLibFilePathMapKey";
// 存储gExecutablePrivateExternalSymbols key
static NSString const *kCacheExecutablePrivateExternalSymbolsKey = @"kCacheExecutablePrivateExternalSymbolsKey";
// 存储可执行文件中的SwiftSymbols key
static NSString const *kCacheExecutableSwiftSymbolsKey = @"kCacheExecutableSwiftSymbolsKey";
// 存储不支持热重载的Swift符号列表 key
static NSString const *kCacheNotSupportHotReloadSwiftSymbolsKey = @"kCacheNotSupportHotReloadSwiftSymbolsKey";
// 存储Swift私有符号 key
static NSString const *kCachePrivateSwiftSymbolsMapKey = @"kCachePrivateSwiftSymbolsMapKey";
// 存储project configuration key
static NSString const *kCacheProjectConfigurationKey = @"kCacheProjectConfigurationKey";

@interface ProjectManager ()

/// 开始执行hot reload时间戳
@property (nonatomic, assign) NSTimeInterval startHotReloadTimeInterval;
/// 是否初始化完成
@property (nonatomic, assign, getter=isDidFinishInitProject) BOOL didFinishInitProject;
/// 是否项目初始化成功
@property (nonatomic, assign, getter=isProjectInitFaild) BOOL projectInitFaild;
/// 记录重编成功的产物(.o/.nib/.sotryboardc)文件
@property (nonatomic, strong) NSMutableSet<NSString *> *recompiledProductFilePathSetM;
/// 是否有动态库正等待发送到客户端
@property (nonatomic, assign) BOOL hasDylibWaitingToSendClient;

/// 设置
@property (nonatomic, strong) CocoaHotReloadSettings *settings;
/// 设置Map
@property (nonatomic, strong) NSMutableDictionary *settingsDicM;

/// 存储替换路径的映射
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSString *> *ouputFilePathDicM;

@end

@implementation ProjectManager

#pragma mark - Override
- (instancetype)init
{
    if (self = [super init]) {
        self.settings = [CocoaHotReloadSettings defaultSettings];
        self.settingsDicM = [NSMutableDictionary dictionary];
        self.ouputFilePathDicM = [NSMutableDictionary dictionary];
    }
    
    return self;
}

- (void)clearData
{
    self.startHotReloadTimeInterval = 0;
    self.didFinishInitProject = NO;
    self.projectInitFaild = NO;
    self.hasDylibWaitingToSendClient = NO;
    
    [self.recompiledProductFilePathSetM removeAllObjects];
    [self.ouputFilePathDicM removeAllObjects];
    
    /// 删除动态库&settings
    [self clearDylibDirectory];
}

#pragma mark - Public
/// 存储最新一次编译成功后的信息(link 库 & 签名等信息)
- (BOOL)saveParsedLastBuildLogInfo
{
    NSMutableDictionary *logInfoDicM = [NSMutableDictionary dictionary];
    LibManager *libManager = LibSharedManager();
    SymbolManager *symbolManager = SymbolSharedManager();
    logInfoDicM[kCacheExportedLibPathsKey] = libManager.exportedLibFilePathSetM;
    logInfoDicM[kCacheExportedSymbolsKey] = libManager.exportedSymbolSetM;
    logInfoDicM[kCacheLibPrivateSymbolsMapKey] = libManager.libPrivateSymbolsDicM;
    logInfoDicM[kCacheTargetLibFilePathsMapKey] = libManager.targetLibFilePathsDicM;
    logInfoDicM[kCacheThinLibFilePathMapKey] = libManager.thinLibFilePathDicM;
    logInfoDicM[kCacheTargetProductPathsMapKey] = libManager.targetProductPathDicM;
    logInfoDicM[kCacheSigningIdentityKey] = [SignSharedManager() signingIdentity];
    logInfoDicM[kCacheExecutablePrivateExternalSymbolsKey] = symbolManager.executablePrivateSymbolSetM;
    logInfoDicM[kCacheExecutableSwiftSymbolsKey] = symbolManager.executableSwiftSymbolSetM;
    logInfoDicM[kCacheNotSupportHotReloadSwiftSymbolsKey] = symbolManager.notSupportHotReloadSymbolSetM;
    logInfoDicM[kCachePrivateSwiftSymbolsMapKey] = symbolManager.privateSwiftSymbolsDicM;
    logInfoDicM[kCacheProjectConfigurationKey] = self.settings.configuration;

    NSString *cacheFilePath = [self cacheLogInfoFilePath];

    NSError *error;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager isExecutableFileAtPath:cacheFilePath]) {

        [fileManager removeItemAtPath:cacheFilePath error:&error];
        if (error) {
            WarningLog(@"存储最新log信息失败！%@", error.localizedDescription);
            return NO;
        }
    }

    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:logInfoDicM];
    BOOL succeed = [data writeToFile:cacheFilePath atomically:YES];

    return succeed;
}

// 获取log信息
- (void)readLogInfoFromFile
{
    NSDictionary *logInfo = [NSKeyedUnarchiver unarchiveObjectWithFile:[self cacheLogInfoFilePath]];
    if (logInfo.allValues.count > 0) {
        LibManager *libManager = LibSharedManager();
        libManager.exportedLibFilePathSetM = logInfo[kCacheExportedLibPathsKey];
        libManager.exportedSymbolSetM = logInfo[kCacheExportedSymbolsKey];
        libManager.libPrivateSymbolsDicM = logInfo[kCacheLibPrivateSymbolsMapKey];
        libManager.targetLibFilePathsDicM = logInfo[kCacheTargetLibFilePathsMapKey];
        libManager.targetProductPathDicM = logInfo[kCacheTargetProductPathsMapKey];
        libManager.thinLibFilePathDicM = logInfo[kCacheThinLibFilePathMapKey];
        SignSharedManager().signingIdentity = logInfo[kCacheSigningIdentityKey];
        SymbolSharedManager().executablePrivateSymbolSetM = logInfo[kCacheExecutablePrivateExternalSymbolsKey] ?: [NSMutableSet set];
        SymbolSharedManager().executableSwiftSymbolSetM = logInfo[kCacheExecutableSwiftSymbolsKey] ?: [NSMutableSet set];
        SymbolSharedManager().notSupportHotReloadSymbolSetM = logInfo[kCacheNotSupportHotReloadSwiftSymbolsKey] ?: [NSMutableSet set];
        SymbolSharedManager().privateSwiftSymbolsDicM = logInfo[kCachePrivateSwiftSymbolsMapKey] ?: [NSMutableDictionary dictionary];
        self.settings.configuration = logInfo[kCacheProjectConfigurationKey];
    }
}

/// 开始热重载
- (void)startHotReload
{
    if (self.isProjectInitFaild) {
        ErrorLog(@"请先完成项目初始化!");
        return;
    }
    self.startHotReloadTimeInterval = [[NSDate date] timeIntervalSince1970];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0), ^{
        [self rebuildDidModifyFilesIfNeed];
    });
}

/// 停止热重载
- (void)stopHotReload
{
    // 取消Apple script脚本执行
    [AppleScriptService cancelScript];
    
    // 改变图标状态
    [CocoaHotReloadSharedManager() setHotReloadStatus:CocoaHotReloadStatusIdle];
    
    HRLog(@"😭 Hot reload is Canceled !");
}

- (NSTimeInterval)lastStartHotReloadTime
{
    return self.startHotReloadTimeInterval;
}

- (void)updateMmkvCacheDirIfNeed
{
    NSString *mmkvDir = [[FileSharedManager() cocoaHotReloadBuildLogsDir] stringByAppendingPathComponent:@"mmkv"];
    [MMKVService setCacheDir:mmkvDir];
}

/// 热重载开启后，做一些初始化
- (void)doProjectInitWithCompletion:(void (^)(void))completion
{
    HRLog(@"%@", kProjectInitLog);
    self.didFinishInitProject = NO;
    
    // 检查ProjectBuildDir
    NSString *projectBuildDir = [FileSharedManager() projectBuildDir];
    if (![[NSFileManager defaultManager] fileExistsAtPath:projectBuildDir]) {
        ErrorLog(@"无法找到项目编译产物文件夹（DerivedData有误），请检查Mac app\"Preferences-Derived Data\"配置与Xcode中\"Preferences-Locations-DerivedData\"是否保持一致!");
        HRLog(@"❌ 项目初始化失败，项目编译产物目录不存在！");
        self.projectInitFaild = YES;
        return;
    }
    
    [self updateMmkvCacheDirIfNeed];
    
    NSTimeInterval initBegin = [[NSDate date] timeIntervalSince1970];
    
    // 解压编译日志
    [FileSharedManager() unzipAllBuildLogsIfNeed];

    NSString *lastLogFilePath = [FileSharedManager() lastBuildSucceedUnzipProjectLogFilePath];
    // 没有新增编译project文件，使用本地缓存
    BOOL useLocalProjectCache = ![[NSFileManager defaultManager] fileExistsAtPath:lastLogFilePath];
    if (useLocalProjectCache) {
        HRLog(@"👏 无新增编译日志，使用本地缓存数据！");
        [self readLogInfoFromFile]; // 读取本地信息
#if !CMDTOOL
        NSArray *swiftSymbols = [SymbolSharedManager() projectSwiftSymbols];
        [[SocketServer currentServer] sendSocketCommand:SocketCommandProjectSwiftSymbols dictionary:@{ @"projectSwiftSymbols" : swiftSymbols ?: @[] }];
#endif
    }
    
    dispatch_group_t group = dispatch_group_create();
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    if (!useLocalProjectCache) {
        dispatch_group_enter(group);
        dispatch_group_async(group, queue, ^{
            // 解析编译日志和缓存编译指令
            [CompileCommandSharedManager() parseCompileLogAndCacheCompileCommandIfNeed];
            dispatch_group_leave(group);
        });
        
        dispatch_group_enter(group);
        dispatch_group_async(group, queue, ^{
            HRLog(@"🚧 获取私有符号库...");
            NSTimeInterval findLibBegin = [[NSDate date] timeIntervalSince1970];
            // 查找私有符号库
            [LibSharedManager() findPrivateSymbolsLib];
            NSTimeInterval findLibEnd = [[NSDate date] timeIntervalSince1970];
            HRLog(@"👏 获取私有符号库结束 %.2f seconds", findLibEnd - findLibBegin);
           dispatch_group_leave(group);
        });

        dispatch_group_enter(group);
        dispatch_group_async(group, queue, ^{
            HRLog(@"🚧 获取项目的私有符号（private external symbols）和Swift symbols...");
            NSTimeInterval privateExternalBegin = [[NSDate date] timeIntervalSince1970];
            // 查找可执行文件和Embed framework私有符号和Swift符号
            [SymbolSharedManager() findProjectPrivateAndSwiftSymbols];
            NSTimeInterval privateExternalEnd = [[NSDate date] timeIntervalSince1970];
            HRLog(@"👏 获取项目的私有符号（private external symbols）和Swift symbols完成 %.2f seconds", privateExternalEnd - privateExternalBegin);
#if !CMDTOOL
            NSArray *swiftSymbols = [SymbolSharedManager() projectSwiftSymbols];
            [[SocketServer currentServer] sendSocketCommand:SocketCommandProjectSwiftSymbols dictionary:@{ @"projectSwiftSymbols" : swiftSymbols ?: @[] }];
#endif
           dispatch_group_leave(group);
        });
        
        if (![self isSimulator] || [self isMacCatalyse]) { // 非模拟器再获取签名 或者非macCatalyse
            dispatch_group_enter(group);
            dispatch_group_async(group, queue, ^{
               HRLog(@"🚧 获取app签名...");
               NSTimeInterval begin = [[NSDate date] timeIntervalSince1970];
               // 获取编译签名
               NSString *signingIdentity = [SignSharedManager() signingIdentityForApp];
               NSTimeInterval end = [[NSDate date] timeIntervalSince1970];
               if (signingIdentity) {
                   HRLog(@"👏 获取app签名成功：%@ %.2f seconds", signingIdentity, end - begin);
               } else {
                   HRLog(@"❌ 获取app签名失败：%@ %.2f seconds", signingIdentity, end - begin);
               }
               dispatch_group_leave(group);
            });
        }
        
        // 获取项目中所有Swift文件
        dispatch_group_enter(group);
        dispatch_group_async(group, queue, ^{
            [FileSharedManager() findAndSaveProjectAllSwiftFileAbsolutePaths];
            if ([FileSharedManager() compileSwiftFileNamesForProject].count > 0) { // 存在Swift文件
                [SymbolSharedManager() findProjectAllSwiftFilePrivateSymbols];
            }
           dispatch_group_leave(group);
        });
        
    }
    
    dispatch_group_notify(group, queue, ^{
        if (!useLocalProjectCache) {
            // 保存last build info
            BOOL saveSuccess = [self saveParsedLastBuildLogInfo];
            if (saveSuccess) { // 保存信息成功后 清空
                // 清除unzip log
                [FileSharedManager() clearAllUnzipLog];
            }
        }
        self.projectInitFaild = NO;
        self.didFinishInitProject = YES;
        NSTimeInterval initEnd = [[NSDate date] timeIntervalSince1970];
        NSTimeInterval duration = initEnd - initBegin;
        HRLog(@"🎉 项目初始化完成！%.2f seconds", duration);
        if (completion) {
            completion();
        }
        NSString *allLog = [CocoaHotReloadSharedManager() allLogInLogWindow];
        NSRange range = [allLog rangeOfString:kProjectInitLog options:NSBackwardsSearch];
        NSString *initLog;
        if (range.location != NSNotFound) {
            initLog = [allLog substringFromIndex:range.location];
        } else {
            initLog = allLog;
        }
        CocoaHotReloadReport(@"project_init", 0, duration * 1000, initLog, nil);
        if ([[LibSharedManager() exportedLibPaths] count] > 0) {
            // 发送exported symbols libs to client
            // [self sentExportedSymbolsLibsToClient];
        }
    });
}

/// 生成动态库地址
- (NSString *)generateDylibFilePath
{
    static int dylibIndex = 0;
    dylibIndex++;
    NSString *dylibFilePath = [NSString stringWithFormat:@"%@/CocoaHotReload_%d.dylib", [self cocoaHotReloadTmpDirectoryPath], dylibIndex];
    
    return dylibFilePath;
}

/// 清除动态库
- (void)clearDylibDirectory
{
    NSString *directoryPath = [FileSharedManager() tmpDirAndCreateIfNeed];
    if (!directoryPath) {
        return;
    }
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:directoryPath]) {
        [fileManager removeItemAtPath:directoryPath error:nil];
    }
    [fileManager createDirectoryAtPath:directoryPath withIntermediateDirectories:NO attributes:nil error:nil];
}

/// 发送exported symbol framework or lib
- (void)sentExportedSymbolsLibsToClient
{
    [self handleRebuildCompiletionWithCompiledFilePaths:@[kCompiledExportedSymbolFilePath]
                                 compileFailedFileNames:nil
                                compileTimeOutFileNames:nil
                                           oFilePathDic:nil
                                               duration:0.0
                                             completion:nil];
}

- (void)setupSettings:(void (^)(CocoaHotReloadSettings * _Nonnull settings))settingsBlock
{
    if (settingsBlock) {
        settingsBlock(self.settings);
    }
}

- (void)clearSettings
{
    if (self.settings.executableName) {
        self.settingsDicM[self.settings.executableName] = self.settings;
    }
    self.settings = [CocoaHotReloadSettings defaultSettings];
}

- (void)updateSettingsIfNeed
{
    CocoaHotReloadSettings *cachedSettings = self.settingsDicM[self.settings.executableName];
    if (cachedSettings.projectFilePath) {
        self.settings.projectFilePath = cachedSettings.projectFilePath;
        self.settings.projectName = cachedSettings.projectName;
        self.settings.bundleIDs = cachedSettings.bundleIDs;
    }
}

- (CocoaHotReloadSettings *)settings
{
    return _settings;
}

- (BOOL)isSimulator
{
    return ![_settings.arch hasPrefix:@"arm"];
}

- (CocoaHotReloadScene)currentScene
{
    return self.settings.currentScene;
}

- (BOOL)isMacCatalyse
{
    return [_settings.platformName isEqualToString:@"maccatalyst"];
}

- (NSString *)originalOutputPathForCurrentFilePath:(NSString *)currentFilePath
{
    return self.ouputFilePathDicM[currentFilePath] ?: currentFilePath;
}

#pragma mark - Private
- (NSString *)cacheLogInfoFilePath
{
    return  [[FileSharedManager() cocoaHotReloadBuildLogsDir] stringByAppendingPathComponent:@"lastLogInfo.plist"];
}


- (BOOL)isHotReloadBusy
{
    __block BOOL isBusy = NO;
    
    [CocoaHotReloadTool runOnMainThreadSync:^{
        isBusy = [((AppDelegate *)[NSApplication sharedApplication].delegate) currentStatus] == CocoaHotReloadStatusBusy;
    }];
    
    return isBusy;
}

// 重编译文件
- (NSString *)rebuildClassWithSourceFilePath:(NSString *)sourceFilePath
{
    NSString *recompileCommand = [CompileCommandSharedManager() compileCommandForSourceFilePath:sourceFilePath];
    
    if (!recompileCommand) {
        ErrorLog("Recompile command not found for %s", sourceFilePath.UTF8String);
        return nil;
    }
    
    NSString *fullFileName = [sourceFilePath lastPathComponent];
    
    // 矫正swift编译依赖的临时文件路径： '/var/folders/0r/5f_3gs9j4nbd04p93hhppysw0000gn/T/sources-f6adcc'
    NSString *fileListPath = [recompileCommand chr_subStringBetweenFrom:@" -filelist " to:@" " backwardsSearch:NO];
    NSString *fileListPathByCocoaHotReload = [ProjectSharedManager() settings].fileListPath ?: [FileSharedManager() fileListPathForProjectAllSwiftFileAbsolutePaths];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    if (fileListPath.length > 0 && [fileManager fileExistsAtPath:fileListPathByCocoaHotReload]) {
        recompileCommand = [recompileCommand stringByReplacingOccurrencesOfString:fileListPath withString:fileListPathByCocoaHotReload];
    }
    
#if CMDTOOL
    // 替换输入源码路径和输出
    NSString *outputString = [recompileCommand chr_subStringFrom:@" -o " to:[NSString stringWithFormat:@"/%@.o", [fullFileName stringByDeletingPathExtension]] backwardsSearch:NO];
    NSArray *components = [recompileCommand componentsSeparatedByString:@" "];
    NSMutableArray *inputFilePathsM = [NSMutableArray array];
    for (NSString *component in components) {
        if ([component hasSuffix:[NSString stringWithFormat:@"/%@", fullFileName]]) {
            [inputFilePathsM addObject:component];
        }
    }
    if (outputString && inputFilePathsM.count > 0) {
        for (NSString *fileName in inputFilePathsM) {
            recompileCommand = [recompileCommand stringByReplacingOccurrencesOfString:fileName withString:[NSString stringWithFormat:@"%@", sourceFilePath]];
        }
        NSString *originalOutput = [outputString substringFromIndex:@" -o ".length];
        NSString *output = [ProjectSharedManager().settings.cmdProductDir stringByAppendingFormat:@"/%@.o", [fullFileName stringByDeletingPathExtension]];
        recompileCommand = [recompileCommand stringByReplacingOccurrencesOfString:outputString withString:[NSString stringWithFormat:@" -o %@", output]];
        self.ouputFilePathDicM[output] = originalOutput;
    } else {
        if ([recompileCommand hasSuffix:@".storyboard"] || [recompileCommand hasSuffix:@".xib"]) {
            NSRange range = [recompileCommand rangeOfString:@" " options:NSBackwardsSearch];
            if (range.location != NSNotFound) {
                NSString *prefixString = [recompileCommand substringToIndex:range.location+range.length];
                recompileCommand = [prefixString stringByAppendingString:sourceFilePath];
            }
        }
    }
#endif

    NSString *productFilePath;
    if ([fullFileName hasSuffix:@".xib"]) {
        productFilePath = [FileSharedManager() compiledProductFilePathForFullFileName:fullFileName pathExtersion:@"nib"];
    } else if ([fullFileName hasSuffix:@".storyboard"]) {
        productFilePath = [FileSharedManager() compiledProductFilePathForFullFileName:fullFileName pathExtersion:@"storyboardc"];
    } else if ([recompileCommand hasSuffix:@".o"]) {
        NSString *outputPath = [recompileCommand chr_subStringBetweenFrom:@" -o " to:@".o" backwardsSearch:YES];
        if (outputPath) {
            productFilePath = [outputPath stringByAppendingPathExtension:@"o"];
        }
    }
    
    if (!productFilePath) {
        ErrorLog(@"Product file path not found !");
        return nil;
    }
    
    NSString *logFile = [NSString stringWithFormat:@"%@/%@.log", [self cocoaHotReloadTmpDirectoryPath], [fullFileName stringByReplacingOccurrencesOfString:@"." withString:@"_"]];
    
    
    // 2>&1 代表： stdout 和 stderr 合并后重定向到 file
    NSString *rebuildCommand = [NSString stringWithFormat:@"%@ > %@ 2>&1", recompileCommand, logFile];
    
    // 替换-r 为 &&
    recompileCommand = [recompileCommand stringByReplacingOccurrencesOfString:@"\r" withString:@" && "];
    
    NSString *shFile = [logFile stringByReplacingCharactersInRange:NSMakeRange(logFile.length-3, 3) withString:@"sh"];
    [recompileCommand writeToFile:shFile atomically:YES encoding:NSUTF8StringEncoding error:nil];
    HRLog("🚧 Compiling %s", sourceFilePath.UTF8String);
    
    BOOL isSuccess = [ShellService doShellWithSource:rebuildCommand];
    
    if (isSuccess) { // 编译成功
        return productFilePath;
    }
    
    NSError *error;
    NSString *errMsg = [NSString stringWithContentsOfFile:logFile encoding:NSUTF8StringEncoding error:&error];
    if (error || !errMsg) {
        ErrorLog("编译日志解析失败：%s errMsg : %s ", logFile.UTF8String, error.localizedDescription.UTF8String);
        return nil;
    }
    
    NSRegularExpression *expression = [NSRegularExpression regularExpressionWithPattern:@": ((error)|(noite)|(warning)):" options:NSRegularExpressionCaseInsensitive error:nil];
    
    NSArray *matchResults = [expression matchesInString:errMsg options:0 range:NSMakeRange(0, errMsg.length)];
    
    NSMutableString *errMsgStringM = [NSMutableString string];
    
    for (int i = 0; i < matchResults.count; i++) {
        NSTextCheckingResult *result = matchResults[i];
        NSString *resultStr = [errMsg substringWithRange:result.range];
        
        if ([resultStr isEqualToString:@": error:"]) { // 错误
            NSRange previousRange = NSMakeRange(0, 0);
            // 寻找最近一个\n
            NSString *subStr = [errMsg substringToIndex:result.range.location];
            // 从后往前找
            NSRange nearestPreviousChangeLineRange = [subStr rangeOfString:@"\n" options:NSBackwardsSearch];
            if (nearestPreviousChangeLineRange.location != NSNotFound) { // 找到了， 记录下
                previousRange = nearestPreviousChangeLineRange;
            }
            
            BOOL isErrorNode = YES;
            BOOL hasFoundNextNode = NO;
            while (matchResults.count > 2 && i < matchResults.count - 2 && isErrorNode) {
                i = i+1;
                NSTextCheckingResult *nextReslt = matchResults[i];
                NSString *nextResultStr = [errMsg substringWithRange:nextReslt.range];
                if ([nextResultStr isEqualToString:@": error:"]) { // "错误" 的节点
                    continue;
                }

                // 寻找最近一个\n
                NSString *subStr = [errMsg substringWithRange:NSMakeRange(result.range.location, nextReslt.range.location - result.range.location)];
                isErrorNode = NO;
                // 非 "错误" 的节点
                NSRange nearestPreviousChangeLineRange = [subStr rangeOfString:@"\n" options:NSBackwardsSearch];
                if (nearestPreviousChangeLineRange.location != NSNotFound) { // 找到了， 记录下
                    NSRange errMsgRange = NSMakeRange(previousRange.location, (result.range.location + nearestPreviousChangeLineRange.location - previousRange.location) + nearestPreviousChangeLineRange.length);
                    NSString *errMsgString = [errMsg substringWithRange:errMsgRange];
                    [errMsgStringM appendString:errMsgString];
                    hasFoundNextNode = YES;
                }
            }
            
            if (!hasFoundNextNode) {
                NSString *errMsgString = [errMsg substringFromIndex:previousRange.location];
                [errMsgStringM appendString:errMsgString];
            }
        }
    }
    
    if (errMsgStringM.length == 0) {
        [errMsgStringM appendString:errMsg];
    }
    
    NSString *tipMsg = [errMsg chr_subStringFrom:@"\n" to:@"\n" backwardsSearch:YES];
    
    if (tipMsg && ![errMsgStringM hasSuffix:tipMsg]) {
        [errMsgStringM appendString:tipMsg];
    }
    ErrorLog("%s", errMsgStringM.UTF8String);
    return nil;
}

- (BOOL)isProjectDidFinishInit
{
    return self.didFinishInitProject;
}

- (BOOL)shouldWaitProjectDidFinishInit {
    
    if ([self isProjectDidFinishInit]) {
        return NO;
    }
    
    NSTimeInterval duration = 0.0;
    while (![self isProjectDidFinishInit] && duration < 60) { // 还未初始化完成, 60秒超时
        usleep(100000); // 微秒
        duration += 0.1;
    }
    
    if (![self isProjectDidFinishInit]) {
        HRLog(@"⚠️ 项目初始化未完成，请注意！！！");
    }
    
    return NO;
}

- (void)waitProjectDidFinishInitIfNeed
{
    if (![self isProjectDidFinishInit]) {
        HRLog(@"⏰ 等待项目初始化完成...");
        
        dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            if (![self shouldWaitProjectDidFinishInit]) {
                dispatch_semaphore_signal(semaphore);
            }
        });
        dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
    }
}

- (void)rebuildDidModifyFilesIfNeed
{
    NSArray *filePaths = [FileChangeSharedManager() didModifyFilePaths];
    [self recompileFilesForFilePaths:filePaths completion:nil];
}

- (void)recompileFilesForFilePaths:(NSArray<NSString *> *)filePaths completion:(void(^_Nullable)(NSDictionary *))completion
{
    if (filePaths.count > 0) {
        [CocoaHotReloadSharedManager() setHotReloadStatus:CocoaHotReloadStatusBusy];
        HRLog(@"%@", kHotReloadStartLog);
        NSMutableSet *needRebuildFilePathSetM = [NSMutableSet set];
        NSMutableSet *headerFilePathSetM = [NSMutableSet set];
        for (NSString *filePath in filePaths) {
            NSString *pathExtension = [filePath pathExtension];
            if ([pathExtension isEqualToString:@"h"]) { // 新增依赖文件
                [headerFilePathSetM addObject:filePath];
            } else {
                [needRebuildFilePathSetM addObject:filePath];
            }
        }

        if (headerFilePathSetM.count > 0) {
            dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
            [FileDependentSharedManager impletionFilePathsDependentHeaderFilePaths:headerFilePathSetM.allObjects compiletion:^(NSDictionary<NSString *, NSArray *> *resultDic) {
                for (NSArray *impletionFilePaths in resultDic.allValues) {
                    [needRebuildFilePathSetM addObjectsFromArray:impletionFilePaths];
                }
                dispatch_semaphore_signal(semaphore);
            }];

            NSTimeInterval timeout = 15; // 超时15s
            dispatch_semaphore_wait(semaphore, dispatch_time(DISPATCH_TIME_NOW, (int64_t)(timeout * NSEC_PER_SEC)));
        }
       
        NSTimeInterval compileBegin = [[NSDate date] timeIntervalSince1970];
        NSMutableSet *compiledFilePathSetM = [NSMutableSet set];
        NSMutableSet *shellcompileFailedFileNameSetMetM = [NSMutableSet set];

        NSMutableArray *needXcodeBuildfileNamesM = [NSMutableArray array];
        NSMutableArray *needShellBuildFilePathsM = [NSMutableArray array];
        // key : filePath value : compileFilePath
        NSArray *needRebuildFilePaths = needRebuildFilePathSetM.allObjects;
#if CMDTOOL
        [needShellBuildFilePathsM addObjectsFromArray:needRebuildFilePaths];
#else
        for (NSString *filePath in needRebuildFilePaths) {
            NSString *fullFileName = [filePath lastPathComponent];
            BOOL hasCompiledProduct = [FileSharedManager() hasCompiledProductFilePathForFullFileName:fullFileName];
            if (!hasCompiledProduct) { // 没有编译
                [needXcodeBuildfileNamesM addObject:fullFileName];
            } else { // 已编译 有log
                [needShellBuildFilePathsM addObject:filePath];
            }
        }
#endif
       
        // 等待项目初始化完成
        [self waitProjectDidFinishInitIfNeed];
        
        NSMutableDictionary<NSString *, NSString *> *oFilePathDicM = [NSMutableDictionary dictionary];
       
        void (^compileFilesByShell)(NSArray *filePaths) = ^(NSArray *filePaths) {
            if (filePaths.count == 0) {
                return;
            }
            dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
           
            dispatch_group_t group = dispatch_group_create();
            dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
           
            for (NSString *filePath in filePaths) {
                dispatch_group_enter(group);
                dispatch_group_async(group, queue, ^{
                    NSString *compiledFilePath = [self rebuildClassWithSourceFilePath:filePath];
                    @synchronized (self) {
                        if (!compiledFilePath) {
                            [shellcompileFailedFileNameSetMetM addObject:[filePath lastPathComponent]];
                        } else {
                            [compiledFilePathSetM addObject:compiledFilePath];
                            oFilePathDicM[filePath] = compiledFilePath;
                        }
                    }
                    dispatch_group_leave(group);
                });
            }
           
            dispatch_group_notify(group, queue, ^{
                dispatch_semaphore_signal(semaphore);
            });
           
            dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);

        };
       
        if (needXcodeBuildfileNamesM.count == 0) {
            compileFilesByShell(needShellBuildFilePathsM);
            NSTimeInterval compileEnd = [[NSDate date] timeIntervalSince1970];
            
            [self handleRebuildCompiletionWithCompiledFilePaths:compiledFilePathSetM.allObjects
                                         compileFailedFileNames:shellcompileFailedFileNameSetMetM.allObjects
                                        compileTimeOutFileNames:nil
                                                   oFilePathDic:oFilePathDicM.copy
                                                       duration:compileEnd - compileBegin
                                                     completion:completion];
            return;
        }
       
        NSString *appleScriptSource = [self compileFileAppleScriptWithFileNames:needXcodeBuildfileNamesM];
        [FullScreenMaskWindow show];
        [AppleScriptService doScriptWithSource:appleScriptSource completionHandler:^(NSError * _Nullable error) {
        // 脚本执行结束
        [FullScreenMaskWindow dismiss];
        NSLog(@"脚本执行结束 %@", error);
        if (error) {
            ErrorLog(@"执行AppleScript失败 ： %@", [error localizedDescription]);
            HRLog(@"请打开《系统偏好设置》->安全与隐私->隐私->辅助功能 添加 %@ app", [[NSBundle mainBundle] infoDictionary][@"CFBundleExecutable"]);
        } else { // 执行成功 加载动态库
            NSMutableSet *compileSucceedFileNameSetM = [NSMutableSet set];
            NSMutableSet *compileFailedFileNameSetM = [NSMutableSet set];
            NSTimeInterval timeout = 30;
            NSTimeInterval duration = 0;
            HRLog(@"🚧 等待Xcode编译指定文件完成...");
            while ((compileSucceedFileNameSetM.count + compileFailedFileNameSetM.count) < needXcodeBuildfileNamesM.count && duration < timeout) {
                if (![self isHotReloadBusy]) { // hot reload 被中断 直接返回
                    return ;
                }
                for (NSString *fullFileName in needXcodeBuildfileNamesM) {
                BOOL hasCompiledProduct = [FileSharedManager() hasCompiledProductFilePathForFullFileName:fullFileName];
                if (hasCompiledProduct) { // 编译完成
                    NSString *compiledFilePath = [FileSharedManager() compiledProductFilePathForFullFileName:fullFileName pathExtersion:@"o"];
                    if ([compiledFilePath hasSuffix:@".o"]) { // 编译成功
                        NSDictionary *fileAttr = [[NSFileManager defaultManager] attributesOfItemAtPath:compiledFilePath error:&error];
                        NSTimeInterval modifyTime = [[fileAttr fileModificationDate] timeIntervalSince1970];
                        if (modifyTime > compileBegin) {
                            [compileSucceedFileNameSetM addObject:fullFileName];
                            [compiledFilePathSetM addObject:compiledFilePath];
                        }
                    } else { // 编译失败
                            [compileFailedFileNameSetM addObject:fullFileName];
                        }
                    }
                }
                   
                usleep(200000); // 微秒
                duration += 0.2;
            }
               
            HRLog(@"👏 Xcode编译指定文件完成");

            /// compile file by shell
            compileFilesByShell(needShellBuildFilePathsM);

            /// add shell compile failed file names
            [compileFailedFileNameSetM addObjectsFromArray:shellcompileFailedFileNameSetMetM.allObjects];

            NSMutableSet *compileTimeOutFileNameSetM = [NSMutableSet new];
            if (compileFailedFileNameSetM.count + compileSucceedFileNameSetM.count != needXcodeBuildfileNamesM.count) {
                for (NSString *fileName in needXcodeBuildfileNamesM) {
                    if (!([compileSucceedFileNameSetM containsObject:fileName] || [compileFailedFileNameSetM containsObject:fileName])) {
                        [compileTimeOutFileNameSetM addObject:fileName];
                    }
                }
            }

            NSTimeInterval compileEnd = [[NSDate date] timeIntervalSince1970];
               
            [self handleRebuildCompiletionWithCompiledFilePaths:compiledFilePathSetM.allObjects
                                         compileFailedFileNames:compileFailedFileNameSetM.allObjects
                                        compileTimeOutFileNames:compileTimeOutFileNameSetM.allObjects
                                                   oFilePathDic:oFilePathDicM.copy
                                                       duration:compileEnd - compileBegin
                                                     completion:completion];
           }
        }];
   } else {

       if (completion) {
           completion(nil);
       }
       
       ErrorLog(@"未监听到文件改动，请检查修改的文件是否保存或者Select Project是否正确。");
   }
}

- (void)handleRebuildCompiletionWithCompiledFilePaths:(NSArray<NSString *> *)compiledFilePaths
                               compileFailedFileNames:(NSArray<NSString *> *)compileFailedFileNames
                              compileTimeOutFileNames:(NSArray<NSString *> *)compileTimeOutFileNames
                                         oFilePathDic:(NSDictionary<NSString *, NSString *> *)oFilePathDic
                                             duration:(NSTimeInterval)duration
                                           completion:(void(^_Nullable)(NSDictionary *))completion
{
    NSMutableSet *failOrTimeoutFileNameSetM = [NSMutableSet set];
    [failOrTimeoutFileNameSetM addObjectsFromArray:compileFailedFileNames];
    [failOrTimeoutFileNameSetM addObjectsFromArray:compileTimeOutFileNames];
    
    NSMutableString *failOrTimeoutFileNamesStringM = [NSMutableString string];
    if (failOrTimeoutFileNameSetM.count > 0) {
        [failOrTimeoutFileNamesStringM appendFormat:@"File names (%@)", [failOrTimeoutFileNameSetM.allObjects componentsJoinedByString:@"  "]];

        ErrorLog(@"Compile fail! Fail(%ld) %@ %.2f seconds", failOrTimeoutFileNameSetM.allObjects.count, failOrTimeoutFileNamesStringM, duration);
        
        CocoaHotReloadReport(@"hot_reload", CocoaHotReloadCodeErrorCompileFailed, duration * 1000, nil, nil);
        return;
    }
    HRLog(@"👏 Compile done! ✅ Success all.  %.2f seconds", duration);
    
    if (compiledFilePaths.count > 0) {
        NSMutableSet *compiledFilePathSetM = [NSMutableSet setWithArray:compiledFilePaths];
        if ([self currentScene] == CocoaHotReloadSceneForTests) {
            if (!self.recompiledProductFilePathSetM) {
                self.recompiledProductFilePathSetM = [NSMutableSet set];
            }
            [self.recompiledProductFilePathSetM addObjectsFromArray:compiledFilePaths];
            compiledFilePathSetM = self.recompiledProductFilePathSetM;
        }
        
        NSMutableArray *compiledStoryboardOrXibFilePathsM = [NSMutableArray array];
        NSMutableArray *compiledOFilePathsM = [NSMutableArray array];
        for (NSString *filePath in compiledFilePathSetM.allObjects) {
            if ([filePath hasSuffix:@".o"]) {
                [compiledOFilePathsM addObject:filePath];
            } else if ([filePath hasSuffix:@".nib"] ||
                       [filePath hasSuffix:@".storyboardc"]) {
                [compiledStoryboardOrXibFilePathsM addObject:filePath];
            }
        }
        int totalDataLength = 0;
        NSMutableDictionary *dataInfoDicM = [NSMutableDictionary dictionary];
        
        NSMutableDictionary *infoM = [NSMutableDictionary dictionary];
        infoM[@"startTimeInterval"] = @(self.startHotReloadTimeInterval);
        if (compiledOFilePathsM.count > 0) {
            NSString *dylibFilePath = [self generateDylibFilePath];
            NSString *customDylibName = self.settings.customDylibName;
            if (customDylibName) {
                dylibFilePath = [[dylibFilePath stringByDeletingLastPathComponent] stringByAppendingPathComponent:customDylibName];
            }
            infoM[@"dylibFilePath"] = dylibFilePath;
            NSFileManager *fileManager = [NSFileManager defaultManager];
            NSError *error;
            if ([fileManager fileExistsAtPath:dylibFilePath]) {
                [fileManager removeItemAtPath:dylibFilePath error:&error];
            }
            if (error) {
                ErrorLog(@"Remove dylib file error : %@", error);
            }
            NSString *shellSource = [self generateDylibAndCodeSignShellScriptWithCompiledFilePaths:compiledOFilePathsM
                                                                                      oFilePathDic:(NSDictionary<NSString *, NSString *> *)oFilePathDic
                                                                                     dylibFilePath:dylibFilePath];
            ShellResult *result = [ShellService doShellOutputWithSource:shellSource];
            if (result.isSuccess) {
                // 编译成功，清除临时link库数据
                [LibSharedManager() clearTempDataForPerlink];
                // 添加类信息
                NSDictionary *classInfo = [self classInfoForDylibWithDylibFilePath:dylibFilePath compiledOFilePaths:compiledOFilePathsM];
                [infoM addEntriesFromDictionary:classInfo];
                
                NSData *dylibData = [NSData dataWithContentsOfFile:dylibFilePath];
                if (dylibData.length) {
                    [dataInfoDicM setValue:dylibData forKey:@"data"];
                    totalDataLength += dylibData.length;
                }
            } else {
                if (completion) {
                    completion(nil);
                }
                ErrorLog(@"执行Shell 脚本失败");
            }
        }
            
        NSMutableDictionary *storyboardOrXibInfoM = [NSMutableDictionary dictionary];
        for (NSString *storyboardOrXibFilePath in compiledStoryboardOrXibFilePathsM) {
            NSData *data;
            if ([storyboardOrXibFilePath hasSuffix:@".storyboardc"]) { // 文件夹
                NSFileManager *fileManager = [NSFileManager defaultManager];
                NSArray<NSString *> *subpaths = [fileManager subpathsAtPath:storyboardOrXibFilePath];
                NSMutableDictionary *storyboardInfoM = [NSMutableDictionary dictionary];
                for (NSString *subpath in subpaths) {
                    NSData *data = [NSData dataWithContentsOfFile:[storyboardOrXibFilePath stringByAppendingPathComponent:subpath]];
                    if (data.length > 0) {
                        totalDataLength += data.length;
                        storyboardInfoM[subpath] = data;
                    }
                }
                [storyboardOrXibInfoM setValue:storyboardInfoM forKey:storyboardOrXibFilePath.lastPathComponent];
            } else {
                data = [NSData dataWithContentsOfFile:storyboardOrXibFilePath];
            }
            if (data.length > 0) {
                [storyboardOrXibInfoM setValue:data forKey:storyboardOrXibFilePath.lastPathComponent];
                totalDataLength += data.length;
            }
        }
        
        infoM[@"storyboardOrXibInfo"] = storyboardOrXibInfoM;
            
        if (completion) {
            completion(infoM);
        }
#if !CMDTOOL
        if (![self isHotReloadBusy]) {
            return;
        }
        
        dataInfoDicM[@"info"] = infoM;
        
        if (totalDataLength <= 0) {
            ErrorLog(@"Data is nil");
            return;
        }
        
        if ([self currentScene] == CocoaHotReloadSceneDefault) {
            // 发送data到Client
            HRLog(@"Sent data(%.2fkb) to client...", totalDataLength / 1024.0);
            [[SocketServer currentServer] sendSocketCommand:SocketCommandSentData dictionary:dataInfoDicM];
        } else if ([self currentScene] == CocoaHotReloadSceneForTests) {
            HRLog(@"Test wthout building by Xcode...");
            NSString *source = @"\
            tell application \"Xcode\" \n \
                activate \n \
                tell application \"System Events\" \n \
                    tell application process \"Xcode\" \n \
                        keystroke \"u\" using {command down, control down} \n \
                    end tell \n \
                end tell \n \
            end tell \n \
            ";
            dispatch_semaphore_t sema = dispatch_semaphore_create(0);
            
            [AppleScriptService doScriptWithSource:source completionHandler:^(NSError * _Nonnull error) {
                if (!error) {
                    self.hasDylibWaitingToSendClient = YES;
                    // 等待socket链接
                    NSTimeInterval timeout = 10;
                    NSTimeInterval duration = 0;
                    while (![SocketServer currentServer].isConnected && duration < timeout) {
                        usleep(200000); // 微秒
                        duration += 0.2;
                    }
                    if ([SocketServer currentServer].isConnected) {
                        // 发送data到Client
                        HRLog(@"Sent data(%.2fkb) to client...", totalDataLength / 1024.0);
                        [[SocketServer currentServer] sendSocketCommand:SocketCommandSentData dictionary:dataInfoDicM];
                        self.hasDylibWaitingToSendClient = NO;
                    } else {
                        ErrorLog(@"Test wthout building by Xcode timeout!!!");
                        self.hasDylibWaitingToSendClient = NO;
                    }
                    dispatch_semaphore_signal(sema);
                } else {
                    dispatch_semaphore_signal(sema);
                    ErrorLog(@"%@", error.localizedDescription);
                }
            }];
            dispatch_semaphore_wait(sema, DISPATCH_TIME_FOREVER);
        }
#endif
    } else {
        NSString *msg = @"";
        if (compileFailedFileNames.count > 0) {
            msg = [msg stringByAppendingString:[NSString stringWithFormat:@" ❌ Compile fail count %lu : %@", (unsigned long)compileFailedFileNames.count, [compileFailedFileNames componentsJoinedByString:@"\n"]]];
        }
        
        if (compileTimeOutFileNames.count > 0) {
            msg = [msg stringByAppendingString:[NSString stringWithFormat:@" ⏰ Compile time out count %lu : %@", (unsigned long)compileTimeOutFileNames.count, [compileTimeOutFileNames componentsJoinedByString:@"\n"]]];
        }
#if !CMDTOOL
        [[SocketServer currentServer] postNotificationForSocketCommand:SocketCommandReloadComplete value:@{@"msg" : msg, @"ret" : @(CocoaHotReloadCodeErrorCompileFailed)}];
#endif
        if (completion) {
            completion(nil);
        }
    }
}

- (NSDictionary *)classInfoForDylibWithDylibFilePath:(NSString *)dylibFilePath compiledOFilePaths:(NSArray<NSString *> *)compiledOFilePaths
{
    NSMutableSet *classSymbolSetM = [NSMutableSet set];
    NSMutableSet *classNameSetM = [NSMutableSet set];
    NSMutableSet *oFileCategoryClassNameSetM = [NSMutableSet set]; //.o 中category
    NSMutableSet *allCategoryClassNameSetM = [NSMutableSet set]; // .dylib 中category
    NSMutableSet *cFuntionNameSetM = [NSMutableSet set];
    NSMutableSet *swiftStaticFuntionNameSetM = [NSMutableSet set];

    NSArray *(^getCategoryNames)(NSString *) = ^NSArray *(NSString *filePath) {
        // 获取category信息
        ShellResult *categoryClassResult = [ShellService doShellOutputWithSource:[NSString stringWithFormat:@"nm -nm %@ | grep 'external __OBJC_$_CATEGORY_'", filePath]];
        NSMutableSet *categoryNamesSet = [NSMutableSet set];
        if (categoryClassResult.isSuccess) {
            NSArray<NSString *> *resultStrings = [categoryClassResult.output componentsSeparatedByString:@"\n"];
            for (NSString *resultString in resultStrings) {
                if ([resultString containsString:@"_METHODS_"]) { // 过滤掉函数
                    continue;
                }
                NSRange prefixRange = [resultString rangeOfString:@"__OBJC_$_CATEGORY_"];
                if (prefixRange.location != NSNotFound) {
                    NSString *categorySymbol = [resultString substringFromIndex:prefixRange.length + prefixRange.location];
                    // NSObject(CocoaHotReload)
                    NSRange spaceRange = [categorySymbol rangeOfString:@"_$_"];
                    if (spaceRange.location != NSNotFound) {
                        NSString *className = [categorySymbol substringToIndex:spaceRange.location];
                        NSString *categoryName = [categorySymbol substringFromIndex:spaceRange.location + spaceRange.length];
                        NSString *categoryClassName = [NSString stringWithFormat:@"%@(%@)", className, categoryName];
                        [categoryNamesSet addObject:categoryClassName];
                    }
                }
            }
        }
        return categoryNamesSet.allObjects;
    };

    for (NSString *oFilePath in compiledOFilePaths) {
        // 获取Class names
        ShellResult *result = [ShellService doShellOutputWithSource:[NSString stringWithFormat:@"nm -nm %@ | grep '(__DATA,__.*) external \\(\\[no dead strip\\] \\)\\?\\(\\[alt entry\\] \\)\\?\\(_OBJC_CLASS\\)\\?_\\$'", oFilePath]];
        if (result.isSuccess) {
            NSArray *results = [result.output componentsSeparatedByString:@"\n"];
            for (NSString *result in results) {
                NSRange range = [result rangeOfString:@" _OBJC_CLASS_$_"];
                if (range.location == NSNotFound) {
                    if ([result containsString:@"__objc_data"]) { // 继承Objc类，因为继承OC类会产生两个符号，一个OC类符号，一个Swift符号 但是都是映射到同一个对象，所以需要过滤掉，上面_OBJC_CLASS_已处理
                        continue;
                    }
                    // 目前Swift类需要包含" _$s"&&以"CN"结尾，目前有待考察
                    if (![result containsString:@" _$s"] || ![result hasSuffix:@"CN"]) {
                        continue;
                    }
                    range = [result rangeOfString:@" _$"];
                }
                if (range.location != NSNotFound) {
                    NSString *classSymbol = [result substringFromIndex:range.location + 2];
                    if (![SymbolSharedManager() isSupportHotReloadWithSwiftSymbol:classSymbol]) {
                        // 部分Swift类不支持热重载
                        WarningLog(@"目前使用了泛型的Swift类不支持热重载，Swift符号过滤：%@", classSymbol);
                        continue;
                    }
                    [classSymbolSetM addObject:classSymbol];
                    if ([classSymbol hasPrefix:@"OBJC_CLASS_$_"]) { // 兼容老版本
                        [classNameSetM addObject:[classSymbol stringByReplacingOccurrencesOfString:@"OBJC_CLASS_$_" withString:@""]];
                    }
                }
            }
        }
       
        // 获取分类信息
        NSArray *categoryClassNames = getCategoryNames(oFilePath);
        [oFileCategoryClassNameSetM addObjectsFromArray:categoryClassNames];
       
        // 获取c函数
        ShellResult *cFuntionResult = [ShellService doShellOutputWithSource:[NSString stringWithFormat:@"nm -nm %@ | grep '(__TEXT,__text) external _'", oFilePath]];
       
        if (cFuntionResult.isSuccess) {
            NSArray<NSString *> *resultStrings = [cFuntionResult.output componentsSeparatedByString:@"\n"];
            for (NSString *resultString in resultStrings) {
                if ([resultString containsString:@"_$_"]) { // 过滤掉OC类
                    continue;
                }
                NSRange range = [resultString rangeOfString:@"external _"];
                if (range.location != NSNotFound) {
                    NSString *cFuntionName = [resultString substringFromIndex:range.length + range.location];
                    [cFuntionNameSetM addObject:cFuntionName];
                }
            }
        }
        
        // 获取Swift函数中静态派发的函数列表
        ShellResult *swiftStaticFunctionResult = [ShellService doShellOutputWithSource:[NSString stringWithFormat:@"nm -nm %@ | grep '(__TEXT,__text) external \\[no dead strip\\] _\\$s.*F.*'", oFilePath]];
        
        if (swiftStaticFunctionResult.isSuccess) {
            NSArray<NSString *> *resultStrings = [swiftStaticFunctionResult.output componentsSeparatedByString:@"\n"];
            for (NSString *resultString in resultStrings) {
                NSRange range = [resultString rangeOfString:@"external [no dead strip] _"];
                if (range.location != NSNotFound && ([resultString hasSuffix:@"FZ"] || [resultString hasSuffix:@"F"])) {
                    NSString *swiftStaticFuntionName = [resultString substringFromIndex:range.length + range.location];
                    [swiftStaticFuntionNameSetM addObject:swiftStaticFuntionName];
                }
            }
        }
    }

    NSMutableSet *ignoreClassMethodNameSetM = [NSMutableSet set];
#if !CMDTOOL
    NSArray<NSString *> *ignoreClassMethodNames = [CocoaHotReloadManager shareInstance].preferences.ignoreClassMethodNames;
    for (NSString *methodName in ignoreClassMethodNames) {
       if (methodName.length > 0) {
           [ignoreClassMethodNameSetM addObject:methodName.lowercaseString];
       }
    }
#endif
    // 获取dylib中category
    [allCategoryClassNameSetM addObjectsFromArray:getCategoryNames(dylibFilePath)];
    
    return @{
        @"compileSucceedFileNames" : compiledOFilePaths ?: @[],
        @"classSymbols" : classSymbolSetM.allObjects ?: @[],
        @"classNames" : classNameSetM.allObjects ?: @[],
        @"oFileCategoryClassNames" : oFileCategoryClassNameSetM.allObjects ?: @[],
        @"allCategoryClassNames" : allCategoryClassNameSetM.allObjects ?: @[],
        @"cFuntionNames" : cFuntionNameSetM.allObjects ?: @[],
        @"startTimeInterval" : @(self.startHotReloadTimeInterval),
        @"ignoreClassMethodNames" : ignoreClassMethodNameSetM.allObjects ?: @[],
        @"swiftStaticFunctionNames" : swiftStaticFuntionNameSetM.allObjects ?: @[]
    };
}

- (NSString *)generateDylibAndCodeSignShellScriptWithCompiledFilePaths:(NSArray<NSString *> *)compiledFilePaths
                                                          oFilePathDic:(NSDictionary<NSString *, NSString *> *)oFilePathDic
                                                            dylibFilePath:(NSString *)dylibFilePath
{
    NSMutableSet *filePathSetM = [NSMutableSet setWithArray:compiledFilePaths];
    NSMutableArray *swiftOFilePathsM = [NSMutableArray array];
    for (NSString *sourceFilePath in oFilePathDic.allKeys) {
        if ([[sourceFilePath pathExtension] isEqualToString:@"swift"]) {
            [swiftOFilePathsM addObject:oFilePathDic[sourceFilePath]];
        }
    }
    
    if (swiftOFilePathsM.count > 0) {
        HRLog(@"🚧 获取.o依赖的其它.o文件...");
        NSTimeInterval begin = [[NSDate date] timeIntervalSince1970];
        // 更新私有符号内容
        for (NSString *compiledFilePath in swiftOFilePathsM) {
            [SymbolSharedManager() updatePrivateSwiftSymbolsDicMWithOFilePath:compiledFilePath];
        };
        NSMutableSet *dependentFilePathSetM = [NSMutableSet set];
        for (NSString *swiftOFilePath in swiftOFilePathsM) {
            [dependentFilePathSetM addObjectsFromArray:[FileDependentSharedManager shouldLinkOFilePathsForSwiftOFilePath:swiftOFilePath]];
        }
        [filePathSetM addObjectsFromArray:dependentFilePathSetM.allObjects];
        NSTimeInterval end = [[NSDate date] timeIntervalSince1970];
        HRLog(@"👏 获取.o依赖的其它.o文件完成！共%lu个 %.2f seconds", (unsigned long)dependentFilePathSetM.count, end - begin);
    }
    
    
    NSString *shellFileNamesString = [filePathSetM.allObjects  componentsJoinedByString:@" "];
    
    CocoaHotReloadSettings *settings = self.settings;
   
    NSString *osSpecific = nil;
    if ([settings.platformName hasPrefix:@"mac"]) {
        BOOL isMacCatalyst = [self isMacCatalyse];
        osSpecific = [NSString stringWithFormat:@"-isysroot %@/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk -target %@ -L%@/Toolchains/XcodeDefault.xctoolchain/usr/lib/swift/%@ ", settings.XcodeDeveloperPath, isMacCatalyst ? @"x86_64-apple-ios13.1-macabi" : @"macosx", settings.XcodeDeveloperPath, isMacCatalyst ? @"maccatalyst" : @"macosx"];
    } else if ([settings.platformName hasPrefix:@"iphone"]) {
        if ([settings.arch hasPrefix:@"arm"]) { // iphoneOS
            osSpecific = [NSString stringWithFormat:@"-isysroot %@/Platforms/iPhoneOS.platform/Developer/SDKs/iPhoneOS.sdk -mios-version-min=%@ -L%@/Toolchains/XcodeDefault.xctoolchain/usr/lib/swift/iphoneos", settings.XcodeDeveloperPath, settings.minimumOSVersion, settings.XcodeDeveloperPath];
        } else if ([settings.arch isEqualToString:@"x86_64"] || [settings.arch isEqualToString:@"i386"]) { // iphonesimulator
            osSpecific = [NSString stringWithFormat:@"-isysroot %@/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator.sdk -mios-simulator-version-min=%@ -L%@/Toolchains/XcodeDefault.xctoolchain/usr/lib/swift/iphonesimulator", settings.XcodeDeveloperPath, settings.minimumOSVersion, settings.XcodeDeveloperPath];
        }
    }
    
    // -L<dir>, --library-directory <arg>, --library-directory=<arg>  Add directory to library search path
    // -F<arg> Add directory to framework include search path
    // -l<静态库名/动态库>
    // Clang 命令说明文档：https://clang.llvm.org/docs/ClangCommandLineReference.html
  
    // 这里只从编译日志中的编译指令 -L、—F、-l 编译参数
    NSString *linkLibAndFramewrokForProjecLog;
    if ([compiledFilePaths containsObject:kCompiledExportedSymbolFilePath]) { // 链接所有exported symbol lib
        NSArray *exportedLibPaths = [LibSharedManager() exportedLibPaths];
        NSMutableString *linkCommandM = [NSMutableString string];
        if (exportedLibPaths.count > 0) {
            // -force_load Force load library or framework
            [linkCommandM appendString:@" -force_load "];
            [linkCommandM appendString:[exportedLibPaths componentsJoinedByString:@" -force_load "]];
        }
        linkLibAndFramewrokForProjecLog = linkCommandM;
    } else { // .o 文件查找编译指令
       linkLibAndFramewrokForProjecLog = [LibSharedManager() linkLibCommandForOFilePaths:compiledFilePaths];
    }
    
    // -undefined dynamic_lookup 很重要！！！ 这个参数是解决.o -> .dylib 时 Undefined symbols 报错提示t";
    // --coverage 解决dlopen 报错 Symbol not found: ___llvm_profile_runtime
    // bug fix https://git.code.oa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/43
    
#if CMDTOOL
    NSString *clangSource = [NSString stringWithFormat:@"%@/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang -dynamiclib -undefined dynamic_lookup --coverage -arch %@ %@ -fobjc-arc -stdlib=libc++ -ObjC %@ %@ -o %@; ", settings.XcodeDeveloperPath, settings.arch, osSpecific, linkLibAndFramewrokForProjecLog, shellFileNamesString, dylibFilePath];
#else
    NSString *clangSource = [NSString stringWithFormat:@"%@/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang -dynamiclib -undefined dynamic_lookup --coverage -arch %@ %@ -fobjc-arc -stdlib=libc++ -ObjC -rpath %@ %@ %@ -o %@; ", settings.XcodeDeveloperPath, settings.arch, osSpecific, settings.frameworksPath, linkLibAndFramewrokForProjecLog, shellFileNamesString, dylibFilePath];
#endif
    
    NSString *clangSourceFilePath = [[dylibFilePath stringByDeletingPathExtension] stringByAppendingString:@".sh"];
    [clangSource writeToFile:clangSourceFilePath atomically:YES encoding:NSUTF8StringEncoding error:nil];
    
    NSString *codeSignSource = [NSString stringWithFormat:@"export CODESIGN_ALLOCATE=%@/Toolchains/XcodeDefault.xctoolchain/usr/bin/codesign_allocate; codesign --force --sign '%@' %@;", settings.XcodeDeveloperPath, [SignSharedManager() signingIdentityForApp]?:@"-", dylibFilePath];
    
    return [NSString stringWithFormat:@"%@ %@", clangSource, codeSignSource];
}

- (NSString *)cocoaHotReloadTmpDirectoryPath
{
    return [FileSharedManager() tmpDirAndCreateIfNeed];
}

- (NSString *)compileFileAppleScriptWithFileNames:(NSArray *)fileNames
{
    NSMutableArray *fileNamesM = [NSMutableArray array];
    NSMutableArray *compiledFilePathSetM = [NSMutableArray array];
    for (NSString *fileName in fileNames) {
        [fileNamesM addObject:[NSString stringWithFormat:@"\"%@\"", fileName]];
        [compiledFilePathSetM addObject:[NSString stringWithFormat:@"%@.o", [[fileName componentsSeparatedByString:@"."] firstObject]]];
    }
    
    NSString *fileNamesString = [fileNamesM componentsJoinedByString:@","];
    
    NSString *source = [NSString stringWithFormat:@" \
    tell application \"Xcode\" \n \
        activate \n \
        set fileNames to { %@ } \n \
        repeat with fileName in fileNames \n \
            tell application \"System Events\" \n \
                tell application process \"Xcode\" \n \
                    keystroke \"o\" using {command down, shift down} \n \
                    delay 0.5 \n \
                    keystroke fileName \n \
                    delay 1 \n \
                    keystroke \"a\" using {command down}  \n \
                    delay 0.3 \n \
                    key code 76 \n \
                    delay 0.5 \n \
                    keystroke \"`\" using {command down, option down}  \n \
                    delay 0.5 \n \
                    keystroke \"j\" using {command down, shift down} \n \
                    delay 0.5 \n \
                    keystroke \"b\" using {command down, control down} \n \
                    delay 0.5 \n \
                end tell \n \
            end tell \n \
        end repeat \n \
    end tell", fileNamesString];
    return source;
}

@end
