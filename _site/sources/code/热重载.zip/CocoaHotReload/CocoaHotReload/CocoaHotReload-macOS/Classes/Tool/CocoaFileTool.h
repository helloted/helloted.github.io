//
//  CocoaFileTool.h
//  CocoaHotReload
//
//  Created by mambaxie on 2019/11/19.
//  Copyright © 2019 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CocoaFileTool : NSObject

/// 创建指定路径文件夹
/// @param dirPath 文件夹路径
+ (NSString *)createDirectoryIfNeedForPath:(NSString *)dirPath;

/// 创建文件
/// @param filePath 文件路径
+ (NSString *)createFileIfNeedForPath:(NSString *)filePath;

/// 获取文件的绝对路径
/// @param filePath 文件路径
+ (NSString *)absolutePathForFilePath:(NSString *)filePath;

/// 获取文件大小
/// @param filePath 文件路径
+ (long long)fileSizeAtPath:(NSString *)filePath;

/// 获取文件夹大小
/// @param directoryPath 文件夹路径
+ (long long)directorySizeAtPath:(NSString *)directoryPath;

@end

NS_ASSUME_NONNULL_END
