//
//  SymbolManager.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/12/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "SymbolManager.h"
#import "FileManager.h"
#import "CocoaHotReloadManager.h"
#import "CocoaHotReloadSettings.h"
#import "CocoaHotReloadPreferences.h"
#import "ShellService.h"
#import "ProjectManager.h"
#import "NSString+CHRRegular.h"

@interface SymbolManager()

@end

@implementation SymbolManager

- (void)clearData
{
    self.executableSwiftSymbolSetM = nil;
    self.executablePrivateSymbolSetM = nil;
    self.notSupportHotReloadSymbolSetM = nil;
}

/// 查找私有符号和Swif符号
- (void)findProjectPrivateAndSwiftSymbols
{
    if (self.executablePrivateSymbolSetM && self.executableSwiftSymbolSetM) {
        return;
    }
    self.executablePrivateSymbolSetM = [NSMutableSet set];
    self.executableSwiftSymbolSetM = [NSMutableSet set];
    self.notSupportHotReloadSymbolSetM = [NSMutableSet set];
    
    NSString *projectBuildDir = [FileSharedManager() projectBuildDir];
    ProjectManager *manager = ProjectSharedManager();
    NSString *productsDir = [projectBuildDir stringByAppendingPathComponent:[NSString stringWithFormat:@"Products/%@-%@", manager.settings.configuration, manager.isSimulator ? @"iphonesimulator" : @"iphoneos"]];
    NSString *executableDir = [productsDir stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.app", manager.settings.executableName]];
    NSString *xctestExecutableFile = [executableDir stringByAppendingPathComponent:[NSString stringWithFormat:@"PlugIns/%@.xctest/%@", manager.settings.testTargetName, manager.settings.testTargetName]];
    
    NSMutableSet *executableFilePathSetM = [NSMutableSet set];
    NSString *executableFilePath = [executableDir stringByAppendingPathComponent:manager.settings.executableName];
    
    if (executableFilePath) {
        [executableFilePathSetM addObject:executableFilePath];
    }
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *frameworksDir = [executableDir stringByAppendingPathComponent:@"Frameworks"];
    NSArray<NSString *> *subpaths = [fileManager subpathsAtPath:frameworksDir];
    for (NSString *subpath in subpaths) {
        NSString *filePath;
        if ([subpath hasSuffix:@".dylib"] ) {
            filePath = [frameworksDir stringByAppendingPathComponent:subpath];
        } else if ([subpath hasSuffix:@".framework"]) {
            NSString *exectuableName = [subpath stringByDeletingPathExtension];
            filePath = [frameworksDir stringByAppendingFormat:@"/%@/%@", subpath, exectuableName];
        }
        
        if (filePath && [fileManager isExecutableFileAtPath:filePath]) {
            [executableFilePathSetM addObject:filePath];
        }
    }
    
    if([fileManager fileExistsAtPath:xctestExecutableFile]) {
        [executableFilePathSetM addObject:xctestExecutableFile];
    }
    
    if (executableFilePathSetM.count == 0) {
        return;
    }
    
    dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
    
    dispatch_group_t group = dispatch_group_create();
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    for (NSString *filePath in executableFilePathSetM.allObjects) {
        dispatch_group_enter(group);
        dispatch_group_async(group, queue, ^{
            [self findPrivateExternalSymbolsForExecutableFilePath:filePath];
            [self findSwiftSymbolsForExecutableFilePath:filePath];
            dispatch_group_leave(group);
        });
    }
    
    dispatch_group_notify(group, queue, ^{
        dispatch_semaphore_signal(semaphore);
    });
    
    dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
}

- (void)findProjectAllSwiftFilePrivateSymbols
{
    HRLog(@"🚧 获取项目所有Swift文件的私有符号...");
    NSTimeInterval begin = [[NSDate date] timeIntervalSince1970];
    if (!_privateSwiftSymbolsDicM) {
        _privateSwiftSymbolsDicM = [NSMutableDictionary dictionary];
        
        NSArray<NSString *> *swiftFileNames = [FileSharedManager() compileSwiftFileNamesForProject];
        CocoaHotReloadSettings *settings = [ProjectSharedManager() settings];
        NSString *targetBuildDir = [[FileSharedManager() projectBuildDir] stringByAppendingPathComponent:[NSString stringWithFormat:@"Intermediates.noindex/%@.build/%@-%@/%@.build/Objects-normal/%@", settings.targetName, settings.configuration, settings.platformName, settings.targetName, settings.arch]];
        
        dispatch_group_t group = dispatch_group_create();
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0);
        dispatch_semaphore_t sema;
        if (swiftFileNames.count > 0) {
            sema = dispatch_semaphore_create(0);
            for (NSString *fileName in swiftFileNames) {
                dispatch_group_enter(group);
                dispatch_group_async(group, queue, ^{
                    @autoreleasepool {
                        NSString *oFilePath = [targetBuildDir stringByAppendingPathComponent:[fileName stringByReplacingOccurrencesOfString:@".swift" withString:@".o"]];
                        if (![[NSFileManager defaultManager] fileExistsAtPath:oFilePath]) {
                            oFilePath = [FileSharedManager() fixOFilePathWithPath:oFilePath];
                            if (![[NSFileManager defaultManager] fileExistsAtPath:oFilePath]) {
                                WarningLog(@".o文件存在：%@", oFilePath);
                            }
                        } else {
                            NSArray *symbols = [self privateSwiftSymbolsForOFilePath:oFilePath targetName:settings.targetName];
                            @synchronized (self) {
                                self.privateSwiftSymbolsDicM[oFilePath] = symbols;
                            }
                        }
                    }
                    dispatch_group_leave(group);
                });
            }
        }
        dispatch_group_notify(group, queue, ^{
            dispatch_semaphore_signal(sema);
        });
        if (sema) {
            dispatch_semaphore_wait(sema, DISPATCH_TIME_FOREVER);
        }
    }
    
    NSTimeInterval end = [[NSDate date] timeIntervalSince1970];
    HRLog(@"👏 获取项目所有Swift文件的私有符号完成！%.2f seconds", end - begin);
}

- (NSArray<NSString *> *)projectSwiftSymbols
{
    return self.executableSwiftSymbolSetM.allObjects;
}

- (void)updatePrivateSwiftSymbolsDicMWithOFilePath:(NSString *)oFilePath
{
    if (!oFilePath) {
        return;
    }
    
    _privateSwiftSymbolsDicM[oFilePath] = [self privateSwiftSymbolsForOFilePath:oFilePath targetName:[ProjectSharedManager() settings].targetName];
}

#pragma mark - Private

/// 根据可执行文件 获取私有符号
- (void)findPrivateExternalSymbolsForExecutableFilePath:(NSString *)filePath
{
    NSString *source = [NSString stringWithFormat:@"nm -nm %@ | grep 'non-external (was a private external) _OBJC_CLASS_'", filePath];
    
    ShellResult *result = [ShellService doShellOutputWithSource:source];
    
    if (result.isSuccess) {
        NSString *privateExternalSymbolsString = result.output;
        
        NSArray <NSString *> *results = [privateExternalSymbolsString componentsSeparatedByString:@"\n"];
        
        for (NSString *result in results) {
            NSRange prefixRange = [result rangeOfString:@"non-external (was a private external) "];
            if (prefixRange.location != NSNotFound) {
                NSString *symbol = [result substringFromIndex:prefixRange.location+prefixRange.length];
                @synchronized (self) {
                    [self.executablePrivateSymbolSetM addObject:symbol];
                }
            }
        }
    }
}

- (void)findSwiftSymbolsForExecutableFilePath:(NSString *)filePath
{
    // 忽略swift系统官方库
    NSString *fileName = [filePath lastPathComponent];
    if ([fileName hasPrefix:@"libswift"] && [fileName hasSuffix:@".dylib"]) {
        return;
    }
    
    // 先获取(__DATA,__bss) non-external _$s8ObjCDemo13SwiftSubClassCMl 数组，用来过滤部分swift符号
    // fix https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/79
    NSString *bssCMlSource = [NSString stringWithFormat:@"nm -nm %@ | grep '(__DATA,__bss) non-external _\\$s.*CMl$'", filePath];
    ShellResult *bssCMlResult = [ShellService doShellOutputWithSource:bssCMlSource];
    NSMutableSet *bssCMlResultSet = [NSMutableSet set];
    NSString *targetName = [ProjectSharedManager() settings].targetName ?: [ProjectSharedManager() settings].projectName;
    if (targetName && bssCMlResult.isSuccess) {
        NSArray <NSString *> *results = [bssCMlResult.output componentsSeparatedByString:@"\n"];
        for (NSString *result in results) {
            NSString *bssCMl = [result chr_subStringBetweenFrom:targetName to:@"CMl" backwardsSearch:YES];
            if (bssCMl) {
                [bssCMlResultSet addObject:bssCMl];
            }
        }
    }
    
    NSString *source = [NSString stringWithFormat:@"nm -nm %@ | grep '(__DATA,__.*) external _\\$s.*CN$'", filePath];
    ShellResult *result = [ShellService doShellOutputWithSource:source];
    
    if (result.isSuccess) {
        NSString *swiftSymbolsString = result.output;
        NSArray <NSString *> *results = [swiftSymbolsString componentsSeparatedByString:@"\n"];
        for (NSString *result in results) {
            
            NSRange prefixRange = [result rangeOfString:@"external _"];
            NSString *symbol;
            if (prefixRange.location != NSNotFound) {
                symbol = [result substringFromIndex:prefixRange.location+prefixRange.length];
            }
            if (!symbol) {
                continue;
            }
            
            if (targetName && ![result containsString:@"(__DATA,__objc_data)"]) { // 不在__objc_data段
                NSString *bbsCMl = [result chr_subStringBetweenFrom:targetName to:@"CN" backwardsSearch:YES];
                if (bbsCMl && [bssCMlResultSet containsObject:bbsCMl]) { // 过滤
                    @synchronized (self) {
                        [self.notSupportHotReloadSymbolSetM addObject:symbol];
                    }
                    continue;
                }
            }
            
            @synchronized (self) {
                [self.executableSwiftSymbolSetM addObject:symbol];
            }
        }
    }
}

- (BOOL)isSupportHotReloadWithSwiftSymbol:(NSString *)swiftSymbol
{
    return ![self.notSupportHotReloadSymbolSetM containsObject:swiftSymbol];
}

- (NSArray<NSString *> *)privateSwiftSymbolsForOFilePath:(NSString *)oFilePath targetName:(NSString *)targetName
{
    NSString *source = [NSString stringWithFormat:@"nm -nm %@ | grep 'private external _$s.*%@'", oFilePath, targetName];
    ShellResult *result = [ShellService doShellOutputWithSource:source];
    if (result.isSuccess) {
        NSMutableSet *symbolSetM = [NSMutableSet set];
        NSArray<NSString *> *results = [result.output componentsSeparatedByString:@"\n"];
        for (NSString *result in results) {
            NSString *symbol = [result chr_subStringFrom:@"private external " containFrom:NO];
            if ([symbol hasPrefix:@"_$s"]) {
                [symbolSetM addObject:symbol];
            }
        }
        
        if (symbolSetM.count > 0) {
            return symbolSetM.allObjects;
        }
        
        return nil;
    }
    
    return nil;
}

@end
