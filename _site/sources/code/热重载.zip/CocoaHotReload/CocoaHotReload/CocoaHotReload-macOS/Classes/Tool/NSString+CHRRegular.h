//
//  NSString+CHRRegular.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/4/14.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (CHRRegular)

/// 获取两个字符串之间的子串(不包含)
/// @param from 字符串开头
/// @param to 字符串结尾
/// @param backwardsSearch 是否逆序查找
/// eg1. 123***999 form: 12 to: 99 backwardsSearch : NO  -> 3***
/// eg2. 123***999 form: 12 to: 99 backwardsSearch : YES  -> 3***9
- (NSString * _Nullable)chr_subStringBetweenFrom:(NSString *)from to:(NSString *)to backwardsSearch:(BOOL)backwardsSearch;

/// 获取以form的子串(包含开头&结尾)
/// @param from 字符串开头
/// @param to 字符串结尾
/// @param backwardsSearch 是否逆序查找
/// eg1. 123***999 form: 2 to: 99 backwardsSearch : NO -> 23***99
/// eg2. 123***999 form: 2 to: 99 backwardsSearch : YES -> 23***999
- (NSString * _Nullable )chr_subStringFrom:(NSString *)from to:(NSString *)to backwardsSearch:(BOOL)backwardsSearch;

/// 根据正则表达式获取结果字符串列表
/// @param regular 正在表达式
/// @param options options
- (NSArray<NSString *> * _Nullable)chr_subStringsWithRegular:(NSString *)regular options:(NSRegularExpressionOptions)options;

/// 根据正则表达式获取结果集
/// @param regular 正在表达式
/// @param options options
- (NSArray<NSTextCheckingResult *> * _Nullable)chr_subStringResultsWithRegular:(NSString *)regular options:(NSRegularExpressionOptions)options;

/// 获取以from开头的字符串
/// @param from 字符串开头
/// @param isContainFrom 是否包含from
/// 12388545xxxx88 form: 8 containFrom: YES -> 88545xxxx88
/// 12388545xxxx88 form: 8 containFrom: NO -> 545xxxx88
- (NSString *)chr_subStringFrom:(NSString *)from containFrom:(BOOL)isContainFrom;

@end

NS_ASSUME_NONNULL_END
