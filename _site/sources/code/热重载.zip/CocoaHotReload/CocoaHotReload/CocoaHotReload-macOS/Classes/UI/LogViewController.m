//
//  LogViewController.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2019/11/23.
//  Copyright © 2019 tencent. All rights reserved.
//

#import "LogViewController.h"
#import "SocketServer.h"
#import "AppDelegate.h"
#import "NSString+CHRRegular.h"
#import "CocoaHotReloadManager.h"

@interface LogViewController ()

@property (nonatomic, strong) NSMutableString *logsM;

@property (nonatomic, strong) NSTextView *logView;

@end

@implementation LogViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupLogView];
    [self addMenuItem];
}

- (void)viewWillAppear
{
    [super viewWillAppear];
    
    [self.view.window setTitle:[NSString stringWithFormat:@"Cocoa Hot Reload Log (%@)", CocoaHotReloadManager.shareInstance.currentVersion]];
}

- (void)setupLogView
{
    NSScrollView *scrolleView = [[NSScrollView alloc] initWithFrame:self.view.bounds];
    scrolleView.backgroundColor = NSColor.blackColor;
    [scrolleView setAutoresizingMask:NSViewWidthSizable | NSViewHeightSizable];
    [self.view addSubview:scrolleView];
    [scrolleView setHasVerticalScroller:NO];
    [scrolleView setHasHorizontalScroller:YES];  //滚动条

    NSTextView *logView = [[NSTextView alloc] init];
    [logView setAutoresizingMask:NSViewHeightSizable];
    logView.frame = scrolleView.bounds;
    [logView setMinSize:scrolleView.contentSize];
    [logView setMaxSize:NSMakeSize(FLT_MAX, FLT_MAX)];

    [logView setAutoresizingMask:NSViewWidthSizable];

    [[logView textContainer] setContainerSize:NSMakeSize(scrolleView.contentSize.width, FLT_MAX)];
    [[logView textContainer] setWidthTracksTextView:YES];

    [logView setVerticallyResizable:YES];
    [logView setHorizontallyResizable:YES];

    logView.editable = NO;  //只显示

    [scrolleView setDocumentView:logView];

    self.logView = logView;

    self.logsM = [NSMutableString string];
}

- (void)addMenuItem {
    NSMenu* textViewContextualMenu = [self.logView menu];
    [textViewContextualMenu addItemWithTitle:@"Clean Log" action:@selector(cleanLog) keyEquivalent:@""];
    [textViewContextualMenu addItemWithTitle:@"Export Log" action:@selector(exportLog) keyEquivalent:@""];
}

- (void)printLog:(NSString *)logStr
{
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    fmt.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    NSString *dateString = [fmt stringFromDate:[NSDate date]];
    [self.logsM appendFormat:@"%@ %@\n", dateString, logStr];
    
    NSString *str = self.logsM;
    
    [self.logView.textStorage deleteCharactersInRange:NSMakeRange(0, self.logView.textStorage.length)];
    NSAttributedString *logString = [[NSAttributedString alloc] initWithString:str attributes:@{NSForegroundColorAttributeName : NSColor.textColor, NSFontAttributeName : [NSFont boldSystemFontOfSize:19]}];
    [self.logView.textStorage appendAttributedString:logString];
    
    // Scroll to end of the textview contents
    [self.logView scrollRangeToVisible: NSMakeRange(self.logView.string.length, 0)];
}

- (NSString *)allLogString
{
    return [self.logView.textStorage mutableString];
}

#pragma mark - NSMenu

- (void)cleanLog {
    [self.logsM setString:@""];
    [self.logView setString:@""];
}

- (void)exportLog {
    [CocoaHotReloadTool runOnMainThread:^{
        NSSavePanel *panel = [NSSavePanel savePanel];
        [panel setTitle:@"保存log文件"];
        panel.nameFieldStringValue = @"file.log";
        panel.allowedFileTypes = @[@"log"];
        [panel setPrompt:NULL];
        [panel setCanCreateDirectories : YES];
        [panel setCanSelectHiddenExtension : NO];
        [panel beginWithCompletionHandler:^(NSModalResponse result) {
            if (result == NSModalResponseOK) {
                NSString *log = [self.logsM copy];
                [log writeToURL:[panel URL] atomically:YES encoding:NSUTF8StringEncoding error:nil];
            }
        }];
    }];
}

@end
