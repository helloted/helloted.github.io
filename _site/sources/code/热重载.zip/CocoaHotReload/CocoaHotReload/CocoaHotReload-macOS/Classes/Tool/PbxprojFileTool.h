//
//  PbxprojFileTool.h
//  CocoaHotReload-macOS
//
//  Created by guoyanshi on 2020/7/2.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN

@interface PbxprojFileTool : NSObject

/// 获取工程文件bundle id
+ (NSSet *)getProjectBundleIDsWithURL:(NSURL *)url;

/// 开机自启动
+ (void)addReloadCompleteNotification;
+ (void)postReloadCompleteNotification;
+ (void)setAutoLaunch:(BOOL)isAutoLaunch;
+ (BOOL)isAutoLaunch;

/// 自动选择工程路径
+ (void)checkAutoSelectProjectIfNeed;
+ (void)selectProjectWithUrl:(NSURL *)selectedURL;
+ (void)saveProjectPath:(NSString *)path;
+ (NSArray *)getRecentProjectPath;
@end

NS_ASSUME_NONNULL_END
