//
//  CocoaHotReloadPreferences.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/9/13.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, DerivedDataType) {
    DerivedDataTypeDefault,
    DerivedDataTypeRelative,
    DerivedDataTypeCustom,
};

@interface CocoaHotReloadPreferences : NSObject <NSCoding>

/// 默认配置
+ (instancetype)defaultPreferences;

/// derivedData类型 与Xcode保持一致
@property (nonatomic, assign) DerivedDataType derivedDataType;

/// derived data path
@property (nonatomic, copy) NSString *derivedDataPath;

/// 自定义Wathing目录路径，默认使用选中project的根目录
@property (nonatomic, copy) NSString *customWatchingDir;

/// 自定义Xcode app路径
@property (nonatomic, copy) NSString *customXcodeAppDir;

/// 忽略的类函数数组，忽略的函数热重载时不会进行替换
@property (nonatomic, strong) NSArray<NSString *> *ignoreClassMethodNames;

@end

NS_ASSUME_NONNULL_END
