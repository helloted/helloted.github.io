//
//  MMKVService.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/9/12.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "MMKVService.h"
#import <MMKV.h>

// compile command db manager
static MMKV *gMmkv;
static NSString *gCurrentMmkvRootDir;

@implementation MMKVService

+ (void)setCacheDir:(NSString *)dir
{
    if (!dir) {
        return;
    }
    
    if (![dir isEqualToString:gCurrentMmkvRootDir]) {
        [gMmkv clearMemoryCache];
        [gMmkv close];
        gCurrentMmkvRootDir = dir;
        gMmkv = [MMKV mmkvWithID:@"com.tencent.cocoahotreload" rootPath:gCurrentMmkvRootDir];
    }
}

/// 存储字符串
/// @param string 存储的字符串
/// @param key 对应的key
+ (void)setString:(NSString *)string forKey:(NSString *)key
{
    NSAssert(gMmkv, @"请先调用[MMKVService setCacheDir:]初始化mmkv。");
    [gMmkv setString:string forKey:key];
}

/// 根据key获取对应的字符串值
/// @param key 存储的key
+ (NSString *)stringForKey:(NSString *)key
{
    NSAssert(gMmkv, @"请先调用[MMKVService setCacheDir:]初始化mmkv。");
    return [gMmkv getStringForKey:key];
}

+ (void)removeValueForKey:(NSString *)key
{
    [gMmkv removeValueForKey:key];
}

@end
