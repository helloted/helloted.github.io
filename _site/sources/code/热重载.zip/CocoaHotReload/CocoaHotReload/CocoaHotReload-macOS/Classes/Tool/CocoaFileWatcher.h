//
//  CocoaFileWatcher.h
//  InjectionIII
//
//  Created by John Holdsworth on 08/03/2015.
//  Copyright (c) 2015 John Holdsworth. All rights reserved.
//

#import <Foundation/Foundation.h>

#define COCOA_HOT_RELOAD_PATTERN @"\\.(m|mm|h|swift|storyboard|xib)$"

typedef void (^FileChangeCallback)(NSArray *filesChanged);

@interface CocoaFileWatcher : NSObject

@property(copy) FileChangeCallback callback;

- (instancetype)initWithRoot:(NSString *)projectRoot plugin:(FileChangeCallback)callback;

@end
