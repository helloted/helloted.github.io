//
//  FileDependentManager.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/4/23.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "FileDependentManager.h"
#import "CocoaFileTool.h"
#import "CocoaHotReloadTool.h"
#import "CocoaHotReloadManager.h"
#import "CocoaHotReloadServerDefine.h"
#import "NSString+CHRRegular.h"
#import "CocoaFileTool.h"
#import "CocoaHotReloadSettings.h"
#import "FileManager.h"
#import "ProjectManager.h"
#import "ShellService.h"
#import "SymbolManager.h"

@interface FileDependentManager()

// 文件映射路径为key .d文件名 实现文件(.m|.mm)路径数组为value
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSString *> *impletionFilePathDicM;

@end

@implementation FileDependentManager

#pragma mark - Override

- (void)clearData
{
    [self.impletionFilePathDicM removeAllObjects];
}

- (NSMutableDictionary<NSString *,NSString *> *)impletionFilePathDicM
{
    if (!_impletionFilePathDicM) {
        _impletionFilePathDicM = [NSMutableDictionary dictionary];
    }
    
    return _impletionFilePathDicM;
}

#pragma mark - Public


/// 根据.h 文件 获取 所以依赖的实现文件 如.m .mm
- (void)impletionFilePathsDependentHeaderFilePaths:(NSArray<NSString *> *)headerFilePaths
                                       compiletion:(void(^)(NSDictionary <NSString *, NSArray *> *resultDic))compiletion
{
    if (compiletion) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSDictionary *resultDic = [self parseFileDependentAndCacheFileDependentMapForHeaderFilePaths:headerFilePaths];
            compiletion(resultDic);
        });
    }
}

- (NSString *)dFilePathForSourceFilePath:(NSString *)sourceFilePath
{
    return [FileSharedManager() compiledProductFilePathForFullFileName:sourceFilePath.lastPathComponent pathExtersion:@"d"];
}

- (NSArray<NSString *> *)allHeaderFilePathsForDFilePath:(NSString *)dFilePath
{
    NSError *error;
    NSString *content = [NSString stringWithContentsOfFile:dFilePath encoding:NSUTF8StringEncoding error:&error];
    
    if (error) {
        ErrorLog(@"解析.d文件失败，path: %@ errMsg: %@", dFilePath, error.localizedDescription);
        return nil;
    } else {
        NSMutableArray *allHeaderFilePathsM = [NSMutableArray array];
        content = [content stringByReplacingOccurrencesOfString:@"\n " withString:@""];
        NSArray *dependentPaths = [content componentsSeparatedByString:@" \\ "];
        
        NSString *lastObj = [dependentPaths lastObject];
        for (NSString *filePath in dependentPaths) {
            NSString *path = filePath;
            if ([filePath isEqual:lastObj]) {
                path = [filePath stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            }
            if ([path hasSuffix:@".h"]) {
                [allHeaderFilePathsM addObject:path];
            }
        }
        return allHeaderFilePathsM;
    }
}

#pragma mark - Private

/// 解析文件依赖和缓存映射关系
- (NSDictionary <NSString *, NSArray *> *)parseFileDependentAndCacheFileDependentMapForHeaderFilePaths:(NSArray<NSString *> *)headerFilePaths
{
    HRLog(@"🚧 解析依赖文件...");
    
    NSTimeInterval parseBegin = [[NSDate date] timeIntervalSince1970];
    NSString *projectBuildDir = [FileSharedManager() projectBuildDir];
    
    NSString *intermediatesDir = [projectBuildDir stringByAppendingPathComponent:@"Intermediates.noindex"];
    
    CocoaHotReloadSettings *settings = ProjectSharedManager().settings;
    NSString *arch = settings.arch;
    
    NSMutableSet *needParseDirSetM = [NSMutableSet set];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray<NSString *> *subFileNames = [fileManager contentsOfDirectoryAtPath:intermediatesDir error:nil];
    NSString *objectsNormalArchDir = [NSString stringWithFormat:@"Objects-normal/%@", arch];
    for (NSString *targetBuild in subFileNames) {
        if ([targetBuild hasSuffix:@".build"]) {
            NSString *targetBuildDir = [intermediatesDir stringByAppendingPathComponent:targetBuild];
            targetBuildDir = [targetBuildDir stringByAppendingPathComponent:[NSString stringWithFormat:@"%@-%@", settings.configuration, settings.platformName]];
            
            NSArray<NSString *> *subFileNames = [fileManager contentsOfDirectoryAtPath:targetBuildDir error:nil];
            for (NSString *fileName in subFileNames) {
                if ([fileName hasSuffix:@".build"]) {
                    NSString *objectsDir = [targetBuildDir stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@", fileName, objectsNormalArchDir]];
                    BOOL isDir = NO;
                    if ([fileManager fileExistsAtPath:objectsDir isDirectory:&isDir]) {
                        if (isDir) {
                            [needParseDirSetM addObject:objectsDir];
                        }
                    }
                }
            }
            
        }
    }
    
    NSMutableDictionary *impletionFilePathsDicM = [NSMutableDictionary dictionary];
    for (NSString *objectIntermediatesDir in needParseDirSetM.allObjects) {

        [self parseAllDependentFilesWithObjectIntermediatesDir:objectIntermediatesDir headerFilePaths:headerFilePaths completion:^(NSDictionary<NSString *,NSArray *> *resultDic) {
            @synchronized (self) {
                [impletionFilePathsDicM addEntriesFromDictionary:resultDic];
            }
        }];
    }
    
    NSTimeInterval parseEnd = [[NSDate date] timeIntervalSince1970];
    HRLog(@"👏 解析依赖文件(%zd个)完成 %.2f seconds", impletionFilePathsDicM.allValues.count, parseEnd - parseBegin);
    return impletionFilePathsDicM;
}

- (void)parseAllDependentFilesWithObjectIntermediatesDir:(NSString *)objectsDir
                                         headerFilePaths:(NSArray <NSString *>*)headerFilePaths
                                              completion:(void(^)(NSDictionary <NSString *, NSArray *> *resultDic))completion
{
    NSArray<NSString *> *subpaths = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:objectsDir error:nil];
    NSMutableArray<NSString *> *dFilePathsM = [NSMutableArray array];
    
    for (NSString *subpath in subpaths) {
        @autoreleasepool {
            if ([subpath hasSuffix:@".d"]) {
                NSString *dFilePath = [objectsDir stringByAppendingPathComponent:subpath];
                [dFilePathsM addObject:dFilePath];
            }
        }
    }
    
    [self parseDependentFilesWithDFilePaths:dFilePathsM
                                 objectsDir:objectsDir
                            headerFilePaths:headerFilePaths completion:completion];
}

- (void)parseDependentFilesWithDFilePaths:(NSArray<NSString *> *)dFilePaths
                               objectsDir:(NSString *)objectsDir headerFilePaths:(NSArray <NSString *> *)headerFilePaths
                               completion:(void(^)(NSDictionary <NSString *, NSArray *> *resultDic))completion
{
    NSMutableDictionary *resultDicM = [NSMutableDictionary dictionary];
    
    dispatch_semaphore_t semaphore;
    dispatch_group_t group = dispatch_group_create();
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    @autoreleasepool {
        NSUInteger filePathsCount = dFilePaths.count;
        for (int i = 0; i < filePathsCount; i++) {
            @synchronized (self) {
                if (!semaphore) {
                    semaphore = dispatch_semaphore_create(0);
                }
            }
            dispatch_group_enter(group);
            dispatch_group_async(group, queue, ^{
                [self parseDependentFilesWithDFilePath:dFilePaths[i] headerFilePaths:headerFilePaths resultDicM:resultDicM compiletion:^{
                    dispatch_group_leave(group);
                }];
            });
        }
    }
    
    dispatch_group_notify(group, queue, ^{
        if (semaphore) {
            dispatch_semaphore_signal(semaphore);
        }
    });
    
    if (semaphore) {
        dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
    }
    
    if (completion) {
        completion(resultDicM);
    }
}

- (void)parseDependentFilesWithDFilePath:(NSString *)dFilePath
                         headerFilePaths:(NSArray *)headerFilePaths
                              resultDicM:(NSMutableDictionary <NSString *, NSMutableArray *> *)resultDicM
                             compiletion:(void(^)(void))completion
{
    NSError *error;
    NSString *content = [NSString stringWithContentsOfFile:dFilePath encoding:NSUTF8StringEncoding error:&error];
    if (error) {
        ErrorLog(@"解析.d文件失败，path: %@ errMsg: %@", dFilePath, error.localizedDescription);
    } else {
        for (NSString *headerFilePath in headerFilePaths) {
            NSMutableArray *impletionFilePathsM;
            @synchronized (self) {
                impletionFilePathsM = resultDicM[headerFilePath];
            }
            if (!impletionFilePathsM) {
                impletionFilePathsM = [NSMutableArray array];
            }
            
            BOOL isDependent = [content containsString:headerFilePath];
            if (!isDependent) {
                continue;
            }
            
            NSString *dFileName = [dFilePath lastPathComponent];
            NSString *impletionFilePath = self.impletionFilePathDicM[dFileName];
            if (!impletionFilePath) {
                impletionFilePath = [content chr_subStringBetweenFrom:@"\n " to:@".mm" backwardsSearch:YES];
                if (impletionFilePath) { // 优先匹配.mm
                    impletionFilePath = [impletionFilePath stringByAppendingString:@".mm"];
                }
                if (!impletionFilePath) { // 然后尝试匹配.m
                    impletionFilePath = [content chr_subStringBetweenFrom:@"\n " to:@".m" backwardsSearch:YES];
                    if (impletionFilePath) {
                        impletionFilePath = [impletionFilePath stringByAppendingString:@".m"];
                    }
                }
                if (!impletionFilePath) { // 最后尝试匹配.swift
                    impletionFilePath = [content chr_subStringBetweenFrom:@"\n " to:@".swift" backwardsSearch:YES];
                    if (impletionFilePath) {
                        impletionFilePath = [impletionFilePath stringByAppendingString:@".swift"];
                    }
                }
            }
            
            if (!impletionFilePath) {
                continue;
            }
            
            [impletionFilePathsM addObject:impletionFilePath];
            
            @synchronized (self) {
                self.impletionFilePathDicM[dFileName] = impletionFilePath;
                if (impletionFilePathsM.count > 0) {
                    resultDicM[headerFilePath] = impletionFilePathsM;
                }
            }
        }
    }
    
    if (completion) {
        completion();
    }
}

- (NSArray<NSString *> *)shouldLinkOFilePathsForSwiftOFilePath:(NSString *)swiftOFilePath
{
    static NSString *lastLinkOFilePath = nil;
    NSMutableSet *shouldLinkOFilePathSetM = [NSMutableSet set];
    
    NSString *source = [NSString stringWithFormat:@"nm -nm %@ | grep '(undefined) external _$s'", swiftOFilePath];
    
    ShellResult *result = [ShellService doShellOutputWithSource:source];
    if (!result.success) {
        return nil;
    }
    
    NSArray *undefineSymbols = [result.output componentsSeparatedByString:@"\n"];
    
    for (NSString *undefineSymbol in undefineSymbols) {
        NSString *symbol = [undefineSymbol chr_subStringFrom:@"(undefined) external " containFrom:NO];
        if (![symbol hasPrefix:@"_$s"]) {
            continue;
        }
        @autoreleasepool {
            NSDictionary *privateSymbolsDic = [SymbolSharedManager() privateSwiftSymbolsDicM];
            if (![lastLinkOFilePath isEqualToString:swiftOFilePath] && [privateSymbolsDic[lastLinkOFilePath] containsObject:symbol]) { // 优先从最近link的.o里面查找
                [shouldLinkOFilePathSetM addObject:lastLinkOFilePath];
                [shouldLinkOFilePathSetM addObjectsFromArray:[self shouldLinkOFilePathsForSwiftOFilePath:lastLinkOFilePath]];
                continue;
            }
            
            for (NSString *key in privateSymbolsDic.allKeys) {
                if (![lastLinkOFilePath isEqualToString:swiftOFilePath] && [privateSymbolsDic[key] containsObject:symbol]) {
                    [shouldLinkOFilePathSetM addObject:key];
                    lastLinkOFilePath = key;
                    // 递归
                    [shouldLinkOFilePathSetM addObjectsFromArray:[self shouldLinkOFilePathsForSwiftOFilePath:key]];
                    break;
                }
            }
        }
    }
    
    return [shouldLinkOFilePathSetM allObjects];
}


@end
