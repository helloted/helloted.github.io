//
//  FileChangeManager.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/12/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "FileChangeManager.h"

@interface FileChangeManager ()

// 改变文件路径集合
@property (nonatomic, strong) NSMutableSet *changedFilePathSetM;

@end

@implementation FileChangeManager

- (void)clearData
{
    [self.changedFilePathSetM removeAllObjects];
}

- (NSArray <NSString *>*)didModifyFileNames
{
    NSMutableArray *fileNamesM = [NSMutableArray array];
    for (NSString *filePath in self.changedFilePathSetM) {
        NSString *fileName = [filePath lastPathComponent];
        if (fileName) {
            [fileNamesM addObject:fileName];
        }
    }
    
    return [fileNamesM copy];
}

- (NSArray <NSString *>*)didModifyFilePaths
{
    return [self.changedFilePathSetM mutableCopy];
}

- (void)addChangedFilePaths:(NSArray *)filePaths
{
    if (!self.changedFilePathSetM) {
        self.changedFilePathSetM = [NSMutableSet set];
    }
    // 文件存在且不为文件夹再添加
    for (NSString *filePath in filePaths) {
        BOOL isDir = NO;
        BOOL isExists = [[NSFileManager defaultManager] fileExistsAtPath:filePath isDirectory:&isDir];
        // 过滤掉 GameCenterGiftEntryView~.m 这种文件
        BOOL shouldIgnore = [[filePath lastPathComponent] containsString:@"~."];
        if (!isDir && !shouldIgnore && isExists) {
            [self.changedFilePathSetM addObject:filePath];
        } else {
            NSLog(@"忽略文件：%@", filePath);
        }
    }
}

@end
