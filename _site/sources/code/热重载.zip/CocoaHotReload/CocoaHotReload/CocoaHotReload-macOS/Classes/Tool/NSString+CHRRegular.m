//
//  NSString+CHRRegular.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/4/14.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "NSString+CHRRegular.h"

@implementation NSString (CHRRegular)

- (NSString *)chr_subStringBetweenFrom:(NSString *)from to:(NSString *)to backwardsSearch:(BOOL)backwardsSearch
{
    NSStringCompareOptions options = NSCaseInsensitiveSearch;
    if (backwardsSearch) {
        options = NSBackwardsSearch;
        NSString *tmp = from;
        from = to;
        to = tmp;
    }
    NSRange fromRange = [self rangeOfString:from options:options];
    if (fromRange.location == NSNotFound)
        return nil;
    
    NSString *subStr = nil;
    if (backwardsSearch) {
        subStr = [self substringToIndex:fromRange.location];
    } else {
        subStr = [self substringFromIndex:fromRange.location + fromRange.length];
    }
    
    NSRange toRange = [subStr rangeOfString:to options:options];
    if (toRange.location == NSNotFound)
        return nil;
    
    NSString *resultStr = nil;
    if (backwardsSearch) {
        resultStr = [subStr substringFromIndex:toRange.location + toRange.length];
    } else {
        resultStr = [subStr substringToIndex:toRange.location];
    }
    return resultStr;
}

- (NSString *)chr_subStringFrom:(NSString *)from to:(NSString *)to backwardsSearch:(BOOL)backwardsSearch
{
    NSString *betweenStr = [self chr_subStringBetweenFrom:from to:to backwardsSearch:backwardsSearch];
    if (!betweenStr)
        return nil;
    
    return [NSString stringWithFormat:@"%@%@%@", from, betweenStr, to];
}

- (NSArray<NSString *> *)chr_subStringsWithRegular:(NSString *)regular options:(NSRegularExpressionOptions)options
{
    NSArray<NSTextCheckingResult *> *result = [self chr_subStringResultsWithRegular:regular options:options];
    if (result) {
        NSMutableArray *array = [NSMutableArray array];
        for (int i = 0; i<result.count; i++) {
           NSTextCheckingResult *res = result[i];
           NSString *subStr = [self substringWithRange:res.range];
           if (subStr) {
               [array addObject:subStr];
           }
        }
        return array;
    } else {
        return nil;
    }
}

- (NSArray<NSTextCheckingResult *> *)chr_subStringResultsWithRegular:(NSString *)regular options:(NSRegularExpressionOptions)options
{
    NSError *error;
    NSRegularExpression *expression = [NSRegularExpression regularExpressionWithPattern:regular options:options error:&error];
    
    NSArray<NSTextCheckingResult *> *result = [expression matchesInString:self options:0 range:NSMakeRange(0, self.length)];
    if (result) {
        return result;
    } else {
        NSLog(@"正则表达式出错：%@", error.localizedDescription);
        return nil;
    }
}

- (NSString *)chr_subStringFrom:(NSString *)from containFrom:(BOOL)isContainFrom
{
    NSRange fromRange = [self rangeOfString:from];
    if (fromRange.location == NSNotFound) {
        return nil;
    }
    
    if (isContainFrom) {
        return [self substringFromIndex:fromRange.location];
    }
    
    return [self substringFromIndex:fromRange.location + fromRange.length];
}

@end
