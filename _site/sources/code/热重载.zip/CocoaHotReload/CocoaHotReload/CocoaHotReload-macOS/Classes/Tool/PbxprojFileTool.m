//
//  PbxprojFileTool.m
//  CocoaHotReload-macOS
//
//  Created by guoyanshi on 2020/7/2.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "PbxprojFileTool.h"
#import "AppDelegate.h"
#import <AppKit/AppKit.h>
#import <ServiceManagement/SMLoginItem.h>
#import "CocoaHotReloadSettings.h"
#import "CocoaHotReloadManager.h"
#import "SocketServer.h"
#import "CocoaHotReloadServerDefine.h"
#import "NSString+CHRRegular.h"
#import "ProjectManager.h"

NSString * const kDefaultShowAutoLaunchTipKey = @"kDefaultShowAutoLaunchTipKey";
NSString * const kCocoaReloadCompleteNotification = @"kCocoaReloadCompleteNotification";

NSString * const kDefaultAutoSelectKey = @"kDefaultAutoSelectKey";
NSString * const kDefaultAutoLaunchKey = @"kDefaultAutoLaunchKey";
static NSString * const kDefaultRecentPathKey = @"kDefaultRecentPathKey";

@implementation PbxprojFileTool

+ (NSSet *)getProjectBundleIDsWithURL:(NSURL *)url {
    NSURL *projectUrl = [url URLByDeletingPathExtension];
    projectUrl = [projectUrl URLByAppendingPathExtension:@"xcodeproj"];
    projectUrl = [projectUrl URLByAppendingPathComponent:@"project.pbxproj"];
    NSData *data = [NSData dataWithContentsOfURL:projectUrl];
    if (!data || data.length == 0) {
        return nil;
    }

    NSDictionary *list = (NSDictionary *)[NSPropertyListSerialization propertyListWithData:data options:NSPropertyListMutableContainersAndLeaves format:nil error:nil];
    
    NSDictionary *objectList = list[@"objects"];
    if (!objectList) {
        return nil;
    }

    NSString *rootObjectKey = list[@"rootObject"];
    if(!rootObjectKey) {
        return nil;
    }
    NSDictionary *rootObject = objectList[rootObjectKey];
    NSArray *target = rootObject[@"targets"];   //targets name list
    
    NSMutableSet *bundleIDsSet = [NSMutableSet setWithCapacity:0];
    [target enumerateObjectsUsingBlock:^(NSString *obj, NSUInteger idx, BOOL * _Nonnull stop) {
       
        NSDictionary *targetInfo = objectList[obj];
        NSString *buildName = targetInfo[@"buildConfigurationList"];
        if (!buildName) {
            return;
        }
        
        NSDictionary *build = objectList[buildName];
        NSArray *buildConfigs = build[@"buildConfigurations"];      //target build config list
        
        [buildConfigs enumerateObjectsUsingBlock:^(NSString *subObj, NSUInteger idx, BOOL * _Nonnull stop) {
            NSDictionary *config = objectList[subObj];
            NSDictionary *buildSettings = config[@"buildSettings"];
            NSString *bundleID = buildSettings[@"PRODUCT_BUNDLE_IDENTIFIER"];
            if (bundleID) {
                [bundleIDsSet addObject:bundleID];
            }
        }];
    }];
    return bundleIDsSet.count > 0 ? [bundleIDsSet copy] : nil;
}


#pragma mark - Auto Launch

+ (void)addReloadCompleteNotification {
    __weak typeof(self)weakSelf = self;
    [[NSNotificationCenter defaultCenter] addObserverForName:kCocoaReloadCompleteNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(NSNotification * _Nonnull note) {
        [weakSelf checkAutoLaunchProjectIfNeed];
    }];

}

+ (void)postReloadCompleteNotification {
    [[NSNotificationCenter defaultCenter] postNotificationName:kCocoaReloadCompleteNotification object:nil];
}

+ (void)checkAutoLaunchProjectIfNeed {
    static int recoloadCount = 0;
    if (recoloadCount < 2) {
        recoloadCount = recoloadCount + 1;
        return;
    }
    
    if (![[NSUserDefaults standardUserDefaults] objectForKey:kDefaultShowAutoLaunchTipKey]) {
           [[NSUserDefaults standardUserDefaults] setObject:@(1) forKey:kDefaultShowAutoLaunchTipKey];
           [[NSUserDefaults standardUserDefaults] synchronize];

           NSAlert *alert = [[NSAlert alloc] init];
           alert.alertStyle = NSAlertStyleWarning;
           alert.messageText = @"是否设置开机自启动,在Preferences可调整";
           [alert addButtonWithTitle:@"确定"];
           [alert addButtonWithTitle:@"取消"];
           [alert beginSheetModalForWindow:[[NSApplication sharedApplication] windows].firstObject completionHandler:^(NSModalResponse returnCode){
               if (returnCode == NSAlertFirstButtonReturn) {
                   [self setAutoLaunch:YES];
               }
           }];
       }
}

+ (void)setAutoLaunch:(BOOL)isAutoLaunch {
    SMLoginItemSetEnabled((__bridge CFStringRef)@"com.tencent.CocoaHotReloadLaunchHelper", isAutoLaunch);
    [[NSUserDefaults standardUserDefaults] setObject:@(isAutoLaunch) forKey:kDefaultAutoLaunchKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
    //https://apple.stackexchange.com/questions/81821/how-to-stop-an-app-from-launching-on-login
    //launchctl disable gui/$UID/com.tencent.CocoaHotReloadLaunchHelper   手动禁止方法
}

+ (BOOL)isAutoLaunch
{
    return [[[NSUserDefaults standardUserDefaults] objectForKey:kDefaultAutoLaunchKey] boolValue];
}

#pragma mark - auto select project

+ (void)checkAutoSelectProjectIfNeed {
    NSControlStateValue autoSelectState = [[[NSUserDefaults standardUserDefaults] objectForKey:kDefaultAutoSelectKey] intValue];
    
    HRLog(@"Auto Selected Project State: %d",autoSelectState == NSControlStateValueOn);
    if (autoSelectState != NSControlStateValueOn) {
        return;
    }
    NSArray *pathAry = [[NSUserDefaults standardUserDefaults] arrayForKey:kDefaultRecentPathKey];
    NSString *path = pathAry.firstObject;
    if (path && [[NSFileManager defaultManager] fileExistsAtPath:path]) {
        [self selectProjectWithUrl:[NSURL fileURLWithPath:path]];
    }
}

+ (void)selectProjectWithUrl:(NSURL *)selectedURL {
    // 检测中文路径
    NSArray *results = [[selectedURL path] chr_subStringsWithRegular:@"[\u4e00-\u9fa5]+" options:NSRegularExpressionDotMatchesLineSeparators];
    if (results.count > 0) {
        ErrorLog(@"项目路径不支持中文，请重新选择！%@", [selectedURL path]);
        return;
    }
    
    [ProjectSharedManager() setupSettings:^(CocoaHotReloadSettings * _Nonnull settings) {
        settings.projectFilePath = [selectedURL path];
        settings.bundleIDs = [PbxprojFileTool getProjectBundleIDsWithURL:selectedURL];
    }];
    HRLog(@"Selected Project : %@", selectedURL.path);
    [[SocketServer currentServer] postNotificationForSocketCommand:SocketCommandDidSelectProject value:nil];
}

+ (void)saveProjectPath:(NSString *)path {
    NSArray *saveAry = nil;
    NSArray *pathAry = [[NSUserDefaults standardUserDefaults] arrayForKey:kDefaultRecentPathKey];
    int maxCount = 5;       //最多展示5条
    if (pathAry && ![pathAry isKindOfClass:[NSArray class]]) {
        pathAry = nil;
    }
    NSMutableArray *mutabUrlAry = [NSMutableArray arrayWithArray:pathAry];
    if ([pathAry containsObject:path]) {
        [mutabUrlAry removeObject:path];
    }
    [mutabUrlAry insertObject:path atIndex:0];
    if (mutabUrlAry.count > maxCount) {
        saveAry = [mutabUrlAry subarrayWithRange:NSMakeRange(0, maxCount)];
    }
    else {
        saveAry = [mutabUrlAry copy];
    }
    
    [[NSUserDefaults standardUserDefaults] setObject:saveAry forKey:kDefaultRecentPathKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (NSArray *)getRecentProjectPath {
    return [[NSUserDefaults standardUserDefaults] arrayForKey:kDefaultRecentPathKey];
}


@end
