//
//  CocoaHotReloadSettings.m
//  CocoaHotReloadDemo
//
//  Created by mambaxie on 2019/11/26.
//  Copyright © 2019 tencent. All rights reserved.
//

#import "CocoaHotReloadSettings.h"
#import "CocoaHotReloadPreferences.h"
#import "CocoaHotReloadManager.h"

static NSString * const kXcodeDeveloperPath = @"/Applications/Xcode.app/Contents/Developer";
static NSString * const kArch = @"x86_64";

@implementation CocoaHotReloadSettings

+ (instancetype)defaultSettings
{
    CocoaHotReloadSettings *settings = [CocoaHotReloadSettings new];
    settings.arch = kArch;
    settings.XcodeDeveloperPath = kXcodeDeveloperPath;
    
    return settings;
}

- (NSArray *)watchDirectoryPaths
{
    if (_watchDirectoryPaths.count == 0 && [self projectDirectoryPath]) {
        return @[[self projectDirectoryPath]];
    }
    return _watchDirectoryPaths;
}

- (NSString *)XcodeDeveloperPath
{
    NSString *customXcodeAppDir = [CocoaHotReloadManager shareInstance].preferences.customXcodeAppDir;
    return (customXcodeAppDir.length > 0) ? [customXcodeAppDir stringByAppendingPathComponent:@"Contents/Developer"] : kXcodeDeveloperPath;
}

- (NSString *)projectDirectoryPath
{
    return [_projectFilePath stringByDeletingLastPathComponent];
}

- (NSString *)configuration
{
    return _configuration ?: @"Debug";
}

- (NSString *)projectName
{
    return _projectName ?: [[_projectFilePath lastPathComponent] stringByDeletingPathExtension];
}

@end
