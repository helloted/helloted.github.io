//
//  PreferencesWindowController.m
//  CocoaHotReload-macOS
//
//  Created by 谢培艺 on 2020/2/18.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "PreferencesWindowController.h"
#import "PTHotKey.h"
#import "PTHotKeyCenter.h"
#import "AppDelegate.h"
#import <ServiceManagement/SMLoginItem.h>
#import "PbxprojFileTool.h"
#import "ShortcutRecorder.h"
#import "CocoaHotReloadPreferences.h"
#import "CocoaHotReloadManager.h"
#import "SocketCommandServerHandler.h"
#import "CocoaHotReloadServerDefine.h"
#import "CocoaHotReloadSettings.h"

@interface CHRRecorderControl : SRRecorderControl

@end

@implementation CHRRecorderControl

- (NSDictionary *)normalLabelAttributes
{
    NSMutableDictionary *attriM = [[super normalLabelAttributes] mutableCopy];
    // 适配夜间模式
    attriM[NSForegroundColorAttributeName] = [NSColor blackColor];
    return [attriM copy];
}

- (NSDictionary *)recordingLabelAttributes
{
    NSMutableDictionary *attriM = [[super normalLabelAttributes] mutableCopy];
    // 适配夜间模式
    attriM[NSForegroundColorAttributeName] = [NSColor grayColor];
    return [attriM copy];
}

@end

@interface PreferencesWindowController() <NSTextFieldDelegate, SRRecorderControlDelegate, SRValidatorDelegate, NSComboBoxDelegate>

@property (nonatomic, strong) SRValidator *validator;

@property (nonatomic, strong) NSTextField *ignoreClassMethodNamesFiled;

/// 热重载快捷键
@property (nonatomic, strong) SRRecorderControl *hotReloadRecorder;

/// 显示或隐藏log window快捷键
@property (nonatomic, strong) SRRecorderControl *showOrHideLogRecorder;

@property (nonatomic, strong) CocoaHotReloadPreferences *preferences;

@property (nonatomic, strong) NSComboBox *derivedDataComboBox;
@property (nonatomic, strong) NSTextField *derivedDataField;
@property (nonatomic, strong) NSArray<NSString *> *derivedDatas;

@property (nonatomic, strong) NSTextField *watchingDirField;

@property (nonatomic, strong) NSTextField *xcodeAppDirField;

@end

@implementation PreferencesWindowController

#pragma mark NSWindowController

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    self.window.title = @"Preferences";
    
    self.preferences = [CocoaHotReloadManager shareInstance].preferences;
    self.validator = [[SRValidator alloc] initWithDelegate:self];
    
    CHRRecorderControl *hotReloadRecorder = [[CHRRecorderControl alloc] initWithFrame:NSZeroRect];
    hotReloadRecorder.delegate = self;
    [hotReloadRecorder setAllowedModifierFlags:NSEventModifierFlagShift | NSEventModifierFlagOption | NSEventModifierFlagCommand
                            requiredModifierFlags:0
                         allowsEmptyModifierFlags:NO];
    CHRRecorderControl *showOrHideLogRecorder = [[CHRRecorderControl alloc] initWithFrame:NSZeroRect];
    showOrHideLogRecorder.delegate = self;
    
    NSTextField *hotReloadLabel = [self titleLabelWithTitle:@"Hot Reload:"];
    
    NSTextField *showOrHideLogLabel = [self titleLabelWithTitle:@"Show Or Hide Log:"];
    
    NSTextField *autoSelectProjectLabel = [self titleLabelWithTitle:@"Auto Select Project:"];
    NSButton *autoSelectProjectBtn = [NSButton checkboxWithTitle:@"" target:self action:@selector(clickAutoSelectProjectAction:)];
    autoSelectProjectBtn.translatesAutoresizingMaskIntoConstraints = NO;
    NSControlStateValue autoSelectState = [[[NSUserDefaults standardUserDefaults] objectForKey:kDefaultAutoSelectKey] intValue];
    autoSelectProjectBtn.state = autoSelectState;
    
    //AutoLaunch
    NSTextField *autoLaunchLabel = [self titleLabelWithTitle:@"Auto Launch:"];
    
    NSButton *autoLaunchBtn = [NSButton checkboxWithTitle:@"" target:self action:@selector(clickAutoLaunchAction:)];
    autoLaunchBtn.translatesAutoresizingMaskIntoConstraints = NO;
    NSControlStateValue autoLaunchState = [[[NSUserDefaults standardUserDefaults] objectForKey:kDefaultAutoLaunchKey] intValue];
    autoLaunchBtn.state = autoLaunchState;
    
    // DerivedData
    NSTextField *derivedDataLabel = [self titleLabelWithTitle:@"Derived Data:"];
    NSComboBox *derivedDataComboBox = [[NSComboBox alloc] init];
    NSArray<NSString *> *datas = @[@"Default", @"Relative", @"Custom"];
    [derivedDataComboBox addItemsWithObjectValues:datas];
    DerivedDataType type = self.preferences.derivedDataType;
    derivedDataComboBox.stringValue = datas[type];
    derivedDataComboBox.editable = NO;
    derivedDataComboBox.translatesAutoresizingMaskIntoConstraints = NO;
    derivedDataComboBox.delegate = self;
    derivedDataComboBox.translatesAutoresizingMaskIntoConstraints = NO;
    self.derivedDataComboBox = derivedDataComboBox;
    NSTextField *derivedDataField = [self createTextFiled];
    if (self.preferences.derivedDataPath) {
        derivedDataField.stringValue = self.preferences.derivedDataPath;
    }
    self.derivedDataField = derivedDataField;
    
    // Custom Xcode app Directory
    NSTextField *xcodeAppDirLabel = [self titleLabelWithTitle:@"Custom Xcode app Directory:"];
    NSTextField *xcodeAppDirField = [self createTextFiled];
    if (self.preferences.customXcodeAppDir) {
        xcodeAppDirField.stringValue = self.preferences.customXcodeAppDir;
    }
    self.xcodeAppDirField = xcodeAppDirField;
    
    // Custom Watching Directory
    NSTextField *watchingDirLabel = [self titleLabelWithTitle:@"Custom Watching Directory:"];
    watchingDirLabel.alignment = NSTextAlignmentLeft;
    NSTextField *watchingDirField = [self createTextFiled];
    if (self.preferences.customWatchingDir) {
        watchingDirField.stringValue = self.preferences.customWatchingDir;
        watchingDirField.delegate = self;
    }
    self.watchingDirField = watchingDirField;
    
    // ignoreClassMethodNames
    NSTextField *ignoreClassMethodNamesLabel = [self titleLabelWithTitle:@"热重载时，忽略类方法列表（用\"|\"分隔&不区分大小写）:"];
    ignoreClassMethodNamesLabel.alignment = NSTextAlignmentLeft;
    NSTextField *ignoreClassMethodNamesFiled = [self createTextFiled];
    ignoreClassMethodNamesFiled.stringValue = [self.preferences.ignoreClassMethodNames componentsJoinedByString:@"|"];
    self.ignoreClassMethodNamesFiled = ignoreClassMethodNamesFiled;

    NSView *contentView = self.window.contentView;
    [contentView addSubview:hotReloadRecorder];
    [contentView addSubview:showOrHideLogRecorder];
    [contentView addSubview:hotReloadLabel];
    [contentView addSubview:showOrHideLogLabel];
    [contentView addSubview:autoSelectProjectLabel];
    [contentView addSubview:autoSelectProjectBtn];
    
    [contentView addSubview:autoLaunchLabel];
    [contentView addSubview:autoLaunchBtn];
    
    [contentView addSubview:derivedDataLabel];
    [contentView addSubview:derivedDataComboBox];
    [contentView addSubview:derivedDataField];
    
    [contentView addSubview:xcodeAppDirLabel];
    [contentView addSubview:xcodeAppDirField];
    
    [contentView addSubview:watchingDirLabel];
    [contentView addSubview:watchingDirField];
    
    [contentView addSubview:ignoreClassMethodNamesLabel];
    [contentView addSubview:ignoreClassMethodNamesFiled];
    
    NSDictionary *views = NSDictionaryOfVariableBindings(hotReloadRecorder,
                                                         showOrHideLogRecorder,
                                                         hotReloadLabel,
                                                         showOrHideLogLabel,
                                                         autoSelectProjectLabel,
                                                         autoSelectProjectBtn,
                                                         autoLaunchLabel,
                                                         autoLaunchBtn,
                                                         derivedDataLabel,
                                                         derivedDataComboBox,
                                                         derivedDataField,
                                                         xcodeAppDirLabel,
                                                         xcodeAppDirField,
                                                         watchingDirLabel,
                                                         watchingDirField,
                                                         ignoreClassMethodNamesLabel,
                                                         ignoreClassMethodNamesFiled);
    [contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[hotReloadLabel(==160)]-[hotReloadRecorder(>=100)]-|"
                                                              options:NSLayoutFormatAlignAllBaseline
                                                              metrics:nil
                                                                views:views]];
    [contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[showOrHideLogLabel(==hotReloadLabel)]-[showOrHideLogRecorder(==hotReloadRecorder)]-|"
                                                              options:NSLayoutFormatAlignAllBaseline
                                                              metrics:nil
                                                                views:views]];
    [contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[autoSelectProjectLabel(==hotReloadLabel)]-[autoSelectProjectBtn(==hotReloadRecorder)]-|"
                                                              options:NSLayoutFormatAlignAllCenterY
                                                              metrics:nil
                                                                views:views]];
    
    [contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[autoLaunchLabel(==hotReloadLabel)]-[autoLaunchBtn(==hotReloadRecorder)]-|"
                                                              options:NSLayoutFormatAlignAllCenterY
                                                              metrics:nil
                                                                views:views]];
    
    [contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[watchingDirLabel(==600)]-|"
                                                              options:NSLayoutFormatAlignAllCenterY
                                                              metrics:nil
                                                                views:views]];
    
    [contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[watchingDirField(==600)]-|"
                                                              options:NSLayoutFormatAlignAllCenterY
                                                              metrics:nil
                                                                views:views]];
    
    [contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[derivedDataLabel]-[derivedDataComboBox(==70)]-[derivedDataField(>=150)]-|"
                                                              options:NSLayoutFormatAlignAllCenterY
                                                              metrics:nil
                                                                views:views]];
    
    [contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[xcodeAppDirLabel]-[xcodeAppDirField(>=150)]-|"
                                                              options:NSLayoutFormatAlignAllCenterY
                                                              metrics:nil
                                                                views:views]];
    
    [contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[ignoreClassMethodNamesLabel(==600)]-|"
                                                              options:NSLayoutFormatAlignAllCenterY
                                                              metrics:nil
                                                                views:views]];
    
    [contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:|-[ignoreClassMethodNamesFiled(==600)]-|"
                                                              options:NSLayoutFormatAlignAllCenterY
                                                              metrics:nil
                                                                views:views]];
    
    [contentView addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-[hotReloadRecorder(==25)]-[showOrHideLogRecorder(==25)]-[autoSelectProjectBtn(==25)]-[autoLaunchBtn(==25)]-[derivedDataLabel(==20)]-[xcodeAppDirLabel(==20)][watchingDirLabel(==20)]-[watchingDirField(>=45)]-[ignoreClassMethodNamesLabel(==20)]-[ignoreClassMethodNamesFiled(>=80)]-|"
                                                              options:0
                                                              metrics:nil
                                                                views:views]];
    
    NSUserDefaultsController *defaults = [NSUserDefaultsController sharedUserDefaultsController];
    self.hotReloadRecorder = hotReloadRecorder;
    [self.hotReloadRecorder bind:NSValueBinding
                           toObject:defaults
                        withKeyPath:kHotReloadKeyPath
                            options:nil];
    self.showOrHideLogRecorder = showOrHideLogRecorder;
    [self.showOrHideLogRecorder bind:NSValueBinding
                                 toObject:defaults
                              withKeyPath:kShowOrHideLogKeyPath
                                  options:nil];
}

- (NSTextField *)titleLabelWithTitle:(NSString *)title
{
    NSTextField *titleLabel = [[NSTextField alloc] initWithFrame:NSZeroRect];
    titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    titleLabel.font = [NSFont systemFontOfSize:14];
    titleLabel.editable = NO;
    titleLabel.selectable = NO;
    titleLabel.bezeled = NO;
    titleLabel.alignment = NSTextAlignmentRight;
    titleLabel.stringValue = title;
    titleLabel.drawsBackground = NO;
    [titleLabel setContentHuggingPriority:NSLayoutPriorityDefaultHigh forOrientation:NSLayoutConstraintOrientationHorizontal];
    
    return titleLabel;
}

- (NSTextField *)createTextFiled
{
    NSTextField *textFiled = [[NSTextField alloc] init];
    textFiled.translatesAutoresizingMaskIntoConstraints = NO;
    textFiled.font = [NSFont systemFontOfSize:14];
    textFiled.editable = YES;
    textFiled.selectable = YES;
    textFiled.bezeled = YES;
    textFiled.backgroundColor = NSColor.textBackgroundColor;
    textFiled.alignment = NSTextAlignmentLeft;
    textFiled.drawsBackground = YES;
    textFiled.delegate = self;
    textFiled.maximumNumberOfLines = 0;
    
    return textFiled;
}

- (void)clickAutoSelectProjectAction:(NSButton *)btn {
    NSLog(@"click auto Select Project state %ld",(long)btn.state);
    [[NSUserDefaults standardUserDefaults] setObject:@(btn.state) forKey:kDefaultAutoSelectKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

- (void)clickAutoLaunchAction:(NSButton *)btn {
    NSLog(@"click auto Launch state %ld",(long)btn.state);
    [PbxprojFileTool setAutoLaunch:btn.state == NSControlStateValueOn];
}

#pragma mark - NSComboBoxDelegate
- (void)comboBoxSelectionDidChange:(NSNotification *)notification
{
    DerivedDataType type = self.derivedDataComboBox.indexOfSelectedItem > 0 ? self.derivedDataComboBox.indexOfSelectedItem : DerivedDataTypeDefault;
    
    NSString *defaultPath = [CocoaHotReloadPreferences defaultPreferences].derivedDataPath;
    switch (type) {
        case DerivedDataTypeDefault:
        {
            self.derivedDataField.stringValue = defaultPath;
            self.derivedDataField.editable = NO;
            break;
        }
        case DerivedDataTypeRelative:
        {
            self.derivedDataField.stringValue = @"DerivedData";
            self.derivedDataField.editable = YES;
            break;
        }
        case DerivedDataTypeCustom:
        {
            self.derivedDataField.stringValue = defaultPath;
            self.derivedDataField.editable = YES;
            break;
        }
            
        default:
            break;
    }
    self.preferences.derivedDataType = type;
    self.preferences.derivedDataPath = self.derivedDataField.stringValue;
    [[CocoaHotReloadManager shareInstance] synchronizePreference];
}

#pragma mark - NSTextFiledDelegate
- (void)controlTextDidEndEditing:(NSNotification *)notification
{
    NSTextField *textField = [notification object];
    if (textField == self.ignoreClassMethodNamesFiled) {
        self.preferences.ignoreClassMethodNames = [self.ignoreClassMethodNamesFiled.stringValue componentsSeparatedByString:@"|"];
    } else if (textField == self.derivedDataField) {
        self.preferences.derivedDataPath = self.derivedDataField.stringValue;
    } else if (textField == self.watchingDirField) {
        BOOL isDir;
        if (![[NSFileManager defaultManager] fileExistsAtPath:self.watchingDirField.stringValue isDirectory:&isDir] || !isDir) {
            if (self.watchingDirField.stringValue.length > 0) {
                ErrorLog(@"The file does not exist or is not a directory : %@", self.watchingDirField.stringValue);
                return;
            }
        }
        self.preferences.customWatchingDir = self.watchingDirField.stringValue;
        [[SocketCommandServiceHandler shareInstance] startWatchDirctoryIfNeed];
    } else if (textField == self.xcodeAppDirField) {
        NSString *xcodeAppDir = self.xcodeAppDirField.stringValue;
        self.preferences.customXcodeAppDir = xcodeAppDir;
    }
    
    [[CocoaHotReloadManager shareInstance] synchronizePreference];
}

#pragma mark SRRecorderControlDelegate

- (BOOL)shortcutRecorder:(SRRecorderControl *)aRecorder canRecordShortcut:(NSDictionary *)aShortcut
{
    __autoreleasing NSError *error = nil;
    BOOL isTaken = [_validator isKeyCode:[aShortcut[SRShortcutKeyCode] unsignedShortValue] andFlagsTaken:[aShortcut[SRShortcutModifierFlagsKey] unsignedIntegerValue] error:&error];

    if (isTaken)
    {
        NSBeep();
        [self presentError:error
            modalForWindow:self.window
                  delegate:nil
        didPresentSelector:NULL
               contextInfo:NULL];
    }

    return !isTaken;
}

- (BOOL)shortcutRecorderShouldBeginRecording:(SRRecorderControl *)aRecorder
{
    [[PTHotKeyCenter sharedCenter] pause];
    return YES;
}

- (void)shortcutRecorderDidEndRecording:(SRRecorderControl *)aRecorder
{
    [[PTHotKeyCenter sharedCenter] resume];
}

- (BOOL)shortcutRecorder:(SRRecorderControl *)aRecorder shouldUnconditionallyAllowModifierFlags:(NSEventModifierFlags)aModifierFlags forKeyCode:(unsigned short)aKeyCode
{
    // Keep required flags required.
    if ((aModifierFlags & aRecorder.requiredModifierFlags) != aRecorder.requiredModifierFlags)
        return NO;

    // Don't allow disallowed flags.
    if ((aModifierFlags & aRecorder.allowedModifierFlags) != aModifierFlags)
        return NO;

    switch (aKeyCode)
    {
        case kVK_F1:
        case kVK_F2:
        case kVK_F3:
        case kVK_F4:
        case kVK_F5:
        case kVK_F6:
        case kVK_F7:
        case kVK_F8:
        case kVK_F9:
        case kVK_F10:
        case kVK_F11:
        case kVK_F12:
        case kVK_F13:
        case kVK_F14:
        case kVK_F15:
        case kVK_F16:
        case kVK_F17:
        case kVK_F18:
        case kVK_F19:
        case kVK_F20:
            return YES;
        default:
            return NO;
    }
}


#pragma mark SRValidatorDelegate

- (BOOL)shortcutValidator:(SRValidator *)aValidator isKeyCode:(unsigned short)aKeyCode andFlagsTaken:(NSEventModifierFlags)aFlags reason:(NSString **)outReason
{
#define IS_TAKEN(aRecorder) (recorder != (aRecorder) && SRShortcutEqualToShortcut(shortcut, [(aRecorder) objectValue]))
    SRRecorderControl *recorder = (SRRecorderControl *)self.window.firstResponder;

    if (![recorder isKindOfClass:[SRRecorderControl class]])
        return NO;

    NSDictionary *shortcut = SRShortcutWithCocoaModifierFlagsAndKeyCode(aFlags, aKeyCode);

    if (IS_TAKEN(_hotReloadRecorder) ||
        IS_TAKEN(_showOrHideLogRecorder))
    {
        *outReason = @"it's already used. To use this shortcut, first remove or change the other shortcut";
        return YES;
    }
    else
        return NO;
#undef IS_TAKEN
}

- (BOOL)shortcutValidatorShouldCheckMenu:(SRValidator *)aValidator
{
    return YES;
}

@end
