//
//  SocketServer.m
//  CocoaHotReloadTool
//
//  Created by mambaxie on 2019/11/20.
//  Copyright © 2019 tencent. All rights reserved.
//

#import "SocketServer.h"
#import "CocoaHotReloadServerDefine.h"
#import "CocoaHotReloadManager.h"
#import "SocketCommandServerHandler.h"
#import "USBSocket.h"
#import "USBDeviceSocketManager.h"
#import "CocoaHotReloadReportService.h"
#import "TCPSocket.h"
#import "SharedManager.h"

@implementation SocketServer

+ (void)run
{
    /// Start tcp server
    HRLog(@"Waiting tcp connect...");
    [self startTCPServer:TCP_ADDRESS];
    /// Start usb server
    HRLog(@"Waiting usb connect...");
    [self startUSBServer:USB_SOCKET_PORT];
}

+ (SocketServer *)currentServer
{
    return (SocketServer *)[super currentSocket];
}

- (void)runInBackground
{
    // read status requests from client app
    /**
        SocketCommandPrintLog, // 输出日志
        SocketCommandClientInfo, // 客户端信息
        SocketCommandReloadComplete, // reload结束
    **/

    if ([self isUSBConnected]) {
        [self usbSocket].didReciveCommandBlock = ^(int cmd, id  _Nonnull value) {
            [self postNotificationForSocketCommand:cmd value:value];
        };
        [self usbSocket].didDisconnectBlock = ^(NSError *error) {
            if ([CocoaHotReloadSharedManager() currentScene] == CocoaHotReloadSceneDefault) {
                // client app disconnected
                NSString *deviceName = [error.userInfo objectForKey:@"deviceName"];
                ErrorLogWithoutToast(@"Client app usb disconnected : %@", deviceName ?: @"");
                if(![[USBDeviceSocketManager shareInstance] getCurrentConnectingChannel] && [[USBDeviceSocketManager shareInstance] getAllConnetingSocketInfos].count > 0) {
                    //usb连接断开了，但是还有其他设备连着
                    ErrorLogWithoutToast(@"请在菜单栏【select Device】中选择新设备连接");
                }

                // 数据上报
                CocoaHotReloadReport(@"connect", 2, 0, nil, nil);
                
                [CocoaToast showErrorWithMsg:@"Client app disconnected"];
                
                [CocoaHotReloadSharedManager() clearAllSharedManagerData];
                
                HRLog(@"Waiting usb connect...");
            }
        };
    } else { // tcp
        SocketCommand command;
        TCPSocket *tcpSocket = self.tcpSocket;
        while ((command = (SocketCommand)[tcpSocket readInt]) != SocketCommandEOF) {
         id value = nil;
         switch (command) {
             case SocketCommandPrintNormalLog:
             case SocketCommandPrintErrorLog:
                 value = [tcpSocket readString];
                 break;
                 
             case SocketCommandClientInfo:
                 value = [tcpSocket readDictionary];
                 break;
                 
             case SocketCommandReloadComplete:
                 value = [tcpSocket readDictionary];
                 break;
             default:
                 break;
         }
             
             [self postNotificationForSocketCommand:command value:value];
        }
        
        if ([CocoaHotReloadSharedManager() currentScene] == CocoaHotReloadSceneDefault) {
            // client app disconnected
            ErrorLogWithoutToast(@"Client app tcp disconnected");
            [CocoaToast showErrorWithMsg:@"Client app disconnected"];
            
            [CocoaHotReloadSharedManager() clearAllSharedManagerData];
            
            // 数据上报
            CocoaHotReloadReport(@"connect", 2, 0, nil, nil);
            
            HRLog(@"Waiting tcp connect...");
        }
        self.tcpSocket = nil;
        [self.class waitToConnectTCPServer];
    }
}

@end
