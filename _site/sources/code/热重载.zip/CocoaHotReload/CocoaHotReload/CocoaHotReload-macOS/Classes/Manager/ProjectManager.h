//
//  ProjectManager.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/12/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "SharedManager.h"
#import "CocoaHotReloadDefine.h"
@class CocoaHotReloadSettings;

/// 开始热重载
extern NSString * _Nonnull const kHotReloadStartLog;
/// 项目初始化
extern NSString * _Nonnull const kProjectInitLog;

#define ProjectSharedManager() [ProjectManager sharedInstance]

NS_ASSUME_NONNULL_BEGIN

@interface ProjectManager : SharedManager

/// 开始热重载
- (void)startHotReload;
/// 停止热重载
- (void)stopHotReload;

/// 最近一次热重载开始时间
- (NSTimeInterval)lastStartHotReloadTime;
/// 是否完成初始化
- (BOOL)isProjectDidFinishInit;
/// 更新mmkv存储目录
- (void)updateMmkvCacheDirIfNeed;

/// 是否有动态库正等待发送到客户端
- (BOOL)hasDylibWaitingToSendClient;

/// 热重载开启后，做一些初始化
/// @param completion 初始化结束回调
- (void)doProjectInitWithCompletion:(void (^_Nullable)(void))completion;

/// 重新编译指定文件路径的文件
/// @param filePaths 所要编译的文件路径数组
/// @param completion 编译结果回调
- (void)recompileFilesForFilePaths:(NSArray<NSString *> *)filePaths completion:(void(^_Nullable)(NSDictionary *))completion;

/// 发送exported symbol framework or lib
- (void)sentExportedSymbolsLibsToClient;

/// 初始化设置
/// @param settingsBlock 初始化的block
- (void)setupSettings:(void (^)(CocoaHotReloadSettings * _Nonnull settings))settingsBlock;
/// 当前设置
- (CocoaHotReloadSettings *)settings;
/// 更新设置内容（如需要）
- (void)updateSettingsIfNeed;
/// 清空设置
- (void)clearSettings;

/// 是否是模拟器
- (BOOL)isSimulator;

/// 是否是mac Catalyse
- (BOOL)isMacCatalyse;

/// 根据当前路径获取原始output路径
/// @param currentFilePath 当前路径
- (NSString *)originalOutputPathForCurrentFilePath:(NSString *)currentFilePath;

@end

NS_ASSUME_NONNULL_END
