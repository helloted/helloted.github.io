//
//  SharedManager.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/12/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

// 所有的SharedManager执行clearData函数的通知
FOUNDATION_EXPORT NSNotificationName const _Nonnull AllSharedManagerClearDataNotification;

NS_ASSUME_NONNULL_BEGIN

@interface SharedManager : NSObject

/// 单例
+ (instancetype)sharedInstance;

/// 清除数据
- (void)clearData;

@end

NS_ASSUME_NONNULL_END
