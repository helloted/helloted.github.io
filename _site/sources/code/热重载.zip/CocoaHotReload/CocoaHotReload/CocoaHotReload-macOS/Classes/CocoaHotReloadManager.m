//
//  CocoaHotReloadManager.m
//  CocoaHotReloadDemo
//
//  Created by mambaxie on 2019/11/26.
//  Copyright © 2019 tencent. All rights reserved.
//

#import "CocoaHotReloadManager.h"
#import "CocoaFileTool.h"
#import "CocoaHotReloadSettings.h"
#import "CocoaHotReloadPreferences.h"
#import "CocoaHotReloadTool.h"
#import "AppDelegate.h"
#import "SharedManager.h"
#import "ProjectManager.h"

static NSString *kCacheUserPreferencesKey = @"kCacheUserPreferencesKey";

@interface CocoaHotReloadManager()

@property (nonatomic, strong) CocoaHotReloadPreferences *preferences;

@end

@implementation CocoaHotReloadManager

+ (instancetype)shareInstance
{
    static dispatch_once_t onceToken;
    static CocoaHotReloadManager *manager;
    dispatch_once(&onceToken, ^{
        manager = [CocoaHotReloadManager new];
        NSData *preferencesData = [[NSUserDefaults standardUserDefaults] objectForKey:kCacheUserPreferencesKey];
        manager.preferences = preferencesData ? [NSKeyedUnarchiver unarchiveObjectWithData:preferencesData] : [CocoaHotReloadPreferences defaultPreferences];
    });
    return manager;
}

- (void)clearAllSharedManagerData
{
    [[NSNotificationCenter defaultCenter] postNotificationName:AllSharedManagerClearDataNotification object:nil];
}

- (void)synchronizePreference
{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setObject:[NSKeyedArchiver archivedDataWithRootObject:self.preferences] forKey:kCacheUserPreferencesKey];
    [userDefaults synchronize];
}

- (CocoaHotReloadScene)currentScene {
    return ProjectSharedManager().settings.currentScene;
}

- (NSString *)currentVersion
{
    return [[[NSBundle mainBundle] infoDictionary] valueForKey:@"CFBundleShortVersionString"];
}

/// 设置状态
- (void)setHotReloadStatus:(CocoaHotReloadStatus)status
{
    [CocoaHotReloadTool runOnMainThreadSync:^{
        [((AppDelegate *)[NSApplication sharedApplication].delegate) setStatusItemStatus:status];
    }];
}

/// 获取最近一次热重载日志
- (NSString *)logForLastHotReload
{
    __block NSString *log;
    [CocoaHotReloadTool runOnMainThreadSync:^{
        NSString *allLog = [((LogViewController *)[[NSApplication sharedApplication] windows].firstObject.contentViewController) allLogString];
        NSRange range = [allLog rangeOfString:kHotReloadStartLog options:NSBackwardsSearch];
        if (range.location != NSNotFound) {
            log = [allLog substringFromIndex:range.location];
        } else {
            log = allLog;
        }
    }];
    
    return log;
}

/// 获取所有日志
- (NSString *)allLogInLogWindow
{
    __block NSString *log;
    [CocoaHotReloadTool runOnMainThreadSync:^{
        log = [((LogViewController *)[[NSApplication sharedApplication] windows].firstObject.contentViewController) allLogString];
    }];
    
    return log;
}

@end
