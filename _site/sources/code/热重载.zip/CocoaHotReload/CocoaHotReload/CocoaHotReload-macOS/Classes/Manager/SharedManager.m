//
//  SharedManager.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/12/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "SharedManager.h"

NSNotificationName const AllSharedManagerClearDataNotification = @"AllSharedManagerClearDataNotification";

@implementation SharedManager

+ (instancetype)sharedInstance
{
    static NSMutableDictionary<NSString *, id> *sharedManagerDicM;
    
    NSString *className = NSStringFromClass(self);
    id sharedManager = sharedManagerDicM[className];
    @synchronized (AllSharedManagerClearDataNotification) {
        if (!sharedManagerDicM) {
            sharedManagerDicM = [NSMutableDictionary dictionary];
        }
        if (!sharedManager) {
            sharedManager = [[self alloc] init];
            [[NSNotificationCenter defaultCenter] addObserver:sharedManager selector:@selector(clearData) name:AllSharedManagerClearDataNotification object:nil];
            sharedManagerDicM[className] = sharedManager;
        }
    }
    
    return sharedManager;
}

- (void)clearData
{
    
}

@end
