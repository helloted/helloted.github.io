//
//  CocoaHotReloadPreferences.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/9/13.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "CocoaHotReloadPreferences.h"
#import "CocoaFileTool.h"

@implementation CocoaHotReloadPreferences

+ (instancetype)defaultPreferences
{
    CocoaHotReloadPreferences *preferences = [CocoaHotReloadPreferences new];
    preferences.derivedDataType = DerivedDataTypeDefault;
    preferences.derivedDataPath = [CocoaFileTool absolutePathForFilePath:@"~/Library/Developer/Xcode/DerivedData"];
    preferences.ignoreClassMethodNames = @[@"GetInstance", @"shareInstance", @"sharedInstance", @"shareManager", @"sharedManager", @"defaultManager"];
    
    return preferences;
}

- (instancetype)initWithCoder:(NSCoder *)coder
{
    if (self = [super init]) {
        self.ignoreClassMethodNames = [coder decodeObjectForKey:@"ignoreClassMethodNames"];
        self.derivedDataType = [[coder decodeObjectForKey:@"derivedDataType"] unsignedIntValue];
        self.derivedDataPath = [coder decodeObjectForKey:@"derivedDataPath"];
        self.customWatchingDir = [coder decodeObjectForKey:@"customWatchingDir"];
        self.customXcodeAppDir = [coder decodeObjectForKey:@"customXcodeAppDir"];
    }
    return self;
}

- (void)encodeWithCoder:(NSCoder *)coder
{
    [coder encodeObject:self.ignoreClassMethodNames forKey:@"ignoreClassMethodNames"];
    [coder encodeObject:@(self.derivedDataType) forKey:@"derivedDataType"];
    [coder encodeObject:self.derivedDataPath forKey:@"derivedDataPath"];
    [coder encodeObject:self.customWatchingDir forKey:@"customWatchingDir"];
    [coder encodeObject:self.customXcodeAppDir forKey:@"customXcodeAppDir"];
}

@end
