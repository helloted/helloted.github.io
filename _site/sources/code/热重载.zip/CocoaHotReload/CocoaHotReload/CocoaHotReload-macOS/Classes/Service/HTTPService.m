//
//  HTTPService.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/8/27.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "HTTPService.h"
#import "AFHTTPSessionManager.h"
// http 请求manager
static AFHTTPSessionManager *gHTTPSessionManager;

@implementation HTTPService

+ (void)load
{
    gHTTPSessionManager = [[AFHTTPSessionManager alloc] init];

    gHTTPSessionManager.requestSerializer = [AFHTTPRequestSerializer serializer];
    [gHTTPSessionManager.requestSerializer setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    gHTTPSessionManager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"image/gif", @"text/javascript", @"text/html", nil];
}

+ (void)get:(NSString *)url params:(NSDictionary *)params completion:(HTTPRequestCompletion)completion
{
    [gHTTPSessionManager GET:url parameters:params headers:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (completion) {
            completion(responseObject, nil);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (completion) {
            completion(nil, error);
        }
    }];
}

+ (void)post:(NSString *)url params:(NSDictionary *)params completion:(HTTPRequestCompletion)completion
{
    [gHTTPSessionManager POST:url parameters:params headers:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        if (completion) {
            completion(responseObject, nil);
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        if (completion) {
            completion(nil, error);
        }
    }];
}

@end
