//
//  FileManager.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/12/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "FileManager.h"
#import "CocoaFileTool.h"
#import "NSString+CHRRegular.h"
#import "ProjectManager.h"
#import "CocoaHotReloadSettings.h"
#import "CocoaHotReloadServerDefine.h"
#import "CocoaHotReloadPreferences.h"
#import "CocoaFileTool.h"
#import "ShellService.h"
#import "CompileCommandManager.h"
#import "CocoaHotReloadPreferences.h"

@interface FileManager()

// 最新编译成功的解压日志路径
@property (nonatomic, copy) NSString *lastBuildSucceedUzipLogFilePath;

// .o编译路径
@property (nonatomic, strong) NSMutableDictionary *fileBuildPathDicM;

// 编译产物 .o or .dia or .d
@property (nonatomic, strong) NSMutableDictionary *fileBuildProductPathDicM;

// 项目编译缓存根路径
@property (nonatomic, copy) NSString *projectBuildBasePath;

// 项目中参与编译的swift文件名
@property (nonatomic, strong) NSMutableSet<NSString *> *compileSwiftFileNameSetM;

@end

@implementation FileManager

- (void)clearData
{
    self.logStoreDic = nil;
    self.lastBuildSucceedUzipLogFilePath = nil;
    self.projectBuildBasePath = nil;
    self.compileSwiftFileNameSetM = nil;
    
    [self.fileBuildPathDicM removeAllObjects];
    [self.fileBuildProductPathDicM removeAllObjects];
}

#pragma mark - Public

- (NSString *)projectBuildLogsDir
{
    NSString *projectBuildPath = [self projectBaseBuildDirctoryWithDir:[self derivedDataPath]];
    
    if (projectBuildPath) {
        return [projectBuildPath stringByAppendingPathComponent:@"Logs/Build/"];
    }
    return nil;
}
- (NSString *)projectBuildDir
{
    NSString *derivedDataPath = [self derivedDataPath];
    
    return [[self projectBaseBuildDirctoryWithDir:derivedDataPath] stringByAppendingPathComponent:@"Build"];
}

- (NSString *)tmpDirAndCreateIfNeed
{
    NSString *tmpDir = ProjectSharedManager().settings.cmdProductDir ?: [[self cocoaHotReloadBuildLogsDir] stringByAppendingPathComponent:@"tmp"];
    
    [CocoaFileTool createDirectoryIfNeedForPath:tmpDir];
    
    return tmpDir;
}

- (NSString *)cocoaHotReloadBuildLogsDir
{
    NSString *buildLogsPath = [self projectBuildLogsDir];
    NSString *cocoaHotReloadDir = [buildLogsPath stringByAppendingPathComponent:@"CocoaHotReload"];
    return [CocoaFileTool createDirectoryIfNeedForPath:cocoaHotReloadDir];;
}

/// 最近一次编译成功日志
- (NSString *)lastBuildSucceedUnzipProjectLogFilePath
{
    if (_lastBuildSucceedUzipLogFilePath) {
        return _lastBuildSucceedUzipLogFilePath;
    }
    
    // 按时间排序
    NSArray<NSDictionary *> *logDics = [self.logStoreDic.allValues sortedArrayUsingComparator:^NSComparisonResult(NSDictionary *obj1, NSDictionary *obj2) {
      return [obj1[@"timeStoppedRecording"] doubleValue] < [obj2[@"timeStoppedRecording"] doubleValue];
    }];
    
    for (NSDictionary *logDic in logDics) {
        // Build executableName or Build projectName
        if (![self isBuildForProjectWithLogInfo:logDic]) {
            // 非Project编译日志，可能是编译单个文件如 Compile xxx.m
            continue;
        }
        
        NSString *logFilePath = logDic[@"unzipLogPath"];
        
        if ([self isBuildProjectSucceedForUnzipLogFilePath:logFilePath]) {
            return logFilePath;
        }
    }
    
    return nil;
}

/// 获取logStore路径
- (NSString *)logStoreFilePathForCocoaHotReload
{
    return [[self cocoaHotReloadBuildLogsDir] stringByAppendingPathComponent:@"logStore.plist"];
}

- (BOOL)hasNewProjectBuildSucceedLog
{
    NSString *buildLogsPath = [self projectBuildLogsDir];
    NSDictionary *logStoreManifest = [NSDictionary dictionaryWithContentsOfFile:[buildLogsPath stringByAppendingPathComponent:@"LogStoreManifest.plist"]];
    if (!logStoreManifest) {
       return NO;
    }
    
    NSDictionary *oldLogStoreDic = [self.logStoreDic mutableCopy];
    
    NSArray<NSDictionary *> *logInfos = [[logStoreManifest valueForKeyPath:@"logs"] allValues];
    for (NSDictionary *logInfo in logInfos) {
        if (![self isBuildForProjectWithLogInfo:logInfo]) {
            continue;
        }
        
        NSString *unuiqueId = logInfo[@"uniqueIdentifier"];
        NSDictionary *handledLogInfo = self.logStoreDic[unuiqueId];
        if (!oldLogStoreDic[unuiqueId] && !handledLogInfo) { // 有新的project编译日志为解析
            // 解压所有代码
            [self unzipAllBuildLogsIfNeed];
        }
        
        if ([self isBuildProjectSucceedForUnzipLogFilePath:handledLogInfo[@"unzipLogPath"]]) {
            return YES;
        }
    }
    
    return NO;
}

/// 解压所有编译日志
- (void)unzipAllBuildLogsIfNeed
{
    NSTimeInterval unzipBegin = [[NSDate date] timeIntervalSince1970];
    
    NSString *buildLogsPath = [self projectBuildLogsDir];
    
    NSString *cocoaHotReloadDir = [self cocoaHotReloadBuildLogsDir];
    
    NSDictionary *logStoreManifest = [NSDictionary dictionaryWithContentsOfFile:[buildLogsPath stringByAppendingPathComponent:@"LogStoreManifest.plist"]];
    if (!logStoreManifest) {
       return;
    }
    
    NSString *logStoreFilePath = [self logStoreFilePathForCocoaHotReload];
    
    NSMutableDictionary *logStoreDic = [[NSDictionary dictionaryWithContentsOfFile:logStoreFilePath] mutableCopy];
    if (!logStoreDic) {
        logStoreDic = [NSMutableDictionary dictionary];
    }
    BOOL didUnzipLog = NO;
    NSArray <NSDictionary *> *logInfos = [[logStoreManifest valueForKeyPath:@"logs"] allValues];
    NSMutableArray *logFileNamesM = [NSMutableArray array];
    for (NSDictionary *logInfo in logInfos) {
        NSString *fileName = logInfo[@"fileName"];
        NSString *projectBuildLogPath = [buildLogsPath stringByAppendingPathComponent:fileName];
        NSString *buildName = [fileName stringByDeletingPathExtension];
        if ([[NSFileManager defaultManager] fileExistsAtPath:projectBuildLogPath]) { // 文件存在
            [logFileNamesM addObject:fileName];
        } else { // 编译日志不存在
            continue;
        }
        if ([logStoreDic.allKeys containsObject:buildName]) { // log已处理或不存在
            continue;
        }
        
        if (!didUnzipLog) {
            HRLog(@"🚧 解压编译日志...");
            didUnzipLog = YES;
        }
        
        NSString *logDir = [CocoaFileTool createDirectoryIfNeedForPath:[cocoaHotReloadDir stringByAppendingPathComponent:buildName]];
        NSString *unzipLogPath = [NSString stringWithFormat:@"%@/%@.log", logDir, buildName];
        NSString *shellSource = [NSString stringWithFormat:@"gunzip -c %@ > %@", projectBuildLogPath, unzipLogPath];
        BOOL success = [ShellService doShellWithSource:shellSource];
        if (!success) {
           return;
        }
        
        NSMutableDictionary *logInfoM = [logInfo mutableCopy];
        logInfoM[@"unzipLogPath"] = unzipLogPath;
        logInfoM[@"logDir"] = logDir;
        
        logStoreDic[buildName] = logInfoM;
    }
    
    // 同步到本地
    [logStoreDic writeToFile:logStoreFilePath atomically:YES];
    
    NSTimeInterval unzipEnd = [[NSDate date] timeIntervalSince1970];
    if (didUnzipLog) {
        HRLog(@"👏 解压编译日志完成 %.2f seconds", unzipEnd - unzipBegin);
    }
    
    self.logStoreDic = logStoreDic;
}

/// 清空unzip log
- (void)clearAllUnzipLog
{
    NSString *logStoreFilePath = [self logStoreFilePathForCocoaHotReload];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSMutableDictionary *logStoreDicM = [[NSDictionary dictionaryWithContentsOfFile:logStoreFilePath] mutableCopy];
    NSString *projectBuildLogDir = [self projectBuildLogsDir];
    if ([fileManager fileExistsAtPath:logStoreFilePath]) {
        // 按时间排序(越早的越前面)
        NSArray<NSDictionary *> *logs = [logStoreDicM.allValues sortedArrayUsingComparator:^NSComparisonResult(NSDictionary *obj1, NSDictionary *obj2) {
           return [obj1[@"timeStoppedRecording"] doubleValue] > [obj2[@"timeStoppedRecording"] doubleValue];
        }];
        BOOL syncDataToMmkv = NO;
        NSTimeInterval begainSyncTime = 0.0;
        for (NSDictionary *logInfo in logs) {
            NSString *dirName = logInfo[@"uniqueIdentifier"];
            NSString *dirPath = logInfo[@"logDir"];
            if ([fileManager fileExistsAtPath:dirPath]) {
                // 先把数据同步到mmkv 再移除
                @autoreleasepool {
                    NSString *compileCommandFilesDir = [dirPath stringByAppendingPathComponent:@"compileCommandFiles"];
                    NSArray *subPaths = [fileManager subpathsOfDirectoryAtPath:compileCommandFilesDir error:nil];
                    for (NSString *subpath in subPaths) {
                        NSString *filePath = [compileCommandFilesDir stringByAppendingPathComponent:subpath];
                        NSDictionary *compileCommandMap = [NSDictionary dictionaryWithContentsOfFile:filePath];
                        for (NSString *key in compileCommandMap.allKeys) {
                            if (!syncDataToMmkv) {
                                syncDataToMmkv = YES;
                                HRLog(@"🚧 同步历史数据到mmkv...");
                                begainSyncTime = [[NSDate date] timeIntervalSince1970];
                            }
                            [CompileCommandSharedManager() setCompileCommand:compileCommandMap[key] forKey:key];
                        }
                    }
                    [fileManager removeItemAtPath:dirPath error:nil];
                }
            }
            
            NSString *originLogPath = [projectBuildLogDir stringByAppendingPathComponent:logStoreDicM[dirName][@"fileName"]];
            if (![fileManager fileExistsAtPath:originLogPath]) {
                [logStoreDicM removeObjectForKey:dirName];
            }
        }
        
        if (syncDataToMmkv) {
            NSTimeInterval endSyncTime = [[NSDate date] timeIntervalSince1970];
            HRLog(@"👏 同步历史数据到mmkv完成！%.2f seconds", endSyncTime - begainSyncTime);
        }

        [logStoreDicM writeToFile:logStoreFilePath atomically:YES];
    }
    
    // 历史版本残留数据移除
    NSString *cocoaHotReloadDir = [self cocoaHotReloadBuildLogsDir];
    NSArray<NSString *> *subpaths = [fileManager subpathsOfDirectoryAtPath:cocoaHotReloadDir error:nil];
    for (NSString *subath in subpaths) {
        if (subath.length == @"A372DF80-8D38-472B-98D5-6C36BB9CEE6C".length || [subath isEqualToString:@"thinLibOrFrameworks"]) {
            NSString *path = [cocoaHotReloadDir stringByAppendingPathComponent:subath];
            if ([fileManager fileExistsAtPath:path]) {
                [fileManager removeItemAtPath:path error:nil];
            }
        }
    }
}

// ViewController.m
- (NSString *)compiledFilePathForFullFileName:(NSString *)fullFileName
{
    NSString *buildPath = self.fileBuildPathDicM[fullFileName];
    if (!buildPath || ![[NSFileManager defaultManager] fileExistsAtPath:buildPath]) {

        NSString *derivedDataPath = [self derivedDataPath];
        buildPath = [self buildBasePathForCurrentBundleWithDir:derivedDataPath modifiedFileName:fullFileName buildedPathExtersion:@"o"];
        if (buildPath.length > 0) {
            self.fileBuildPathDicM[fullFileName] = buildPath;
        }
    }
    return buildPath;
}

/// 可能是 .o or .dia or .d or .storyboardc
- (NSString *)compiledProductFilePathForFullFileName:(NSString *)fullFileName pathExtersion:(NSString *)pathExtersion
{
    if ([fullFileName hasSuffix:@"xib"] && [pathExtersion isEqualToString:@"nib"]) {
        NSString *compileCommand = [CompileCommandSharedManager() compileCommandForSourceFilePath:fullFileName];
        NSString *filePath = [[compileCommand chr_subStringBetweenFrom:@"--compile " to:@".nib " backwardsSearch:YES] stringByAppendingString:@".nib"];
        return filePath;
    }
    NSString *buildProductPath = self.fileBuildProductPathDicM[fullFileName];
    if (![[buildProductPath pathExtension] isEqualToString:pathExtersion]) {
        buildProductPath = [[buildProductPath stringByDeletingPathExtension] stringByAppendingString:pathExtersion];
    }
    if (!buildProductPath || ![[NSFileManager defaultManager] fileExistsAtPath:buildProductPath]) {

       NSString *derivedDataPath = [self derivedDataPath];
       buildProductPath = [self buildBasePathForCurrentBundleWithDir:derivedDataPath modifiedFileName:fullFileName buildedPathExtersion:pathExtersion];
       if (buildProductPath.length > 0) {
           self.fileBuildProductPathDicM[fullFileName] = buildProductPath;
       }
    }
    
    return buildProductPath;
}

- (NSString *)compiledProductFilePathByDeletePathExtersionForFullFileName:(NSString *)fullFileName
{
    if ([fullFileName hasSuffix:@".storyboard"]) {
        NSString *filePath = [self compiledProductFilePathForFullFileName:fullFileName pathExtersion:@"storyboardc"];
        return [filePath stringByDeletingPathExtension];
    } else if ([fullFileName hasSuffix:@".xib"]) {
        return [[self compiledProductFilePathForFullFileName:fullFileName pathExtersion:@"nib"] stringByDeletingPathExtension];
    }
    NSString *filePath = [self compiledProductFilePathForFullFileName:fullFileName pathExtersion:@"d"];
    
    if (!filePath) {
        filePath = [self compiledProductFilePathForFullFileName:fullFileName pathExtersion:@"dia"];
    }
    
    if (!filePath) {
        filePath =[self compiledProductFilePathForFullFileName:fullFileName pathExtersion:@"o"];
    }
    
    return [filePath stringByDeletingPathExtension];
}

/// 是否存在编译产物 .o or .dia or .d
- (BOOL)hasCompiledProductFilePathForFullFileName:(NSString *)fullFileName
{
    return [self compiledProductFilePathByDeletePathExtersionForFullFileName:fullFileName] > 0;
}

- (void)findAndSaveProjectAllSwiftFileAbsolutePaths
{
    HRLog(@"🚧 获取项目所有Swift文件...");
    if (!self.compileSwiftFileNameSetM) {
        self.compileSwiftFileNameSetM = [NSMutableSet set];
    }
    NSTimeInterval begin = [[NSDate date] timeIntervalSince1970];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;
    
    // 解析project.pbxproj
    NSString *projectPath = [[ProjectSharedManager() settings] projectFilePath];
    projectPath = [projectPath stringByReplacingOccurrencesOfString:@".xcworkspace" withString:@".xcodeproj"];
    NSString *pbxprojPath = [projectPath stringByAppendingPathComponent:@"project.pbxproj"];
    
    if (![fileManager fileExistsAtPath:pbxprojPath]) {
        ErrorLog(@"project.pbxproj文件不存在：%@", pbxprojPath);
        return;
    }
    
    NSString *pbxprojCopyPath = [[self cocoaHotReloadBuildLogsDir] stringByAppendingPathComponent:@"project.json"];
    
    // 转json
    NSString *pbxproj2JsonSource = [NSString stringWithFormat:@"cp -f %@ %@; plutil -convert json %@", pbxprojPath, pbxprojCopyPath, pbxprojCopyPath];
    
    ShellResult *result = [ShellService doShellOutputWithSource:pbxproj2JsonSource];
    if (result.isSuccess) {
        NSData *jsonData = [NSData dataWithContentsOfFile:pbxprojCopyPath options:0 error:&error];
        if (error || !jsonData) {
            ErrorLog(@"解析project.json文件失败：%@", pbxprojCopyPath);
            return;
        }
        NSDictionary *pbxprojDic = [NSJSONSerialization JSONObjectWithData:jsonData options:0 error:&error];
        if (error || !pbxprojDic) {
            ErrorLog(@"解析project.json文件失败：%@", pbxprojCopyPath);
            return;
        }
        
        NSDictionary<NSString *, NSDictionary *> *objectsDic = pbxprojDic[@"objects"];
        // rootObject -> targets -> 遍历数组 找出 name -> buildPhases -> 遍历找出isa PBXSourcesBuildPhase -> 读取files
        NSString *rootObjectKey = pbxprojDic[@"rootObject"];
        NSDictionary *rootInfo = objectsDic[rootObjectKey];
        NSArray<NSString *> *targets = rootInfo[@"targets"];
        NSString *targetName = [[ProjectSharedManager() settings] targetName];
        if (!targetName) {
            ErrorLog(@"target name is nil !");
            return;
        }
        NSString *mainGroupKey = rootInfo[@"mainGroup"];
        NSDictionary *mainGroupInfo = objectsDic[mainGroupKey];
        NSString *projectDir = [[ProjectSharedManager() settings] projectDirectoryPath];
        NSDictionary *filePathDic = [self subpathsDicForPBXGroupInfo:mainGroupInfo
                                                          projectDir:projectDir
                                                            filePath:projectDir
                                                          objectsDic:objectsDic
                                                            fileType:@"sourcecode.swift"
                                                            uniqueId:mainGroupKey];
        NSMutableSet *swiftFilePathSetM = [NSMutableSet set];
        for (NSString *target in targets) {
            NSDictionary *targetInfo = objectsDic[target];
            if ([targetInfo[@"name"] isEqualToString:targetName]) {
                NSArray<NSString *> *buildPhasesKeys = targetInfo[@"buildPhases"];
                for (NSString *buildPhasesKey in buildPhasesKeys) {
                    NSDictionary *buildPhasesInfo = objectsDic[buildPhasesKey];
                    if (![buildPhasesInfo[@"isa"] isEqualToString:@"PBXSourcesBuildPhase"]) {
                        continue;
                    }
                    NSArray<NSString *> *fileKeys = buildPhasesInfo[@"files"];
                    for (NSString *fileKey in fileKeys) {
                        NSDictionary *fileInfo = objectsDic[fileKey];
                        NSString *fileRefKey = fileInfo[@"fileRef"];
                        NSDictionary *fileRefInfo = objectsDic[fileRefKey];
                        if (![fileRefInfo[@"lastKnownFileType"] isEqualToString:@"sourcecode.swift"]) {
                            continue;
                        }
                        // 查找文件绝对路径
                        NSString *swiftFilePath = filePathDic[fileRefKey];
                        if ([swiftFilePath hasSuffix:@".swift"]) {
                            [swiftFilePathSetM addObject:swiftFilePath];
                            [self.compileSwiftFileNameSetM addObject:[swiftFilePath lastPathComponent]];
                        }
                    }
                }
            }
        }
        
        NSString *allFilePathsString = [swiftFilePathSetM.allObjects componentsJoinedByString:@"\n"];
        NSString *fileListPath = [self fileListPathForProjectAllSwiftFileAbsolutePaths];
        if ([fileManager fileExistsAtPath:fileListPath]) {
            [fileManager removeItemAtPath:fileListPath error:nil];
        }
        [allFilePathsString writeToFile:fileListPath atomically:YES encoding:NSUTF8StringEncoding error:&error];
        
        if (error) {
            ErrorLog(@"项目所有Swift文件路径写入文件失败：%@", [error localizedDescription]);
            return;
        }
        
        [fileManager removeItemAtPath:pbxprojCopyPath error:nil];
        
        NSTimeInterval end = [[NSDate date] timeIntervalSince1970];
        HRLog(@"👏 获取项目中所有Swift文件完成！共 %lu 个 %.2f seconds", (unsigned long)swiftFilePathSetM.count, end - begin);
    }
}

// 唯一id B01D0F8B25513D6E0057A554 为key 绝对路径为value 的文件映射
- (NSDictionary<NSString *, NSString *> *)subpathsDicForPBXGroupInfo:(NSDictionary *)groupInfo projectDir:(NSString *)projectDir  filePath:(NSString *)filePath objectsDic:(NSDictionary *)objectsDic fileType:(NSString *)fileType uniqueId:(NSString *)uniqueId
{
    NSMutableDictionary *subpathDicM = [NSMutableDictionary dictionary];
    NSString *path = groupInfo[@"path"];
    NSString *currentFilePath = [filePath stringByAppendingPathComponent:path];
    if ([groupInfo[@"sourceTree"] isEqualToString:@"SOURCE_ROOT"]) { // 相对根目录
        currentFilePath = [projectDir stringByAppendingPathComponent:path];
    }
    if ([groupInfo[@"isa"] isEqualToString:@"PBXGroup"]) {
        for (NSString *children in groupInfo[@"children"]) {
            [subpathDicM addEntriesFromDictionary:[self subpathsDicForPBXGroupInfo:objectsDic[children] projectDir:projectDir filePath:currentFilePath objectsDic:objectsDic fileType:fileType uniqueId:children]];
        }
    } else if ([groupInfo[@"isa"] isEqualToString:@"PBXFileReference"]) {
        if ([groupInfo[@"lastKnownFileType"] isEqualToString:fileType]) {
            subpathDicM[uniqueId] = [CocoaFileTool absolutePathForFilePath:currentFilePath];
        }
    }
    
    return [subpathDicM copy];
}

- (NSString *)fileListPathForProjectAllSwiftFileAbsolutePaths
{
    return [[self cocoaHotReloadBuildLogsDir] stringByAppendingPathComponent:@"fileListForSwift"];
}

- (NSArray<NSString *> *)compileSwiftFileNamesForProject
{
    if (!self.compileSwiftFileNameSetM) {
        self.compileSwiftFileNameSetM = [NSMutableSet set];
        
        NSString *fileListForSwiftString = [NSString stringWithContentsOfFile:[self fileListPathForProjectAllSwiftFileAbsolutePaths] encoding:NSUTF8StringEncoding error:nil];
        NSArray<NSString *> *filePaths = [fileListForSwiftString componentsSeparatedByString:@"\n"];
        for (NSString *filePath in filePaths) {
            [self.compileSwiftFileNameSetM addObject:[filePath lastPathComponent]];
        }
    }
    
    return [self.compileSwiftFileNameSetM allObjects];
}

- (NSString *)fixOFilePathWithPath:(NSString *)oFilePath
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:oFilePath]) {
        return oFilePath;
    }
    
    // QZMenuBgItem-35edb2631a160a4a64225df870564045edfb7c6a1fddd2be0bf399d20e77a97a.o
    // 容错逻辑，后缀有问题
    NSString *fileBasePath = [oFilePath stringByDeletingLastPathComponent];
    NSArray<NSString *> *subpaths = [fileManager subpathsAtPath:fileBasePath];
    NSString *fileName = [[oFilePath lastPathComponent] stringByDeletingPathExtension];
    NSString *pathExtersion = [[oFilePath lastPathComponent] pathExtension];
    for (NSString *subpath in subpaths) {
        NSString *prefix = [NSString stringWithFormat:@"%@-", fileName];
        NSInteger length = prefix.length + @"35edb2631a160a4a64225df870564045edfb7c6a1fddd2be0bf399d20e77a97a".length + 1 + pathExtersion.length;
        if ([subpath hasPrefix:prefix]
            && subpath.length == length
            && [subpath hasSuffix:pathExtersion]) { // 容错
            return [fileBasePath stringByAppendingPathComponent:subpath];
        }
    }
    
    return oFilePath;
}

#pragma mark - Private

- (NSString *)derivedDataPath
{
    ProjectManager *manager = ProjectSharedManager();
    if (manager.settings.derivedDataPath) { // cmd 工具使用
        return manager.settings.derivedDataPath;
    }
    return CocoaHotReloadSharedManager().preferences.derivedDataPath;
}

- (BOOL)isBuildForProjectWithLogInfo:(NSDictionary *)logInfo
{
    NSString *signature = logInfo[@"signature"];
    // Xcode build or run 生成signature Build
    // xcodebuild build 生成signature Building xxx
    // xcodebuild build-for-testing 生成signature Testing xxx
    return [signature isEqualToString:[NSString stringWithFormat:@"Build %@", logInfo[@"schemeIdentifier-schemeName"]]] || [signature hasPrefix:@"Building "] || [signature hasPrefix:@"Testing "];
}

- (BOOL)isBuildProjectSucceedForUnzipLogFilePath:(NSString *)logFilePath
{
    NSFileHandle *fileHandle = [NSFileHandle fileHandleForReadingAtPath:logFilePath];
    if (fileHandle) {
        long long fileSize = [CocoaFileTool fileSizeAtPath:logFilePath];
        unsigned long dataLength = MIN(5000, fileSize);
        [fileHandle seekToFileOffset:fileSize-dataLength];
        NSData *strData = [fileHandle readDataToEndOfFile];
        NSString *lastString = [[NSString alloc] initWithData:strData encoding:NSUTF8StringEncoding];
        if (lastString.length > 0) {
            NSString *configuration = [lastString chr_subStringBetweenFrom:@"| Configuration " to:@" | " backwardsSearch:NO];
            if (configuration.length > 0) {
                ProjectSharedManager().settings.configuration = configuration;
            }
            // 正常的编译错误是已 "Build finished- 程序无法运行
            // 如果是Run Script 中添加echo "error: xxx" 会出现"Build finished with errors- 程序正常运行
            // bug fix : https://git.code.oa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/39
            BOOL isBuildSuccessed = [lastString hasSuffix:@"\"Build succeeded-"] || [lastString hasSuffix:@"\"Build finished with errors-"];
            
            if (isBuildSuccessed) {
                return YES;
            }
        }
    }
    
    return  NO;
}

- (NSString *)projectBaseBuildDirctoryWithDir:(NSString *)dir
{
    if (self.projectBuildBasePath) {
        return self.projectBuildBasePath;
    }
    
    /// 真实路径
    NSFileManager *fileManager = [NSFileManager defaultManager];
    CocoaHotReloadSettings *settings = ProjectSharedManager().settings;
    
    if (settings.derivedDataPath) {
        self.projectBuildBasePath = settings.derivedDataPath;
        return self.projectBuildBasePath;
    }
    
    NSString *projectDir = settings.projectDirectoryPath;
    NSString *projectName = settings.projectName;
    NSString *projectBaseBuildDir;
    if (!projectName) {
        return nil;
    }
    CocoaHotReloadPreferences *preferences = [CocoaHotReloadManager shareInstance].preferences;
    if (preferences.derivedDataType == DerivedDataTypeRelative) {
        dir = [NSString stringWithFormat:@"%@/%@", projectDir, preferences.derivedDataPath];
    }
    
    NSArray *derivedDatasubfileNames = [fileManager contentsOfDirectoryAtPath:dir error:nil];
    NSTimeInterval diffTimeInterval = settings.projectRunTimeInterval ?: [[NSDate date] timeIntervalSince1970];
    for (NSString *fileName in derivedDatasubfileNames) {
        NSError *error;
        NSString *fullPath = [dir stringByAppendingPathComponent:fileName];
        NSDictionary *fileAttr = [fileManager attributesOfItemAtPath:fullPath error:&error];
        BOOL isDir = [fileAttr fileType] == NSFileTypeDirectory;
        if (isDir && [fileName hasPrefix:projectName]) { // 文件夹
            NSArray *subfileNames = [fileManager contentsOfDirectoryAtPath:fullPath error:nil];
            for (NSString *subfileName in subfileNames) {
                if ([subfileName isEqualToString:@"info.plist"]) { // 文件
                    NSDictionary *dic = [NSDictionary dictionaryWithContentsOfFile:[fullPath stringByAppendingPathComponent:subfileName]];
                    if ([dic[@"WorkspacePath"] hasPrefix:projectDir]) {
                        /// 寻找修改时间最接近的项目运行时间
                        NSDate *lastAccessedDate = dic[@"LastAccessedDate"];
                        NSTimeInterval diff = fabs([lastAccessedDate timeIntervalSince1970] - settings.projectRunTimeInterval);
                        if (diff < diffTimeInterval) {
                            diffTimeInterval = diff;
                            projectBaseBuildDir = fullPath;
                        }
                    }
                }
            }
        }
    }
    self.projectBuildBasePath = projectBaseBuildDir;
    return self.projectBuildBasePath;
}

// 需要返回的文件后缀 pathExtersion
- (NSString *)buildBasePathForCurrentBundleWithDir:(NSString *)dir modifiedFileName:(NSString *)modifiedFileName buildedPathExtersion:(NSString *)pathExtersion
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    CocoaHotReloadSettings *settings = ProjectSharedManager().settings;
    NSString *platformName = settings.platformName;
    
    NSString *projectBuildPath = [self projectBaseBuildDirctoryWithDir:dir];
    
    NSString *baseBuildPath = [projectBuildPath stringByAppendingPathComponent:@"Build/Intermediates.noindex"];
    NSError *error;
    NSArray *projectBuildNames = [fileManager contentsOfDirectoryAtPath:baseBuildPath error:&error];
    if (!error) {
        for (NSString *projectBuildName in projectBuildNames) {
            if (![projectBuildName hasSuffix:@".build"])
                continue;
            NSString *projectBuildPath = [baseBuildPath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@/%@-%@", projectBuildName, settings.configuration, platformName]];

            if (![fileManager fileExistsAtPath:projectBuildPath]) { // 文件不存在
                continue;
            }
            NSMutableArray *targetBuildNames = [[fileManager contentsOfDirectoryAtPath:projectBuildPath error:&error] mutableCopy];
            if (error) {
                continue;
            }
            if (settings.targetName) {
                [targetBuildNames insertObject:[NSString stringWithFormat:@"%@.build", settings.targetName] atIndex:0];
            }
            for (NSString *targetBuild in targetBuildNames) {
                if (![targetBuild hasSuffix:@".build"])
                    continue;
                NSString *fileName = [[modifiedFileName componentsSeparatedByString:@"."] firstObject];
                if ([pathExtersion isEqualToString:@"storyboardc"]) {
                    NSString *filePath = [projectBuildPath stringByAppendingPathComponent:[NSString stringWithFormat:@"/%@/%@.%@", targetBuild, fileName, pathExtersion]];
                    if ([fileManager fileExistsAtPath:filePath]) {
                        return filePath;
                    }
                    
                    filePath = [projectBuildPath stringByAppendingPathComponent:[NSString stringWithFormat:@"/%@/Base.lproj/%@.%@", targetBuild, fileName, pathExtersion]];
                    if ([fileManager fileExistsAtPath:filePath]) {
                        return filePath;
                    }
                    continue;
                }
                NSString *fileBasePath = [projectBuildPath stringByAppendingPathComponent:[NSString stringWithFormat:@"/%@/Objects-normal/%@", targetBuild, settings.arch]];
                NSString *filePath = [fileBasePath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.%@", fileName, pathExtersion]];
                if ([fileManager fileExistsAtPath:filePath]) {
                    return filePath;
                }
                // 修正ofile路径
                return [self fixOFilePathWithPath:filePath];
            }
        }
    }
    
    return nil;
}

@end
