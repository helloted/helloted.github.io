//
//  CocoaFileTool.m
//  CocoaHotReload
//
//  Created by mambaxie on 2019/11/19.
//  Copyright © 2019 tencent. All rights reserved.
//

#import "CocoaFileTool.h"
#import "CocoaHotReloadManager.h"
#import "CocoaHotReloadServerDefine.h"
#import "ShellService.h"
#import "NSString+CHRRegular.h"
#import "CocoaHotReloadSettings.h"
#import "CocoaHotReloadPreferences.h"

@interface CocoaFileTool()

@end

@implementation CocoaFileTool

#pragma mark - Public

/// 绝对路径
+ (NSString *)absolutePathForFilePath:(NSString *)filePath
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *absolutePath = [[fileManager componentsToDisplayForPath:filePath] componentsJoinedByString:@"/"];
    // Macintosh HD/Users/mambaxie/Library/Developer/Xcode/DerivedData -> /Users/mambaxie/Library/Developer/Xcode/DerivedData
    // 转化下
    NSRange userRange = [absolutePath rangeOfString:@"/Users/"];
    if (userRange.location == NSNotFound) {
        userRange = [absolutePath rangeOfString:@"/Volumes/"];
    }
    if (userRange.location != NSNotFound) {
        return [absolutePath substringFromIndex:userRange.location];
    }
    return absolutePath;
}

+ (long long)fileSizeAtPath:(NSString *)filePath
{
    NSFileManager* manager = [NSFileManager defaultManager];
    if ([manager fileExistsAtPath:filePath]){
        return [[manager attributesOfItemAtPath:filePath error:nil] fileSize];
    }
    return 0;
}

+ (long long)directorySizeAtPath:(NSString *)directoryPath
{
    NSFileManager* manager = [NSFileManager defaultManager];
    if (![manager fileExistsAtPath:directoryPath]) {
        return 0;
    }
    NSString* fileName = [directoryPath copy];
    long long folderSize = 0;
   
    BOOL isDir;
    [manager fileExistsAtPath:fileName isDirectory:&isDir];
    if (!isDir) {
        return [self fileSizeAtPath:fileName];
    } else {
        NSArray *items = [manager contentsOfDirectoryAtPath:fileName error:nil];
        for (int i = 0; i < items.count; i++) {
            BOOL subisdir;
            NSString* fileAbsolutePath = [fileName stringByAppendingPathComponent:items[i]];
            [manager fileExistsAtPath:fileAbsolutePath isDirectory:&subisdir];
            if (subisdir) {
                folderSize += [self directorySizeAtPath:fileAbsolutePath]; //文件夹就递归计算
            } else {
                folderSize += [self fileSizeAtPath:fileAbsolutePath];//文件直接计算
            }
        }
    }
    return folderSize;
}

+ (NSString *)createDirectoryIfNeedForPath:(NSString *)dirPath
{
    NSFileManager *fileMgr = [NSFileManager defaultManager];
    if (![fileMgr fileExistsAtPath:dirPath] && dirPath) {
        NSError *error;
        [fileMgr createDirectoryAtPath:dirPath withIntermediateDirectories:NO attributes:nil error:&error];
        if (error) {
            ErrorLog(@"创建文件夹 %@ 失败：%@", dirPath, error);
            return nil;
        }
    }
    return dirPath;
}

+ (NSString *)createFileIfNeedForPath:(NSString *)filePath
{
    NSFileManager *fileMgr = [NSFileManager defaultManager];
    if (![fileMgr fileExistsAtPath:filePath]) {
        [fileMgr createFileAtPath:filePath contents:[NSData new] attributes:nil];
    }
    
    return filePath;
}

@end
