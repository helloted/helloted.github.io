//
//  FileManager.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/12/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "SharedManager.h"

#define FileSharedManager() [FileManager sharedInstance]

NS_ASSUME_NONNULL_BEGIN

@interface FileManager : SharedManager

// cocoaHotReload缓存日志Dic
@property (nonatomic, strong, nullable) NSDictionary<NSString *, NSDictionary *> *logStoreDic;

/// 获取项目编译logs
- (NSString *)projectBuildLogsDir;
/// 获取项目build dir
- (NSString *)projectBuildDir;
/// 获取临时目录
- (NSString *)tmpDirAndCreateIfNeed;
/// 项目build dir 目录下 创建CocoaHotReload文件夹
- (NSString *)cocoaHotReloadBuildLogsDir;
/// 获取logStore路径
- (NSString *)logStoreFilePathForCocoaHotReload;
/// 最近一次编译成功日志
- (NSString *)lastBuildSucceedUnzipProjectLogFilePath;

/// 是否有新的project编译成功日志
- (BOOL)hasNewProjectBuildSucceedLog;

/// 解压所有编译日志
- (void)unzipAllBuildLogsIfNeed;
/// 清空unzip log
- (void)clearAllUnzipLog;

/// 获取指定后缀的编译产物
/// @param fullFileName 完整文件名 eg. xxx.m
/// @param pathExtersion 文件扩展名
- (NSString *)compiledProductFilePathForFullFileName:(NSString *)fullFileName pathExtersion:(NSString *)pathExtersion;

/// 判断是否存在编译产物 .o or .dia or .d or .storyboardc
/// @param fullFileName 完整文件名 eg. xxx.m
- (BOOL)hasCompiledProductFilePathForFullFileName:(NSString *)fullFileName;

/// 获取编译去除扩展名的产物路径
/// @param fullFileName 完整文件名 eg. xxx.m
- (NSString *)compiledProductFilePathByDeletePathExtersionForFullFileName:(NSString *)fullFileName;

/// 查找项目所有Swift文件的绝对路径
- (void)findAndSaveProjectAllSwiftFileAbsolutePaths;

/// 返回存储项目所有Swift文件绝对路径的文件地址
- (NSString *)fileListPathForProjectAllSwiftFileAbsolutePaths;

/// 返回项目中所有参与编译的swift文件
- (NSArray<NSString *> *)compileSwiftFileNamesForProject;

/// 修正oFile文件
/// QZMenuBgItem.o -> QZMenuBgItem-35edb2631a160a4a64225df870564045edfb7c6a1fddd2be0bf399d20e77a97a.o
- (NSString *)fixOFilePathWithPath:(NSString *)oFilePath;

@end

NS_ASSUME_NONNULL_END
