//
//  CocoaHotReloadTool.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2019/12/12.
//  Copyright © 2019 tencent. All rights reserved.
//

#import "CocoaHotReloadTool.h"

@implementation CocoaHotReloadTool

/// 异步主线程执行
+ (void)runOnMainThread:(dispatch_block_t)block
{
    if (!block)
        return;
    
    BOOL isMainThread = [NSThread isMainThread];
    if (isMainThread) {
        block();
    } else {
        dispatch_async(dispatch_get_main_queue(), block);
    }
}

/// 同步主线程执行
+ (void)runOnMainThreadSync:(dispatch_block_t)block
{
    if (!block) {
        return;
    }
    
    dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
    [self runOnMainThread:^{
        block();
        dispatch_semaphore_signal(semaphore);
    }];
    
    dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
}


@end
