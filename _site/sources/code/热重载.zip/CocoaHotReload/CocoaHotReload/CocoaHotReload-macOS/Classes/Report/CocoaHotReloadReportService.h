//
//  CocoaHotReloadReportService.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/8/24.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#ifdef __cplusplus
extern "C" {
#endif

    /// 通过http上报到atta
    /// 对应上报表格: https://docs.qq.com/sheet/DYnZHdEhqTklWaVpo?tab=BB08J2
    /// @param operName 操作名称
    /// @param ret 返回码
    /// @param duration 操作耗时(毫秒)
    /// @param log 相关日志(最大32k)
    /// @param longExt 长数据扩展字段(最大16k)
    void CocoaHotReloadReport(NSString *operName, int ret, long long duration, NSString * _Nullable log, NSString * _Nullable longExt);

#ifdef __cplusplus
}
#endif

NS_ASSUME_NONNULL_END
