//
//  MMKVService.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/9/12.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MMKVService : NSObject

/// 存储的文件夹目录
/// @param dir mmkv存储的文件夹目录
+ (void)setCacheDir:(NSString *)dir;

/// 存储字符串
/// @param string 存储的字符串
/// @param key 对应的key
+ (void)setString:(NSString *)string forKey:(NSString *)key;

/// 根据key获取对应的字符串值
/// @param key 存储的key
+ (NSString *)stringForKey:(NSString *)key;

/// 移除key对应的值
/// @param key 存储的key
+ (void)removeValueForKey:(NSString *)key;

@end

NS_ASSUME_NONNULL_END
