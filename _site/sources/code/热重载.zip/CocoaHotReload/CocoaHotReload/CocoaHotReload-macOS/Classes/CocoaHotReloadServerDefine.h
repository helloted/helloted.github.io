//
//  CocoaHotReloadServerDefine.h
//  CocoaHotReloadDemo
//
//  Created by mambaxie on 2019/11/26.
//  Copyright © 2019 tencent. All rights reserved.
//

#ifndef CocoaHotReloadServerDefine_h
#define CocoaHotReloadServerDefine_h

#import "CocoaHotReloadDefine.h"
#import "CocoaHotReloadManager.h"
#import "LogViewController.h"
#import "CocoaToast.h"
#import "CocoaHotReloadTool.h"

/// print normal log
#if CMDTOOL
#define HRLog(format, ...) NSLog((@"" format), ##__VA_ARGS__);
#else
#define HRLog(format, ...) \
[CocoaHotReloadTool runOnMainThread:^{ \
    [((LogViewController *)[[NSApplication sharedApplication] windows].firstObject.contentViewController) printLog:[NSString stringWithFormat:(@"" format), ##__VA_ARGS__]]; \
}];
#endif

/// print warning log
#if CMDTOOL
#define WarningLog(format, ...) NSLog((@"【Warning】⚠️ " format), ##__VA_ARGS__);
#else
#define WarningLog(format, ...) \
[CocoaHotReloadTool runOnMainThread:^{ \
    [((LogViewController *)[[NSApplication sharedApplication] windows].firstObject.contentViewController) printLog:[NSString stringWithFormat:(@"【Warning】⚠️ " format), ##__VA_ARGS__]]; \
}];
#endif

/// print error log & show toast
#if CMDTOOL
#define ErrorLog(format, ...) NSLog((@"【Error】❌ " format), ##__VA_ARGS__); \
exit(EXIT_FAILURE);
#else
#define ErrorLog(format, ...) \
HRLog(@"%@", [NSString stringWithFormat:(@"【Error】❌ " format), ##__VA_ARGS__]); \
[CocoaHotReloadSharedManager() setHotReloadStatus:CocoaHotReloadStatusError];\
[CocoaToast showErrorWithMsg:@"Hot Reload Failed"];
#endif

/// Print error log
#if CMDTOOL
#define ErrorLogWithoutToast(format, ...) NSLog((@"【Error】❌ " format), ##__VA_ARGS__); \
exit(EXIT_FAILURE);
#else
#define ErrorLogWithoutToast(format, ...) \
HRLog(@"%@", [NSString stringWithFormat:(@"【Error】❌ " format), ##__VA_ARGS__]); \
[CocoaHotReloadSharedManager() setHotReloadStatus:CocoaHotReloadStatusError];
#endif

#endif /* CocoaHotReloadDefine_h */
