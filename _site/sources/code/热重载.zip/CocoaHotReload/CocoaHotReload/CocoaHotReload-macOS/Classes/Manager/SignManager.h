//
//  SignManager.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/12/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "SharedManager.h"

#define SignSharedManager() [SignManager sharedInstance]

NS_ASSUME_NONNULL_BEGIN

@interface SignManager : SharedManager

// 签名标识
@property (nonatomic, copy) NSString *signingIdentity;

/// 获取app签名字符串
- (NSString *)signingIdentityForApp;

@end

NS_ASSUME_NONNULL_END
