//
//  PreferencesWindowController.m
//  CocoaHotReload-macOS
//
//  Created by 谢培艺 on 2020/2/18.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface PreferencesWindowController : NSWindowController 

@end
