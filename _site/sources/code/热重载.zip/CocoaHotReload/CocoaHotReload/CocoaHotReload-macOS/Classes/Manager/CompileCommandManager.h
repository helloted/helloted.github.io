//
//  CompileCommandManager.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/12/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "SharedManager.h"

#define CompileCommandSharedManager() [CompileCommandManager sharedInstance]

NS_ASSUME_NONNULL_BEGIN

@interface CompileCommandManager : SharedManager

/// 解析编译日志和缓存编译指令
- (void)parseCompileLogAndCacheCompileCommandIfNeed;

/// 根据源文件获取编译指令
/// @param sourceFilePath 源文件路径
- (NSString *)compileCommandForSourceFilePath:(NSString *)sourceFilePath;

/// 存储编译命令
/// @param command 编译命令
/// @param key 所要存储的key
- (void)setCompileCommand:(NSString *)command forKey:(NSString *)key;

@end

NS_ASSUME_NONNULL_END
