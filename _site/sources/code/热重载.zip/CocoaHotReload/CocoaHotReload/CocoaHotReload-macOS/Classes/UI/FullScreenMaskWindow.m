//
//  FullScreenMaskWindow.m
//  CocoaHotReload-macOS
//
//  Created by 谢培艺 on 2020/2/18.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "FullScreenMaskWindow.h"
#import "CocoaHotReloadTool.h"
#import "ProjectManager.h"

static FullScreenMaskWindow *gCurrentWindow;
@implementation FullScreenMaskWindow

+ (NSWindow *)currentWindow
{
    if (!gCurrentWindow) {
        NSRect screenFrame = [[NSScreen mainScreen] frame];
        FullScreenMaskWindow *window = [[FullScreenMaskWindow alloc] initWithContentRect:screenFrame styleMask:NSWindowStyleMaskFullSizeContentView backing:0 defer:YES];
        [window setBackgroundColor:[NSColor colorWithWhite:0.0 alpha:0.3]];
        window.level = kCGCursorWindowLevel;
        
        NSTextView *tipsView = [[NSTextView alloc] init];
        [tipsView setAutoresizingMask:NSViewHeightSizable];
        [tipsView setMaxSize:NSMakeSize(screenFrame.size.width * 0.5, screenFrame.size.height)];
        
        
        NSString *tip = @"正在执行Apple Script脚本指令...\n\n请勿操作键盘！执行结束即可操作键盘。\n\n如要手动停止，可点击下方“Stop Hot Reload” 按钮";
        NSAttributedString *tipsString = [[NSAttributedString alloc] initWithString:tip attributes:@{NSForegroundColorAttributeName : NSColor.whiteColor, NSFontAttributeName : [NSFont boldSystemFontOfSize:22]}];
        [tipsView.textStorage appendAttributedString:tipsString];
        [tipsView.textStorage setAlignment:NSTextAlignmentCenter range:NSMakeRange(0, tip.length)];
        tipsView.backgroundColor = NSColor.clearColor;
        tipsView.editable = NO;
        tipsView.selectable = NO;
        
        NSButton *stopButton = [[NSButton alloc] init];
        stopButton.bezelStyle = NSBezelStyleRegularSquare;
        [stopButton setFont:[NSFont boldSystemFontOfSize:23]];
        [stopButton setTitle:@"Stop Hot Reload"];
        [stopButton setAction:@selector(stopHotReload)];
        [stopButton setTarget:self];
        CGFloat buttonWidth = 225;
        CGFloat buttonHeight = 55;
        stopButton.frame = CGRectMake((screenFrame.size.width - buttonWidth) * 0.5, (screenFrame.size.height - buttonHeight) * 0.5, buttonWidth, buttonHeight);
        
        [window.contentView addSubview:stopButton];
        
        CGFloat tipsWidth = screenFrame.size.width * 0.5;
        CGFloat tipsHeight = 80;
        tipsView.frame = CGRectMake((screenFrame.size.width - tipsWidth) * 0.5, (screenFrame.size.height * 0.5 - tipsHeight + tipsHeight + 80), tipsWidth, tipsHeight);
        
        [window.contentView addSubview:tipsView];
        
        gCurrentWindow = window;
    }
    return gCurrentWindow;
}

+ (void)show {
    [CocoaHotReloadTool runOnMainThread:^{
        [[self currentWindow] setIsVisible:YES];
    }];
}

+ (void)dismiss
{
    [CocoaHotReloadTool runOnMainThread:^{
        [[self currentWindow] setIsVisible:NO];
    }];
}

+ (void)stopHotReload
{
    [self dismiss];
    
    [ProjectSharedManager() stopHotReload];
}
@end
