//
//  SymbolManager.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/12/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "SharedManager.h"

#define SymbolSharedManager() [SymbolManager sharedInstance]

NS_ASSUME_NONNULL_BEGIN

@interface SymbolManager : SharedManager

// 可执行文件中的私有符号
@property (nonatomic, strong, nullable) NSMutableSet<NSString *> *executablePrivateSymbolSetM;

// 可执行文件中的Swift符号
@property (nonatomic, strong, nullable) NSMutableSet<NSString *> *executableSwiftSymbolSetM;

/// 不支持热重载的Swift符号
@property (nonatomic, strong, nullable) NSMutableSet<NSString *> *notSupportHotReloadSymbolSetM;

/// 存储Swift符号 o file path 为key 私有Swift(private external _$sxxxxx)符号为value
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSArray<NSString *> *> *privateSwiftSymbolsDicM;

/// 查找私有符号和查找Swift符号
- (void)findProjectPrivateAndSwiftSymbols;

/// 获取项目中的Swift符号
- (NSArray <NSString *> *)projectSwiftSymbols;

/// 判断Swift是否支持热重载，目前不支持使用泛型的类进行热重载
- (BOOL)isSupportHotReloadWithSwiftSymbol:(NSString *)swiftSymbol;

/// 查找所有Swift文件中的私有符号
- (void)findProjectAllSwiftFilePrivateSymbols;

/// 根据OFilePath更新privateSwiftSymbolsDicM
- (void)updatePrivateSwiftSymbolsDicMWithOFilePath:(NSString *)oFilePath;

@end

NS_ASSUME_NONNULL_END
