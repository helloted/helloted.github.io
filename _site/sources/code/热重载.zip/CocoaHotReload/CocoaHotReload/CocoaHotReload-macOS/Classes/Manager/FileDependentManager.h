//
//  FileDependentManager.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/4/23.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "SharedManager.h"

#define FileDependentSharedManager [FileDependentManager sharedInstance]

NS_ASSUME_NONNULL_BEGIN

@interface FileDependentManager : SharedManager

/// 查找依赖.h头文件的实现文件.m .mm
/// @param headerFilePaths .h 文件路径数组
/// @param compiletion 查找结果的回调 resultDic，key为.h文件路径 value为.m or .mm 文件路径数组
- (void)impletionFilePathsDependentHeaderFilePaths:(NSArray<NSString *> *)headerFilePaths
                                       compiletion:(void(^)(NSDictionary <NSString *, NSArray *> *resultDic))compiletion;

/// 获取源文件对应的.d文件录
/// @param sourceFilePath 源文件地址
- (NSString *)dFilePathForSourceFilePath:(NSString *)sourceFilePath;

/// 获取.d文件中的.h文件路径列表
/// @param dFilePath .d文件路径
- (NSArray<NSString *> *)allHeaderFilePathsForDFilePath:(NSString *)dFilePath;

/// 分析swift生成的.o文件是否需要link 其他.o文件，返回需要链接的.o文件路径列表
/// @param swiftOFilePath 需要分析的.o文件，这里只分析Swift生成的.o文件！
- (NSArray<NSString *> *)shouldLinkOFilePathsForSwiftOFilePath:(NSString *)swiftOFilePath;

@end

NS_ASSUME_NONNULL_END
