//
//  CocoaHotReloadManager.h
//  CocoaHotReloadDemo
//
//  Created by mambaxie on 2019/11/26.
//  Copyright © 2019 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CocoaHotReloadServerDefine.h"

#define CocoaHotReloadSharedManager() [CocoaHotReloadManager shareInstance]

typedef NS_ENUM(NSUInteger, CocoaHotReloadStatus) {
    CocoaHotReloadStatusIdle, // green
    CocoaHotReloadStatusBusy, // yellow
    CocoaHotReloadStatusError, // red
};

@class CocoaHotReloadPreferences, CocoaHotReloadSettings;

NS_ASSUME_NONNULL_BEGIN

@interface CocoaHotReloadManager : NSObject

/// 返回单例
+ (instancetype)shareInstance;

/// 用户Preferences
- (CocoaHotReloadPreferences *)preferences;

/// 同步到NSUerDefault
- (void)synchronizePreference;

// 所有shared manager调用clearData函数
- (void)clearAllSharedManagerData;

/// 设置状态
- (void)setHotReloadStatus:(CocoaHotReloadStatus)status;

/// 当前场景
- (CocoaHotReloadScene)currentScene;

/// 获取最近一次热重载日志
- (NSString *)logForLastHotReload;
/// 获取所有日志
- (NSString *)allLogInLogWindow;

// 返回当前版本 如：0.0.1
- (NSString *)currentVersion;

@end

NS_ASSUME_NONNULL_END
