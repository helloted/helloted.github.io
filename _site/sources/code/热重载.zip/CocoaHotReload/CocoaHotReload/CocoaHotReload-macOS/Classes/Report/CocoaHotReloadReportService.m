//
//  CocoaHotReloadReportService.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/8/24.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "CocoaHotReloadReportService.h"
#import "HTTPService.h"
#import "CocoaHotReloadManager.h"
#import "CocoaHotReloadSettings.h"
#import "ProjectManager.h"

// atta 上报id
static NSString * const kAttaReportAppId = @"02300034762";
// atta 上报token
static NSString * const kAttaReportToken = @"4428284513";

static NSString * gHardwareUUID;
//
NSString *getHardwareUUID()
{
    if (gHardwareUUID) {
        return gHardwareUUID;
    }
    NSString *ret = nil;
    io_service_t platformExpert ;
    platformExpert = IOServiceGetMatchingService(kIOMasterPortDefault, IOServiceMatching("IOPlatformExpertDevice")) ;
    
    if (platformExpert)    {
        CFTypeRef serialNumberAsCFString ;
        serialNumberAsCFString = IORegistryEntryCreateCFProperty(platformExpert, CFSTR("IOPlatformUUID"), kCFAllocatorDefault, 0) ;
        if (serialNumberAsCFString) {
            ret = [(__bridge NSString *)(CFStringRef)serialNumberAsCFString copy];
            CFRelease(serialNumberAsCFString); serialNumberAsCFString = NULL;
        }
        IOObjectRelease(platformExpert); platformExpert = 0;
    }
    gHardwareUUID = ret ?: @"Unknow";
    return gHardwareUUID;
}


void CocoaHotReloadReport(NSString *operName, int ret, long long duration, NSString * _Nullable log, NSString * _Nullable longExt)
{
#if CMDTOOL
    // 命令行工具忽略数据上报
    return;
#else
    // 上报文档: http://atta.pcg.com/#/dataaccess/apiAccessGuide
    NSMutableDictionary *paramsM = [NSMutableDictionary dictionary];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    paramsM[@"attaid"] = kAttaReportAppId;
    paramsM[@"token"] = kAttaReportToken;
    dateFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    paramsM[@"op_time"] = [dateFormatter stringFromDate:[NSDate date]];
    paramsM[@"device_id"] = getHardwareUUID();
    paramsM[@"user_name"] = NSFullUserName() ?: @"Unknow";
    CocoaHotReloadManager *manager = [CocoaHotReloadManager shareInstance];
    CocoaHotReloadSettings *settings = [ProjectSharedManager() settings];
    paramsM[@"mac_app_version"] = [manager currentVersion] ?: @"";
    paramsM[@"ios_framework_version"] = [settings clientFrameworkVersion] ?: @"";
    paramsM[@"project_name"] = [settings projectName] ?: @"";
    NSDictionary *clientBundleInfo = [settings clientBundleInfo];
    paramsM[@"ios_app_name"] = clientBundleInfo[@"CFBundleDisplayName"] ?: (clientBundleInfo[@"CFBundleName"] ?: @"");
    paramsM[@"_dc"] = @(arc4random());
    paramsM[@"op_name"] = operName;
    paramsM[@"duration"] = @(((int)duration));
    paramsM[@"log"] = log ?: @"";
    paramsM[@"long_ext"] = longExt ?: @"";
    paramsM[@"ret_code"] = @(ret);
    
    [HTTPService post:@"https://h.trace.qq.com/kv" params:paramsM completion:^(id  _Nullable rsp, NSError * _Nullable error) {
        
    }];
#endif
}
