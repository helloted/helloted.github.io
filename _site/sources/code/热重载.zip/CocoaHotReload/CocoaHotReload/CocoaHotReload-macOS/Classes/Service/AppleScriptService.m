//
//  AppleScriptService.m
//  CocoaHotReloadTool
//
//  Created by mambaxie on 2019/11/20.
//  Copyright © 2019 tencent. All rights reserved.
//

#import "AppleScriptService.h"
#import <AppKit/AppKit.h>
#import "SocketServer.h"
#import "CocoaHotReloadServerDefine.h"

static NSTask *gCurrentTask;

@implementation AppleScriptService

+ (void)doScriptWithSource:(NSString *)source completionHandler:(void(^)(NSError *error))handler
{
    NSTask *task = [NSTask new];
    
    /// 执行apple script
    [task setLaunchPath:@"/usr/bin/osascript"];
    task.arguments = @[@"-e", source?:@""];
    
    // Create error pipe
    NSPipe *errorPipe = [NSPipe new];
    [task setStandardError: errorPipe];
    
    // Create output pipee
    NSPipe *outputPipe = [NSPipe new];
    [task setStandardOutput:outputPipe];
    
    // Set termination handler
    [task setTerminationHandler: ^(NSTask *task){

        // Log errors
        NSFileHandle* errFile = [errorPipe fileHandleForReading];
        NSString* errMsg = [[NSString alloc] initWithData: [errFile readDataToEndOfFile] encoding: NSUTF8StringEncoding];

        if ([errMsg containsString:@"execution error:"]) { // 执行错误
            ErrorLogWithoutToast(@"[Apple Script Task Error] : %@", errMsg);
            NSError *error = [NSError errorWithDomain:@"com.tencent.cocoahotreload.error" code:-1 userInfo:@{
                NSLocalizedDescriptionKey : errMsg?:@"",
                NSLocalizedFailureReasonErrorKey : errMsg?:@""
            }];
            if (handler) {
                handler(error);
            }
            return;
        }
        
        // Save output
        NSFileHandle* outFile = [outputPipe fileHandleForReading];
        NSString* output = [[NSString alloc] initWithData: [outFile readDataToEndOfFile] encoding: NSUTF8StringEncoding];

        if ([output length]) {
            NSLog(@"[Apple Script Task Result] : %@", output);
        }
        
        if (handler) { // 执行成功
            handler(nil);
        }
    }];

    // Start task
    [task launch];
    
    gCurrentTask = task;
}

+ (void)cancelScript {
    
    [gCurrentTask interrupt];
    gCurrentTask = nil;
}

@end
