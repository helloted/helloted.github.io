//
//  ShellService.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2019/12/12.
//  Copyright © 2019 tencent. All rights reserved.
//

#import "ShellService.h"
#import "CocoaHotReloadServerDefine.h"
#import "CocoaFileTool.h"
#import "FileManager.h"

@implementation ShellResult

@end

@implementation ShellService

+ (BOOL)doShellWithSource:(NSString *)source
{
    NSTask *task = [NSTask new];
    task.launchPath = @"/bin/bash";
    // \r 替换为 && 操作 不然会执行shell失败
    source = [source stringByReplacingOccurrencesOfString:@"\r" withString:@"  && "];
    task.arguments = @[@"-c", source?:@""];
    [task launch];
    [task waitUntilExit];
    int result = task.terminationStatus;
    return result == EXIT_SUCCESS;
}

// 是否允许错误
+ (ShellResult *)doShellOutputWithSource:(NSString *)source ignoreError:(BOOL)ignoreError
{
    static long long index = 0;
    NSString *filePath;
    @synchronized (self) {
        index ++;
        
        NSString *tmpDir = [FileSharedManager() tmpDirAndCreateIfNeed];
        NSString *shellOutDir = [tmpDir stringByAppendingPathComponent:@"Shell"];
        [CocoaFileTool createDirectoryIfNeedForPath:shellOutDir];
        filePath = [NSString stringWithFormat:@"%@/out_%lld.log", shellOutDir, index];
        [[NSFileManager defaultManager] createFileAtPath:filePath contents:nil attributes:nil];
    }
    
    NSTask *task = [NSTask new];
    task.launchPath = @"/bin/bash";
    // \r 替换为 && 操作 不然会执行shell失败
    source = [source stringByReplacingOccurrencesOfString:@"\r" withString:@"  && "];
    if (![source containsString:@" > "]) {
        // 2>&1 代表：stderr 重定向到 stdout
        source = [source stringByAppendingFormat:@" > %@ 2>&1", filePath];
    }
    task.arguments = @[@"-c", source?:@""];
    [task launch];
    [task waitUntilExit];
    
    ShellResult *result = [ShellResult new];
    // NSTaskTerminationReasonExit The task exited normally.
    result.success = task.terminationStatus == EXIT_SUCCESS;
    NSError *error;
    result.output = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:&error];
    if (error) {
        ErrorLogWithoutToast(@"[Shell Error] : %@", error);
    }
    
    if (!ignoreError && !result.isSuccess && result.output.length > 0) { // 执行shell失败
        ErrorLog(@"[Shell] %@", result.output);
    }
    
    @synchronized (self) {
        [[NSFileManager defaultManager] removeItemAtPath:filePath error:nil];
    }
    
    return result;
}

+ (ShellResult *)doShellOutputWithSource:(NSString *)source
{
    return [self doShellOutputWithSource:source ignoreError:NO];
}

@end
