//
//  ShellService.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2019/12/12.
//  Copyright © 2019 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShellResult : NSObject

/// 是否成功
@property (nonatomic, assign, getter=isSuccess) BOOL success;

/// 脚本执行结果内容
@property (nonatomic, copy) NSString * _Nullable output;

@end

NS_ASSUME_NONNULL_BEGIN

@interface ShellService : NSObject

/// 执行shell脚本
/// @param source 执行脚本的内容
+ (BOOL)doShellWithSource:(NSString *)source;

/// 执行shell脚本，并返回结果内容
/// @param source 执行脚本的内容
+ (ShellResult *)doShellOutputWithSource:(NSString *)source;

/// 执行shell脚本，并返回结果内容
/// @param source 执行脚本的内容
/// @param ignoreError 是否忽略脚本错误，默认：NO
+ (ShellResult *)doShellOutputWithSource:(NSString *)source ignoreError:(BOOL)ignoreError;

@end

NS_ASSUME_NONNULL_END
