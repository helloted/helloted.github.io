//
//  CocoaHotReloadTool.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2019/12/12.
//  Copyright © 2019 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CocoaHotReloadTool : NSObject

/// 异步主线程执行
+ (void)runOnMainThread:(dispatch_block_t)block;
/// 同步主线程执行
+ (void)runOnMainThreadSync:(dispatch_block_t)block;

@end

NS_ASSUME_NONNULL_END
