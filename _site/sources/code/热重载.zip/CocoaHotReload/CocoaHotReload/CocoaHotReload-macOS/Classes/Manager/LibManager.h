//
//  LibManager.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/12/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "SharedManager.h"

#define LibSharedManager() [LibManager sharedInstance]

NS_ASSUME_NONNULL_BEGIN

@interface LibManager : SharedManager

// 库路径为key 库中的私有符号为value
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSArray *> *libPrivateSymbolsDicM;
// 通过-exported_symbols 导出的符号
@property (nonatomic, strong) NSMutableSet<NSString *> *exportedSymbolSetM;
// -exported_symbols 链接的库路径
@property (nonatomic, strong) NSMutableSet<NSString *> *exportedLibFilePathSetM;
// taget name 为key target中使用到的库file path为value 为改库所依赖的 lib file paths
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSArray *> *targetLibFilePathsDicM;
// taget name 为key target对应产物路径为path
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSString *> *targetProductPathDicM;
// key: 路径 value: 瘦身后的库
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSString *> *thinLibFilePathDicM;

/// 查找私有符号库
- (void)findPrivateSymbolsLib;

/// 存储加载到客户端的库
- (void)saveLoadedToClientExportedLibPaths;

/// exported symbol lib or framework file path
- (NSArray<NSString *> *)exportedLibPaths;

/// 寻找-L -F -l 指令，多个.o生成dylib 链接时需要
- (NSString *)linkLibCommandForOFilePaths:(NSArray<NSString *> *)oFilePaths;

/// 清除临时数据 链接阉割版（去除重复.o）依赖库
- (void)clearTempDataForPerlink;

@end

NS_ASSUME_NONNULL_END
