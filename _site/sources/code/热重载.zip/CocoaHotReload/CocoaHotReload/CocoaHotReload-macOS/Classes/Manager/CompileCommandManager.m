//
//  CompileCommandManager.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/12/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "CompileCommandManager.h"
#import "MMKVService.h"
#import "FileManager.h"
#import "CocoaHotReloadServerDefine.h"
#import "NSString+CHRRegular.h"
#import "ProjectManager.h"

// 存储compile command key prifix
static NSString const *kCacheCompileCommandKeyPrefix = @"kCacheCompileCommandKeyPrefix";

@implementation CompileCommandManager

/// 解析编译日志和缓存编译指令
- (void)parseCompileLogAndCacheCompileCommandIfNeed
{
    // 解压编译日志
    [FileSharedManager() unzipAllBuildLogsIfNeed];
    
    // 按时间排序
    NSArray<NSDictionary *> *logInfos = [[FileSharedManager() logStoreDic].allValues sortedArrayUsingComparator:^NSComparisonResult(NSDictionary *obj1, NSDictionary *obj2) {
       return [obj1[@"timeStoppedRecording"] doubleValue] > [obj2[@"timeStoppedRecording"] doubleValue];
    }];
    
    /// 查找编译指令
    [self findCompileCommandWithLogInfos:logInfos];
}

/// 获取编译文件对应的编译指令
- (NSString *)compileCommandForSourceFilePath:(NSString *)sourceFilePath
{
    //HRLog(@"🚧 Searching compile command for %@ ", sourceFilePath);
    
    NSString *fileName = [sourceFilePath lastPathComponent];
    
    NSString *compileCommandStr = [self compileCommandForKey:fileName];
    if (compileCommandStr)
        return compileCommandStr;
    
    if (!compileCommandStr) { // 尝试解压未处理的日志
        [self parseCompileLogAndCacheCompileCommandIfNeed];

        // 处理完日志再次获取
        compileCommandStr = [self compileCommandForKey:fileName];
    }
    
    return compileCommandStr;
}

- (void)setCompileCommand:(NSString *)command forKey:(NSString *)key
{
    [MMKVService setString:command forKey:[self cacheCompileCommandKeyWithKey:key]];
    
    if ([key pathExtension]) { // 删除历史存储，历史存储key为文件名(无后缀)
       [MMKVService removeValueForKey:[self cacheCompileCommandKeyWithKey:[key stringByDeletingPathExtension]]];
    }
}

#pragma mark - Private

- (void)findCompileCommandWithLogInfos:(NSArray<NSDictionary *> *)logInfos
{
    if (logInfos.count == 0) {
        return;
    }
    
    HRLog(@"🚧 获取编译日志...");
    
    NSTimeInterval getCommandBegin = [[NSDate date] timeIntervalSince1970];

    __block NSInteger totalCount = 0;
    
    NSMutableDictionary *logStoreDicM = [NSMutableDictionary dictionary];
    // 获取所有解压路径
    for (int i = 0; i < logInfos.count; i++) {
        NSMutableDictionary *logInfoM = [logInfos[i] mutableCopy];
        NSString *fileName = [logInfoM[@"fileName"] stringByDeletingPathExtension];
        
        BOOL isHandledLog = [logInfoM[@"isHandledLog"] boolValue];
        NSString *unzipLogPath = logInfoM[@"unzipLogPath"];
        NSString *logDir = logInfoM[@"logDir"];
        if (isHandledLog || !unzipLogPath || !logDir) {
            logStoreDicM[fileName] = logInfoM;
            continue;
        }
        
        // 按顺序进行
        dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
       
        [self handleCompileLogWithFilePath:unzipLogPath
                                completion:^(NSString *filePath, int commandCount, NSTimeInterval dutaion) {
            logInfoM[@"isHandledLog"] = @(YES);
            logStoreDicM[fileName] = logInfoM;
            totalCount += commandCount;
            dispatch_semaphore_signal(semaphore);
        }];
        
        dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
    }
    
    NSString *logStoreFilePath = [FileSharedManager() logStoreFilePathForCocoaHotReload];
    
    [ProjectSharedManager() updateMmkvCacheDirIfNeed];
    
    [logStoreDicM writeToFile:logStoreFilePath atomically:YES];
    
    FileSharedManager().logStoreDic = logStoreDicM;

    NSTimeInterval getCommandEnd = [[NSDate date] timeIntervalSince1970];
    if (totalCount > 0) {
         HRLog(@"👏 获取编译命令成功，新增个数：%ld  %.2f seconds", (long)totalCount, getCommandEnd - getCommandBegin);
    } else {
        HRLog(@"👏 获取编译命令成功，无新增 %.2f seconds", getCommandEnd - getCommandBegin);
    }
}

- (void)handleCompileLogWithFilePath:(NSString *)logFilePath completion:(void(^)(NSString *filePath, int commandCount, NSTimeInterval dutaion))completion
{
    NSTimeInterval begin = [[NSDate date] timeIntervalSince1970];
    
    NSError *error;
    NSDictionary *fileDic = [[NSFileManager defaultManager] attributesOfItemAtPath:logFilePath error:&error]; //获取文件的属性
    
    unsigned long long totalSize = [[fileDic objectForKey:NSFileSize] unsignedLongLongValue];
    
    // 多个任务一起跑
    int maxTaskCount = 4;
    
    unsigned long long dataLengthPerTask = ceil(totalSize / maxTaskCount) + 10; // 多10个字节
    
    if (totalSize < 50 * 1024 * 1024) {
        dataLengthPerTask = totalSize;
    }
    
    unsigned long long didReadDataLength = 0;
    
    NSMutableArray *shouldHandleRanges = [NSMutableArray array];
    
    dispatch_semaphore_t semaphore;
    
    __block int totalCount = 0;

    dispatch_group_t group = dispatch_group_create();
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    while (didReadDataLength < totalSize) {
        if (dataLengthPerTask > totalSize - didReadDataLength) {
            dataLengthPerTask = totalSize - didReadDataLength;
        }
        NSRange range = NSMakeRange(didReadDataLength, dataLengthPerTask);
        
        didReadDataLength += dataLengthPerTask;
        
        @synchronized (self) {
            if (!semaphore) {
                semaphore = dispatch_semaphore_create(0);
            }
        }

        dispatch_group_enter(group);
        
        dispatch_group_async(group, queue, ^{
            [self handleCompileLogWithLogFilePath:logFilePath
                                            range:range
                                       completion:^(int count, NSRange firstRange, NSRange lastRange) {
                @synchronized (self) {
                    totalCount += count;
                    if (firstRange.length > 0) {
                        [shouldHandleRanges addObject:[NSValue valueWithRange:firstRange]];
                    }
                    if (lastRange.length > 0) {
                        [shouldHandleRanges addObject:[NSValue valueWithRange:lastRange]];
                    }
                }
                dispatch_group_leave(group);
            }];
        });
    }
    
    dispatch_group_notify(group, queue, ^{
        if (semaphore) {
            dispatch_semaphore_signal(semaphore);
        }
    });
    
    if (semaphore) {
        dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
    }
    
    if (shouldHandleRanges.count >= 4) {

        dispatch_semaphore_t semaphore;
        
        [shouldHandleRanges sortUsingComparator:^NSComparisonResult(NSValue *obj1, NSValue *obj2) {
            return obj1.rangeValue.location > obj2.rangeValue.location;
        }];
        // 移除首尾
        [shouldHandleRanges removeObjectAtIndex:0];
        [shouldHandleRanges removeLastObject];
        
        NSInteger times = shouldHandleRanges.count / 2;
        for (int i = 0; i < times; i++) {
            NSRange leftRange = [shouldHandleRanges[i * 2] rangeValue];
            NSRange rightRange = [shouldHandleRanges[i * 2 + 1] rangeValue];
            
            if (rightRange.location < leftRange.location)
                continue;
            
            unsigned long long location = leftRange.location + leftRange.length;
            unsigned long long length = rightRange.location - location;
            NSRange range = NSMakeRange(location, length);

            @synchronized (self) {
                if (!semaphore) {
                    semaphore = dispatch_semaphore_create(0);
                }
            }
            dispatch_group_enter(group);
            dispatch_group_async(group, queue, ^{
                [self handleCompileLogWithLogFilePath:logFilePath
                                                range:range
                                           completion:^(int count, NSRange firstRange, NSRange lastRange) {
                    @synchronized (self) {
                        totalCount += count;
                    }
                    dispatch_group_leave(group);
                }];
            });
        }
        dispatch_group_notify(group, queue, ^{
            if (semaphore) {
                dispatch_semaphore_signal(semaphore);
            }
        });
        if (semaphore) {
            dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
        }
    }
    
    NSTimeInterval end = [[NSDate date] timeIntervalSince1970];
    if (completion) {
        completion(logFilePath, totalCount, end - begin);
    }
}

- (void)handleCompileLogWithLogFilePath:(NSString *)filePath range:(NSRange)range completion:(void(^)(int count, NSRange firstRange, NSRange lastRange))completion
{
    NSFileHandle *fileHandle = [NSFileHandle fileHandleForReadingAtPath:filePath];
    
    unsigned long long totalSize = range.length;
    
    unsigned long long didReadDataLength = 0;
    /// 每次50M
    unsigned long long dataBuffer = 50 * 1024 * 1024;
    unsigned long long shouldLoadDataLength = 0;
    
    __block NSRange handledFirstRange = NSMakeRange(0, 0);
    __block NSRange handledLastRange = NSMakeRange(0, 0);
    
    __block int totalCount = 0; // 处理共个数
    
    NSError *error;
    // export LANG && -o 判断oc编译指令
    // CompileSwift normal && -o判断swift编译指令
    // CompileXIB && --compile 判断xib编译
    // CompileStoryboard && --compilation-directory 判断sotryboard编译
    NSRegularExpression *expression = [NSRegularExpression regularExpressionWithPattern:@"((export LANG)|(CompileSwift normal )|(CompileXIB )|(CompileStoryboard )).*?((-o )|(--compile )|(--compilation-directory )){1}.*?((\\.o)|(\\.xib)|(\\.storyboard)){1}" options:NSRegularExpressionDotMatchesLineSeparators error:&error];
    
    dispatch_semaphore_t semaphore;
    
    dispatch_group_t group = dispatch_group_create();
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    while (didReadDataLength < totalSize) {
        @synchronized (self) {
            if (!semaphore) {
                semaphore = dispatch_semaphore_create(0);
            }
        }
        
        @autoreleasepool {
            [fileHandle seekToFileOffset:range.location + didReadDataLength];
            
            shouldLoadDataLength = totalSize - didReadDataLength;
            
            if (shouldLoadDataLength > dataBuffer) {
                shouldLoadDataLength = dataBuffer;
            }
            NSArray<NSTextCheckingResult *> *results;
            
            NSData *logData = [fileHandle readDataOfLength:shouldLoadDataLength];
            
            NSString *unzipLogString = [[NSString alloc] initWithData:logData encoding:NSASCIIStringEncoding];
        
            // 正则匹配编译日志
            results = [expression matchesInString:unzipLogString options:0 range:NSMakeRange(0, unzipLogString.length)];
            
            if (results.count > 0) {
                // 回溯到最后一个匹配
                NSRange lastRange = [results lastObject].range;
                if (NSEqualRanges(handledFirstRange, NSMakeRange(0, 0))) {
                    NSRange firstRange = [results firstObject].range;
                    handledFirstRange = NSMakeRange(didReadDataLength + range.location + firstRange.location, firstRange.length);
                }
                
                handledLastRange = NSMakeRange(didReadDataLength + range.location + lastRange.location, lastRange.length);
                
                if (didReadDataLength + shouldLoadDataLength < totalSize) {
                    didReadDataLength = didReadDataLength + lastRange.location + lastRange.length;
                } else {
                    didReadDataLength += shouldLoadDataLength;
                }
            } else {
                didReadDataLength += shouldLoadDataLength;
            }
            
            dispatch_group_enter(group);
            dispatch_group_async(group, queue, ^{
                // 异步处理结果
                NSInteger count = [self handleCompileCommandCheckResults:results
                                                          unzipLogString:unzipLogString
                                                             logFilePath:filePath];
                @synchronized (self) {
                   totalCount += count;
                }
                dispatch_group_leave(group);
            });
        }
    }
    
    [fileHandle closeFile];
    
    dispatch_group_notify(group, queue, ^{
        if (semaphore) {
            dispatch_semaphore_signal(semaphore);
        }
    });
    if (semaphore) {
        dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);
    }
    
    if (completion) {
        completion(totalCount, handledFirstRange, handledLastRange);
    }
}

- (NSInteger)handleCompileCommandCheckResults:(NSArray<NSTextCheckingResult *> *)results
                               unzipLogString:(NSString *)unzipLogString
                                  logFilePath:(NSString *)logFilePath
{
    NSInteger handledCount = 0;
    // 异步处理编译指令
    for (NSTextCheckingResult *result in results) {
        
        NSString *resultString = [unzipLogString substringWithRange:result.range];
        if ([resultString hasPrefix:@"export LANG"] && result.range.location > 500) { // oc
            // 往前500个字符
            NSInteger length = 500;
            NSInteger location = result.range.location - length;
            if (location < 0) {
                location = 0;
            }
            
            NSRange fowardRange = NSMakeRange(location, result.range.length + length);
            resultString = [unzipLogString substringWithRange:fowardRange];
        }
        NSRange cdRange = [resultString rangeOfString:@"cd /Users/" options:NSBackwardsSearch];
        if (cdRange.location == NSNotFound) {
            cdRange = [resultString rangeOfString:@"cd /Volumes/" options:NSBackwardsSearch];
        }
        if (cdRange.location != NSNotFound) {
            NSString *compileCommandStr = [resultString substringFromIndex:cdRange.location];
            NSString *fileName;
            // 获取编译日志
            if ([resultString containsString:@"CompileXIB"]) {
                NSRange nibRange = [compileCommandStr rangeOfString:@".nib "];
                if (nibRange.location != NSNotFound) {
                    NSString *xibFilePath = [compileCommandStr substringFromIndex:nibRange.location + nibRange.length];
                    if ([xibFilePath hasSuffix:@".xib"]) {
                        fileName = [xibFilePath lastPathComponent];
                    }
                }
            } else if ([resultString containsString:@"CompileStoryboard"]) {
                NSRange spaceRange = [compileCommandStr rangeOfString:@" /" options:NSBackwardsSearch];
                if (spaceRange.location != NSNotFound) {
                    NSString *storyboardFilePath = [compileCommandStr substringFromIndex:spaceRange.location + spaceRange.length];
                    if ([storyboardFilePath hasSuffix:@".storyboard"]) {
                        fileName = [storyboardFilePath lastPathComponent];
                    }
                }
            } else if ([resultString containsString:@"CompileSwift"]) {
                NSString *sourceFilePath;
                if([resultString hasSuffix:@".o"]) {
                    sourceFilePath = [compileCommandStr chr_subStringBetweenFrom:@" -o " to:@".o" backwardsSearch:YES];
                } else {
                    sourceFilePath = [compileCommandStr chr_subStringBetweenFrom:@" -o " to:@".o " backwardsSearch:YES];
                }
                fileName = [[sourceFilePath lastPathComponent] stringByAppendingString:@".swift"];
            } else {
                // 编译日志为 cd /User/xxx ... -o /User/xxx/xx../xx.o
                NSString *sourceFilePath = [compileCommandStr chr_subStringBetweenFrom:@" -c " to:@" -o " backwardsSearch:YES];
                fileName = [sourceFilePath lastPathComponent];
            }
            if (compileCommandStr && fileName) {
                @synchronized (self) {
                    [self setCompileCommand:compileCommandStr forKey:fileName];
                }
                handledCount++;
            }
        }
    }
    
    return handledCount;
}


- (NSString *)compileCommandForKey:(NSString *)key
{
    NSString *result = [MMKVService stringForKey:[self cacheCompileCommandKeyWithKey:key]];
    if (!result && [key pathExtension]) { // 兼容就逻辑 历史存储key为文件名(无后缀)
        result = [MMKVService stringForKey:[self cacheCompileCommandKeyWithKey:[key stringByDeletingPathExtension]]];
    }
    
    return result;
}

- (NSString *)cacheCompileCommandKeyWithKey:(NSString *)key
{
    return [NSString stringWithFormat:@"%@_%@", kCacheCompileCommandKeyPrefix, key];
}

@end
