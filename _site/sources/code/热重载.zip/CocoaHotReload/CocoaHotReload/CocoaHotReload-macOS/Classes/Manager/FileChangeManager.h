//
//  FileChangeManager.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/12/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "SharedManager.h"

#define FileChangeSharedManager() [FileChangeManager sharedInstance]

NS_ASSUME_NONNULL_BEGIN

@interface FileChangeManager : SharedManager

/// 获取修改的文件名称
- (NSArray <NSString *>*)didModifyFileNames;
/// 获取修改的文件路径
- (NSArray <NSString *>*)didModifyFilePaths;

/// 添加文件路径
/// @param filePaths 文件路径列表
- (void)addChangedFilePaths:(NSArray<NSString *> *)filePaths;

@end

NS_ASSUME_NONNULL_END
