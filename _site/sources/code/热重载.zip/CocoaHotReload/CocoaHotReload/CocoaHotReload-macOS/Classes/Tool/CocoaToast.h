//
//  CocoaToast.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/5/23.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CocoaToast : NSObject

/// 显示成功toast
/// @param msg 提示文案
+ (void)showSuccessWithMsg:(NSString *)msg;

/// 显示失败toast
/// @param msg 提示文案
+ (void)showErrorWithMsg:(NSString *)msg;

@end

NS_ASSUME_NONNULL_END
