//
//  SocketCommandServiceHandler.m
//  Cocoa Hot Reload
//
//  Created by mambaxie on 2019/11/23.
//  Copyright © 2019 tencent. All rights reserved.
//

#import "SocketCommandServerHandler.h"
#import "SocketServer.h"
#import "AppleScriptService.h"
#import "CocoaHotReloadServerDefine.h"
#import "CocoaHotReloadManager.h"
#import "CocoaFileTool.h"
#import "CocoaClassTool.h"
#import "ShellService.h"
#import "CocoaHotReloadTool.h"
#import "CocoaFileWatcher.h"
#import "AppDelegate.h"
#import "CocoaToast.h"
#import "FileManager.h"
#import "PbxprojFileTool.h"
#import "CocoaHotReloadReportService.h"
#import "CocoaHotReloadDefine.h"
#import "CocoaHotReloadSettings.h"
#import "CocoaHotReloadPreferences.h"
#import "FileChangeManager.h"
#import "LibManager.h"
#import "ProjectManager.h"

@interface SocketCommandServiceHandler()

@property (nonatomic, strong) CocoaFileWatcher *watcher;

@end

@implementation SocketCommandServiceHandler

+ (void)load
{
    SocketCommandServiceHandler *handler = [self shareInstance];
    
    [[NSNotificationCenter defaultCenter] addObserver:handler selector:@selector(handleSocketCommandNotification:) name:SocketDidReceiveCommandNotification object:nil];
}

+ (instancetype)shareInstance
{
    static dispatch_once_t onceToken;
    static SocketCommandServiceHandler *handler;
    dispatch_once(&onceToken, ^{
        handler = [SocketCommandServiceHandler new];
    });
    return handler;
}

- (void)handleSocketCommandNotification:(NSNotification *)noti
{
    SocketCommand command = [noti.userInfo[kSocketReceiveCommandKey] intValue];
    id value = noti.userInfo[kSocketReceiveValueKey];
    
    switch (command) {
        case SocketCommandHotReload:
        {
            if ([SHARED_APP_DELEAGTE currentStatus] == CocoaHotReloadStatusBusy) {
                HRLog(@"Current status is busy, try again later...");
                return;
            }
            
            if (!ProjectSharedManager().settings.projectDirectoryPath) {
                ErrorLogWithoutToast(@"Please select project first!");
                return;
            }
            if ([CocoaHotReloadSharedManager() currentScene] == CocoaHotReloadSceneDefault && ![[SocketServer currentServer] isConnected]) {
                ErrorLog(@"No client connected !");
                return;
            }
            [ProjectSharedManager() startHotReload];
            break;
        }
        case SocketCommandClientInfo: {
            
            if ([CocoaHotReloadSharedManager() currentScene] == CocoaHotReloadSceneForTests && [ProjectSharedManager() isProjectDidFinishInit]) {
                if (![FileSharedManager() hasNewProjectBuildSucceedLog]) { // 无新的编译日志无需初始化
                    if (![ProjectSharedManager() hasDylibWaitingToSendClient]) { // 无需发送dylib 直接告诉终端初始化完成
                        [[SocketServer currentServer] sendSocketCommand:SocketCommandDidInitProject];
                    }
                    return;
                }
                
                // 清除数据
                [CocoaHotReloadSharedManager() clearAllSharedManagerData];
            }
      
            NSDictionary *info = value;
            static long long random = 0;
            NSNumber *curRandom = info[@"random"];
            if (random == 0 || random != [curRandom longLongValue]) {
                random = [curRandom longLongValue];
            }
            else {
                //重新连接
                [CocoaHotReloadSharedManager() setHotReloadStatus:CocoaHotReloadStatusIdle];
                // 数据上报
                CocoaHotReloadReport(@"connect", 3, 0, nil, nil);
                return ;
            }
            
            CocoaHotReloadSettings *settings = [ProjectSharedManager() settings];
            settings.arch = info[@"arch"];
            settings.frameworksPath = info[@"frameworksPath"];
            NSDictionary *bundleInfo = info[@"bundleInfo"];
            settings.clientBundleInfo = bundleInfo;
            settings.platformName = info[@"isMacCatalyst"] ? @"maccatalyst" : bundleInfo[@"DTPlatformName"];
            settings.targetName = bundleInfo[@"CFBundleName"];
            settings.minimumOSVersion = bundleInfo[@"MinimumOSVersion"] ?: bundleInfo[@"LSMinimumSystemVersion"];
            settings.executableName = bundleInfo[@"CFBundleExecutable"];
            settings.clientFrameworkVersion = info[@"framewrokVersion"];
            settings.projectRunTimeInterval = [[NSDate date] timeIntervalSince1970];
            NSString *clientBunldID = bundleInfo[@"CFBundleIdentifier"];
            settings.currentScene = [info[@"scene"] integerValue];
            if(settings.bundleIDs && clientBunldID) {
                if (![settings.bundleIDs containsObject:clientBunldID]) {
                    ErrorLogWithoutToast(@"client bundleID %@ !=  project BundleIDs",clientBunldID);
                    settings.projectFilePath = nil;
                    settings.projectName = nil;
                    settings.bundleIDs = nil;
                }
            }
            
            [ProjectSharedManager() updateSettingsIfNeed];
            
            [ProjectSharedManager() updateMmkvCacheDirIfNeed];
            
            HRLog("Mac app version is %@, client version is %@", [CocoaHotReloadManager shareInstance].currentVersion?:@"Unknow", settings.clientFrameworkVersion?:@"Unknow");
            
            if ([self startWatchDirctoryIfNeed]) {
                [self projectInit];
            }
            
            // 第一次连接 清除数据
            [self clearAllMemoryAndDiskCache];
            
            NSError *err;
            NSData *jsonData = [NSJSONSerialization  dataWithJSONObject:info options:0 error:&err];
            NSString *jsonString = [[NSString alloc] initWithData:jsonData   encoding:NSUTF8StringEncoding];
            
            // 数据上报
            CocoaHotReloadReport(@"connect", 1, 0, nil, jsonString);
            
            break;
        }
        case SocketCommandDidSelectProject: {
            if ([self startWatchDirctoryIfNeed]) {
                [self projectInit];
            }
            break;
        }
        case SocketCommandReloadComplete: {
            NSDictionary *info = value;
            int ret = [info[@"ret"] intValue];
            NSString *log;
            NSTimeInterval duration = [[NSDate date] timeIntervalSince1970] - [ProjectSharedManager() lastStartHotReloadTime];
            if (ret == CocoaHotReloadCodeSuccess) { // succeed
                HRLog(@"%@", info[@"msg"]);
                [CocoaToast showSuccessWithMsg:@"Hot Reload Succeeded"];
                [FileChangeSharedManager() clearData];
                [CocoaHotReloadSharedManager() setHotReloadStatus:CocoaHotReloadStatusIdle];
                [LibSharedManager() saveLoadedToClientExportedLibPaths];
                [PbxprojFileTool postReloadCompleteNotification];
                if (duration > 10) { // 热重载成功 先上报10秒以上的log
                    log = [CocoaHotReloadSharedManager() logForLastHotReload];
                }
            } else { // fail
                ErrorLog(@"%@", info[@"msg"]);
                log = [CocoaHotReloadSharedManager() logForLastHotReload];
            }
            
            CocoaHotReloadReport(@"hot_reload", ret, duration * 1000, log, nil);
            break;
        }
        case SocketCommandPrintNormalLog:
        {
            HRLog("【Client】%@", value);
            break;
        }
        case SocketCommandPrintErrorLog:
        {
            ErrorLog("【Client】%@", value);
            break;
        }
        default:
            break;
    }
}

- (BOOL)startWatchDirctoryIfNeed
{
    CocoaHotReloadSettings *settings = ProjectSharedManager().settings;
    if (!settings.projectDirectoryPath) {
        ErrorLogWithoutToast(@"Please select project first!");
        return NO;
    }
    
    if ([[SocketServer currentServer] isConnected]) {
        [CocoaHotReloadSharedManager() setHotReloadStatus:CocoaHotReloadStatusIdle];
        NSString *customWatchingDir = [CocoaHotReloadManager shareInstance].preferences.customWatchingDir;
        NSString *watchingDir = customWatchingDir.length ? customWatchingDir : settings.projectDirectoryPath;
        if (watchingDir.length <= 0) {
            ErrorLog(@"Watching directory is nil !");
            return NO;
        }
        self.watcher = [[CocoaFileWatcher alloc]
           initWithRoot:watchingDir
                        plugin:^(NSArray *filesChanged) {
            [FileChangeSharedManager() addChangedFilePaths:filesChanged];
        }];
        HRLog(@"👀 Watching the project directory: %@", watchingDir);
        return YES;
    }
    
    return NO;
}

- (void)projectInit
{
    // 开始
    dispatch_async(dispatch_get_global_queue(0, DISPATCH_QUEUE_PRIORITY_HIGH), ^{
        [ProjectSharedManager() doProjectInitWithCompletion:^{
            [[SocketServer currentServer] sendSocketCommand:SocketCommandDidInitProject];
        }];
    });
}

// 清除所有mac端缓存，第一次连接清除上一次的
- (void)clearAllMemoryAndDiskCache
{
    // 清除所有数据
    [CocoaHotReloadSharedManager() clearAllSharedManagerData];
}

@end
