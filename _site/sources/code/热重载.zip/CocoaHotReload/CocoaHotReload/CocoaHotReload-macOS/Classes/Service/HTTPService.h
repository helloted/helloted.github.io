//
//  HTTPService.h
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/8/27.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^HTTPRequestCompletion)(id _Nullable rsp,  NSError * _Nullable error);

NS_ASSUME_NONNULL_BEGIN

@interface HTTPService : NSObject

/// 发起get请求
/// @param url 请求地址
/// @param params 请求参数
/// @param completion 请求结果回调
+ (void)get:(NSString *)url params:(NSDictionary * _Nullable )params completion:(HTTPRequestCompletion)completion;

/// 发起post请求
/// @param url 请求地址
/// @param params 请求参数
/// @param completion 请求结果回调
+ (void)post:(NSString *)url params:(NSDictionary * _Nullable )params completion:(HTTPRequestCompletion)completion;
@end

NS_ASSUME_NONNULL_END
