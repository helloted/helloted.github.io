//
//  LibManager.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/12/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "LibManager.h"
#import "FileManager.h"
#import "NSString+CHRRegular.h"
#import "CocoaHotReloadManager.h"
#import "CocoaHotReloadSettings.h"
#import "CocoaHotReloadServerDefine.h"
#import "ShellService.h"
#import "CocoaFileTool.h"
#import "ProjectManager.h"

// 是否支持符号导出
#define SUPPORT_EXPORT_SYMBOL 1

@interface TargetLinkInfo : NSObject

@property (nonatomic, copy) NSString *targetName;

@property (nonatomic, copy) NSString *targetProjectPath;

@property (nonatomic, copy) NSArray<NSString *> *searchLibraryDirs;

@property (nonatomic, copy) NSArray<NSString *> *searchFrameworkDirs;

@property (nonatomic, copy) NSArray<NSString *> *forceLoadFilePaths;

@property (nonatomic, copy) NSArray<NSString *> *linkFrameworkNames;

@property (nonatomic, copy) NSArray<NSString *> *linkLibraryNames;

@property (nonatomic, copy) NSArray<NSString *> *dependentFilePaths;

@property (nonatomic, assign, getter=isExportedSymbols) BOOL exportedSymbols;

@end

@implementation TargetLinkInfo

@end

@interface LibManager()

// 已加载到客户端的库
@property (nonatomic, strong) NSMutableSet<NSString *> *didLoadToClientExportedLibPathSetM;

// o files link lib file paths
@property (nonatomic, strong) NSMutableSet<NSString *> *shouldLinkLibFilePathSetM;

// key: lib path value:依赖的库路径
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSArray<NSString *> *> *libDependentOtherLibFilePathsDicM;

// 库路径为key 库中的_OBJC_IVAR_$_符号为value
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSArray *> *libPrivateObjcIvarSymbolsDicM;

@end

@implementation LibManager

#pragma mark - Override
- (void)clearData
{
    [self.didLoadToClientExportedLibPathSetM removeAllObjects];
    [self.shouldLinkLibFilePathSetM removeAllObjects];
    [self.libDependentOtherLibFilePathsDicM removeAllObjects];
    [self.libPrivateObjcIvarSymbolsDicM removeAllObjects];
    [self.libPrivateSymbolsDicM removeAllObjects];
    [self.exportedSymbolSetM removeAllObjects];
    [self.exportedLibFilePathSetM removeAllObjects];
    [self.targetProductPathDicM removeAllObjects];
    [self.targetLibFilePathsDicM removeAllObjects];
    [self.thinLibFilePathDicM removeAllObjects];
}

#pragma mark - Public

/// 清除临时数据 链接阉割版（去除重复.o）依赖库
- (void)clearTempDataForPerlink
{
    NSString *dir = [self removedDuplicateOFileLibsDir];
    [[NSFileManager defaultManager] removeItemAtPath:dir error:nil];
}

/// 查找私有库
- (void)findPrivateSymbolsLib
{
    if (!self.libPrivateSymbolsDicM) {
        // 先清空缓存数据
        [self findLibFilePathWithLogFilePath:[FileSharedManager() lastBuildSucceedUnzipProjectLogFilePath]];
    }
    
    NSLog(@"私有符号的库有 %zd 个 \n %@ \n", self.libPrivateSymbolsDicM.allKeys.count, self.libPrivateSymbolsDicM.allKeys);
}

/// 存储加载到客户端的库
- (void)saveLoadedToClientExportedLibPaths
{
    if (!self.didLoadToClientExportedLibPathSetM) {
        self.didLoadToClientExportedLibPathSetM = [NSMutableSet set];
    }
    for (NSString *libFilePath in self.shouldLinkLibFilePathSetM.allObjects) {
        if ([self.exportedLibFilePathSetM containsObject:libFilePath]) { // exported symbol 库 不需要多次加载
            [self.didLoadToClientExportedLibPathSetM addObject:libFilePath];
        }
    }
}

/// exported symbol lib or framework file path
- (NSArray<NSString *> *)exportedLibPaths
{
    return self.exportedLibFilePathSetM.allObjects;
}

/// 寻找-L -F -l 指令，多个.o生成dylib 链接时需要
- (NSString *)linkLibCommandForOFilePaths:(NSArray<NSString *> *)oFilePaths
{
    HRLog(@"🚧 查找.o依赖的库...");
    NSTimeInterval findBegin = [[NSDate date] timeIntervalSince1970];
    
    self.shouldLinkLibFilePathSetM = [NSMutableSet set];
    
    for (NSString *oFilePath in oFilePaths) {
        NSMutableSet *didHandleFilePathSetM = [NSMutableSet set];
        NSArray *filePaths = [self findAllDependentLibOrFrameworkForFilePath:oFilePath
                                                     didHandleLibFilePathSet:didHandleFilePathSetM
                                                         privateLibFilePaths:nil
                                                          targetLibFilePaths:nil];
        for (NSString *filePath in filePaths) {
            if ([self.didLoadToClientExportedLibPathSetM containsObject:filePath]) { // 过滤掉已加载的exported symbol lib
                continue;
            }
            [self.shouldLinkLibFilePathSetM addObject:filePath];
        }
    }
    
    NSMutableString *searchAndLinkCommandM = [@"" mutableCopy];
    NSMutableSet *linkLibFilePathSetM = [NSMutableSet set];
    NSMutableArray *linkFileNamesM = [NSMutableArray array];
    NSMutableSet *needRemoveOFileNameSetM = [NSMutableSet set];
    for (NSString *oFilePath in oFilePaths) {
        NSString *oFileName = [oFilePath lastPathComponent];
        if ([oFileName hasSuffix:@".o"]) {
            [needRemoveOFileNameSetM addObject:oFileName];
        }
    }
    for (NSString *filePath in self.shouldLinkLibFilePathSetM.allObjects) { // 优先链接私有库
        // 剔除重复的.o 避免 duplicate symbol
        NSString *thinFilePath = [self deleteOFilesFromLibFilePath:filePath oFileNames:needRemoveOFileNameSetM.allObjects];
        NSArray *oFileNamesInLib = [self oFileNameWithFilePath:thinFilePath];
        if (oFileNamesInLib.count <= 0) { // 剔除完没有.o了，不link了
            continue;
        }
        [needRemoveOFileNameSetM addObjectsFromArray:oFileNamesInLib];
        if (![[NSFileManager defaultManager] fileExistsAtPath:thinFilePath]) {
            thinFilePath = filePath;
        }
        NSString *fileName;
        if ([thinFilePath pathExtension].length > 0) { // .a
            fileName = filePath.lastPathComponent;
        } else { // 父目录
            fileName = [[filePath stringByDeletingLastPathComponent] lastPathComponent];
        }
        if (fileName && ![linkFileNamesM containsObject:fileName]) {
            [linkFileNamesM addObject:fileName];
            [linkLibFilePathSetM addObject:thinFilePath];
        }
    }
    
    if (linkLibFilePathSetM.count > 0) {
        // -force_load Force load library or framework
        [searchAndLinkCommandM appendString:@" -force_load "];
        [searchAndLinkCommandM appendString:[linkLibFilePathSetM.allObjects componentsJoinedByString:@" -force_load "]];
    }
    
    NSString *libFileNamesStringM = [linkFileNamesM componentsJoinedByString:@" "];
    
    NSTimeInterval findEnd = [[NSDate date] timeIntervalSince1970];
    HRLog(@"👏 查找.o依赖的库完成！%.2f seconds 共 %zd 个 %@", findEnd - findBegin, linkFileNamesM.count, libFileNamesStringM);
    
    return searchAndLinkCommandM;
}

#pragma mark - Private

- (void)findLibFilePathWithLogFilePath:(NSString *)logFilePath
{
    NSError *error;
    NSDictionary *fileDic = [[NSFileManager defaultManager] attributesOfItemAtPath:logFilePath error:&error]; //获取文件的属性
    
    unsigned long long totalSize = [[fileDic objectForKey:NSFileSize] unsignedLongLongValue];
    
    unsigned long long dataBuffer = 25 * 1024 * 1024;
    
    unsigned long long didReadDataLength = 0;
    
    NSFileHandle *fileHandle = [NSFileHandle fileHandleForReadingAtPath:logFilePath];
    
    self.targetLibFilePathsDicM = [NSMutableDictionary dictionary];
    
    // 匹配全局
    //"Link / or"Libtool / or "Ld /
    NSRegularExpression *expression = [NSRegularExpression regularExpressionWithPattern:@"\"((Link)|(Libtool)|(Ld)) /.*?(( -o ){1}\\S*)" options:NSRegularExpressionDotMatchesLineSeparators error:&error];
    
    NSString *projectBuildDir = [FileSharedManager() projectBuildDir];
    // 依赖库
    NSRegularExpression *dependentExpression = [NSRegularExpression regularExpressionWithPattern:[NSString stringWithFormat:@"( %@/Products/).*?((\\.a)|(\\.framework))", projectBuildDir] options:NSRegularExpressionDotMatchesLineSeparators error:&error];
    __block unsigned long long shouldLoadDataLength = 0;
    dispatch_semaphore_t sema = nil;
    
    dispatch_group_t group = dispatch_group_create();
    
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    while (didReadDataLength < totalSize) {
        shouldLoadDataLength = dataBuffer;
        if (shouldLoadDataLength > totalSize - didReadDataLength) {
            shouldLoadDataLength = totalSize - didReadDataLength;
        }
        [fileHandle seekToFileOffset:didReadDataLength];
       
        @autoreleasepool {
            NSArray<NSTextCheckingResult *> *results;

            NSData *logData = [fileHandle readDataOfLength:shouldLoadDataLength];
            NSString *unzipLogString = [[NSString alloc] initWithData:logData encoding:NSASCIIStringEncoding];

            // 正则匹配编译日志
            results = [expression matchesInString:unzipLogString options:0 range:NSMakeRange(0, unzipLogString.length)];

            NSArray<NSString *> *(^symbolsFromSymbolsList)(NSString *) = ^NSArray<NSString *> *(NSString *filePath){
                NSFileManager *fileMgr = [NSFileManager defaultManager];
                if ([fileMgr fileExistsAtPath:filePath]) {
                    NSString *symbolsString = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
                    return [symbolsString componentsSeparatedByString:@"\n"];
                }
                return nil;
            };

            if (results.count <= 0) {
                didReadDataLength += shouldLoadDataLength;
                continue;
            }
            
            if (didReadDataLength + shouldLoadDataLength < totalSize) {
               // 回溯到最后一个匹配
               NSRange lastRange = [results lastObject].range;
               didReadDataLength = didReadDataLength + lastRange.location + lastRange.length;
            } else {
               didReadDataLength += shouldLoadDataLength;
            }
            if (!sema) {
               sema = dispatch_semaphore_create(0);
            }

           dispatch_group_enter(group);
           dispatch_group_async(group, queue, ^{
               // 异步处理结果
               for (NSTextCheckingResult *result in results) {
                   TargetLinkInfo *targetLinkInfo = [[TargetLinkInfo alloc] init];
                   
                   NSString *subString = [unzipLogString substringWithRange:result.range];
                   
                   if ([subString containsString:@"cd /Users/"]) {
                       subString = [subString chr_subStringFrom:@"cd /Users/" containFrom:YES];
                   } else if ([subString containsString:@"cd /Volumes/"]) {
                       subString = [subString chr_subStringFrom:@"cd /Volumes/" containFrom:YES];
                   }
                   
                   NSString *targetProjectPath = [subString chr_subStringBetweenFrom:@"cd " to:@"\r" backwardsSearch:NO];
                   BOOL isExportedSymbolsTarget = NO;
                   if ([subString containsString:@"-exported_symbols_list"]) { // 指定导出
                       NSString *filePath = [unzipLogString chr_subStringBetweenFrom:@"-exported_symbols_list " to:@" " backwardsSearch:NO];
                       NSArray *symbols = symbolsFromSymbolsList(filePath);
                       if (!self.exportedSymbolSetM) {
                           self.exportedSymbolSetM = [NSMutableSet set];
                       }
                       [self.exportedSymbolSetM addObjectsFromArray:symbols];
                       isExportedSymbolsTarget = YES;
                   }
                   
                   NSString *targetName = [subString chr_subStringBetweenFrom:@"Intermediates.noindex/" to:@".build/" backwardsSearch:NO];
                   if ([targetName isEqualToString:@"Pods"]) { // 忽略
                       continue;
                   }
                   
                   NSString *targetProductPath = [subString chr_subStringFrom:@" -o " containFrom:NO];
                   
                   if (targetProductPath && targetName) {
                       if (!self.targetProductPathDicM) {
                           self.targetProductPathDicM = [NSMutableDictionary dictionary];
                       }
                       
                       self.targetProductPathDicM[targetName] = targetProductPath;
                   }
                   
                   NSArray *dependentFilePathResults = [dependentExpression matchesInString:subString options:0 range:NSMakeRange(0, subString.length)];
                   
                   targetLinkInfo.targetName = targetName;
                   targetLinkInfo.targetProjectPath = targetProjectPath;
                   targetLinkInfo.exportedSymbols = isExportedSymbolsTarget;
                   
                   // 处理依赖管理
                   [self handleDependentFilePathResults:dependentFilePathResults
                                           sourceString:subString
                                         targetLinkInfo:targetLinkInfo];
                   
                   // 查找所以依赖库
                   [self findAllLinkLibWithTargetLinkInfo:targetLinkInfo];
               }
               
               dispatch_group_leave(group);
           });
        }
    }
    
    dispatch_group_notify(group, queue, ^{
        if (sema) {
            dispatch_semaphore_signal(sema);
        }
    });
    
    if (sema) {
        dispatch_semaphore_wait(sema, DISPATCH_TIME_FOREVER);
    }
    
    NSMutableSet *linkLibFilePathSetM = [NSMutableSet set];
    NSArray<NSArray<NSString *> *> *filePathLists = self.targetLibFilePathsDicM.allValues;
    for (NSArray *filePathList in filePathLists) {
        [linkLibFilePathSetM addObjectsFromArray:filePathList];
    }
    
    if (linkLibFilePathSetM.count > 0) {
        self.libPrivateSymbolsDicM = [NSMutableDictionary dictionary];
        if (!sema) {
            sema = dispatch_semaphore_create(0);
        }

        NSMutableSet *didHandleLibOrFrameworkFileNames = [NSMutableSet set];
        
        int i = 0;
        for (NSString *filePath in linkLibFilePathSetM.allObjects) {
            i++;
            @synchronized (self) {
                if ([didHandleLibOrFrameworkFileNames containsObject:[filePath lastPathComponent]]) {
                    continue;
                }
            }
            dispatch_group_enter(group);
            dispatch_group_async(group, queue, ^{
                NSArray *privateSymbols = [self getPrivateSymbolsWithlibFilePath:filePath];
                @synchronized (self) {
                    if (privateSymbols.count > 0) {
                        self.libPrivateSymbolsDicM[filePath] = privateSymbols;
                    }
                    
                    [didHandleLibOrFrameworkFileNames addObject:[filePath lastPathComponent]];
                    
                    dispatch_group_leave(group);
                }
            });
        }
        
        dispatch_group_notify(group, queue, ^{
            dispatch_semaphore_signal(sema);
        });
        dispatch_semaphore_wait(sema, DISPATCH_TIME_FOREVER);
    }
    
    // 查找Pods依赖的库
    [self findLibFilePathForPods];
}

- (void)findLibFilePathForPods
{
    NSString *projectBuildDir = [FileSharedManager() projectBuildDir];
    
    // 加载Pods
    NSMutableSet *podLibFilePathSetM = [NSMutableSet set];
    CocoaHotReloadSettings *settings = ProjectSharedManager().settings;
    
    NSString *podBuildTargetsDir = [projectBuildDir stringByAppendingPathComponent:[NSString stringWithFormat:@"Intermediates.noindex/Pods.build/%@-%@", settings.configuration, settings.platformName]];
    
    NSString *projectProductsDir = [projectBuildDir stringByAppendingFormat:@"/Products/%@-%@", settings.configuration, settings.platformName];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:podBuildTargetsDir]) {
        NSArray<NSString *> *subpaths = [fileManager contentsOfDirectoryAtPath:podBuildTargetsDir error:nil];
        for (NSString *subpath in subpaths) {
            if ([subpath hasSuffix:@".build"]) {
                NSString *targetName = [subpath stringByDeletingPathExtension];
                NSString *targetProductFilePath = [projectProductsDir stringByAppendingFormat:@"/%@/lib%@.a", targetName, targetName];
                if ([fileManager fileExistsAtPath:targetProductFilePath]) { // libxxx.a
                    [podLibFilePathSetM addObject:targetProductFilePath];
                } else {
                    targetProductFilePath = [projectProductsDir stringByAppendingFormat:@"/%@.framework/%@", targetName, targetName];
                    if ([fileManager fileExistsAtPath:targetProductFilePath]) { //xxx.frameworl/xxx
                        [podLibFilePathSetM addObject:targetName];
                    }
                }
            }
        }
    }
    if (podLibFilePathSetM.count > 0) {
        self.targetLibFilePathsDicM[@"Pods"] = podLibFilePathSetM.allObjects;
    }
}

- (void)handleDependentFilePathResults:(NSArray<NSTextCheckingResult *> *)dependentFilePathResults
                          sourceString:(NSString *)sourceString
                        targetLinkInfo:(TargetLinkInfo *)targetLinkInfo
{
    NSError *error;
    // 匹配细节-L -F -l
    NSRegularExpression *expression = [NSRegularExpression regularExpressionWithPattern:@"-((L/)|(F/)|(l)|(framework)|(force_load)).*?(( ){1})" options:NSRegularExpressionDotMatchesLineSeparators error:&error];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSMutableSet *dependentFilePathSetM = [NSMutableSet set];
    NSMutableSet *searchFrameworkDirSetM = [NSMutableSet set];
    NSMutableSet *searchLibraryDirSetM = [NSMutableSet set];
    NSMutableSet *forceLoadLibOrFrameworkPathSetM = [NSMutableSet set];
    NSMutableSet *linkLibraryNameSetM = [NSMutableSet set];
    NSMutableSet *linkFrameworkNameSetM = [NSMutableSet set];
    
    for (NSTextCheckingResult *result in dependentFilePathResults) {
        NSString *resultStr = [sourceString substringWithRange:result.range];
        if (resultStr.length > 2) {
            // 去除首个空格
            resultStr = [resultStr substringWithRange:NSMakeRange(1, resultStr.length - 1)];
            if (resultStr && [[NSFileManager defaultManager] fileExistsAtPath:resultStr]) {
                if ([resultStr hasSuffix:@".framework"]) {
                    // xxx.framework -> xxx.framework/xxx
                    resultStr = [resultStr stringByAppendingPathComponent:resultStr.lastPathComponent.stringByDeletingPathExtension];
                    [dependentFilePathSetM addObject:resultStr];
                }
                if ([[NSFileManager defaultManager] fileExistsAtPath:resultStr]) {
                    [dependentFilePathSetM addObject:resultStr];
                }
            }
        }
    }
    
    // "-force_load " -> "-force_load"
    sourceString = [sourceString stringByReplacingOccurrencesOfString:@"-force_load " withString:@"-force_load"];
     // "-framework " -> "-force_load"
    sourceString = [sourceString stringByReplacingOccurrencesOfString:@"-framework " withString:@"-framework"];
    
    NSArray<NSTextCheckingResult *> *subResults = [expression matchesInString:sourceString options:0 range:NSMakeRange(0, sourceString.length)];
    for (NSTextCheckingResult *subResult in subResults) {
        NSString *resultStr = [sourceString substringWithRange:subResult.range];
        
        NSString *checkStr = [NSString stringWithFormat:@" %@", resultStr];
        BOOL isValid = [sourceString containsString:checkStr];
        if (isValid && resultStr && checkStr.length > 4) {
            // 移除前后空格
            NSRange resultRange = NSMakeRange(3, checkStr.length - 4);
            NSString *result = [checkStr substringWithRange:resultRange];
            if ([checkStr hasPrefix:@" -force_load"]) {
                result = [checkStr substringWithRange:NSMakeRange(@" -force_load".length, checkStr.length - (@" -force_load".length + 1))];
            } else if ([checkStr hasPrefix:@" -framework"]) {
                result = [checkStr substringWithRange:NSMakeRange(@" -framework".length, checkStr.length - (@" -framework".length + 1))];
            } else if ([checkStr hasPrefix:@" -l"]) {
                result = [checkStr substringWithRange:NSMakeRange(@" -l".length, checkStr.length - (@" -l".length + 1))];
            }
            if ([checkStr hasPrefix:@" -force_load"]) {
                if (![fileManager fileExistsAtPath:result]) { // 可能是相对路径
                    result = [targetLinkInfo.targetProjectPath stringByAppendingPathComponent:result];
                    if ([fileManager fileExistsAtPath:result]) {
                        [forceLoadLibOrFrameworkPathSetM addObject:result];
                    }
                } else { // 文件存在
                    [forceLoadLibOrFrameworkPathSetM addObject:result];
                }
            } if ([checkStr hasPrefix:@" -L"]) {
                if (![fileManager fileExistsAtPath:result]) { // 可能是相对路径
                    result = [targetLinkInfo.targetProjectPath stringByAppendingPathComponent:result];
                    if ([fileManager fileExistsAtPath:result]) {
                        [searchLibraryDirSetM addObject:result];
                    }
                } else { // 文件存在
                    [searchLibraryDirSetM addObject:result];
                }
            } else if ([checkStr hasPrefix:@" -F"]) {
                if (![fileManager fileExistsAtPath:result]) { // 可能是相对路径
                    result = [targetLinkInfo.targetProjectPath stringByAppendingPathComponent:result];
                    if ([fileManager fileExistsAtPath:result]) {
                        [searchFrameworkDirSetM addObject:result];
                    }
                } else { // 文件存在
                    [searchFrameworkDirSetM addObject:result];
                }
            } else if ([checkStr hasPrefix:@" -l"]) {
                [linkLibraryNameSetM addObject:result];
            } else if ([checkStr hasPrefix:@" -framework"]) {
                [linkFrameworkNameSetM addObject:result];
            }
        }
    }
    
    targetLinkInfo.searchLibraryDirs = [searchLibraryDirSetM allObjects];
    targetLinkInfo.searchFrameworkDirs = [searchFrameworkDirSetM allObjects];
    targetLinkInfo.forceLoadFilePaths = [forceLoadLibOrFrameworkPathSetM allObjects];
    targetLinkInfo.linkLibraryNames = [linkLibraryNameSetM allObjects];
    targetLinkInfo.linkFrameworkNames = [linkFrameworkNameSetM allObjects];
    targetLinkInfo.dependentFilePaths = [dependentFilePathSetM allObjects];
}

- (void)findAllLinkLibWithTargetLinkInfo:(TargetLinkInfo *)targetLinkInfo
{
    NSMutableSet *handledLibNameSetM = [NSMutableSet set];
    NSMutableSet *linkLibFilePathSetM = [NSMutableSet setWithArray:self.targetLibFilePathsDicM[targetLinkInfo.targetName]];
    for (NSString *forceloadFilePath in targetLinkInfo.forceLoadFilePaths) {
        NSString *fullFileName = [forceloadFilePath lastPathComponent];
        NSString *name = fullFileName;
        if ([fullFileName hasSuffix:@".a"]) {
            if ([name hasPrefix:@"lib"]) {
                name = [name chr_subStringBetweenFrom:@"lib" to:@".a" backwardsSearch:NO];
            } else {
                name = [name stringByDeletingPathExtension];
            }
        } else if ([fullFileName hasSuffix:@".framework"]) {
            name = [fullFileName stringByDeletingPathExtension];
        }
        if ([handledLibNameSetM containsObject:name]
            || ![[NSFileManager defaultManager] fileExistsAtPath:forceloadFilePath]) {
            continue;
        }

        if (name) {
            [linkLibFilePathSetM addObject:forceloadFilePath];
            [handledLibNameSetM addObject:name];
        } else {
            WarningLog(@"ignore force_load path : %@", forceloadFilePath);
        }
    }

    BOOL isSimulator = ProjectSharedManager().isSimulator;
    NSFileManager *fileMgr = [NSFileManager defaultManager];
    
    void (^findLibFilePathFromDir)(NSString *dir) = ^(NSString *libDir){
        NSArray *subpaths = [fileMgr contentsOfDirectoryAtPath:libDir error:nil];
        __block BOOL hasFramework = NO;
        
        void(^findLibFilePathWithDirAndSubpath)(NSString *dir, NSString *subpath) = ^(NSString *dir, NSString *subpath) {
            NSString *filePath;
            NSString *name;
            if ([subpath hasSuffix:@".framework"]) {
               name = [subpath stringByDeletingPathExtension];
               filePath = [[libDir stringByAppendingPathComponent:subpath] stringByAppendingPathComponent:name];
            } else if ([subpath hasSuffix:@".xcframework"]) {
               NSString *dir = [libDir stringByAppendingPathComponent:subpath];
               if (isSimulator) {
                   dir = [dir stringByAppendingPathComponent:@"ios-i386_x86_64-simulator"];
               } else {
                   dir = [dir stringByAppendingPathComponent:@"ios-armv7_arm64"];
               }

               NSArray *subpaths = [fileMgr contentsOfDirectoryAtPath:dir error:nil];
               for (NSString *subpath in subpaths) {
                   if ([subpath hasSuffix:@".framework"]) {
                       filePath = [dir stringByAppendingFormat:@"/%@/%@", subpath, subpath.stringByDeletingPathExtension];
                       name = [filePath lastPathComponent];
                       break;
                   } else if([subpath hasSuffix:@".a"]) {
                       filePath = [dir stringByAppendingPathComponent:subpath];
                       name = [subpath chr_subStringBetweenFrom:@"lib" to:@".a" backwardsSearch:NO];
                   }
               }
            } else if ([subpath hasSuffix:@".a"]) {
               name = [subpath chr_subStringBetweenFrom:@"lib" to:@".a" backwardsSearch:NO];
               filePath = [libDir stringByAppendingPathComponent:subpath];
            }

            if (name && filePath) {
                hasFramework = YES;
                if ([handledLibNameSetM containsObject:name]
                    || ![[NSFileManager defaultManager] fileExistsAtPath:filePath]
                    || (![targetLinkInfo.targetName isEqualToString:@"Pods"] && ![targetLinkInfo.linkLibraryNames containsObject:name] && ![targetLinkInfo.linkFrameworkNames containsObject:name])) {
                    // 非Pods target 需要linkLibraries & linkFrameworks
                    return;
                }
                [linkLibFilePathSetM addObject:filePath];
                [handledLibNameSetM addObject:name];
            }
        };
        
        for (NSString *subpath in subpaths) {
            findLibFilePathWithDirAndSubpath(libDir, subpath);
        }
        
        if (!hasFramework) { // 没找到，递归去找
           NSArray *allSubpaths = [fileMgr subpathsAtPath:libDir];
           for (NSString *subpath in allSubpaths) {
               findLibFilePathWithDirAndSubpath(libDir, subpath);
           }
        }
    };
    
    CocoaHotReloadSettings *settings = ProjectSharedManager().settings;
    NSString *configuration = settings.configuration;
    NSString *configurationDir = [NSString stringWithFormat:@"%@-%@", configuration, settings.platformName];
    for (NSString *libDir in targetLinkInfo.searchLibraryDirs) {
        if ([targetLinkInfo.targetName isEqualToString:@"Pods"]
            && ([libDir hasSuffix:configurationDir])) { // 忽略Pods中直接产物的目录文件夹
            continue;
        }
        // 查找库
        findLibFilePathFromDir(libDir);
    }

    for (NSString *libDir in targetLinkInfo.searchFrameworkDirs) {
        if ([targetLinkInfo.targetName isEqualToString:@"Pods"]
            && [libDir hasSuffix:configurationDir]) { // 忽略Pods中直接产物的目录文件夹
            continue;
        }
        // 查找库
        findLibFilePathFromDir(libDir);
    }
    
    [linkLibFilePathSetM addObjectsFromArray:targetLinkInfo.dependentFilePaths];
    
    @synchronized (self) {
        if (linkLibFilePathSetM.count > 0) {
            self.targetLibFilePathsDicM[targetLinkInfo.targetName] = linkLibFilePathSetM.allObjects;
            if (targetLinkInfo.isExportedSymbols) {
                if (!self.exportedLibFilePathSetM) {
                    self.exportedLibFilePathSetM = [NSMutableSet set];
                }
                [self.exportedLibFilePathSetM addObjectsFromArray:linkLibFilePathSetM.allObjects];
            }
        }
    }
}

- (NSArray<NSString *> *)getPrivateSymbolsWithlibFilePath:(NSString *)filePath
{
    if ([filePath hasSuffix:@".framework"]) { // 动态库路径调整为可执行文件路径 xxx.framework -> xxx.framework/xxx
        filePath = [filePath stringByAppendingPathComponent:filePath.lastPathComponent.stringByDeletingPathExtension];
    }
    
    if (![[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        return nil;
    }

    BOOL isExported = [self.exportedLibFilePathSetM containsObject:filePath];

    filePath = [self thinLibWithFilePathIfNeed:filePath];
    ShellResult *result;
    // 私有符号库
    // C 或 C++ 符号为_开头
    // OC类符号为 _OBJC_CLASS_$
    // Swift [alt entry] _$ 或 [alt entry] _OBJC_CLASS_$ 开头
    NSString *source = [NSString stringWithFormat:@"nm -nm %@ | grep '(__.*,__.*) private external \\(\\[alt entry\\] \\)\\?_'", filePath];

    if (isExported) { // 符号导出的库
#if SUPPORT_EXPORT_SYMBOL
        source = [source stringByReplacingOccurrencesOfString:@" private external " withString:@" external "];
        result = [ShellService doShellOutputWithSource:source];
#else
        return nil;
#endif
    } else {
        result = [ShellService doShellOutputWithSource:source];
    }

    if (result.isSuccess) {
        @autoreleasepool {
            NSArray<NSString *> *symbols = [result.output componentsSeparatedByString:@"\n"];
            NSMutableArray *symbolsM = [NSMutableArray array];
            for (NSString *symbol in symbols) {
                if ([symbol containsString:@"_$"]) {
                    if (![symbol containsString:@"[alt entry] _$"] &&
                        ![symbol containsString:@" _OBJC_CLASS_$"]) { // 过滤掉OC or Swift中非Class的符号 如(_OBJC_METACLASS_$、_OBJC_IVAR_$等)
                        continue;
                    }
                }
                NSRange prefixRange = [symbol rangeOfString:@"external "];
                if (prefixRange.location != NSNotFound) {
                    [symbolsM addObject:[symbol substringFromIndex:prefixRange.location + prefixRange.length]];
                }
            }
            if (symbolsM.count > 0) { // 私有库
                return symbolsM;
            }
        }
        
        return nil;
    }
    
    return nil;
}

- (NSString *)thinLibsDir
{
    return [[FileSharedManager() tmpDirAndCreateIfNeed] stringByAppendingPathComponent:@"thinLibs"];;
}

// 库瘦身
- (NSString *)thinLibWithFilePathIfNeed:(NSString *)filePath
{
    NSString *thinFilePath;

    NSString *arch = ProjectSharedManager().settings.arch;

    NSString *thinLibsDir = [self thinLibsDir];
    
    @synchronized (self) {
        if (!self.thinLibFilePathDicM) {
            self.thinLibFilePathDicM = [NSMutableDictionary dictionary];
        }

        [CocoaFileTool createDirectoryIfNeedForPath:thinLibsDir];
        
        thinFilePath = self.thinLibFilePathDicM[filePath];
    }
    
    if (![[NSFileManager defaultManager] fileExistsAtPath:thinFilePath]) {
        ShellResult *result = [ShellService doShellOutputWithSource:[NSString stringWithFormat:@"lipo -archs %@", filePath]];
        if (result.isSuccess) {
            NSString *archsString = [result.output stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            archsString = [archsString stringByReplacingOccurrencesOfString:@" " withString:@""];
            
            if ([archsString containsString:arch] && archsString.length > arch.length) {
                // 瘦身
                NSString *fullFileName = [filePath lastPathComponent];
                NSString *fileName = [fullFileName stringByDeletingPathExtension];
                NSString *pathExtension = [fullFileName pathExtension];
                
                NSString *thinFilePath = [thinLibsDir stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_thin_%@%@", fileName, arch, pathExtension.length > 0 ? [NSString stringWithFormat:@".%@", pathExtension] : @""]];
                result = [ShellService doShellOutputWithSource:[NSString stringWithFormat:@"lipo %@ -thin %@ -output %@", filePath, arch, thinFilePath] ignoreError:YES];
                @synchronized (self) {
                    if (result.isSuccess) {
                        self.thinLibFilePathDicM[filePath] = thinFilePath;
                    } else {
                        //WarningLog(@"库瘦身失败：%@", filePath);
                    }
                }
                if ([[NSFileManager defaultManager] fileExistsAtPath:thinFilePath]) {
                    return thinFilePath;
                }
                
                return filePath;
            }
        }
    }
    
    return filePath;
}

// 查找库依赖的库 .o .a .framework file path
- (NSArray *)findAllDependentLibOrFrameworkForFilePath:(NSString *)filePath
                               didHandleLibFilePathSet:(NSMutableSet<NSString *> *)didHandleLibFilePathSet
                                   privateLibFilePaths:(NSArray<NSString *> *)privateLibFilePaths
                                    targetLibFilePaths:(NSArray<NSString *> *)targetLibFilePaths
{
    if (!self.libDependentOtherLibFilePathsDicM) {
        self.libDependentOtherLibFilePathsDicM = [NSMutableDictionary dictionary];
    }
    BOOL isLibFilePath = ![filePath hasSuffix:@".o"];
    if (isLibFilePath
        && [self.libDependentOtherLibFilePathsDicM.allKeys containsObject:filePath]) {
        return self.libDependentOtherLibFilePathsDicM[filePath];
    }
    
    if (!isLibFilePath) {
#if CMDTOOL
        filePath = [ProjectSharedManager() originalOutputPathForCurrentFilePath:filePath];
#endif
        NSString *targetName = [filePath chr_subStringBetweenFrom:@"Intermediates.noindex/" to:@".build/" backwardsSearch:NO];
    //    NSArray *libFilePaths = self.libPrivateSymbolsDicM.allKeys;
        
        NSMutableSet *targetLibFilePathSetM = [NSMutableSet setWithArray: self.targetLibFilePathsDicM[targetName]];
        
        // 添加所有依赖该产物的target所依赖的库
        NSString *productPath = self.targetProductPathDicM[targetName];
        if (productPath) {
            for (NSString *targetName in self.targetLibFilePathsDicM.allKeys) {
                if ([self.targetLibFilePathsDicM[targetName] containsObject:productPath]) {
                    [targetLibFilePathSetM addObjectsFromArray:self.targetLibFilePathsDicM[targetName]];
                }
            }
        }
        targetLibFilePaths = [targetLibFilePathSetM allObjects];
        NSMutableSet *libFilePathSetM = [NSMutableSet set];
        for (NSString *libFilePath in targetLibFilePaths) {
            if ([self.libPrivateSymbolsDicM.allKeys containsObject:libFilePath]) {
                [libFilePathSetM addObject:libFilePath];
            }
        }
        
        privateLibFilePaths = libFilePathSetM.allObjects;
    }
    
    NSMutableSet *dependentLibOrFrameworksFilePathsM = [NSMutableSet set];
    
    @autoreleasepool {
        NSString *source = [NSString stringWithFormat:@"nm --undefined-only %@", filePath];
        
        ShellResult *result = [ShellService doShellOutputWithSource:source];
        if (result.isSuccess) {
            NSArray<NSString *> *undefindSymbols = [result.output componentsSeparatedByString:@"\n"];
            
            for (NSString *undefindSymbol in undefindSymbols) {
                if ([self.exportedSymbolSetM containsObject:undefindSymbol]) { // 已导出
                    continue;
                }
                // oc category会访问到私有属性
                if ([undefindSymbol hasPrefix:@"_OBJC_IVAR_$_"]) { // 场景特殊 临时解析
                    if (!self.libPrivateObjcIvarSymbolsDicM) {
                        self.libPrivateObjcIvarSymbolsDicM = [NSMutableDictionary dictionary];
                    }
                    
                    for (int i = 0; i < targetLibFilePaths.count; i++) {
                        NSString *libFilePath = targetLibFilePaths[i];
                        NSArray<NSString *> *privateObjcIvarSymbols = self.libPrivateObjcIvarSymbolsDicM[libFilePath];
                        if (!privateObjcIvarSymbols) {
                            NSString *source = [NSString stringWithFormat:@"nm -nm %@ | grep 'private external _OBJC_IVAR_'", libFilePath];
                            ShellResult *result = [ShellService doShellOutputWithSource:source];
                            if (result.isSuccess) {
                                NSArray<NSString *> *results = [result.output componentsSeparatedByString:@"\n"];
                                NSMutableSet *ivarSymbolSet = [NSMutableSet set];
                                for (NSString *result in results) {
                                    NSRange range = [result rangeOfString:@"_OBJC_IVAR_"];
                                    if (range.location != NSNotFound) {
                                        [ivarSymbolSet addObject:[result substringFromIndex:range.location]];
                                    }
                                }
                                privateObjcIvarSymbols = ivarSymbolSet.allObjects;
                                if (privateObjcIvarSymbols.count > 0) {
                                    self.libPrivateObjcIvarSymbolsDicM[libFilePath] = privateObjcIvarSymbols;
                                } else {
                                    self.libPrivateObjcIvarSymbolsDicM[libFilePath] = @[];
                                }
                            } else {
                                self.libPrivateObjcIvarSymbolsDicM[libFilePath] = @[];
                            }
                        }
                        
                        if ([privateObjcIvarSymbols containsObject:undefindSymbol]) {
                            [dependentLibOrFrameworksFilePathsM addObject:libFilePath];
                            break;
                        }
                    }
                } else { // 普通私有类符号
                    for (int i = 0; i < privateLibFilePaths.count; i++) {
                        NSString *libFilePath = privateLibFilePaths[i];
                        if ([libFilePath isEqualToString:filePath]) {
                            continue;
                        }
                        NSArray *privateSymbols = self.libPrivateSymbolsDicM[libFilePath];
                        if ([privateSymbols containsObject:undefindSymbol]) {
                            [dependentLibOrFrameworksFilePathsM addObject:libFilePath];
                        }
                    }
                }
            }
        }
        
        if (isLibFilePath) {
            [didHandleLibFilePathSet addObject:filePath];
        }
        
        if (dependentLibOrFrameworksFilePathsM.count > 0) { // 依赖库
            NSMutableSet *subDependentSet = [NSMutableSet set];
            for (NSString *filePath in dependentLibOrFrameworksFilePathsM.allObjects) { // 递归
                if ([didHandleLibFilePathSet containsObject:filePath]) { // 库已处理过
                    continue;
                }
                NSArray *dependentFilePaths = [self findAllDependentLibOrFrameworkForFilePath:filePath
                                                                      didHandleLibFilePathSet:didHandleLibFilePathSet
                                                                          privateLibFilePaths:privateLibFilePaths
                                                                           targetLibFilePaths:targetLibFilePaths
                                               ];
                self.libDependentOtherLibFilePathsDicM[filePath] = dependentFilePaths;
                [subDependentSet addObjectsFromArray:dependentFilePaths];
                // 添加到已处理中  避免死循环
                [didHandleLibFilePathSet addObject:filePath];
            }
            [dependentLibOrFrameworksFilePathsM addObjectsFromArray:subDependentSet.allObjects];
        }
    }
    
    return dependentLibOrFrameworksFilePathsM.allObjects;
}

- (NSString *)deleteOFilesFromLibFilePath:(NSString *)libFilePath oFileNames:(NSArray<NSString *> *)oFileNames
{
    NSString *parseFilePath = self.thinLibFilePathDicM[libFilePath];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (parseFilePath.length > 0 && ![fileManager fileExistsAtPath:parseFilePath]) {
        // 库进行瘦身
        parseFilePath = [self thinLibWithFilePathIfNeed:libFilePath];
    }
    if (!parseFilePath) {
       // parseFilePath = libFilePath;
       parseFilePath = libFilePath;
    }
    
    NSArray *oFileNamesInLib = [self oFileNameWithFilePath:parseFilePath];
    NSMutableSet *needRemoveOFileNameSetM = [NSMutableSet set];
    for (NSString *oFileName in oFileNamesInLib) {
        if ([oFileNames containsObject:oFileName]) {
            [needRemoveOFileNameSetM addObject:oFileName];
        }
    }
    
    if (needRemoveOFileNameSetM.count == oFileNamesInLib.count) { // 全部需要移除 则返回nil
        return nil;
    }
    
    if (needRemoveOFileNameSetM.count > 0) { // 需要剔除.o
        NSString *dir = [self removedDuplicateOFileLibsDir];
        NSString *castrationFilePath = [dir stringByAppendingPathComponent:[parseFilePath lastPathComponent]];
        ShellResult *result = [ShellService doShellOutputWithSource:[NSString stringWithFormat:@"cp -rf %@ %@; chmod 777 %@; ar -d %@ %@ ", parseFilePath, castrationFilePath, castrationFilePath, castrationFilePath, [needRemoveOFileNameSetM.allObjects componentsJoinedByString:@" "]] ignoreError:YES];
        if (result.isSuccess) {
            return castrationFilePath;
        }
        return parseFilePath;
    } else {
        return parseFilePath;
    }
    
    return parseFilePath;
}

- (NSArray<NSString *> *)oFileNameWithFilePath:(NSString *)libFilePath
{
    ShellResult *result = [ShellService doShellOutputWithSource:[NSString stringWithFormat:@"ar -t %@", libFilePath] ignoreError:YES];

    if (result.isSuccess) {
        NSArray *oFileNames = [result.output componentsSeparatedByString:@"\n"];
        NSMutableSet *oFileNameSet = [NSMutableSet set];
        for (NSString *oFileName in oFileNames) {
            if ([oFileName hasSuffix:@".o"]) {
                [oFileNameSet addObject:oFileName];
            }
        }
        return oFileNameSet.allObjects;
    }
    
    return nil;
}

- (NSString *)removedDuplicateOFileLibsDir
{
    NSString *dir = [[FileSharedManager() tmpDirAndCreateIfNeed] stringByAppendingPathComponent:@"removedDumplicatieOFileLibOrFrameworks"];
   
    [CocoaFileTool createDirectoryIfNeedForPath:dir];
    
    return dir;
}

@end
