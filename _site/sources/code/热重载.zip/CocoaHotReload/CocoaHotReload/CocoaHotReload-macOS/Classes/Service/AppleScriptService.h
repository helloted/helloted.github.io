//
//  AppleScriptService.h
//  CocoaHotReloadTool
//
//  Created by mambaxie on 2019/11/20.
//  Copyright © 2019 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AppleScriptService : NSObject

/// 执行AppleScript脚本
/// @param source 所要执行的AppleScript脚本内容
/// @param handler 回调执行结果
+ (void)doScriptWithSource:(NSString *)source completionHandler:(void(^)(NSError *error))handler;

/// 取消执行AppleScript
+ (void)cancelScript;

@end

NS_ASSUME_NONNULL_END
