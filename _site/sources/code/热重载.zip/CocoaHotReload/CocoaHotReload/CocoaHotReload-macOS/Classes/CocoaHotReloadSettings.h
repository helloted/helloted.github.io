//
//  CocoaHotReloadSettings.h
//  CocoaHotReloadDemo
//
//  Created by mambaxie on 2019/11/26.
//  Copyright © 2019 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CocoaHotReloadDefine.h"

NS_ASSUME_NONNULL_BEGIN

@interface CocoaHotReloadSettings : NSObject

/// 默认配置
+ (instancetype)defaultSettings;

/// 当前场景
@property (nonatomic, assign) CocoaHotReloadScene currentScene;

/// 监听文件变化路径
@property (nonatomic, copy) NSArray *watchDirectoryPaths;

/// 项目文件路径
@property (nonatomic, copy, nullable) NSString *projectFilePath;

/// 项目文件夹路径
@property (nonatomic, copy, readonly) NSString *projectDirectoryPath;

/// 可执行文件名称
@property (nonatomic, copy) NSString *executableName;

/// 客户端版本信息
@property (nonatomic, strong) NSDictionary *clientBundleInfo;

/// 项目名称，优先从Build log中获取，如果有返回，否则返回 [[_projectFilePath lastPathComponent] stringByDeletingPathExtension]
@property (nonatomic, copy, nullable) NSString *projectName;

/// target
@property (nonatomic, copy) NSString *targetName;

/// target name for test
@property (nonatomic, copy) NSString *testTargetName;

/// platform名称
@property (nonatomic, copy) NSString *platformName;

/// 最低系统版本
@property (nonatomic, copy) NSString *minimumOSVersion;

/// 对应xcode编译环境变量CONFIGURATION 默认为Debug
@property (nonatomic, copy) NSString *configuration;

/// xcode devloper 路径 默认为：/Applications/Xcode.app/Contents/Developer
@property (nonatomic, copy) NSString *XcodeDeveloperPath;

/// default is x86_64
@property (nonatomic, copy) NSString *arch;

/// app main bundle path (socket自动传的 用户无需设置)
@property (nonatomic, copy) NSString *frameworksPath;

/// 项目运行时间
@property (nonatomic, assign) NSTimeInterval projectRunTimeInterval;

/// 当前客户端动态库版本
@property (nonatomic, copy) NSString *clientFrameworkVersion;

/// 工程bundle ID
@property (nonatomic, copy , nullable) NSSet *bundleIDs;

@property (nonatomic, copy) NSString *fileListPath;

/// cmd工具执行产物的目录
@property (nonatomic, copy) NSString *cmdProductDir;
/// 仅cmd工具使用 工程deriveddata目录（绝对路径）
@property (nonatomic, copy) NSString *derivedDataPath;
/// 仅cmd工具使用
@property (nonatomic, copy) NSString *customDylibName;

@end

NS_ASSUME_NONNULL_END
