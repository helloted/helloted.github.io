//
//  CocoaToast.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/5/23.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "CocoaToast.h"
#import "ToastWindowController.h"
#import "CocoaHotReloadTool.h"

@implementation CocoaToast

// 成功提示
+ (void)showSuccessWithMsg:(NSString *)msg
{
    [self showToastWithMsg:msg];
}

// 失败提示
+ (void)showErrorWithMsg:(NSString *)msg
{
    [self showToastWithMsg:msg];
}

+ (void)showToastWithMsg:(NSString *)msg
{
    [CocoaHotReloadTool runOnMainThread:^{
        ToastWindowController *toastWindow = [ToastWindowController getToastWindow];
        
        toastWindow.animater = CTAnimaterFade;
        toastWindow.animaterTimeSecond = 0.5;
        toastWindow.autoDismissTimeInSecond = 2.5;
        toastWindow.textFont = [NSFont systemFontOfSize:22];
        toastWindow.autoDismiss = YES;
        toastWindow.toastPostion = CTPositionCenter;

        toastWindow.minWidth = 10;
        // toastWindow.maxWidth = 360;
        
        [toastWindow showCoolToast:msg];
    }];
}

@end
