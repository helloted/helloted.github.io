//
//  FullScreenMaskWindow.h
//  CocoaHotReload-macOS
//
//  Created by 谢培艺 on 2020/2/18.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface FullScreenMaskWindow : NSWindow

/// 显示全屏遮罩
+ (void)show;

/// 隐藏全屏遮罩
+ (void)dismiss;

@end

NS_ASSUME_NONNULL_END
