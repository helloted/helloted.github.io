//
//  SignManager.m
//  CocoaHotReload-macOS
//
//  Created by mambaxie on 2020/12/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "SignManager.h"
#import "FileManager.h"

// 签名标识长度为40
static int const kSigningIdentityLength = 40;

@implementation SignManager

- (void)clearData
{
    _signingIdentity = nil;
}

/// 获取app签名字符串
- (NSString *)signingIdentityForApp
{
    if (_signingIdentity) {
        return _signingIdentity;
    }
    
    NSString *logFilePath = [FileSharedManager() lastBuildSucceedUnzipProjectLogFilePath];
    
    if (![[NSFileManager defaultManager] fileExistsAtPath:logFilePath]) {
        return nil;
    }
    NSFileHandle *fileHandle = [NSFileHandle fileHandleForReadingAtPath:logFilePath];
    
    NSDictionary *fileDic = [[NSFileManager defaultManager] attributesOfItemAtPath:logFilePath error:nil]; //获取文件的属性
    
    unsigned long long totalSize = [[fileDic objectForKey:NSFileSize] unsignedLongLongValue];
    unsigned long long readDataLengthEach = 50 * 1024 * 1024;
    unsigned long long didReadDataLength = 0;
    
    while (didReadDataLength < totalSize) {
        
        if (totalSize - didReadDataLength < readDataLengthEach) {
            readDataLengthEach = totalSize - didReadDataLength;
        }
        
        unsigned long long begin = totalSize - didReadDataLength - readDataLengthEach;
        if (begin < 0) {
            begin = 0;
        }
        
        [fileHandle seekToFileOffset:begin];
        
        NSString *log = [[NSString alloc] initWithData:[fileHandle readDataOfLength:readDataLengthEach] encoding:NSUTF8StringEncoding];
        /// 逆序查找
        NSRange range = [log rangeOfString:@"/usr/bin/codesign --force --sign " options:NSBackwardsSearch];
        if (range.location != NSNotFound) {
            NSString *subString = [log substringWithRange:NSMakeRange(range.location + range.length, kSigningIdentityLength + 1)];
            NSRange spaceRange = [subString rangeOfString:@" "];
            if (spaceRange.location != NSNotFound) {
                _signingIdentity = [subString substringToIndex:spaceRange.location];
                return _signingIdentity;
            }
        } else { // 容错
             NSRange range = [log rangeOfString:@"export EXPANDED_CODE_SIGN_IDENTITY=" options:NSBackwardsSearch];
             if (range.location != NSNotFound) {
                 NSString *subString = [log substringWithRange:NSMakeRange(range.location + range.length, kSigningIdentityLength + 1)];
                 NSRange spaceRange = [subString rangeOfString:@"\r"];
                 if (spaceRange.location != NSNotFound) {
                     _signingIdentity = [subString substringToIndex:spaceRange.location];
                     return _signingIdentity;
                 }
             }
        }
        
        didReadDataLength += readDataLengthEach;
    }

    return nil;
}

@end
