//
//  XCTestHookToolTests.m
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/4.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "XCTestHookTool.h"
#import "CocoaClassTool.h"

@interface XCTestHookToolTests : XCTestCase

@end

@implementation XCTestHookToolTests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testHookXCTestFunctions {
    
    [XCTestHookTool hookXCTestFunctions];
    
    Class testClass = [XCTest class];
    IMP performTestImp = [testClass instanceMethodForSelector:@selector(performTest:)];
    CocoaClassImpInfo *impInfo = [CocoaClassTool impInfoForImp:performTestImp];
    XCTAssertEqualObjects(impInfo.className, NSStringFromClass([XCTestHookTool class]));
}

@end
