//
//  CocoaClassToolTests.m
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/4.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "CocoaClassTool.h"
#import "TestClass.h"
#import "TestClass+Category.h"
#import <dlfcn.h>
#import <mach-o/dyld.h>
#import <mach-o/ldsyms.h>
#import "TestSubClass.h"

@interface CocoaClassToolTests : XCTestCase

@end

@implementation CocoaClassToolTests

// 运行无需测试的函数
+ (void)runNotTestFunctions
{
    [CocoaClassTool setup];
    [CocoaClassTool preupdateCategoryMethodForBasicClasses];
    [CocoaClassTool printClassInstanceMethodInfo:[TestClass class]];
}

+ (void)setUp
{
    [self runNotTestFunctions];
}

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    
}

- (NSString *)bundlePathForDylibName:(NSString *)dylibName
{
    Class oldClass = [TestClass class];
    return [[NSBundle bundleForClass:oldClass] pathForResource:[NSString stringWithFormat:@"Products/%@", dylibName] ofType:nil];
}

- (void)testUpdateAllShouldBeReplaceClassWithNewClass
{
    Class oldClass = [TestClass class];
    NSString *path = [self bundlePathForDylibName:@"CocoaHotReload_all.dylib"];
    void *libHandle = dlopen(path.UTF8String, RTLD_NOW);
    Dl_info info;
    dladdr((__bridge const void *)(oldClass), &info);
    id newSym = (__bridge id)dlsym(libHandle, info.dli_sname);
    Class newClass = [newSym class];
    {
        id oldObject = [oldClass new];
        
        BOOL result = [CocoaClassTool updateAllShouldBeReplaceClassWithNewClass:newClass
                                                                    dylibHandle:libHandle
                                                                       classSym:info.dli_sname
                                                         ignoreClassMethodNames:@[@"classFunction"]];
        XCTAssertEqual(result, YES);
        SEL sel = @selector(classFunction);
        IMP newSelImp = method_getImplementation(class_getClassMethod(newClass, sel));
        Dl_info newSelInfo;
        dladdr(newSelImp, &newSelInfo);
        XCTAssertNotEqualObjects([NSString stringWithUTF8String:newSelInfo.dli_fname], path);

        SEL toRemoveSel = @selector(toRemoveInstanceFunction);
        IMP toRemoveImp = method_getImplementation(class_getInstanceMethod(oldClass, toRemoveSel));
        Dl_info toRemoveImpInfo;
        dladdr(toRemoveImp, &toRemoveImpInfo);
        XCTAssertEqualObjects([NSString stringWithCString:toRemoveImpInfo.dli_sname encoding:NSUTF8StringEncoding], @"_objc_msgForward");

        SEL addSel = NSSelectorFromString(@"addInstanceFunction");
        IMP addImp = method_getImplementation(class_getInstanceMethod(oldClass, addSel));
        IMP newAddImp =  method_getImplementation(class_getInstanceMethod(newClass, addSel));
        XCTAssertEqual(addImp, newAddImp);
        
        // 访问删除的函数
        @try {
            [oldObject performSelector:@selector(toRemoveInstanceFunction)];
        } @catch (NSException *exception) {
            XCTAssertEqual([[exception description] containsString:@"unrecognized selector sent"], YES);
        } @finally {
            ;
        }
        // 访问删除的属性
        [oldClass performSelector:NSSelectorFromString(@"addClassFunction")];
        
        XCTAssertEqual([oldObject isKindOfClass:[oldClass class]], YES);
        XCTAssertEqual([oldObject isKindOfClass:[newClass class]], YES);
        XCTAssertEqual([oldObject isKindOfClass:NSClassFromString(@"TestClass")], YES);
        XCTAssertEqual([oldObject isMemberOfClass:NSClassFromString(@"TestClass")], YES);
        
        XCTAssertEqual([TestSubClass isSubclassOfClass:[oldClass class]], YES);
        XCTAssertEqual([TestSubClass isSubclassOfClass:[newClass class]], YES);
        XCTAssertEqual([TestSubClass isSubclassOfClass:NSClassFromString(@"TestClass")], YES);
        
        [oldObject setValue:@(10) forKey:@"addTestInt"];
        XCTAssertEqual([[oldObject valueForKey:@"addTestInt"] intValue], 10);
        [oldObject setValue:@(100) forKeyPath:@"addTestInt"];
        XCTAssertEqual([[oldObject valueForKeyPath:@"addTestInt"] intValue], 100);
    }
    {
        BOOL result = [CocoaClassTool updateAllShouldBeReplaceClassWithNewClass:NSClassFromString(@"FakeClassName")
                                                                    dylibHandle:libHandle
                                                                       classSym:info.dli_sname
                                                         ignoreClassMethodNames:@[]];
        XCTAssertEqual(result, NO);
    }
    {
        BOOL result = [CocoaClassTool updateAllShouldBeReplaceClassWithNewClass:newClass
                                                                    dylibHandle:libHandle
                                                                       classSym:info.dli_sname
                                                         ignoreClassMethodNames:@[]];
        XCTAssertEqual(result, YES);
        SEL sel = @selector(instanceFunction);
        IMP oldSelImp = [oldClass instanceMethodForSelector:sel];
        IMP newSelImp = [newClass instanceMethodForSelector:sel];
        XCTAssertEqual(oldSelImp, newSelImp);
    }
    
    dlclose(libHandle);
}

- (void)testSynchronizeOrginClassToAllClassWithClassNames
{
    NSArray<NSString *> *classNames = @[@"TestClass"];
    NSArray<NSString *> *oFileClassNames = @[@"TestClass"];
    
    Class oldClass = [TestClass class];
    
    NSString *classPath = [self bundlePathForDylibName:@"CocoaHotReload_class.dylib"];
    void *classLibHandle = dlopen(classPath.UTF8String, RTLD_NOW);
    
    NSString *path = [self bundlePathForDylibName:@"CocoaHotReload_category.dylib"];
    void *libHandle = dlopen(path.UTF8String, RTLD_NOW);
    Dl_info info;
    dladdr((__bridge const void *)(oldClass), &info);
    {
        [CocoaClassTool synchronizeOrginClassToAllClassWithClassNames:classNames
                                                      oFileClassNames:oFileClassNames
                                                      ignoreLibHandle:libHandle];
        
        id newSym = (__bridge id)dlsym(libHandle, info.dli_sname);
        Class newClass = [newSym class];
        
        SEL sel = @selector(categoryClassFunction);
        IMP newSelImp = method_getImplementation(class_getClassMethod(newClass, sel));
        XCTAssertEqual(newSelImp, nil);
    }
    {
    
        [CocoaClassTool synchronizeOrginClassToAllClassWithClassNames:classNames
                                                      oFileClassNames:nil
                                                      ignoreLibHandle:libHandle];
        
        

        id newSym = (__bridge id)dlsym(classLibHandle, info.dli_sname);
        Class newClass = [newSym class];
        SEL sel = @selector(categoryClassFunction);
        IMP oldSelImp = method_getImplementation(class_getClassMethod(oldClass, sel));
        IMP newSelImp = method_getImplementation(class_getClassMethod(newClass, sel));
        XCTAssertEqual(newSelImp, oldSelImp);
    }
    
    dlclose(libHandle);
    dlclose(classLibHandle);
}

- (void)testIsCategoryInstanceMethodHooked
{
    {
        Class class = [TestClass class];
        Method nullMethod = nil;
        BOOL result = [CocoaClassTool isCategoryInstanceMethodHookedWithMethod:nullMethod aClass:class];
        XCTAssertEqual(result, NO);
    }
    {
        Class class = [TestClass class];
        Method noncategoryMethod = class_getInstanceMethod(class, @selector(instanceFunction));
        BOOL result = [CocoaClassTool isCategoryInstanceMethodHookedWithMethod:noncategoryMethod aClass:class];
        XCTAssertEqual(result, NO);
    }
    {
        Class class = [TestClass class];
        Method categoryHookedInstanceMethod = class_getInstanceMethod(class, @selector(hook_toHookInstanceFunction));
        BOOL result = [CocoaClassTool isCategoryInstanceMethodHookedWithMethod:categoryHookedInstanceMethod aClass:class];
        XCTAssertEqual(result, YES);
    }
    {
        Class class = [TestClass class];
        Method categoryHookedClassMethod = class_getClassMethod(class, @selector(hook_toHookClassFunction));
        BOOL result = [CocoaClassTool isCategoryInstanceMethodHookedWithMethod:categoryHookedClassMethod aClass:class];
        XCTAssertEqual(result, NO);
    }
}

- (void)testIsCategoryMethod
{
    {
        Method nullMethod = nil;
        BOOL result = [CocoaClassTool isCategoryMethod:nullMethod];
        XCTAssertEqual(result, NO);
    }
    {
        Method noncategoryMethod = class_getInstanceMethod([TestClass class], @selector(instanceFunction));
        BOOL result = [CocoaClassTool isCategoryMethod:noncategoryMethod];
        XCTAssertEqual(result, NO);
    }
    {
        Method categoryInstanceMethod = class_getInstanceMethod([TestClass class], @selector(categoryInstanceFunction));
        BOOL result = [CocoaClassTool isCategoryMethod:categoryInstanceMethod];
        XCTAssertEqual(result, YES);
    }
    {
        Method categoryClassMethod = class_getClassMethod([TestClass class], @selector(categoryClassFunction));
        BOOL result = [CocoaClassTool isCategoryMethod:categoryClassMethod];
        XCTAssertEqual(result, YES);
    }
}

- (void)testOrginClassForClassName
{
    {
        NSString *nullClassName = nil;
        Class result = [CocoaClassTool orginClassForClassName:nullClassName];
        XCTAssertEqualObjects(result, nil);
    }
    {
        NSString *fakeClassName = @"FakeClassName";
        Class result = [CocoaClassTool orginClassForClassName:fakeClassName];
        XCTAssertEqualObjects(result, nil);
    }
    {
        NSString *className = @"TestClass";
        Class result = [CocoaClassTool orginClassForClassName:className];
        XCTAssertEqualObjects(result, [TestClass class]);
    }
    {
        NSString *categoryClassName = @"TestClass(Category)";
        Class result = [CocoaClassTool orginClassForClassName:categoryClassName];
        XCTAssertEqualObjects(result, [TestClass class]);
    }
}

- (void)testClassNameForClassSymbol
{
    {
        NSString *nullClassSymbol = nil;
        NSString *result = [CocoaClassTool classNameForClassSymbol:nullClassSymbol];
        XCTAssertEqualObjects(result, nil);
    }
    {
        NSString *fakeClassSymbol = @"OBJC_CLASS_$_FakeClass";
        NSString *result = [CocoaClassTool classNameForClassSymbol:fakeClassSymbol];
        XCTAssertEqualObjects(result, nil);
    }
    {
        NSString *classSymbol = @"OBJC_CLASS_$_TestClass";
        NSString *result = [CocoaClassTool classNameForClassSymbol:classSymbol];
        XCTAssertEqualObjects(result, @"TestClass");
    }
    {
        NSString *categoryClassName = @"_OBJC_$_CATEGORY_TestClass_$_Category";
        NSString *result = [CocoaClassTool classNameForClassSymbol:categoryClassName];
        XCTAssertEqualObjects(result, @"TestClass(Category)");
    }
}

- (void)testMethodNameForImp
{
    {
        IMP nullImp = nil;
        NSString *result = [CocoaClassTool methodNameForImp:nullImp];
        XCTAssertEqualObjects(result, nil);
    }
    {
        SEL notHookedMethodSel = @selector(instanceFunction);
        IMP notHookedMethodImp = [TestClass instanceMethodForSelector:notHookedMethodSel];
        NSString *result = [CocoaClassTool methodNameForImp:notHookedMethodImp];
        XCTAssertEqualObjects(result, NSStringFromSelector(notHookedMethodSel));
    }
    {
        SEL hookedMethodSel = @selector(toHookInstanceFunction);
        IMP hookedMethodImp = [TestClass instanceMethodForSelector:hookedMethodSel];
        NSString *result = [CocoaClassTool methodNameForImp:hookedMethodImp];
        XCTAssertEqualObjects(result, NSStringFromSelector(@selector(hook_toHookInstanceFunction)));
    }
}

- (void)testClassNameForImp
{
    {
        IMP nullImp = nil;
        NSString *result = [CocoaClassTool methodNameForImp:nullImp];
        XCTAssertEqualObjects(result, nil);
    }
    {
        SEL instanceMethodSel = @selector(instanceFunction);
        IMP instanceMethodImp = [TestClass instanceMethodForSelector:instanceMethodSel];
        NSString *result = [CocoaClassTool classNameForImp:instanceMethodImp];
        XCTAssertEqualObjects(result, NSStringFromClass([TestClass class]));
    }
    {
        SEL categoryInstanceMethodSel = @selector(categoryInstanceFunction);
        IMP categoryInstanceMethodImp = [TestClass instanceMethodForSelector:categoryInstanceMethodSel];
        NSString *result = [CocoaClassTool classNameForImp:categoryInstanceMethodImp];
        XCTAssertEqualObjects(result, @"TestClass(Category)");
    }
}

- (void)testClassNameForCategoryClassName
{
    {
        NSString *nullClassName = nil;
        NSString *result = [CocoaClassTool classNameForCategoryClassName:nullClassName];
        XCTAssertEqualObjects(result, nil);
    }
    {
        NSString *normalClassName = @"TestClass";
        NSString *result = [CocoaClassTool classNameForCategoryClassName:normalClassName];
        XCTAssertEqualObjects(result, normalClassName);
    }
    {
        NSString *categoryClassName = @"TestClass(Category)";
        NSString *result = [CocoaClassTool classNameForCategoryClassName:categoryClassName];
        XCTAssertEqualObjects(result, @"TestClass");
    }
}

- (void)testSwizzleInstanceMethodWithSel
{
    {
        Class class = [TestClass class];
        SEL oldSel = @selector(instanceFunction);
        IMP oldImp = [class instanceMethodForSelector:oldSel];
        SEL swizzleSel = @selector(categoryInstanceFunction);
        IMP swizzleImp = [class instanceMethodForSelector:swizzleSel];
        [CocoaClassTool swizzleInstanceMethodWithSel:oldSel swizzleSel:swizzleSel forClass:class];
        
        XCTAssertEqual([class instanceMethodForSelector:oldSel], swizzleImp);
        XCTAssertEqual([class instanceMethodForSelector:swizzleSel], oldImp);
    }
}

@end
