//
//  NSBundle+CocoaHotReloadTests.m
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/20.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <XCTest/XCTest.h>
#import <UIKit/UINibLoading.h>
#import "TestClass.h"
#import "CocoaHotReload.h"
#import "CocoaHotReloadClientTool.h"

@interface NSBundle_CocoaHotReloadTests : XCTestCase

@end

@implementation NSBundle_CocoaHotReloadTests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
    [CocoaHotReloadClientTool clearDylibDirectory];
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testCocoaHotReload_loadNibNamed {
    NSBundle *mainBundle = [NSBundle bundleForClass:[TestClass class]];
    
    NSArray<UIView *> *bundles = [mainBundle loadNibNamed:@"TestXib" owner:nil options:nil];
    XCTAssertEqualObjects([bundles[0] backgroundColor], [UIColor darkGrayColor]);
    
    // 资源更新
    NSString *productsDir = [[mainBundle bundlePath] stringByAppendingPathComponent:@"Products"];
    [CocoaHotReload hotReloadWithDirectory:productsDir];
    
    bundles = [mainBundle loadNibNamed:@"TestXib" owner:nil options:nil];
    XCTAssertEqualObjects([bundles[0] backgroundColor], [UIColor blackColor]);
}

@end
