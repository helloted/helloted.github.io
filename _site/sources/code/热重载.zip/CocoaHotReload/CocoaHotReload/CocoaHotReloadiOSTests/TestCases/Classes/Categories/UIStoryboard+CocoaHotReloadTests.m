//
//  UIStoryboard+CocoaHotReloadTests.m
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/23.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "TestClass.h"
#import "CocoaHotReloadClientTool.h"
#import "CocoaHotReload.h"

@interface UIStoryboard_CocoaHotReloadTests : XCTestCase

@end

@implementation UIStoryboard_CocoaHotReloadTests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
    [CocoaHotReloadClientTool clearDylibDirectory];
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testCocoaHotReload_storyboardWithName
{
    NSBundle *mainBundle = [NSBundle bundleForClass:[TestClass class]];
    
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"TestStoryboard" bundle:mainBundle];
    UIViewController *viewController = [storyboard instantiateInitialViewController];
    XCTAssertEqualObjects([viewController.view backgroundColor], [UIColor whiteColor]);
    
    // 资源更新
    NSString *productsDir = [[mainBundle bundlePath] stringByAppendingPathComponent:@"Products"];
    [CocoaHotReload hotReloadWithDirectory:productsDir];
    storyboard = [UIStoryboard storyboardWithName:@"TestStoryboard" bundle:mainBundle];
    viewController = [storyboard instantiateInitialViewController];
    XCTAssertEqualObjects([viewController.view backgroundColor], [UIColor blackColor]);
}

@end
