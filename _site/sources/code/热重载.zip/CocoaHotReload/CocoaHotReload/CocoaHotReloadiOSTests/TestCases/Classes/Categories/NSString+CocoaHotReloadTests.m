//
//  NSString+CocoaHotReloadTests.m
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/4.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "NSString+CocoaHotReload.h"

@interface NSString_CocoaHotReloadTests : XCTestCase

@end

@implementation NSString_CocoaHotReloadTests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testCocoaHotReload_stringWithUTF8String {
    {
        char *nullCString = nil;
        NSString *result = [NSString cocoaHotReload_stringWithUTF8String:nullCString];
        XCTAssertEqualObjects(result, @"");
    }
    {
        char *nonnullCString = "c string";
        NSString *result = [NSString cocoaHotReload_stringWithUTF8String:nonnullCString];
        XCTAssertEqualObjects(result, @"c string");
    }
}

- (void)testCocoaHotReload_deviceNameWithModel
{
    {
        NSString *model = @"iPhone12,1";
        NSString *result = [NSString cocoaHotReload_deviceNameWithModel:model];
        XCTAssertEqualObjects(result, @"iPhone_11");
    }
    {
        NSString *model = @"x86_64";
        NSString *result = [NSString cocoaHotReload_deviceNameWithModel:model];
        XCTAssertEqualObjects(result, @"Simulator_x86_64");
    }
    {
        NSString *model = @"test";
        NSString *result = [NSString cocoaHotReload_deviceNameWithModel:model];
        XCTAssertEqualObjects(result, model);
    }
}

@end
