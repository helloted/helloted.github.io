//
//  TCPSocketTests.m
//  CocoaHotReloadiOSTests
//
//  Created by guoyanshi on 2020/11/6.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "CocoaSocket.h"
#import "TCPSocket.h"
#import "CHRProtocol.h"
@interface TCPSocketTests : XCTestCase
@property(nonatomic,strong)TCPSocket *tcpServer;
@end

@implementation TCPSocketTests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        //异步创建一个tcp服务器等待连接
        self.tcpServer = [TCPSocket runServerWithAddress:TCP_ADDRESS];
    });
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testConnectTCP {

    XCTestExpectation* exception = [self expectationWithDescription:@"ConnectTCP"];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_global_queue(0, 0), ^{
        
        TCPSocket *client = [TCPSocket connectToServer:@""];
        XCTAssertFalse(client.clientSocket > 0);        //连接失败
        
        //开始连接服务器
        client = [TCPSocket connectToServer:TCP_ADDRESS];
        XCTAssertTrue(client.clientSocket > 0);    //连接成功
        
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
           
            NSString *testSendStr = @"testSendStrtest";
            BOOL result = [client writeString:testSendStr];
            XCTAssertTrue(result);              //发送成功
            
            NSData *testData = [testSendStr dataUsingEncoding:NSUTF8StringEncoding];
            result = [client writeData:testData];
            XCTAssertTrue(result);               //发送成功
            
            int testTag = 10000;
            result = [client writeCommand:testTag withString:testSendStr];
            XCTAssertTrue(result);               //发送成功
            
            result = [client writeCommand:testTag withData:testData];
            XCTAssertTrue(result);               //发送成功
            
            NSDictionary *sendDict = @{testSendStr:testSendStr};
            dispatch_data_t payload = [sendDict createReferencingDispatchData];
            result = [client writeData:[NSData dataWithContentsOfDispatchData:payload]];
            XCTAssertTrue(result);   //发送成功
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_global_queue(0, 0), ^{

                NSString *readStr = [self.tcpServer readString];
                XCTAssertEqual([readStr isEqualToString:testSendStr], YES);    //接收成功
                
                NSData *readData = [self.tcpServer readData];
                NSString *readDataStr = [[NSString alloc] initWithData:readData encoding:NSUTF8StringEncoding];
                XCTAssertEqual([readDataStr isEqualToString:testSendStr], YES);    //接收成功
                
                int readTag = [self.tcpServer readInt];
                XCTAssertEqual(testTag == readTag, YES);
                readStr = [self.tcpServer readString];;
                XCTAssertEqual([readStr isEqualToString:testSendStr], YES);    //接收成功
                
                readTag = [self.tcpServer readInt];
                XCTAssertEqual(testTag == testTag, YES);
                readData = [self.tcpServer readData];;
                readStr = [[NSString alloc] initWithData:readData encoding:NSUTF8StringEncoding];
                XCTAssertEqual([readStr isEqualToString:testSendStr], YES);    //接收成功
                
                NSDictionary *readDict = [self.tcpServer readDictionary];
                XCTAssertEqual([readDict isEqualToDictionary:sendDict],YES);    //接收成功
                
                close(client.clientSocket);
                close(self.tcpServer.clientSocket);
                self.tcpServer = nil;
                [exception fulfill];
            });
        });
    });
    
    [self waitForExpectationsWithTimeout:3 handler:^(NSError * _Nullable error) {
          
    }];
}


@end
