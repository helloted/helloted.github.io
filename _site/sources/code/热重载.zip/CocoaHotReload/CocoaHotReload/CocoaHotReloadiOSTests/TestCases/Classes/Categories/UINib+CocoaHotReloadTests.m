//
//  UINib+CocoaHotReloadTests.m
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/23.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <XCTest/XCTest.h>
#import <UIKit/UINibLoading.h>
#import "TestClass.h"
#import "CocoaHotReload.h"
#import "CocoaHotReloadClientTool.h"
#import <UIKit/UINib.h>

@interface UINib_CocoaHotReloadTests : XCTestCase

@end

@implementation UINib_CocoaHotReloadTests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
    [CocoaHotReloadClientTool clearDylibDirectory];
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testCocoaHotReload_nibWithNibName {
    
    NSBundle *mainBundle = [NSBundle bundleForClass:[TestClass class]];
    
    UINib *nib = [UINib nibWithNibName:@"TestXib" bundle:mainBundle];
    NSArray<UIView *> *bundles = [nib instantiateWithOwner:nil options:nil];
    XCTAssertEqualObjects([bundles[0] backgroundColor], [UIColor darkGrayColor]);
    
    // 资源更新
    NSString *productsDir = [[mainBundle bundlePath] stringByAppendingPathComponent:@"Products"];
    [CocoaHotReload hotReloadWithDirectory:productsDir];
    
    nib = [UINib nibWithNibName:@"TestXib" bundle:mainBundle];
    bundles = [nib instantiateWithOwner:nil options:nil];
    XCTAssertEqualObjects([bundles[0] backgroundColor], [UIColor blackColor]);
}

@end
