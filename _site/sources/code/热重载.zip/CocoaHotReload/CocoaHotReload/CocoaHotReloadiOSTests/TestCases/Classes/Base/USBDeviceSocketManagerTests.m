//
//  USBDeviceSocketManagerTests.m
//  CocoaHotReloadiOSTests
//
//  Created by guoyanshi on 2020/11/4.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "USBDeviceSocketManager.h"

@interface USBDeviceSocketManagerTests : XCTestCase

@end

@implementation USBDeviceSocketManagerTests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
    [USBDeviceSocketManager shareInstance];
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testHasSocketConnectInfoWithDeviceID {
    XCTAssertEqual([[USBDeviceSocketManager shareInstance] hasSocketConnectInfoWithDeviceID:@(0)], false);
    XCTAssertEqual([[USBDeviceSocketManager shareInstance] hasSocketConnectInfoWithDeviceID:@(CGFLOAT_MIN)], false);
    XCTAssertEqual([[USBDeviceSocketManager shareInstance] hasSocketConnectInfoWithDeviceID:@(CGFLOAT_MAX)], false);
}

- (void)testAddSocketConnectInfo {
    NSNumber *testDeviceID = @(100);
    USBSocketConnectInfo *info = [USBSocketConnectInfo new];
    info.deviceID = testDeviceID;
    [[USBDeviceSocketManager shareInstance] addSocketConnectInfo:info];
    
    XCTAssertEqual([[USBDeviceSocketManager shareInstance] hasSocketConnectInfoWithDeviceID:testDeviceID], true);
    XCTAssertEqual([[USBDeviceSocketManager shareInstance] hasSocketConnectInfoWithDeviceID:@(CGFLOAT_MAX)], false);
}

- (void)testGetInfoWithDeviceID {
    NSNumber *testDeviceID = @(101);
    USBSocketConnectInfo *info = [USBSocketConnectInfo new];
    info.deviceID = testDeviceID;
    [[USBDeviceSocketManager shareInstance] addSocketConnectInfo:info];

    XCTAssertEqual([[USBDeviceSocketManager shareInstance] getInfoWithDeviceID:testDeviceID], info);
    XCTAssertEqual([[USBDeviceSocketManager shareInstance] getInfoWithDeviceID:@(CGFLOAT_MAX)], nil);
}

- (void)testRemoveInfoWithDeviceID {
    NSNumber *testDeviceID = @(102);
    USBSocketConnectInfo *info = [USBSocketConnectInfo new];
    info.deviceID = testDeviceID;
    [[USBDeviceSocketManager shareInstance] addSocketConnectInfo:info];
    
    [[USBDeviceSocketManager shareInstance] removeInfoWithDeviceID:testDeviceID];
    XCTAssertEqual([[USBDeviceSocketManager shareInstance] getInfoWithDeviceID:testDeviceID], nil);
    XCTAssertEqual([[USBDeviceSocketManager shareInstance] getInfoWithDeviceID:@(CGFLOAT_MAX)], nil);

}

- (void)testGetAllConnetingSocketInfos {
    NSNumber *testDeviceID = @(103);
    USBSocketConnectInfo *info = [USBSocketConnectInfo new];
    info.deviceID = testDeviceID;
    info.connectChannel = [CHRChannel new];
    [[USBDeviceSocketManager shareInstance] addSocketConnectInfo:info];
    
    XCTAssertEqual([[USBDeviceSocketManager shareInstance] getAllConnetingSocketInfos].count > 0, true);
}

- (void)testSelectUuid {
    NSString *testUuid = @"104";
    USBSocketConnectInfo *info = [USBSocketConnectInfo new];
    info.uuid = testUuid;
    info.targetModel = @"";
    info.connectChannel = [CHRChannel new];
    [[USBDeviceSocketManager shareInstance] addSocketConnectInfo:info];
    
    [[USBDeviceSocketManager shareInstance] selectDeviceUuid:testUuid notify:YES];
    XCTAssertEqual([[USBDeviceSocketManager shareInstance] getCurrentConnectingChannel], info.connectChannel);
}

@end
