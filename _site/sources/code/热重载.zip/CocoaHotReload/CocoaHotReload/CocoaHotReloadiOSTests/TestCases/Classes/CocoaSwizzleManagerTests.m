//
//  CocoaSwizzleManagerTests.m
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/24.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "CocoaSwizzleManager.h"
#import "HookTestClass+Category.h"
#import <dlfcn.h>
#import <mach-o/dyld.h>
#import <mach-o/ldsyms.h>
#import <objc/runtime.h>
#import "CocoaClassTool.h"

@interface CocoaSwizzleManagerTests : XCTestCase

@end

@implementation CocoaSwizzleManagerTests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

+ (void)setUp
{
    [HookTestClass hookFunctionsWhenAppDidLaunch];
    
    [CocoaClassTool updateCategoryMethodForClassIfNeed:[HookTestClass class] isForce:YES];
}

- (void)testHandleCycleInvokeForClassesIfNeed {
    
    [CocoaSwizzleManager hookSwizzleFuntion];
    [CocoaSwizzleManager disallowSwizzle];
    
    Class oldClass = [HookTestClass class];
    
    {
        Dl_info oldImpInfo;
        IMP oldImp = method_getImplementation(class_getInstanceMethod(oldClass, @selector(hook_toHookInstanceFunctionByMethod_exchangeImplementations)));
        dladdr(oldImp, &oldImpInfo);
        
        XCTAssertEqualObjects([NSString stringWithUTF8String:oldImpInfo.dli_sname], @"-[HookTestClass toHookInstanceFunctionByMethod_exchangeImplementations]");
        
        NSString *libPath = [[[NSBundle bundleForClass:oldClass] bundlePath] stringByAppendingFormat:@"/Products/CocoaHotReload_hookedCategory.dylib"];
        void *libHandle = dlopen(libPath.UTF8String, RTLD_NOW);
        XCTAssertNotEqual(libHandle, nil);
        
        Dl_info beforeHandleImpInfo;
        IMP beforeHandleImp = method_getImplementation(class_getInstanceMethod(oldClass, @selector(hook_toHookInstanceFunctionByMethod_exchangeImplementations)));
        dladdr(beforeHandleImp, &beforeHandleImpInfo);
        
        XCTAssertEqualObjects([NSString stringWithUTF8String:beforeHandleImpInfo.dli_sname], @"-[HookTestClass(Category) hook_toHookInstanceFunctionByMethod_exchangeImplementations]");
        
        [CocoaSwizzleManager handleCycleInvokeForClassesIfNeed:@[oldClass] dylibPath:libPath];
        
        Dl_info afterHandleImpInfo;
        IMP afterHandleImp = method_getImplementation(class_getInstanceMethod(oldClass, @selector(hook_toHookInstanceFunctionByMethod_exchangeImplementations)));
        dladdr(afterHandleImp, &afterHandleImpInfo);
        
        XCTAssertEqualObjects([NSString stringWithUTF8String:afterHandleImpInfo.dli_sname], @"-[HookTestClass toHookInstanceFunctionByMethod_exchangeImplementations]");
    }
    
//    {
//        Dl_info oldImpInfo;
//        IMP oldImp = method_getImplementation(class_getInstanceMethod(oldClass, @selector(hook_toHookInstanceFunctionByMethod_setImplementation)));
//        dladdr(oldImp, &oldImpInfo);
//
//        XCTAssertEqualObjects([NSString stringWithUTF8String:oldImpInfo.dli_sname], @"-[HookTestClass toHookInstanceFunctionByMethod_setImplementation]");
//        NSString *libPath = [[[NSBundle bundleForClass:oldClass] bundlePath] stringByAppendingFormat:@"/Products/CocoaHotReload_hookedCategory.dylib"];
//
//        void *libHandle = dlopen(libPath.UTF8String, RTLD_NOW);
//        XCTAssertNotEqual(libHandle, nil);
//
//        Dl_info beforeHandleImpInfo;
//        IMP beforeHandleImp = method_getImplementation(class_getInstanceMethod(oldClass, @selector(hook_toHookInstanceFunctionByMethod_setImplementation)));
//        dladdr(beforeHandleImp, &beforeHandleImpInfo);
//
//        XCTAssertEqualObjects([NSString stringWithUTF8String:beforeHandleImpInfo.dli_sname], @"-[HookTestClass(Category) hook_toHookInstanceFunctionByMethod_setImplementation]");
//
//        [CocoaSwizzleManager handleCycleInvokeForClassesIfNeed:@[oldClass] dylibPath:libPath];
//
//        Dl_info afterHandleImpInfo;
//        IMP afterHandleImp = method_getImplementation(class_getInstanceMethod(oldClass, @selector(hook_toHookInstanceFunctionByMethod_setImplementation)));
//        dladdr(afterHandleImp, &afterHandleImpInfo);
//
//        XCTAssertEqualObjects([NSString stringWithUTF8String:afterHandleImpInfo.dli_sname], @"-[HookTestClass toHookInstanceFunctionByMethod_setImplementation]");
//    }
    
    [CocoaSwizzleManager allowSwizzle];
}

@end
