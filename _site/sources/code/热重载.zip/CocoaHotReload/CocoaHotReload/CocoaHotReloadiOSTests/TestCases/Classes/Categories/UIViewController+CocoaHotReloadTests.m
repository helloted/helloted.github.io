//
//  UIViewController+CocoaHotReloadTests.m
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/23.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "TestClass.h"
#import "CocoaHotReloadClientTool.h"
#import "CocoaHotReload.h"

@interface UIViewController_CocoaHotReloadTests : XCTestCase

@end

@implementation UIViewController_CocoaHotReloadTests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
    [CocoaHotReloadClientTool clearDylibDirectory];
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testCocoaHotReload_initWithNibName {
    NSBundle *mainBundle = [NSBundle bundleForClass:[TestClass class]];

    UIViewController *viewController = [[UIViewController alloc] initWithNibName:@"TestViewController" bundle:mainBundle];
    XCTAssertEqualObjects([viewController.view backgroundColor], [UIColor darkGrayColor]);

    // 资源更新
    NSString *productsDir = [[mainBundle bundlePath] stringByAppendingPathComponent:@"Products"];
    [CocoaHotReload hotReloadWithDirectory:productsDir];

    viewController = [[UIViewController alloc] initWithNibName:@"TestViewController" bundle:mainBundle];
    XCTAssertEqualObjects([viewController.view backgroundColor], [UIColor blackColor]);
}

@end
