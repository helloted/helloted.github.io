//
//  CocoaHotReloadTests.m
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/24.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "CocoaHotReload.h"
#import "CmdTestClass.h"

@interface CocoaHotReloadTests : XCTestCase

@end

@implementation CocoaHotReloadTests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

//- (void)testCocoaHotReloadRun {
//    [CocoaHotReload run];
//
//    XCTAssertEqual([CocoaHotReload currentMode], CocoaHotReloadModeSocket);
//    XCTAssertEqual([CocoaHotReload currentScene], CocoaHotReloadSceneForTests);
//}

- (void)testSocketStatus
{
    XCTAssertEqual([CocoaHotReload socketStatus] , CocoaHotReloadClientStatusDisConnect);
    
    [CocoaHotReload setSocketStatus:CocoaHotReloadClientStatusConnected];
    XCTAssertEqual([CocoaHotReload socketStatus] , CocoaHotReloadClientStatusConnected);
}

- (void)testHotReloadQueue {
    XCTAssertNotEqual([CocoaHotReload hotReloadQueue], dispatch_get_main_queue());
}

- (void)testCurrentVersion
{
    NSArray *components = [[CocoaHotReload currentVersion] componentsSeparatedByString:@"."];
    
    XCTAssertEqual(components.count >= 3, YES);
}

//- (void)testHotReloadWithDirectory
//{
//    XCTAssertEqualObjects([CmdTestClass testString], @"test");
//
//    NSBundle *mainBundle = [NSBundle bundleForClass:[CmdTestClass class]];
//    // 资源更新
//    NSString *cmdProductsDir = [[mainBundle bundlePath] stringByAppendingPathComponent:@"Products/CocoaHotReloadCmd"];
//
//    [CocoaHotReload hotReloadWithDirectory:cmdProductsDir];
//    XCTAssertEqualObjects([CmdTestClass testString], @"test changed");
//}

@end
