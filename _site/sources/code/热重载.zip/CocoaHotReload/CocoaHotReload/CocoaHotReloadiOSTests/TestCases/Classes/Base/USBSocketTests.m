//
//  USBSocketTests.m
//  CocoaHotReloadiOSTests
//
//  Created by guoyanshi on 2020/11/10.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <XCTest/XCTest.h>
#import "USBSocket.h"
#import "CocoaSocket.h"
#import "CHRUSBHub.h"
#import "USBDeviceSocketManager.h"
#import "CHRChannel.h"

@interface USBSocket (UnitTest)
- (BOOL)ioFrameChannel:(CHRChannel*)channel shouldAcceptFrameOfType:(uint32_t)type tag:(uint32_t)tag payloadSize:(uint32_t)payloadSize;
- (void)ioFrameChannel:(CHRChannel *)channel didReceiveFrameOfType:(uint32_t)type tag:(uint32_t)tag payload:(CHRData *)payload;

@end

@interface CHRData (UnitTest)
- (id)initWithMappedDispatchData:(dispatch_data_t)mappedContiguousData data:(void*)data length:(size_t)length;
@end


@interface USBSocketTests : XCTestCase

@end

@implementation USBSocketTests

- (void)setUp {
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
}

- (void)testConnectToServer {
    USBSocket *client = [USBSocket new];
    [client connectToServerWithPort:USB_SOCKET_PORT];
    XCTestExpectation* exception = [self expectationWithDescription:@"ConnectUSB"];

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        XCTAssertTrue(client.serverChannel);
        [exception fulfill];
    });

    [self waitForExpectationsWithTimeout:0.3 handler:^(NSError * _Nullable error) {

    }];
}

- (void)testDeviceAttachNotify {
    USBSocket *server = [USBSocket new];
    [server runServerWithPort:USB_SOCKET_PORT];
    NSNumber *testDeviceID = @(111111);
    NSString *testUUID = @"1233456677";
    [[NSNotificationCenter defaultCenter] postNotificationName:CHRUSBDeviceDidAttachNotification
                                                        object:CHRUSBHub.sharedHub
                                                      userInfo:@{@"DeviceID":testDeviceID,
                                                                 @"Properties":@{
                                                                         @"UDID":testUUID}
                                                      }];

    XCTAssertTrue([[USBDeviceSocketManager shareInstance] hasSocketConnectInfoWithDeviceID:testDeviceID]);
    
    [[NSNotificationCenter defaultCenter] postNotificationName:CHRUSBDeviceDidDetachNotification
                                                        object:CHRUSBHub.sharedHub
                                                      userInfo:@{@"DeviceID":testDeviceID,
                                                                 @"Properties":@{
                                                                         @"UDID":testUUID}
                                                      }];
    XCTAssertFalse([[USBDeviceSocketManager shareInstance] hasSocketConnectInfoWithDeviceID:testDeviceID]);
    
}

- (void)testDeviceDidChangeNotify {
    
    XCTestExpectation* exception = [self expectationWithDescription:@"USBConnect"];

    NSNumber *testDeviceID = @(111111);
    NSString *testUuid = @"1111";
    USBSocketConnectInfo *info = [USBSocketConnectInfo new];
    info.deviceID = testDeviceID;
    info.uuid = testUuid;
    info.connectChannel = [CHRChannel new];
    [[USBDeviceSocketManager shareInstance] addSocketConnectInfo:info];
    [[USBDeviceSocketManager shareInstance] selectDeviceUuid:testUuid notify:NO];
    
    USBSocket *server = [USBSocket new];
    [server runServerWithPort:USB_SOCKET_PORT];
    server.didConnectBlock = ^(BOOL result) {
        XCTAssertTrue(result);
        [[USBDeviceSocketManager shareInstance] removeInfoWithDeviceID:testDeviceID];
        [exception fulfill];
    };

    [[NSNotificationCenter defaultCenter] postNotificationName:kChangeDeviceNotification object:nil];
    [self waitForExpectationsWithTimeout:0.5 handler:^(NSError * _Nullable error) {
          
    }];
}

- (void)testDidReceiveFrame {
    NSDictionary *testDict = @{@"test":@"test"};
    SocketCommand testCommand = SocketCommandClientInfo;
    NSDictionary *sendDict = @{kSocketReceiveCommandKey:@(testCommand),
                               kSocketReceiveValueKey:testDict
    };
    dispatch_data_t payload = [sendDict createReferencingDispatchData];
    CHRData *data = [[CHRData alloc] initWithMappedDispatchData:payload data:NULL length:0];
    
    USBSocket *socket = [USBSocket new];
    [socket runServerWithPort:USB_SOCKET_PORT];
    
    socket.didReciveCommandBlock = ^(int cmd, id  _Nonnull value) {
        if (cmd == PTFrameTypeDictionary) {
            XCTAssertEqual([testDict isEqualToDictionary:value], YES);
        }
        else if(cmd == PTFrameTypeData) {
            NSDictionary *receDict = [NSDictionary dictionaryWithContentsOfDispatchData:(dispatch_data_t)value];
            XCTAssertEqual([testDict isEqualToDictionary:receDict], YES);
        }
    };
    [socket ioFrameChannel:[CHRChannel new] didReceiveFrameOfType:PTFrameTypeDictionary tag:1 payload:data];
    [socket ioFrameChannel:[CHRChannel new] didReceiveFrameOfType:PTFrameTypeData tag:2 payload:data];
    [socket ioFrameChannel:[CHRChannel new] didReceiveFrameOfType:PTFrameTypePong tag:3 payload:data];
}

- (void)testShouldAcceptFrame {
    USBSocket *socket = [USBSocket new];
    XCTAssertFalse([socket ioFrameChannel:[CHRChannel new] shouldAcceptFrameOfType:-1 tag:0 payloadSize:0]);
    XCTAssertTrue([socket ioFrameChannel:[CHRChannel new] shouldAcceptFrameOfType:PTFrameTypeEndOfStream tag:0 payloadSize:0]);
    XCTAssertTrue([socket ioFrameChannel:[CHRChannel new] shouldAcceptFrameOfType:PTFrameTypeStart tag:0 payloadSize:0]);
}

@end
