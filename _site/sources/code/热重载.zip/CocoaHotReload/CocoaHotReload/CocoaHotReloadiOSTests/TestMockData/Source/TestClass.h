//
//  TestClass.h
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/6.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol TestProtocol <NSObject>

- (void)protocolInstanceFunction;

@end

NS_ASSUME_NONNULL_BEGIN

@interface TestClass : NSObject <TestProtocol> {
    NSString *_testString;
    int _toRemoveTestString;
}

@property (nonatomic, assign) int testInt;
@property (nonatomic, assign) int toRemoveTestInt;

- (void)instanceFunction;
+ (void)classFunction;

- (void)toHookInstanceFunction;
+ (void)toHookClassFunction;

- (void)toRemoveInstanceFunction;
+ (void)toRemoveClassFunction;

@end

NS_ASSUME_NONNULL_END
