//
//  HookTestClass+Category.h
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/24.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "HookTestClass.h"

NS_ASSUME_NONNULL_BEGIN

@interface HookTestClass (Category)

- (void)hook_toHookInstanceFunctionByMethod_exchangeImplementations;
- (void)hook_toHookInstanceFunctionByMethod_setImplementation;
- (void)hook_toHookInstanceFunctionByClass_replaceMethod;

+ (void)hookFunctionsWhenAppDidLaunch;

@end

NS_ASSUME_NONNULL_END
