//
//  HookTestClass+Category.m
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/24.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "HookTestClass+Category.h"
#import <objc/runtime.h>

@implementation HookTestClass (Category)

- (void)hook_toHookInstanceFunctionByMethod_exchangeImplementations
{
    
}

- (void)hook_toHookInstanceFunctionByMethod_setImplementation
{
    
}

- (void)hook_toHookInstanceFunctionByClass_replaceMethod
{
    
}

+ (void)hookFunctionsWhenAppDidLaunch
{
    Method oldInstanceMethod = class_getInstanceMethod(self, @selector(toHookInstanceFunctionByMethod_exchangeImplementations));
    Method swizzleInstanceMethod = class_getInstanceMethod(self, @selector(hook_toHookInstanceFunctionByMethod_exchangeImplementations));
    method_exchangeImplementations(oldInstanceMethod, swizzleInstanceMethod);
    
    Method oldHookBySetImpMethod = class_getInstanceMethod(self, @selector(toHookInstanceFunctionByMethod_setImplementation));
    IMP oldHookBySetImpMethodImp = method_getImplementation(oldHookBySetImpMethod);
    Method swizzleHookBySetImpMethod = class_getInstanceMethod(self, @selector(hook_toHookInstanceFunctionByMethod_setImplementation));
    IMP swizzleHookBySetImpMethodImp = method_getImplementation(swizzleHookBySetImpMethod);
    method_setImplementation(oldHookBySetImpMethod, swizzleHookBySetImpMethodImp);
    method_setImplementation(swizzleHookBySetImpMethod, oldHookBySetImpMethodImp);
    
    Method oldHookByReplaceMethod = class_getInstanceMethod(self, @selector(toHookInstanceFunctionByClass_replaceMethod));
    IMP oldHookByReplaceMethodImp = method_getImplementation(oldHookByReplaceMethod);
    Method swizzleHookByReplaceMethod  = class_getInstanceMethod(self, @selector(hook_toHookInstanceFunctionByClass_replaceMethod));
    IMP swizzleHookByReplaceImp = method_getImplementation(swizzleHookByReplaceMethod);
    class_replaceMethod(self, method_getName(oldHookByReplaceMethod), swizzleHookByReplaceImp, method_getTypeEncoding(oldHookByReplaceMethod));
    class_replaceMethod(self, method_getName(swizzleHookByReplaceMethod), oldHookByReplaceMethodImp, method_getTypeEncoding(swizzleHookByReplaceMethod));
}

@end
