#!/bin/sh

#  generate_dylib.sh
#  CocoaHotReload
#
#  Created by mambaxie on 2020/11/9.
#  Copyright © 2020 tencent. All rights reserved.

# $1 所要遍历的文件夹
# $2 匹配正则表达式
# $3 结果是否取反
function recomplie_files_command() {
    for file in `ls $1`
    do
        if [ -d $1"/"$file ]; # 判断是否是目录，是目录则递归
        then
            recomplie_files_command $1"/"$file
        elif [[ -f $1"/"$file ]] && [[ $file =~ \.(m|mm|swift|xib|storyboard|c|cpp)$ ]];
        then
            matched=0;
            if [[ $file =~ $2 ]];
            then
                matched=1;
            fi
            if [[ $3 == 1 ]];
            then
                if [[ $matched == 1 ]];
                then
                    matched=0;
                else
                    matched=1;
                fi
            fi
            if [[ $matched == 1 ]];
            then
                echo " -f $1"/"$file"
            fi
        fi
    done
}

cd `dirname $0`
CURRENT_DIR=$(pwd)
 
cd $CURRENT_DIR/../../../
PROJECT_DIR=$(pwd)

CMDTOOL_DERIVED_DATA_DIR=$PROJECT_DIR/CocoaHotReloadiOSTests/TestMockData/DerivedData/cmdTool
iOSTESTS_DERIVED_DATA_DIR=$PROJECT_DIR/CocoaHotReloadiOSTests/TestMockData/DerivedData/iOSTests
iOSTESTS_RESULT_BUNDLE_PATH=$iOSTESTS_DERIVED_DATA_DIR/build.xcresult

xcodebuild build -workspace CocoaHotReload.xcworkspace -configuration "Debug" -scheme "CocoaHotReload-cmdTool" -sdk "macosx" -derivedDataPath $CMDTOOL_DERIVED_DATA_DIR
rm -rf /usr/local/bin/cocoahotreload
cp $CMDTOOL_DERIVED_DATA_DIR/Build/Products/Debug/CocoaHotReload-cmdTool /usr/local/bin/cocoahotreload

cd $PROJECT_DIR
pod install --repo-update
rm -rf $iOSTESTS_RESULT_BUNDLE_PATH
xcodebuild build-for-testing -workspace CocoaHotReload.xcworkspace -configuration "Debug" -scheme "CocoaHotReloadiOSTests" -sdk "iphonesimulator" ARCHS="x86_64" VALID_ARCHS="x86_64" -derivedDataPath $iOSTESTS_DERIVED_DATA_DIR -resultBundlePath $iOSTESTS_RESULT_BUNDLE_PATH

INTERMEDIATES_DIR=$PROJECT_DIR/CocoaHotReloadiOSTests/TestMockData/Intermediates
PRODUCTS_DIR=$PROJECT_DIR/CocoaHotReloadiOSTests/TestMockData/Products

rm -rf $INTERMEDIATES_DIR
rm -rf $PRODUCTS_DIR
mkdir $PRODUCTS_DIR
mkdir $INTERMEDIATES_DIR

# TestClass类和分类
files=$(recomplie_files_command $CURRENT_DIR '^TestClass.*\.m$')
echo $files
cocoahotreload -p $PROJECT_DIR/CocoaHotReload.xcworkspace -d $iOSTESTS_DERIVED_DATA_DIR -e CocoaHotReloadiOSTests $files -n CocoaHotReload_all.dylib -o $INTERMEDIATES_DIR/CocoaHotReloadAll
cp $INTERMEDIATES_DIR/CocoaHotReloadAll/CocoaHotReload_all.dylib $PRODUCTS_DIR

# 只编译TestClass
files=$(recomplie_files_command $CURRENT_DIR '^TestClass\.m$')
cocoahotreload -p $PROJECT_DIR/CocoaHotReload.xcworkspace -d $iOSTESTS_DERIVED_DATA_DIR  -e CocoaHotReloadiOSTests $files -o $INTERMEDIATES_DIR/CocoaHotReloadClassOnly -n CocoaHotReload_class.dylib
cp $INTERMEDIATES_DIR/CocoaHotReloadClassOnly/CocoaHotReload_class.dylib $PRODUCTS_DIR

# 只编译TestClass+Category
files=$(recomplie_files_command $CURRENT_DIR '^TestClass\+Category\.m$')
cocoahotreload -p $PROJECT_DIR/CocoaHotReload.xcworkspace -d $iOSTESTS_DERIVED_DATA_DIR  -e CocoaHotReloadiOSTests $files -o $INTERMEDIATES_DIR/CocoaHotReloadCategoryOnly -n CocoaHotReload_category.dylib
cp $INTERMEDIATES_DIR/CocoaHotReloadCategoryOnly/CocoaHotReload_category.dylib $PRODUCTS_DIR

# 只编译Storyboard+xib
files=$(recomplie_files_command $CURRENT_DIR '.*(xib|storyboard)$')
echo $files
cocoahotreload -p $PROJECT_DIR/CocoaHotReload.xcworkspace -d $iOSTESTS_DERIVED_DATA_DIR  -e CocoaHotReloadiOSTests $files -o $INTERMEDIATES_DIR/CocoaHotReloadXibAndStoryboard
cp $INTERMEDIATES_DIR/CocoaHotReloadXibAndStoryboard/info.plist $PRODUCTS_DIR

# 只编译hooked categroy
files=$(recomplie_files_command $CURRENT_DIR '^HookTestClass\+Category\.m$')
cocoahotreload -p $PROJECT_DIR/CocoaHotReload.xcworkspace -d $iOSTESTS_DERIVED_DATA_DIR  -e CocoaHotReloadiOSTests $files -o $INTERMEDIATES_DIR/CocoaHotReloadHookedCategoryOnly -n CocoaHotReload_hookedCategory.dylib
cp $INTERMEDIATES_DIR/CocoaHotReloadHookedCategoryOnly/CocoaHotReload_hookedCategory.dylib $PRODUCTS_DIR

# 拷贝cmd产物
files=$(recomplie_files_command $CURRENT_DIR '.*(CmdTestClass\.m|CFunctionTest\.c)$')
cocoahotreload -p $PROJECT_DIR/CocoaHotReload.xcworkspace -d $iOSTESTS_DERIVED_DATA_DIR  -e CocoaHotReloadiOSTests $files -o $INTERMEDIATES_DIR/CocoaHotReloadCmd -n CocoaHotReload_cmd.dylib
cp -rf $INTERMEDIATES_DIR/CocoaHotReloadCmd $PRODUCTS_DIR

# 删除.o文件
cd $INTERMEDIATES_DIR
find . -name "*.o"  | xargs rm -f

cd $PRODUCTS_DIR
find . -name "*.o"  | xargs rm -f
