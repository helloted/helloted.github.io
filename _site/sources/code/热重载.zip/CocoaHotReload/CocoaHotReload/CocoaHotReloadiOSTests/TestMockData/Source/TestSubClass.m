//
//  TestSubClass.m
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/10.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "TestSubClass.h"

@implementation TestSubClass

@end
