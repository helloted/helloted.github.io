//
//  TestClass+Category.h
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/10.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "TestClass.h"

NS_ASSUME_NONNULL_BEGIN

@interface TestClass (Category)

- (void)categoryInstanceFunction;
+ (void)categoryClassFunction;

- (void)toRemoveCategoryInstanceFunction;
+ (void)toRemoveCategoryClassFunction;

- (void)hook_toHookInstanceFunction;
+ (void)hook_toHookClassFunction;

@end

NS_ASSUME_NONNULL_END
