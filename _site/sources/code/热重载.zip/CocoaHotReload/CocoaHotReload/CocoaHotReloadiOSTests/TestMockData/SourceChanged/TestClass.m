//
//  TestClass.m
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/6.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "TestClass.h"
#import <objc/runtime.h>

@implementation TestClass

- (void)instanceFunction {
    
}

+ (void)classFunction {
    
}

- (void)toHookInstanceFunction {
    
}

+ (void)toHookClassFunction {
    
}

//- (void)toRemoveInstanceFunction
//{
//    
//}
//
//+ (void)toRemoveClassFunction
//{
//    
//}

- (void)addInstanceFunction {
    
}

+ (void)addClassFunction {
    
}

- (void)toHookInstanceFunctionWhenAppDidLaunch
{
    
}

@end
