//
//  HookTestClass.h
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/24.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HookTestClass : NSObject

- (void)toHookInstanceFunctionByMethod_exchangeImplementations;
- (void)toHookInstanceFunctionByMethod_setImplementation;
- (void)toHookInstanceFunctionByClass_replaceMethod;

@end

NS_ASSUME_NONNULL_END
