//
//  HookTestClass.m
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/24.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "HookTestClass.h"

@implementation HookTestClass

- (void)toHookInstanceFunctionByMethod_exchangeImplementations
{
    
}

- (void)toHookInstanceFunctionByMethod_setImplementation
{
    
}

- (void)toHookInstanceFunctionByClass_replaceMethod
{
    
}

@end
