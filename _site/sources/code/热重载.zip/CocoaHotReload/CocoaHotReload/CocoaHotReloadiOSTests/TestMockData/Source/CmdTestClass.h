//
//  CmdTestClass.h
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/24.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CmdTestClass : NSObject

/// 返回 @"test"
+ (NSString *)testString;

@end

NS_ASSUME_NONNULL_END
