//
//  TestClass+Category.m
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/10.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "TestClass+Category.h"
#import <objc/runtime.h>

@implementation TestClass (Category)

+ (void)load
{
    Method oldInstanceMethod = class_getInstanceMethod(self, @selector(toHookInstanceFunction));
    Method swizzleInstanceMethod = class_getInstanceMethod(self, @selector(hook_toHookInstanceFunction));
    
    method_exchangeImplementations(oldInstanceMethod, swizzleInstanceMethod);
    
    Method oldClassMethod = class_getClassMethod(self, @selector(toHookClassFunction));
    Method swizzleClassMethod = class_getClassMethod(self, @selector(hook_toHookClassFunction));
    
    method_exchangeImplementations(oldClassMethod, swizzleClassMethod);
}

- (void)categoryInstanceFunction {
    
}

+ (void)categoryClassFunction {
    
}

- (void)hook_toHookInstanceFunction {
    
}

+ (void)hook_toHookClassFunction {
    
}

@end

