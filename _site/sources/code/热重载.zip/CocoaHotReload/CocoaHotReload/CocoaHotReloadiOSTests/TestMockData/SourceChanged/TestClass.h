//
//  TestClass.h
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/6.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol TestProtocol <NSObject>

- (void)protocolInstacneFunction;

@end

@protocol NewTestProtocol <NSObject>

- (void)newProtocolInstacneFunction;

@end

NS_ASSUME_NONNULL_BEGIN

@interface TestClass : NSObject <NewTestProtocol> {
    NSString *_testString;
//    NSString *_toRemoveTestString;
    NSString *_addTestString;
}

@property (nonatomic, assign) int testInt;
//@property (nonatomic, assign) int toRemoveTestInt;
@property (nonatomic, assign) int addTestInt;

- (void)instanceFunction;
+ (void)classFunction;

- (void)toHookInstanceFunction;
+ (void)toHookClassFunction;

//- (void)toRemoveInstanceFunction;
//+ (void)toRemoveClassFunction;

- (void)addInstanceFunction;
+ (void)addClassFunction;

- (void)toHookInstanceFunctionWhenAppDidLaunch;

@end

NS_ASSUME_NONNULL_END
