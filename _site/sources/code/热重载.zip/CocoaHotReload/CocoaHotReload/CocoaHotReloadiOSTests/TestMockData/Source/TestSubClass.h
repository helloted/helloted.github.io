//
//  TestSubClass.h
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/10.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "TestClass.h"

NS_ASSUME_NONNULL_BEGIN

@interface TestSubClass : TestClass

@end

NS_ASSUME_NONNULL_END
