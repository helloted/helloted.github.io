//
//  CFunctionTest.c
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/24.
//  Copyright © 2020 tencent. All rights reserved.
//

#include "CFunctionTest.h"

int testInt(void)
{
    return 0;
}
