//
//  CmdTestClass.m
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/24.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "CmdTestClass.h"

@implementation CmdTestClass

+ (NSString *)testString
{
    return @"test changed";
}

@end
