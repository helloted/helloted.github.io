//
//  CFunctionTest.h
//  CocoaHotReloadiOSTests
//
//  Created by mambaxie on 2020/11/24.
//  Copyright © 2020 tencent. All rights reserved.
//

#ifndef CFunctionTest_h
#define CFunctionTest_h

#include <stdio.h>

// return 0
int testInt(void);

#endif /* CFunctionTest_h */
