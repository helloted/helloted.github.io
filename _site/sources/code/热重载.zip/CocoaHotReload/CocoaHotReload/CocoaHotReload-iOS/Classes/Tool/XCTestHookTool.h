//
//  XCTestHookTool.h
//  CocoaHotReload-iOS
//
//  Created by mambaxie on 2020/10/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface XCTestHookTool : NSObject

/// hook XCTest 某些函数 当CocoaHotReloadScene 为 CocoaHotReloadSceneForTests 需要调用此函数
+ (void)hookXCTestFunctions;

@end

NS_ASSUME_NONNULL_END
