//
//  USBSocket.m
//  CocoaHotReload-iOS
//
//  Created by mambaxie on 2019/12/13.
//  Copyright © 2019 tencent. All rights reserved.
//

#if ! __has_feature(objc_arc)
#error This file must be compiled with ARC. Use -fobjc-arc flag (or convert project to ARC).
#endif

#import "USBSocket.h"
#import "CHRUSBHub.h"
#import "CHRChannel.h"
#import "CocoaSocket.h"
#import "CHRProtocol.h"
#import "USBDeviceSocketManager.h"
static const NSTimeInterval PTAppReconnectDelay = 2.0;

@interface USBSocket () <CHRChannelDelegate> {
    // If the remote connection is over USB transport...

    dispatch_queue_global_t notConnectedQueue_;
    BOOL notConnectedQueueSuspended_;
    CHRChannel *connectedChannel_;
    CHRChannel *serverChannel_;
    NSMutableDictionary *pings_;
    int _port;
    BOOL _isServer;
}

@property CHRChannel *connectedChannel;

@end

@implementation USBSocket

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)close
{
    [self.connectedChannel close];
    self.connectedChannel = nil;
}

- (void)runServerWithPort:(int)port
{
    _isServer = YES;
    [[NSNotificationCenter defaultCenter] removeObserver:self name:kChangeDeviceNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(deviceDidChange) name:kChangeDeviceNotification object:nil];
    [self close];
    
    _port = port;
    
    [self startListeningForDevices];
        
    [self ping];
}

- (void)deviceDidChange {
    self.connectedChannel = [[USBDeviceSocketManager shareInstance] getCurrentConnectingChannel];
    if (self.connectedChannel) {
        if (self.didConnectBlock) {
            self.didConnectBlock(YES);
        }
    }
}

- (void)disConnectDeviceWithName:(NSString *)name {
    NSLog(@"USBSocket: socket disconnect %@",self.connectedChannel.userInfo);
    [self.connectedChannel close];
    self.connectedChannel = nil;
    [[USBDeviceSocketManager shareInstance] selectDeviceUuid:nil notify:NO];
    if (self.didDisconnectBlock) {  //如果是当前连接断开
        NSError *error = [NSError errorWithDomain:@"cocoahotreload" code:-1 userInfo:@{@"deviceName":name ?: @""}];
        self.didDisconnectBlock(error);
    }
}


- (void)connectToServerWithPort:(int)port
{
    // Create a new channel that is listening on our IPv4 port
    CHRChannel *channel = [CHRChannel channelWithDelegate:self];
    _port = port;
    [channel listenOnPort:port IPv4Address:INADDR_LOOPBACK callback:^(NSError *error) {
        if (error) {
            self.error = error;
        } else {
            self->serverChannel_ = channel;
        }
    }];
}

- (void)sendCommand:(int)cmd value:(id)value
{
    NSMutableDictionary *info = [@{
        kSocketReceiveCommandKey : @(cmd),
    } mutableCopy];
    
    if (value) {
        info[kSocketReceiveValueKey] = value;
    }
    
    dispatch_data_t payload = [info createReferencingDispatchData];
    [self->connectedChannel_ sendFrameOfType:PTFrameTypeDictionary tag:PTFrameNoTag withPayload:payload callback:^(NSError *error) {
        if (error) {
            NSLog(@"Send PTFrameTypeDictionary fail : %@", error);
        }
    }];
}

/// 字符串
- (void)sendCommand:(int)cmd string:(NSString *__nullable)string
{
    [self sendCommand:cmd value:string];
}

- (void)sendCommand:(int)cmd dictionary:(NSDictionary *__nullable)dictionary
{
    [self sendCommand:cmd value:dictionary];
}

/// 二进制数据
- (void)sendCommand:(int)cmd data:(NSData *__nullable)data
{
    dispatch_data_t payload = [data createReferencingDispatchData];
    [self->connectedChannel_ sendFrameOfType:PTFrameTypeData tag:cmd withPayload:payload callback:^(NSError *error) {
        if (error) {
            NSLog(@"Send PTFrameTypeDictionary fail : %@", error);
        }
    }];
}

- (CHRChannel*)connectedChannel {
  return connectedChannel_;
}

- (CHRChannel *)clientChannel
{
    return connectedChannel_;
}

- (CHRChannel *)serverChannel
{
    return serverChannel_;
}

- (void)setConnectedChannel:(CHRChannel*)connectedChannel {
    connectedChannel_ = connectedChannel;
}

#pragma mark - Ping
- (void)pongWithTag:(uint32_t)tagno error:(NSError*)error {
    NSNumber *tag = [NSNumber numberWithUnsignedInt:tagno];
    NSMutableDictionary *pingInfo = [pings_ objectForKey:tag];
    if (pingInfo) {
    NSDate *now = [NSDate date];
    [pingInfo setObject:now forKey:@"date ended"];
    [pings_ removeObjectForKey:tag];
    NSLog(@"Ping total roundtrip time: %.3f ms", [now timeIntervalSinceDate:[pingInfo objectForKey:@"date created"]]*1000.0);
    }
}

- (void)ping {
    if (connectedChannel_) {
        if (!pings_) {
            pings_ = [NSMutableDictionary dictionary];
        }
        uint32_t tagno = [connectedChannel_.protocol newTag];
        NSNumber *tag = [NSNumber numberWithUnsignedInt:tagno];
        NSMutableDictionary *pingInfo = [NSMutableDictionary dictionaryWithObjectsAndKeys:[NSDate date], @"date created", nil];
        [pings_ setObject:pingInfo forKey:tag];
        [connectedChannel_ sendFrameOfType:PTFrameTypePing tag:tagno withPayload:nil callback:^(NSError *error) {
            [self performSelector:@selector(ping) withObject:nil afterDelay:1.0];
            [pingInfo setObject:[NSDate date] forKey:@"date sent"];
            if (error) {
                [self->pings_ removeObjectForKey:tag];
            }
        }];
    } else {
        [self performSelector:@selector(ping) withObject:nil afterDelay:1.0];
    }
}

#pragma mark - CHRChannelDelegate
- (BOOL)ioFrameChannel:(CHRChannel*)channel shouldAcceptFrameOfType:(uint32_t)type tag:(uint32_t)tag payloadSize:(uint32_t)payloadSize {
    if ((type < PTFrameTypeStart || type > PTFrameTypeEnd ) &&  type != PTFrameTypeEndOfStream) {
        NSLog(@"Unexpected frame of type %u", type);
        [channel close];
        return NO;
    } else {
        return YES;
    }
}

- (void)ioFrameChannel:(CHRChannel *)channel didReceiveFrameOfType:(uint32_t)type tag:(uint32_t)tag payload:(CHRData *)payload {
    
    id value;
    int cmd = 0;
    
    switch (type) {
        case PTFrameTypePong:
            [self pongWithTag:tag error:nil];
            break;
        case PTFrameTypeDictionary: {
            NSDictionary *info = [NSDictionary dictionaryWithContentsOfDispatchData:payload.dispatchData];

            value = info[kSocketReceiveValueKey];
            cmd = [info[kSocketReceiveCommandKey] intValue];
            if (_isServer && cmd == SocketCommandClientInfo) {
                USBSocketConnectInfo *info = [[USBDeviceSocketManager shareInstance] getInfoWithDeviceID:channel.userInfo];
                if (info && [value isKindOfClass:[NSDictionary class]]) {
                    info.targetName = value[@"deviceName"];
                    info.targetModel = value[@"deviceModel"];
                }
            }
            
            break;
        }
        case PTFrameTypeData:
        {
            cmd = tag;
            value = [NSData dataWithContentsOfDispatchData:payload.dispatchData];
        }
        default:
            break;
    }
    if (self.didReciveCommandBlock) {
        self.didReciveCommandBlock(cmd, value);
    }
}

// Invoked when the channel closed. If it closed because of an error, *error* is
// a non-nil NSError object.
- (void)ioFrameChannel:(CHRChannel*)channel didEndWithError:(NSError*)error {
    if (_isServer) {
        USBSocketConnectInfo *info = [[USBDeviceSocketManager shareInstance] getInfoWithDeviceID:channel.userInfo];
        if(info.connectChannel) { //异常断连
            if (self.connectedChannel == info.connectChannel) {
                info.connectChannel = nil;
                [self disConnectDeviceWithName:info.targetName];
            }else {
                info.connectChannel = nil;
            }
            [self enqueueConnectToUSBDevice:channel.userInfo]; //发起重试
            NSLog(@"USBSocket: sockect reconnecting %@, error = %@",channel.userInfo,error);
        }
        return;
    }

        /// client
    if (self.connectedChannel == channel) {
        self.connectedChannel = nil;
        if (self.didDisconnectBlock) {
            self.didDisconnectBlock(error);
        }
    }

}

// For listening channels, this method is invoked when a new connection has been
// accepted.
- (void)ioFrameChannel:(CHRChannel*)channel didAcceptConnection:(CHRChannel*)otherChannel fromAddress:(CHRAddress*)address {
    if (_isServer) {
        return;
    }
    if (otherChannel == connectedChannel_)
        return;
    // Cancel any other connection. We are FIFO, so the last connection
    // established will cancel any previous connection and "take its place".
    if (connectedChannel_) {
//        [connectedChannel_ cancel];
        return;
    }

    connectedChannel_ = otherChannel;
    connectedChannel_.userInfo = address;
    
    if (self.didConnectBlock) {
        self.didConnectBlock(YES);
    }
}

#pragma mark - Wired device connections
- (void)startListeningForDevices {

    if (!notConnectedQueue_) {
        notConnectedQueue_ = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    }
    
    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];
    __weak typeof(self) weakSelf = self;
    [nc addObserverForName:CHRUSBDeviceDidAttachNotification object:CHRUSBHub.sharedHub queue:nil usingBlock:^(NSNotification *note) {
        NSNumber *deviceID = [note.userInfo objectForKey:@"DeviceID"];
        NSString *uuid = [note.userInfo valueForKeyPath:@"Properties.UDID"];
        NSLog(@"CHRUSBDeviceDidAttachNotification: %@ \n uuid: %@", deviceID,uuid);

        if (deviceID && ![[USBDeviceSocketManager shareInstance] hasSocketConnectInfoWithDeviceID:deviceID]) {
            USBSocketConnectInfo *info = [USBSocketConnectInfo new];
            info.uuid = uuid;
            info.deviceID = deviceID;
            [[USBDeviceSocketManager shareInstance] addSocketConnectInfo:info];
            [weakSelf enqueueConnectToUSBDevice:deviceID];      //发起连接请求
        }
    }];

    [nc addObserverForName:CHRUSBDeviceDidDetachNotification object:CHRUSBHub.sharedHub queue:nil usingBlock:^(NSNotification *note) {
        NSNumber *deviceID = [note.userInfo objectForKey:@"DeviceID"];
        NSString *uuid = [note.userInfo valueForKeyPath:@"Properties.UDID"];
        NSLog(@"CHRUSBDeviceDidDetachNotification: %@ \n uuid: %@", deviceID,uuid);
        if (!deviceID) {
            return;
        }
       
        USBSocketConnectInfo *info = [[USBDeviceSocketManager shareInstance] removeInfoWithDeviceID:deviceID];
        [info.connectChannel close];
        if (weakSelf.connectedChannel == info.connectChannel) {
            info.connectChannel = nil;
            [weakSelf disConnectDeviceWithName:info.targetName];
        }
        else {
            info.connectChannel = nil;
        }
    }];
}

- (void)enqueueConnectToUSBDevice:(NSNumber *)deviceID{
    dispatch_async(notConnectedQueue_, ^{
        [self connectToUSBDevice:deviceID];
    });
}

/// server to client
- (void)connectToUSBDevice:(NSNumber *)deviceID {
    CHRChannel *channel = [CHRChannel channelWithDelegate:self];
    channel.userInfo = deviceID;
    channel.delegate = self;
    
    __weak typeof(self) weakSelf = self;
    [channel connectToPort:_port overUSBHub:CHRUSBHub.sharedHub deviceID:deviceID callback:^(NSError *error) {
        USBSocketConnectInfo *info = [[USBDeviceSocketManager shareInstance] getInfoWithDeviceID:deviceID];
        if (!info) { //已经断开链接
            [channel close];
            return;
        }
        
        if (error) {
         [weakSelf performSelector:@selector(enqueueConnectToUSBDevice:) withObject:deviceID afterDelay:PTAppReconnectDelay];

        } else {
            NSLog(@"USBSocket: sockect connected %@",channel.userInfo);
            
            info.connectChannel = channel;
            if (!weakSelf.connectedChannel) {
                weakSelf.connectedChannel = channel;
                [[USBDeviceSocketManager shareInstance] selectDeviceUuid:info.uuid notify:NO];
                if (weakSelf.didConnectBlock) {
                    weakSelf.didConnectBlock(YES);
                }
            }
        }
    }];
}

@end

