//
//  SocketCommandServerHandler.h
//  CocoaHotReload
//
//  Created by mambaxie on 2019/11/23.
//  Copyright © 2019 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SocketCommandClientHandler : NSObject

/// 单例
+ (instancetype)shareInstance;

/// 初始化
- (void)setup;

/// 默认从directory文件夹获取info.plist进行解析，hot reload日志写到directory目录下ClientHotReload.log，服务于CocoaHotRemoad-cmdTool工具产物
/// @param directory 热重载产物所在的文件夹路径
- (void)hotReloadWithDirectory:(NSString *)directory;


@end

NS_ASSUME_NONNULL_END
