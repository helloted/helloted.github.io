//
//  CocoaHotReloadClientTool.h
//  CocoaHotReloadDemo
//
//  Created by mambaxie on 2019/12/12.
//  Copyright © 2019 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CocoaHotReloadClientTool : NSObject

/// 生成动态库地址
+ (NSString *)generateDylibFilePath;

/// 动态库存储文件夹
+ (NSString *)getCocoaHotReloadTmpDirectoryPath;

/// 清除动态库
+ (void)clearDylibDirectory;

/// 获取客户端信息
+ (NSDictionary *)clientInfo;

/// 是否是模拟器
+ (BOOL)isSimulator;
        
/// 打印指定类型的日志
/// @param log 所要打印的日志
+ (void)printLog:(NSString *)log;

/// 设置日志输出文件地址
/// @param logFilePath 日志文件地址
+ (void)setLogFilePath:(NSString *)logFilePath;

/// bundle存储的文件夹
+ (NSString *)bundleDirForCocoaHotReloadAndCreateIfNeed;

/// 根据nib name获取对应的bundle，对应nib name的文件存在返回Bundle，否则返回nil。
/// @param nibName nib名字
+ (NSBundle *)bundleForHotReloadWithNibName:(NSString *)nibName;

/// 根据sotryboard name获取对应的bundle，对应sotryboard name的文件存在返回Bundle，否则返回nil。
/// @param storyboardName sotryboard名字
+ (NSBundle *)bundleForHotrloadWithStoryboardName:(NSString *)storyboardName;

@end

NS_ASSUME_NONNULL_END
