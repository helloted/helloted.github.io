//
//  NSString+CocoaHotReload.m
//  CocoaHotReload
//
//  Created by mambaxie on 2020/8/4.
//

#if ! __has_feature(objc_arc)
#error This file must be compiled with ARC. Use -fobjc-arc flag (or convert project to ARC).
#endif

#import "NSString+CocoaHotReload.h"

@implementation NSString (CocoaHotReload)

+ (NSString *)cocoaHotReload_stringWithUTF8String:(const char *)nullableCString
{
    if (!nullableCString || strlen(nullableCString) == 0) {
        return @"";
    }
    
    return [NSString stringWithUTF8String:nullableCString];
}

+ (NSString *)cocoaHotReload_deviceNameWithModel:(NSString *)model {

    NSDictionary *deviceNameDic = @{
        // iPhone
        @"iPhone1,1" : @"iPhone",
        @"iPhone1,2" : @"iPhone_3G",
        @"iPhone2,1" : @"iPhone_3GS",
        @"iPhone3,1" : @"iPhone_4",
        @"iPhone3,2" : @"iPhone_iPhone_4",
        @"iPhone3,3" : @"iPhone_4",
        @"iPhone4,1" : @"iPhone_4S",
        // iPhone_5 | iPhone_5S |  iPhone_5c
        @"iPhone5,1" : @"iPhone_5",
        @"iPhone5,2" : @"iPhone_5",
        @"iPhone5,3" : @"iPhone_5c",
        @"iPhone6,1" : @"iPhone_5S",
        @"iPhone6,2" : @"iPhone_5S",
        // iPhone_6 | iPhone_6P | iPhone_6S | iPhone_6SP
        @"iPhone7,1" : @"iPhone_6_Plus",
        @"iPhone7,2" : @"iPhone_6",
        @"iPhone8,1" : @"iPhone_6S",
        @"iPhone8,2" : @"iPhone_6S_Plus",
        // iPhone_SE
        @"iPhone8,3" : @"iPhone_SE",
        @"iPhone8,4" : @"iPhone_SE",
        // iPhone_7 | iPhone_7P
        @"iPhone9,1" : @"iPhone_7",
        @"iPhone9,2" : @"iPhone_7_Plus",
        @"iPhone9,3" : @"iPhone_7",
        @"iPhone9,4" : @"iPhone_7_Plus",
        // iPhone_8 | iPhone_8P
        @"iPhone10,1" : @"iPhone_8",
        @"iPhone10,4" : @"iPhone_8",
        @"iPhone10,2" : @"iPhone_8_Plus",
        @"iPhone10,5" : @"iPhone_8_Plus",
        // iPhone_X
        @"iPhone10,3" : @"iPhone_X",
        @"iPhone10,6" : @"iPhone_X",
        // iPhone_XR | iPhone_XS | iPhone_XS_Max
        @"iPhone11,8" : @"iPhone_XR",
        @"iPhone11,2" : @"iPhone_XS",
        @"iPhone11,4" : @"iPhone_XS_Max_China",
        @"iPhone11,6" : @"iPhone_XS_Max",
        // iPhone 11 | iPhone 11 Pro | iPhone 11 Pro Max
        @"iPhone12,1" : @"iPhone_11",
        @"iPhone12,3" : @"iPhone_11_Pro",
        @"iPhone12,5" : @"iPhone_11_Pro_Max",
        // 新版SE2
        @"iPhone12,8" : @"iPhone_SE_2",
        // iPhone 12 mini | iPhone 12 | iPhone 12 Pro | iPhone 12 Pro Max
        @"iPhone13,1" : @"iPhone_12_Mini",
        @"iPhone13,2" : @"iPhone_12",
        @"iPhone12,3" : @"iPhone_12_Pro",
        @"iPhone12,4" : @"iPhone_12_Pro_Max",
        // .....
        // iPod Touch
        @"iPod1,1" : @"iPod_Touch",
        @"iPod2,1" : @"iPod_Touch_2",
        @"iPod3,1" : @"iPod_Touch_3",
        @"iPod4,1" : @"iPod_Touch_4",
        @"iPod5,1" : @"iPod_Touch_5",
        @"iPod7,1" : @"iPod_Touch_6",
        // iPad
        @"iPad1,1" : @"iPad",
        @"iPad2,1" : @"iPad_2 (WiFi)",
        @"iPad2,2" : @"iPad_2 (GSM)",
        @"iPad2,3" : @"iPad_2 (CDMA)",
        @"iPad3,1" : @"iPad_2",
        @"iPad3,2" : @"iPad_3",
        @"iPad3,3" : @"iPad_3",
        @"iPad3,4" : @"iPad_4 (WiFi)",
        @"iPad3,5" : @"iPad_4",
        @"iPad3,6" : @"iPad_4",
        @"iPad6,11" : @"iPad_5",
        @"iPad6,12" : @"iPad_5",
        @"iPad7,5" : @"iPad_6",
        @"iPad7,6" : @"iPad_6",
        // iPad_Air
        @"iPad4,1" : @"iPad_Air",
        @"iPad4,2" : @"iPad_Air",
        @"iPad4,3" : @"iPad_Air",
        @"iPad5,3" : @"iPad_Air_2",
        @"iPad5,4" : @"iPad_Air_2",
        // iPad_mini
        @"iPad2,5" : @"iPad_mini",
        @"iPad2,6" : @"iPad_mini",
        @"iPad2,7" : @"iPad_mini",
        // iPad_mini 2
        @"iPad4,4" : @"iPad_mini_2",
        @"iPad4,5" : @"iPad_mini_2",
        @"iPad4,6" : @"iPad_mini_2",
        // iPad_mini 3
        @"iPad4,7" : @"iPad_mini_3",
        @"iPad4,8" : @"iPad_mini_3",
        @"iPad4,9" : @"iPad_mini_3",
        // iPad_mini 4
        @"iPad5,1" : @"iPad_mini_4",
        @"iPad5,2" : @"iPad_mini_4",
        // iPad_Pro(9.7)
        @"iPad6,3" : @"iPad_Pro(9.7)",
        @"iPad6,4" : @"iPad_Pro(9.7)",
        // iPad_Pro(10.5)
        @"iPad7,3" : @"iPad_Pro(10.5)",
        @"iPad7,4" : @"iPad_Pro(10.5)",
        // iPad_Pro(11)
        @"iPad8,1" : @"iPad_Pro(11)",
        @"iPad8,2" : @"iPad_Pro(11)",
        @"iPad8,3" : @"iPad_Pro(11)",
        @"iPad8,4" : @"iPad_Pro(11)",
        // iPad_Pro(12.9)
        @"iPad6,7" : @"iPad_Pro(12.9)",
        @"iPad6,8" : @"iPad_Pro(12.9)",
        // iPad_Pro(12.9)
        @"iPad7,1" : @"iPad_Pro_2(12.9)",
        @"iPad7,2" : @"iPad_Pro_2(12.9)",
        // iPad_Pro_3(12.9)
        @"iPad8,5" : @"iPad_Pro_3(12.9)",
        @"iPad8,6" : @"iPad_Pro_3(12.9)",
        @"iPad8,7" : @"iPad_Pro_3(12.9)",
        @"iPad8,8" : @"iPad_Pro_3(12.9)",
        // 模拟器
        @"i386" : @"Simulator_i386",
        @"x86_64" : @"Simulator_x86_64",
    };

    return deviceNameDic[model] ?: model;
}

@end
