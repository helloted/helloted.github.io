//
//  USBSocketManager.h
//  CocoaHotReload-iOS
//
//  Created by guoyanshi on 2020/8/5.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CHRChannel.h"


NS_ASSUME_NONNULL_BEGIN
extern NSString * const kChangeDeviceNotification;  //设备改变通知

@interface USBSocketConnectInfo: NSObject
@property(nonatomic,strong)NSNumber *deviceID;      //设备iD
@property(nonatomic,copy)NSString *uuid;            //设备uuid
@property(nonatomic,copy)NSString *targetName;      //设备名字
@property(nonatomic,copy)NSString *targetModel;     //设备型号
@property(nonatomic,strong,nullable) CHRChannel *connectChannel;


@end

@interface USBDeviceSocketManager : NSObject

+ (USBDeviceSocketManager *)shareInstance;

/// 当前设备USB是否插入连接
/// @param deviceID 设备ID
- (BOOL)hasSocketConnectInfoWithDeviceID:(NSNumber *)deviceID;

/// 增加插入USB接口的设备
/// @param info 设备信息
- (void)addSocketConnectInfo:(USBSocketConnectInfo *)info;

/// 移除设备
/// @param deviceID 设备ID
- (USBSocketConnectInfo *)removeInfoWithDeviceID:(NSNumber *)deviceID;
- (USBSocketConnectInfo *)getInfoWithDeviceID:(NSNumber *)deviceID;

/// 获取所有连接中的设备
- (NSArray *)getAllConnetingSocketInfos;

/// 获取当前连接中设备
- (CHRChannel *)getCurrentConnectingChannel;

/// 选择连接设备
/// @param uuid 设备uuid
/// @param notify 是否广播
- (void)selectDeviceUuid:(nullable NSString *)uuid notify:(BOOL)notify;
@end

NS_ASSUME_NONNULL_END
