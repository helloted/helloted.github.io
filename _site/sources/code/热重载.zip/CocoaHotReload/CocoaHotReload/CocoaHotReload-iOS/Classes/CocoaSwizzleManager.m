//
//  CocoaSwizzleManager.m
//  CocoaHotReload-iOS
//
//  Created by mambaxie on 2020/6/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#if ! __has_feature(objc_arc)
#error This file must be compiled with ARC. Use -fobjc-arc flag (or convert project to ARC).
#endif

#import "CocoaSwizzleManager.h"
#import <Objc/runtime.h>
#import "cocoahotreloadfishhook.h"
#import "CocoaClassTool.h"
#import <dlfcn.h>
#import <mach-o/dyld.h>
#import <mach-o/ldsyms.h>
#import "NSString+CocoaHotReload.h"
#import "CocoaHotReloadClientDefine.h"

// 是否允许sizzle
static BOOL gIsAllowSwizzle = YES;

@implementation CocoaSwizzleManager

static void (*origin_method_exchangeImplementations)(Method _Nonnull m1, Method _Nonnull m2);
static void cocoaHotReload_method_exchangeImplementations(Method _Nonnull m1, Method _Nonnull m2)
{
//    printf("origin_method_exchangeImplementations\n");
    if (gIsAllowSwizzle || !m1 || !m2) { // 调用原始函数
        origin_method_exchangeImplementations(m1, m2);
    } else {
        IMP imp1 = method_getImplementation(m1);
        IMP imp2 = method_getImplementation(m2);
        method_setImplementation(m1, imp2);
        method_setImplementation(m2, imp1);
    }
}

static IMP _Nonnull (*origin_method_setImplementation)(Method _Nonnull m, IMP _Nonnull imp);
static IMP _Nonnull cocoaHotReload_method_setImplementation(Method _Nonnull m, IMP _Nonnull imp)
{
//    printf("cocoaHotReload_method_setImplementation\n");
    IMP (^invokeOriginMehtod)(void) = ^IMP{
        IMP previousImp = origin_method_setImplementation(m, imp);
        return previousImp;
    };
    
    if (gIsAllowSwizzle || !m || !imp) { // 调用原始函数
        return invokeOriginMehtod();
    } else {
        BOOL isCategoryMethod = [CocoaClassTool isCategoryMethod:m];
        if (isCategoryMethod) { // 只处理分类
            CocoaClassImpInfo *impInfo = [CocoaClassTool impInfoForImp:method_getImplementation(m)];
            NSString *className = impInfo.className;
            // originClass 是dlopen以后的类 已更新了分类函数
            Class originClass = [CocoaClassTool orginClassForClassName:className];
            if (impInfo.isClassMethod) { // class method
                originClass = object_getClass(originClass);
            }
            IMP previousImp = method_getImplementation(m);
            BOOL replaceSuccess = [CocoaSwizzleManager replaceOriginHookWithClass:originClass swizzleMethod:m];
            if (replaceSuccess) {
                return previousImp;
            } else { // 替换失败执行原始函数
                return invokeOriginMehtod();
            }
        }
        // 不处理
        return method_getImplementation(m);
    }
}

/*
 * @note This function behaves in two different ways:
 *  - If the method identified by \e name does not yet exist, it is added as if \c class_addMethod were called.
 *    The type encoding specified by \e types is used as given.
 *  - If the method identified by \e name does exist, its \c IMP is replaced as if \c method_setImplementation were called.
 *    The type encoding specified by \e types is ignored.
 */
static IMP _Nullable (*origin_class_replaceMethod)(Class _Nullable cls, SEL _Nonnull name, IMP _Nonnull imp,
                    const char * _Nullable types);
static IMP _Nullable cocoaHotReload_class_replaceMethod(Class _Nullable cls, SEL _Nonnull name, IMP _Nonnull imp,
                    const char * _Nullable types)
{
    IMP (^invokeOriginMehtod)(void) = ^IMP{
        IMP previousImp = origin_class_replaceMethod(cls, name, imp, types);
        return previousImp;
    };
    
    if (gIsAllowSwizzle || !(cls && name && imp && types)) { // 调用原始函数
        return invokeOriginMehtod();
    } else {
        if (!class_getInstanceMethod(cls, name)) { // should add
            return invokeOriginMehtod();
        } else { // replace
            Method method = class_getInstanceMethod(cls, name);
            IMP previousImp = method_setImplementation(method, imp);
            
            return previousImp;
        }
    }
}
   
+ (void)hookSwizzleFuntion
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        cocoa_hot_reload_rebind_symbols((struct rebinding[3]) {
            {"method_exchangeImplementations", cocoaHotReload_method_exchangeImplementations, (void *)&origin_method_exchangeImplementations},
            {"method_setImplementation", cocoaHotReload_method_setImplementation, (void *)&origin_method_setImplementation},
            {"class_replaceMethod", cocoaHotReload_class_replaceMethod, (void *)&origin_class_replaceMethod}
         }, 3);
    });
}

+ (void)disallowSwizzle
{
    @synchronized (self) {
        gIsAllowSwizzle = NO;
    }
}

+ (void)allowSwizzle
{
    @synchronized (self) {
        gIsAllowSwizzle = YES;
    }
}

+ (void)handleCycleInvokeForClassesIfNeed:(NSArray<Class> *)classes dylibPath:(NSString *)dylibPath
{
    for (Class class in classes) { // 所有镜像
        [self handleCycleInvokeForClass:object_getClass(class) dylibPath:dylibPath];
        [self handleCycleInvokeForClass:class dylibPath:dylibPath];
    }
}

+ (void)handleCycleInvokeForClass:(Class)class dylibPath:(NSString *)dylibPath
{
    if (!class) {
        return;
    }
    
    unsigned int methodCount = 0;
    Method *methodCounts = class_copyMethodList(class, &methodCount);

    NSMutableDictionary<NSString *, NSValue *> *sholdHandleMethodMap = [NSMutableDictionary dictionary];
    
    void(^handleMehtodIfNeed)(Method, Method) = ^(Method previousMethod, Method method) {

        IMP previousImp = method_getImplementation(previousMethod);
        IMP imp = method_getImplementation(method);
        NSString *previousImpName = [CocoaClassTool methodNameForImp:previousImp];
        NSString *impName = [CocoaClassTool methodNameForImp:imp];
        if (![previousImpName isEqualToString:impName]) { // hook 有问题需要矫正
            cocoaHotReload_method_setImplementation(previousMethod, imp);
        }
    };
    
    for (int i = 0; i < methodCount; i++) {
        Method method = methodCounts[i];
        // 是否是被hook函数
        BOOL isHookMethod = [CocoaClassTool isCategoryInstanceMethodHookedWithMethod:method aClass:class];
        if (!isHookMethod) { // 死循环只处理hook的category函数
            continue;
        }
        // 如果imp是系统库 会返回nil
        CocoaClassImpInfo *impInfo = [CocoaClassTool impInfoForImp:method_getImplementation(method)];
        NSString *methodName = [NSString cocoaHotReload_stringWithUTF8String:sel_getName(method_getName(method))];
        
        if (impInfo.isClassMethod && [methodName isEqualToString:@"load"]) { // 忽略
            continue;
        }
        
        BOOL currentUnhooked = [impInfo.methodName isEqualToString:methodName];
        if (!currentUnhooked && ![sholdHandleMethodMap.allKeys containsObject:methodName]) { // hook函数已经被处理过了，因为如果hook是在load里面的 会自动处理
            continue;
        }

        BOOL isFromLastDylib = [[impInfo.imagePath lastPathComponent] isEqualToString:dylibPath.lastPathComponent];
   
        // 分类函数判断是在列表前面，一般如果遇到非分类函数了，就判定后续的不会再出现分类函数了，这里还有待观察是不是这个规则
        if (!isFromLastDylib && sholdHandleMethodMap.allKeys.count <= 0) {
            break;
        }
        
        if ([sholdHandleMethodMap.allKeys containsObject:methodName]) {
            Method previousMethod = [sholdHandleMethodMap[methodName] pointerValue];
            handleMehtodIfNeed(previousMethod, method);
            [sholdHandleMethodMap removeObjectForKey:methodName];
        } else {
            NSValue *methodValue = [NSValue valueWithPointer:method];
            if (methodValue && isFromLastDylib) {
                sholdHandleMethodMap[methodName] = methodValue;
            }
        }
    }

    free(methodCounts);
}

// 替换原生hook实现
+ (BOOL)replaceOriginHookWithClass:(Class)class swizzleMethod:(Method)swizzleMethod
{
    const char *methodName = sel_getName(method_getName(swizzleMethod));
    Method previousMethod = [CocoaSwizzleManager findMethodWhichImpForMethodName:methodName class:class];
    IMP swizzleImp = method_getImplementation(swizzleMethod);
    // swizzleImp -> method name -> origin method -> origin imp
    NSString *swizzleImpMethodName = [CocoaClassTool methodNameForImp:swizzleImp];
    Method originClassMethod = [self oldMethodForMethodName:swizzleImpMethodName.UTF8String class:class];
    IMP originImp = method_getImplementation(originClassMethod);
    
    if (previousMethod && swizzleImp && originImp) {
        // previous method -> swizzle imp
        origin_method_setImplementation(previousMethod, swizzleImp);
        // swizzle method -> origin imp
        origin_method_setImplementation(swizzleMethod, originImp);
        return YES;
    }
    
    return NO;
}

+ (Method)oldMethodForMethodName:(const char *)methodName class:(Class)class
{
    unsigned int methodCount = 0;
    Method *methodList = class_copyMethodList(class, &methodCount);
    
    Method targetMethod = NULL;
    for (int i = 0; i < methodCount; i++) {
        Method method = methodList[i];
        if (strcmp(methodName, sel_getName(method_getName(method))) == 0) {
            if (targetMethod) { // 上一个函数，因为分类函数会在第一个，老函数在第二个
                targetMethod = method;
                return targetMethod;
            } else {
                targetMethod = method;
            }
        }
    }
    free(methodList);
    
    return targetMethod;
}

// 查找原生hook链中指向method name的imp 对应的method
+ (Method)findMethodWhichImpForMethodName:(const char *)methodName class:(Class)class
{
    unsigned int methodCount = 0;
    Method *methodList = class_copyMethodList(class, &methodCount);
    // 查找倒数第二个(如果有)或者最新一个
    Method targetMethod = NULL;
    for (int i = 0; i < methodCount; i++) {
        Method method = methodList[i];
        IMP imp = method_getImplementation(method);
        if ([[NSString cocoaHotReload_stringWithUTF8String:methodName] isEqualToString:[CocoaClassTool methodNameForImp:imp]]) {
            if (targetMethod) { // 上一个函数，因为分类函数会在第一个，老函数在第二个
                targetMethod = method;
                return targetMethod;
            } else {
                targetMethod = method;
            }
        }
    }
    
    free(methodList);
    return targetMethod;
}

@end
