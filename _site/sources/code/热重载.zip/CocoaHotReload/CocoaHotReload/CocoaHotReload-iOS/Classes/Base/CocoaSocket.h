//
//  CocoaSocket.h
//  CocoaHotReload-iOS
//
//  Created by mambaxie on 2019/12/08.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#include <arpa/inet.h>

#define TCP_ADDRESS @":8999"
#define USB_SOCKET_PORT 8998

@class CHRChannel, TCPSocket, USBSocket;

static NSNotificationName _Nullable const SocketDidReceiveCommandNotification = @"SocketDidReceiveCommandNotification";
static NSString * _Nullable const kSocketReceiveCommandKey = @"kSocketReceiveCommandKey";
static NSString * _Nullable const kSocketReceiveValueKey = @"kSocketReceiveValueKey";

typedef NS_ENUM(int, SocketCommand) {
    SocketCommandNone, // 无
    
    /// command to client
    SocketCommandSentData, // 发送二进制文件
    SocketCommandReloadDylib, // 重新加载动态库
    
    /// command to server
    SocketCommandHotReload, // 开始热重载
    SocketCommandDidSelectProject, // 选择好项目文件
    /// command from client
    SocketCommandPrintNormalLog, // 输出日志
    SocketCommandPrintErrorLog, // 输出错误日志
    SocketCommandClientInfo, // 客户端信息
    SocketCommandReloadComplete, // reload结束
    /// command to client
    SocketCommandDidInitProject, // 项目初始化完成
    SocketCommandProjectSwiftSymbols, // 项目中Swift符号
    
    SocketCommandEOF = ~0
};

@interface CocoaSocket : NSObject

/// 模拟器通信：tcp socket
@property (nonatomic, strong) TCPSocket * _Nullable tcpSocket;

/// 真机通信：usb socket
@property (nonatomic, strong) USBSocket * _Nullable usbSocket;

/// 开启tcp服务器
/// @param address 服务器地址
+ (void)startTCPServer:(NSString *_Nullable)address;

/// 开启tcp服务器
/// @param address 服务器地址
/// @param completion 完成时回调
+ (void)startTCPServer:(NSString *_Nonnull)address completion:(void(^_Nullable)(CocoaSocket * _Nullable socket))completion;

/// 等待客户端连接tcp服务器
+ (void)waitToConnectTCPServer;

/// 连接tcp服务器
/// @param address 服务器地址
+ (instancetype _Nullable)connectToTCPServer:(NSString *_Nonnull)address;

/// 开启usb服务器
/// @param port 服务器端口
+ (void)startUSBServer:(int)port;

/// 开启usb服务器（server）
/// @param port 服务器端口
/// @param completion 完成时回调
+ (void)startUSBServer:(int)port completion:(void(^_Nullable)(CocoaSocket * _Nullable socket))completion;

/// （Client）连接usb服务器
/// @param port 服务器端口
/// @param completion 完成时回调
+ (void)connectToUSBServer:(int)port completion:(void(^_Nullable)(BOOL connected))completion;

/// 当前socket
+ (CocoaSocket *_Nullable)currentSocket;

/// 连接提示
+ (void)showConnectingTipForDevice:(BOOL)isDevice;

/// 运行
- (void)run;

/// 异步线程运行
- (void)runInBackground;

/// 是否是usb连接
- (BOOL)isUSBConnected;

/// 是否是tcp连接
- (BOOL)isTCPConnected;

/// 是否已连接
- (BOOL)isConnected;

/// 打印strerror
/// @param message 信息
+ (int)printStrerror:(NSString *_Nullable)message;

/// 发送SocketCommand指令
/// @param cmd SocketCommand指令
- (void)sendSocketCommand:(SocketCommand)cmd;

/// 发送cmd和json数据
/// @param cmd SocketCommand指令
/// @param dictionary json数据
- (void)sendSocketCommand:(SocketCommand)cmd dictionary:(NSDictionary * __nullable)dictionary;

/// 发送字符串数据
/// @param cmd SocketCommand指令
/// @param string 字符串数据
- (void)sendSocketCommand:(SocketCommand)cmd string:(NSString *__nullable)string;

/// 发送二进制数据
/// @param cmd SocketCommand指令
/// @param data 二进制数据
- (void)sendSocketCommand:(SocketCommand)cmd data:(NSData *__nullable)data;

/// 发送指令通知
/// @param cmd SocketCommand指令
/// @param value 附带的数据
- (void)postNotificationForSocketCommand:(SocketCommand)cmd value:(id __nullable)value;

/// 发送指令通知
/// @param cmd SocketCommand指令
- (void)postNotificationForSocketCommand:(SocketCommand)cmd;

@end
