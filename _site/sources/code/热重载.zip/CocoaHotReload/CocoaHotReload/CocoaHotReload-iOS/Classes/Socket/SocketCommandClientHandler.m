//
//  SocketCommandHandler.m
//  Cocoa Hot Reload
//
//  Created by mambaxie on 2019/11/23.
//  Copyright © 2019 tencent. All rights reserved.
//

#if ! __has_feature(objc_arc)
#error This file must be compiled with ARC. Use -fobjc-arc flag (or convert project to ARC).
#endif

#import "SocketCommandClientHandler.h"
#import "SocketClient.h"
#import <dlfcn.h>
#import <Objc/runtime.h>
#import "CocoaHotReloadClientDefine.h"
#import "CocoaHotReloadClientTool.h"
#import "CocoaClassTool.h"
#import "CocoaSwizzleManager.h"
#import "NSString+CocoaHotReload.h"
#import "CocoaHotReload.h"
#import "SwiftInjectTool.h"
#import "CocoaHotReloadDefine.h"
#import "DobbyTool.h"

@implementation SocketCommandClientHandler

+ (instancetype)shareInstance
{
    static dispatch_once_t onceToken;
    static SocketCommandClientHandler *handler;
    dispatch_once(&onceToken, ^{
        handler = [SocketCommandClientHandler new];
    });
    return handler;
}

- (void)setup
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didReceiveCommandNotification:) name:SocketDidReceiveCommandNotification object:nil];
}

- (void)didReceiveCommandNotification:(NSNotification *)notification
{
    if ([CocoaHotReload currentMode] == CocoaHotReloadModeHotReloadDylibOnly) {
        [self handleSocketCommandNotification:notification];
        return;
    }
    
    dispatch_async([CocoaHotReload hotReloadQueue], ^{
        [self handleSocketCommandNotification:notification];
    });
}

- (void)handleSocketCommandNotification:(NSNotification *)notification
{
    SocketCommand command = [notification.userInfo[kSocketReceiveCommandKey] intValue];
    id value = notification.userInfo[kSocketReceiveValueKey];
    switch (command) {
        case SocketCommandSentData: {
            
            NSMutableDictionary *info = [value[@"info"] mutableCopy];
            
            CocoaHotReloadMode currentMode = [CocoaHotReload currentMode];
            NSTimeInterval begin = [[NSDate date] timeIntervalSince1970];
            
            long long totalDataLength = 0;
            NSData *dylibData = value[@"data"];
            totalDataLength += dylibData.length;

            NSFileManager *fileManager = [NSFileManager defaultManager];
            NSDictionary<NSString *, NSData *> *storyboardOrXibInfo = info[@"storyboardOrXibInfo"];
            NSString *tmpDir = [CocoaHotReloadClientTool getCocoaHotReloadTmpDirectoryPath];
            if (![fileManager fileExistsAtPath:tmpDir]) {
                NSError *error;
                [fileManager createDirectoryAtPath:tmpDir withIntermediateDirectories:NO attributes:nil error:&error];
                if (error) {
                    ErrorLog(@"Create dir failed: %@", [error localizedDescription]);
                    return;
                }
            }
            
            NSString *bundleDir = [CocoaHotReloadClientTool bundleDirForCocoaHotReloadAndCreateIfNeed];
            
            for (NSString *storyboardOrXibFileName in storyboardOrXibInfo.allKeys) {
                NSString *dirPath = [bundleDir stringByAppendingPathComponent:[storyboardOrXibFileName stringByReplacingOccurrencesOfString:@"." withString:@"_"]];
                if ([fileManager fileExistsAtPath:dirPath]) {
                    [fileManager removeItemAtPath:dirPath error:nil];
                }
                
                [fileManager createDirectoryAtPath:dirPath withIntermediateDirectories:NO attributes:nil error:nil];
                
                NSString *filePath = [dirPath stringByAppendingPathComponent:storyboardOrXibFileName];
                
                id value = [storyboardOrXibInfo valueForKey:storyboardOrXibFileName];
                if ([value isKindOfClass:NSDictionary.class]) {
                    [fileManager createDirectoryAtPath:filePath withIntermediateDirectories:NO attributes:nil error:nil];
                    for (NSString *fileName in [value allKeys]) {
                        NSData *data = value[fileName];
                        [fileManager createFileAtPath:[filePath stringByAppendingPathComponent:fileName] contents:data attributes:nil];
                        totalDataLength += data.length;
                    }
                } else if ([value isKindOfClass:NSData.class]) {
                    [fileManager createFileAtPath:filePath contents:value attributes:nil];
                    totalDataLength += ((NSData *)value).length;
                }
            }
            
            HRLog(@"Did received data(%.2fkb) ", totalDataLength / 1024.0);
            if (dylibData.length > 0) {
                // 获取Documents目录路径
                NSString *dylibPath = [CocoaHotReloadClientTool generateDylibFilePath];
                [fileManager createFileAtPath:dylibPath contents:dylibData attributes:nil];
                info[@"dylibFilePath"] = dylibPath;
                [self reloadDylibWithInfo:info];
            } else {
                NSTimeInterval startTimeInterval = [info[@"startTimeInterval"] doubleValue];
                NSTimeInterval duration = [[NSDate date] timeIntervalSince1970] - (currentMode == CocoaHotReloadModeSocket ? startTimeInterval : begin);
                NSString *msg = [NSString stringWithFormat:@"🎉 Hot reload success %lu files.", storyboardOrXibInfo.allKeys.count];
                msg = [msg stringByAppendingFormat:@" %.2f seconds", duration];

                if (currentMode == CocoaHotReloadModeSocket) {
                    [[SocketClient currentClient] sendSocketCommand:SocketCommandReloadComplete dictionary:@{@"msg" : msg, @"ret" : @(0)}];
                } else {
                    HRLog(@"%@", msg);
                }
            }
            
            break;
        }
        case SocketCommandReloadDylib: {
            [self reloadDylibWithInfo:value];
            break;
        }
        
        case SocketCommandDidInitProject: {
            if ([CocoaHotReload currentScene] == CocoaHotReloadSceneForTests) {
                [CocoaHotReload actionWhenHotReloadDidComplete];
            }
            break;
        }
            
        case SocketCommandProjectSwiftSymbols: {
            NSArray *swiftSymbols = value[@"projectSwiftSymbols"];
            if ([swiftSymbols isKindOfClass:[NSArray class]] && swiftSymbols.count > 0) {
                [SwiftInjectTool handleSwiftSymbols:swiftSymbols];
            }
            break;
        }
            
        default:
            break;
    }
}

- (void)hotReloadWithDirectory:(NSString *)directory
{
    [CocoaHotReloadClientTool setLogFilePath:[directory stringByAppendingPathComponent:@"ClientHotReload.log"]];
    
    NSDictionary *dylibInfo = [NSDictionary dictionaryWithContentsOfFile:[directory stringByAppendingPathComponent:@"info.plist"]];
    if (!dylibInfo) {
        ErrorLog(@"info.plist file does not exist in %@ directory!", directory);
        return;
    }
    
    NSMutableDictionary *swiftSymbolsUserInfoM = [NSMutableDictionary dictionary];
    swiftSymbolsUserInfoM[kSocketReceiveCommandKey] = @(SocketCommandProjectSwiftSymbols);
    NSMutableDictionary *swiftSymbolsValueInfoM = [NSMutableDictionary dictionary];
    swiftSymbolsValueInfoM[@"projectSwiftSymbols"] = dylibInfo[@"projectSwiftSymbols"] ?: @[];
    swiftSymbolsUserInfoM[kSocketReceiveValueKey] = [swiftSymbolsValueInfoM copy];
    
    // handle swift symbols
    [[NSNotificationCenter defaultCenter] postNotificationName:SocketDidReceiveCommandNotification object:nil userInfo:swiftSymbolsUserInfoM];
    
    NSMutableDictionary *userInfoM = [NSMutableDictionary dictionary];
    userInfoM[kSocketReceiveCommandKey] = @(SocketCommandSentData);
    
    NSData *dylibData = [NSData dataWithContentsOfFile:dylibInfo[@"dylibFilePath"]];
    NSMutableDictionary *valueInfoM = [NSMutableDictionary dictionary];
    valueInfoM[@"info"] = dylibInfo;
    valueInfoM[@"data"] = dylibData;
    userInfoM[kSocketReceiveValueKey] = [valueInfoM copy];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:SocketDidReceiveCommandNotification object:nil userInfo:[userInfoM copy]];
}

- (void)reloadDylibWithInfo:(NSDictionary *)info
{
    CocoaHotReloadMode currentMode = [CocoaHotReload currentMode];
    NSTimeInterval begin = [[NSDate date] timeIntervalSince1970];
    
    HRLog(@"Loading dylib...");
    /// 打开动态库
    NSString *dylibFilePath = info[@"dylibFilePath"];
    NSArray *compileSucceedFileNames = info[@"compileSucceedFileNames"];
    NSArray *compileFailedFileNames = info[@"compileFailedFileNames"];
    NSArray *compileTimeOutFileNames = info[@"compileTimeOutFileNames"];
    NSArray *classNames = info[@"classNames"]; // 兼容旧版本 mac端0.1.5及之前版本使用classNames
    NSArray *classSymbols = info[@"classSymbols"]; // 兼容swift mac端0.1.6后使用classSymbols
    NSArray *allCategoryClassNames = info[@"allCategoryClassNames"];
    NSArray *oFileCategoryClassNames = info[@"oFileCategoryClassNames"];
    NSArray *cFunctionNames = info[@"cFuntionNames"];
    NSTimeInterval startTimeInterval = [info[@"startTimeInterval"] doubleValue];
    NSArray *ignoreClassMethodNames = info[@"ignoreClassMethodNames"];
    NSArray *swiftStaticFunctionNames = info[@"swiftStaticFunctionNames"];
    // RTLD_LAZY : resolve undefined symbols as code from the dynamic library is executed
    // RTLD_NOW : resolve all undefined symbols before dlopen() returns and fail if this cannot be done
    HRLog(@"dlopen dylib by RTLD_NOW");
    
    if (allCategoryClassNames.count > 0) {
        [CocoaClassTool updateCategoryMethodForClassNames:allCategoryClassNames];
    }
    
    NSMutableSet *needSyncClassNamesSet = [NSMutableSet set];
    for (NSString *categoryClassName in oFileCategoryClassNames) {
        NSString *className = [CocoaClassTool classNameForCategoryClassName:categoryClassName];
        [needSyncClassNamesSet addObject:className];
    }
    
    // 开始hook sizzle
    [CocoaSwizzleManager hookSwizzleFuntion];
    
    // dlopen 前禁止swizzle，内部处理hook链，保证不会出现死循环
    [CocoaSwizzleManager disallowSwizzle];
    void *libHandle = dlopen([dylibFilePath cStringUsingEncoding:NSUTF8StringEncoding], RTLD_NOW);
    
    if (libHandle == NULL) {
        // dlopen 后开启sizzle
        [CocoaSwizzleManager allowSwizzle];
        
        char *error = dlerror();
        // 真机iOS13以下会报错
        NSString *tips = @"";
        if ([[NSString cocoaHotReload_stringWithUTF8String:error] containsString:@"file system sandbox blocked mmamp()"]) {
            tips = @"目前真机调试只支持系统iOS 13+，请检查系统版本. ";
        }
        NSString *msg = [NSString stringWithFormat:@"dlopen error: %@ %s file path: %@ ", tips, error?:"", dylibFilePath];
        if (currentMode == CocoaHotReloadModeSocket) {
            [[SocketClient currentClient] sendSocketCommand:SocketCommandReloadComplete dictionary:@{@"msg" : msg, @"ret" : @(CocoaHotReloadCodeErrorDlopenError)}];
        } else {
            ErrorLog(@"%@", msg);
        }
        
        return;
    }
    // dlopen success
    if (allCategoryClassNames.count > 0) {

        HRLog(@"🚧 Handling cycle invoke...");
        
        NSTimeInterval handleBegin = [[NSDate date] timeIntervalSince1970];
        NSMutableSet *needHandleCycleInvokeClassSet = [NSMutableSet set];
        for (NSString *categoryClassName in allCategoryClassNames) {
            NSString *className = [CocoaClassTool classNameForCategoryClassName:categoryClassName];
            Class oldClass = NSClassFromString(className);
            Dl_info info;
            int result = dladdr((__bridge const void *)(oldClass), &info);
            if (result == 0) {
               continue;
            }
            const char *sym = info.dli_sname;
            id newSym = (__bridge id)(dlsym(libHandle, sym));
            Class newClass = [newSym class];
            
            // origin class
            Class originClass = [CocoaClassTool orginClassForClassName:className];
            // 当dylib中分类和类同时存在，分类的函数会添加到dylib的类中，所以这里要将category 添加到origin class
            if ([classNames containsObject:className] && newClass) { // 修改的文件与category同一个类
                [CocoaClassTool addCategoryClassInfoToNewClass:originClass originClass:newClass];
            } else { // 需要处理循环调用
                [needHandleCycleInvokeClassSet addObject:originClass];
            }
        }
        // 处理循环调用
        [CocoaSwizzleManager handleCycleInvokeForClassesIfNeed:needHandleCycleInvokeClassSet.allObjects dylibPath:dylibFilePath];

        NSTimeInterval handleEnd = [[NSDate date] timeIntervalSince1970];
        HRLog(@"👏 Handle cycle invoke success! %.2f seconds", handleEnd - handleBegin);
    }
    // dlopen 后开启sizzle
    [CocoaSwizzleManager allowSwizzle];
    
    printf("【CocoaHotReload】 Loaded .dylib - Ignore any duplicate class warning ^\n");
    
    // 以class name 为key class symbol 为value
    NSMutableDictionary *classSymbolsDicM = [NSMutableDictionary dictionary];
    // 这里是因为Swift类通过符号判断不出来，需要通过镜像取出类名
    if (classSymbols.count > 0) {
        NSMutableArray *classNamesM = [NSMutableArray array];
        for (NSString *classSymbol in classSymbols) {
            id class = (__bridge id)(dlsym(libHandle, classSymbol.UTF8String));
            NSString *className = NSStringFromClass(class);
            if (className) {
                [classNamesM addObject:className];
                classSymbolsDicM[className] = classSymbol;
            }
        }
        // 新版本优先级更高
        classNames = [classNamesM copy];
    }
    
    NSMutableSet *reloadFailedClassNameSetM = [NSMutableSet set];
    
    /// 类替换
    void (^replaceClassWithClassName)(NSString *className) = ^(NSString *classNameString) {
        Class oldClass = NSClassFromString(classNameString);
        NSString *classSymbol = classSymbolsDicM[classNameString];
        if (!classSymbol) {
            return;
        }
        const char *sym = classSymbol.UTF8String;
        id newSym = (__bridge id)(dlsym(libHandle, sym));
        Class newClass = [newSym class];
        if (newClass && libHandle && sym) {
            // symbol以OBJC_CLASS_$开头为继承Swift的类，用OC来替换处理
            BOOL isSwiftClass = [classNameString containsString:@"."];
            if (isSwiftClass) {
                if ([SwiftInjectTool isSwiftClass:oldClass newClass:newClass]) {
                    // replace swift class
                    [SwiftInjectTool updateAllShouldBeReplaceClassWithNewClass:newClass
                                                                   dylibHandle:libHandle
                                                                     className:classNameString];
                } else {
                    [reloadFailedClassNameSetM addObject:classNameString];
                    ErrorLog(@"Swift类替换失败，请确认工程是否引入SwiftHotReloadTool.framework");
                }
            }
            
            // replace class (Swift or ObjC)
            [CocoaClassTool updateAllShouldBeReplaceClassWithNewClass:newClass
                                                          dylibHandle:libHandle
                                                             classSym:sym
                                               ignoreClassMethodNames:ignoreClassMethodNames];
        }
    };
  
    if (cFunctionNames.count > 0) {
        NSTimeInterval replaceCFunctionBegin = [[NSDate date] timeIntervalSince1970];
        HRLog(@"🚧 Replacing c funtions...");
        [DobbyTool replaceFunctionImplementationWithLibHandle:libHandle functionSymbols:   cFunctionNames];
        NSTimeInterval replaceCFunctionEnd = [[NSDate date] timeIntervalSince1970];
        HRLog(@"👏 Replace c functions success! %.2f seconds", replaceCFunctionEnd - replaceCFunctionBegin);
    }
    
    if (swiftStaticFunctionNames.count > 0) { // 替换Swift直接派发的函数
        [DobbyTool replaceFunctionImplementationWithLibHandle:libHandle functionSymbols:   swiftStaticFunctionNames];
    }
    
    NSInteger classNamesCount = oFileCategoryClassNames.count + classNames.count;
    
    BOOL shouldReplaceClass = classNamesCount > 0;

    NSTimeInterval replaceClassesBegin = [[NSDate date] timeIntervalSince1970];
    if (shouldReplaceClass) {
        HRLog(@"🚧 Replacing classes...");
    }
    
    // 同步类信息，当添加分类后需要同步下类信息
    if (needSyncClassNamesSet.count > 0) {
        [CocoaClassTool synchronizeOrginClassToAllClassWithClassNames:needSyncClassNamesSet.allObjects
                                                      oFileClassNames:classNames
                                                      ignoreLibHandle:libHandle];
    }
    
    // 替换类
    for (NSString *className in classNames) {
        replaceClassWithClassName(className);
    }
    
    if (shouldReplaceClass) {
        NSTimeInterval replaceClassesEnd = [[NSDate date] timeIntervalSince1970];
        if (reloadFailedClassNameSetM.count == 0) {
            HRLog(@"👏 Replace classes success! %.2f seconds", replaceClassesEnd - replaceClassesBegin);
        }
    }
    
    NSString *msg = [NSString stringWithFormat:@"🎉 Hot reload success %lu files, %ld classes, %ld c functions!", (unsigned long)compileSucceedFileNames.count, (long)classNamesCount, (long)cFunctionNames.count];
    int ret = CocoaHotReloadCodeSuccess;
    if (classNamesCount <= 0 && cFunctionNames.count <= 0) {
        msg = [NSString stringWithFormat:@"Hot reload fail %lu files, no classes, no c functions!", (unsigned long)compileSucceedFileNames.count];
        ret = CocoaHotReloadCodeErrorUnknow;
    }
    if (reloadFailedClassNameSetM.count > 0) {
        msg = [NSString stringWithFormat:@"Hot reload fail, %zd classes : %@", reloadFailedClassNameSetM.count, [reloadFailedClassNameSetM.allObjects componentsJoinedByString:@"、"]];
        ret = CocoaHotReloadCodeErrorCompileFailed;
    }
    if (compileFailedFileNames.count > 0) {
        msg = [msg stringByAppendingString:[NSString stringWithFormat:@"\n ❌ Compile fail count %lu : %@", (unsigned long)compileFailedFileNames.count, [compileFailedFileNames componentsJoinedByString:@"、"]]];
        ret = CocoaHotReloadCodeErrorCompileFailed;
    }
    if (compileTimeOutFileNames.count > 0) {
        msg = [msg stringByAppendingString:[NSString stringWithFormat:@"\n ⏰ Compile time out count %lu : %@", (unsigned long)compileTimeOutFileNames.count, [compileTimeOutFileNames componentsJoinedByString:@"、"]]];
        ret = CocoaHotReloadCodeErrorCompileFailed;
    }
    
    NSTimeInterval duration = [[NSDate date] timeIntervalSince1970] - (currentMode == CocoaHotReloadModeSocket ? startTimeInterval : begin);
    msg = [msg stringByAppendingFormat:@" %.2f seconds", duration];

    if (currentMode == CocoaHotReloadModeSocket) {
        [[SocketClient currentClient] sendSocketCommand:SocketCommandReloadComplete dictionary:@{@"msg" : msg, @"ret" : @(ret)}];
    } else {
        HRLog(@"%@", msg);
    }
}

@end
