//
//  CocoaHotReloadServerDefine.h
//  CocoaHotReloadDemo
//
//  Created by mambaxie on 2019/11/26.
//  Copyright © 2019 tencent. All rights reserved.
//

#ifndef CocoaHotReloadClientDefine_h
#define CocoaHotReloadClientDefine_h

#import "CocoaHotReloadClientTool.h"

// 开发时可设置为1，提交代码时请务必设置为0 ！！！！
#define COCOA_HOT_RELOAD_DEBUG 0

/// Print debug log
#if COCOA_HOT_RELOAD_DEBUG
#define DebugLog(format, ...) (NSLog)((format), ##__VA_ARGS__);
#else
#define DebugLog(...);
#endif

// Print normal log
#define HRLog(format, ...) \
DebugLog((@"【CocoaHotReload】" format), ##__VA_ARGS__); \
[CocoaHotReloadClientTool printLog:[NSString stringWithFormat:(@"" format), ##__VA_ARGS__]];
 
/// Print error log
#define ErrorLog(format, ...) \
DebugLog((@"【CocoaHotReload】【Error】❌ " format), ##__VA_ARGS__); \
[CocoaHotReloadClientTool printLog:[NSString stringWithFormat:(@"【Error】❌ " format), ##__VA_ARGS__]];

#endif /* CocoaHotReloadDefine_h */
