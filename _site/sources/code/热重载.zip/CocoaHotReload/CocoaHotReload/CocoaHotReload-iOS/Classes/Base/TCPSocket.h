//
//  TCPSocket.h
//  CocoaHotReload-iOS
//
//  Created by mambaxie on 2020/9/12.
//  Copyright © 2020 tencent. All rights reserved.
//  模拟器使用TCP socket进行通信

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TCPSocket : NSObject

@property (nonatomic, assign, readonly) int clientSocket;

/// 开启指定服务器
/// @param address 服务器地址
+ (instancetype _Nullable)runServerWithAddress:(NSString *)address;

/// 服务器等待客户端连接
+ (instancetype _Nullable)waitToConnectServer;

/// 连接指定服务器
/// @param address 服务器地址
+ (instancetype _Nullable)connectToServer:(NSString *)address;

/// 读取int类型数据
- (int)readInt;

/// 读取二进制数据
- (NSData *_Nullable)readData;

/// 读取字符串数据
- (NSString *_Nullable)readString;

/// 读取json数据
- (NSDictionary *_Nullable)readDictionary;

/// 写入字符串数据
/// @param string 字符串数据
- (BOOL)writeString:(NSString *_Nonnull)string;

/// 写入cmd和字符串数据
/// @param command SocketCommand指令
/// @param string 字符串数据
- (BOOL)writeCommand:(int)command withString:(NSString *_Nullable)string;

/// 写入二进制数据
/// @param data 二进制数据
- (BOOL)writeData:(NSData *_Nonnull)data;

/// 写入cmd和二进制数据
/// @param command SocketCommand指令
/// @param data 二进制数据
- (BOOL)writeCommand:(int)command withData:(NSData *_Nullable)data;

@end

NS_ASSUME_NONNULL_END
