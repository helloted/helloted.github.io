//
//  XCTestHookTool.m
//  CocoaHotReload-iOS
//
//  Created by mambaxie on 2020/10/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "XCTestHookTool.h"
#import <objc/runtime.h>

@implementation XCTestHookTool

+ (void)hookXCTestFunctions
{
    id xctestClass = NSClassFromString(@"XCTest");
    if (!xctestClass) {
        return;
    }
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [self swizzleXCTestMethodWithSelStr:@"setUp"];
        [self swizzleXCTestMethodWithSelStr:@"setUpWithError:"];
        [self swizzleXCTestMethodWithSelStr:@"tearDown"];
        [self swizzleXCTestMethodWithSelStr:@"tearDownWithError:"];
        [self swizzleXCTestMethodWithSelStr:@"performTest:"];
        [self swizzleXCTestMethodWithSelStr:@"runTest"];
        
        Method addMethod = class_getInstanceMethod(self, @selector(cocoaHotReload_shouldIgnoreInvoke));
        class_addMethod(xctestClass, method_getName(addMethod), method_getImplementation(addMethod), method_getTypeEncoding(addMethod));
    });
}

#pragma mark - Private

+ (void)swizzleXCTestMethodWithSelStr:(NSString *)selStr {
    SEL sel = NSSelectorFromString(selStr);
    id xctestClass = NSClassFromString(@"XCTest");
    SEL swizzleSel = NSSelectorFromString([NSString stringWithFormat:@"cocoaHotReload_%@", selStr]);
    if (!xctestClass || !sel || !swizzleSel) {
        return;
    }
    
    Method oldMethod = class_getInstanceMethod(xctestClass, sel);
    Method replaceMethod = class_getInstanceMethod(self, swizzleSel);
    class_addMethod(xctestClass, swizzleSel, method_getImplementation(replaceMethod), method_getTypeEncoding(replaceMethod));
    Method swizzleMethod = class_getInstanceMethod(xctestClass, swizzleSel);
    method_exchangeImplementations(oldMethod, swizzleMethod);
}

- (BOOL)cocoaHotReload_shouldIgnoreInvoke
{
    // fix 如果热重载后会所有case会重复执行，这里CocoaHotReload的直接return不执行
    if ([self respondsToSelector:@selector(name)]) {
        NSString *name = [self performSelector:@selector(name)];
        return [name isEqualToString:@"CocoaHotReload"];
    }
    
    return NO;
}

#pragma mark - Hook
- (void)cocoaHotReload_setUp
{
    if ([self cocoaHotReload_shouldIgnoreInvoke]) {
        return;
    }
    
    return [self cocoaHotReload_setUp];
}

- (BOOL)cocoaHotReload_setUpWithError:(NSError **)error
{
    if ([self cocoaHotReload_shouldIgnoreInvoke]) {
        return YES;
    }
    
    return [self cocoaHotReload_setUpWithError:error];
}

- (void)cocoaHotReload_tearDown
{
    if ([self cocoaHotReload_shouldIgnoreInvoke]) {
        return;
    }
    
    return [self cocoaHotReload_tearDown];
}

- (BOOL)cocoaHotReload_tearDownWithError:(NSError **)error
{
    if ([self cocoaHotReload_shouldIgnoreInvoke]) {
        return YES;
    }
    
    return [self cocoaHotReload_tearDownWithError:error];
}

// XCTestRun *
- (void)cocoaHotReload_performTest:(id)run
{
    if ([self cocoaHotReload_shouldIgnoreInvoke]) {
        return;
    }
    
    return [self cocoaHotReload_performTest:run];
}

- (void)cocoaHotReload_runTest
{
    if ([self cocoaHotReload_shouldIgnoreInvoke]) {
        return;
    }
    
    return [self cocoaHotReload_runTest];
}

@end
