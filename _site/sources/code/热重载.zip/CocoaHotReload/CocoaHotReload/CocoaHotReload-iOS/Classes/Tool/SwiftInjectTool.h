//
//  SwiftInjectTool.h
//  CocoaHotReload-iOS
//
//  Created by yuqingyuan on 2020/7/30.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SwiftInjectTool : NSObject

+ (BOOL)isSwiftClass:(Class)oldClass newClass:(Class)newClass;
+ (void)swizzleSwiftClassWithOldClass:(Class)oldClass newClass:(Class)newClass;

/// 更新所有镜像中的swift类
/// @param newClass 新的Swift类
/// @param dylibHandle dlopen的镜像路径
/// @param className swift类名
+ (BOOL)updateAllShouldBeReplaceClassWithNewClass:(Class)newClass
                                      dylibHandle:(const void *)dylibHandle
                                        className:(NSString *)className;


/// 处理swift symbol，根据swift symbol获取所有的类名及类对象
/// @param symbols 所要处理的symbol
+ (void)handleSwiftSymbols:(NSArray<NSString *> *)symbols;

@end
