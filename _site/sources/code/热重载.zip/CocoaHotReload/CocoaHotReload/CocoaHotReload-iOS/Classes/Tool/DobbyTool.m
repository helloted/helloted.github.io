//
//  DobbyTool.m
//  CocoaHotReload-iOS
//
//  Created by mambaxie on 2020/12/7.
//  Copyright © 2020 tencent. All rights reserved.
//

#import "DobbyTool.h"
#import "CocoaClassTool.h"
#if !TARGET_OS_MACCATALYST
#import "dobby.h"
#endif
#import <mach-o/dyld.h>
#import <dlfcn.h>
#import <CocoaHotReloadClientDefine.h>

@implementation DobbyTool

+ (void)replaceFunctionImplementationWithLibHandle:(void *)libHandle functionSymbols:(NSArray<NSString *> *)functionSymbols
{
#if !TARGET_OS_MACCATALYST
    for (NSString *functionSymbol in functionSymbols) {
        [CocoaClassTool handleAllImagesWithAction:^BOOL(void *handle, BOOL isSystemLib) {
            if (isSystemLib || handle == libHandle) {
                return NO;
            }
            // 函数替换
            void *oldFunction = dlsym(handle, functionSymbol.UTF8String);
            if (oldFunction) {
                void *newFunction = dlsym(libHandle, functionSymbol.UTF8String);
                if (!newFunction) {
                    return NO;
                }
                void *orgin;
                int result = DobbyHook((void *)oldFunction, (void *)newFunction, &orgin);
                if (result != 0) {
                    HRLog(@"函数替换失败：funtion symbol = %@, ret = %d", functionSymbol, result);
                }
            }
            return NO;
        }];
    }
#else
    HRLog(@"Mac Catalast 目前不支持直接派发的函数热重载！");
#endif
}

@end
