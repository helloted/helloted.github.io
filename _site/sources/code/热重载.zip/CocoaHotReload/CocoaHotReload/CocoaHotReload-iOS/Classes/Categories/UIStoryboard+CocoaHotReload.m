//
//  UIStoryboard+CocoaHotReload.m
//  CocoaHotReload
//
//  Created by mambaxie on 2020/8/3.
//

#if ! __has_feature(objc_arc)
#error This file must be compiled with ARC. Use -fobjc-arc flag (or convert project to ARC).
#endif

#import "UIStoryboard+CocoaHotReload.h"
#import <Objc/runtime.h>
#import "CocoaHotReloadClientTool.h"
#import "CocoaClassTool.h"

@implementation UIStoryboard (CocoaHotReload)

+ (void)load
{
    [CocoaClassTool swizzleInstanceMethodWithSel:@selector(storyboardWithName:bundle:)
                                      swizzleSel:@selector(cocoaHotReload_storyboardWithName:bundle:)
                                        forClass:object_getClass(self)];
}

+ (UIStoryboard *)cocoaHotReload_storyboardWithName:(NSString *)name bundle:(nullable NSBundle *)storyboardBundleOrNil
{
    NSBundle *bundle = [CocoaHotReloadClientTool bundleForHotrloadWithStoryboardName:name];
    if (bundle) {
        return [self cocoaHotReload_storyboardWithName:name bundle:bundle];
    }
    
    return [self cocoaHotReload_storyboardWithName:name bundle:storyboardBundleOrNil];
}

@end
