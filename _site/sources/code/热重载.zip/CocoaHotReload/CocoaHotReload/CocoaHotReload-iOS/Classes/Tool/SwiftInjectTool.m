//
//  SwiftInjectTool.m
//  CocoaHotReload-iOS
//
//  Created by yuqingyuan on 2020/7/30.
//  Copyright © 2020 tencent. All rights reserved.
//

#if ! __has_feature(objc_arc)
#error This file must be compiled with ARC. Use -fobjc-arc flag (or convert project to ARC).
#endif

#import "SwiftInjectTool.h"
#import <dlfcn.h>
#import "CocoaClassTool.h"

// key为class name value为所以镜像中类的集合
static NSMutableDictionary<NSString *, NSMutableSet<Class> *> *gSwiftClassSetDicM;

// 项目中的swift符号
static NSArray<NSString *> *gProjectSwiftSymbols;

@implementation SwiftInjectTool

+ (BOOL)isSwiftClass:(Class)oldClass newClass:(Class)newClass {
    NSString *path = [[[NSBundle mainBundle] privateFrameworksPath] stringByAppendingString:@"/SwiftHotReload.framework/SwiftHotReload"];
    void *handler = dlopen(path.UTF8String, RTLD_NOW);
    if (handler != NULL) {
        Class toolClass = NSClassFromString(@"SwiftHotReload.SwiftHotReload");
        SEL sel = NSSelectorFromString(@"isSwiftClassWithOldClass:newClass:");
        IMP imp = [toolClass methodForSelector:sel];
        BOOL (*func)(id, SEL, Class, Class) = (void *)imp;
        BOOL result = func(toolClass, sel, oldClass, newClass);
        return result;
    }
    return false;
}

+ (void)swizzleSwiftClassWithOldClass:(Class)oldClass newClass:(Class)newClass {
    NSString *path = [[[NSBundle mainBundle] privateFrameworksPath] stringByAppendingString:@"/SwiftHotReload.framework/SwiftHotReload"];
    void *handler = dlopen(path.UTF8String, RTLD_NOW);
    if (handler != NULL && [self isSwiftClass:oldClass newClass:newClass]) {
        Class toolClass = NSClassFromString(@"SwiftHotReload.SwiftHotReload");
        SEL sel = NSSelectorFromString(@"swizzleSwiftClassWithOldClass:newClass:");
        IMP imp = [toolClass methodForSelector:sel];
        void (*func)(id, SEL, Class, Class) = (void *)imp;
        func(toolClass, sel, oldClass, newClass);
    }
}

+ (BOOL)updateAllShouldBeReplaceClassWithNewClass:(Class)newClass
                                      dylibHandle:(const void *)dylibHandle
                                        className:(NSString *)className
{
    // targetName.className -> className
    className = [[className componentsSeparatedByString:@"."] lastObject];
    if (!newClass || !className || !dylibHandle) {
        return NO;
    }
    
    NSMutableSet *classSetM = [self classSetForClassName:className];
    for (Class class in classSetM.allObjects) {
        [self swizzleSwiftClassWithOldClass:class newClass:newClass];
    }
    
    [classSetM addObject:newClass];
    
    return YES;
}

+ (void)handleSwiftSymbols:(NSArray<NSString *> *)symbols
{
    gProjectSwiftSymbols = symbols;
}

#pragma mark - Private
+ (NSMutableSet *)classSetForClassName:(NSString *)className
{
    if (!gSwiftClassSetDicM) {
        gSwiftClassSetDicM = [NSMutableDictionary dictionary];
    }
    NSMutableSet *classSetM = gSwiftClassSetDicM[className];
    if (classSetM) {
        return classSetM;
    }
    
    classSetM = [NSMutableSet set];
    for (NSString *symbol in gProjectSwiftSymbols) {
        if (![symbol hasSuffix:[NSString stringWithFormat:@"%@CN", className]]) {
            continue;
        }
        [CocoaClassTool handleAllImagesWithAction:^BOOL(void *handle, BOOL isSystemLib) {
            id classSym = (__bridge id)(dlsym(handle, symbol.UTF8String));
            Class class = [classSym class];
            NSString *clsName = NSStringFromClass(class);
            // targetName.className -> className
            clsName = [[clsName componentsSeparatedByString:@"."] lastObject];
            if (class) {
                if ([className isEqualToString:clsName]) {
                    [classSetM addObject:class];
                }
                return YES;
            }
            return NO;
        }];
    }
    gSwiftClassSetDicM[className] = classSetM;
    
    return classSetM;
}

@end
