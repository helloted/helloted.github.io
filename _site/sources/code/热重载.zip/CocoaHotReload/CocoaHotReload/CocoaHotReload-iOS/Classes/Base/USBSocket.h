//
//  USBSocket.h
//  CocoaHotReload-iOS
//
//  Created by mambaxie on 2019/12/13.
//  Copyright © 2019 tencent. All rights reserved.
//  真机使用USB socket进行通信

#import <Foundation/Foundation.h>

@class CHRChannel, CHRData;

enum {
    PTFrameTypeStart = 99,
    PTFrameTypeData,
    PTFrameTypeString,
    PTFrameTypeDictionary,
    PTFrameTypePing,
    PTFrameTypePong,
    PTFrameTypeEnd,
};

typedef struct _PTStringFrame {
  uint32_t length;
  uint8_t utf8[0];
} PTStringFrame;

NS_ASSUME_NONNULL_BEGIN

@interface USBSocket : NSObject

/// 接收到cmd的block
@property (nonatomic, copy) void(^didReciveCommandBlock)(int cmd, id value);

/// 断开连接block
@property (nonatomic, copy) void(^didDisconnectBlock)(NSError *error);

/// 完成连接block
@property (nonatomic, copy) void(^didConnectBlock)(BOOL);

/// 错误
@property (nonatomic, strong) NSError *error;

/// 运行指定端口
/// @param port 端口号
- (void)runServerWithPort:(int)port;

/// 连接指定端口
/// @param port 端口号
- (void)connectToServerWithPort:(int)port;

/// 发送字符串数据
/// @param cmd SocketCommand指令
/// @param string 字符串数据
- (void)sendCommand:(int)cmd string:(NSString *__nullable)string;

/// 发送json数据
/// @param cmd SocketCommand指令
/// @param dictionary json数据
- (void)sendCommand:(int)cmd dictionary:(NSDictionary *__nullable)dictionary;

/// 发送二进制数据
/// @param cmd SocketCommand指令
/// @param data 二进制数据
- (void)sendCommand:(int)cmd data:(NSData *__nullable)data;

/// 发送对象
/// @param cmd  SocketCommand指令
/// @param value 对象
- (void)sendCommand:(int)cmd value:(id)value;

/// 客户端通道
- (CHRChannel *)clientChannel;

/// 服务器通道
- (CHRChannel *)serverChannel;

/// 关闭
- (void)close;

@end

NS_ASSUME_NONNULL_END
