//
//  TCPSocket.m
//  CocoaHotReload-iOS
//
//  Created by mambaxie on 2020/9/12.
//  Copyright © 2020 tencent. All rights reserved.
//

#if ! __has_feature(objc_arc)
#error This file must be compiled with ARC. Use -fobjc-arc flag (or convert project to ARC).
#endif

#import "TCPSocket.h"
#include <sys/socket.h>
#include <netinet/tcp.h>
#include <netdb.h>
#import "CocoaSocket.h"
#import "CHRProtocol.h"
#import "NSString+CocoaHotReload.h"
#if TARGET_OS_IPHONE
#import "CocoaHotReloadClientDefine.h"
#else
#import "CocoaHotReloadServerDefine.h"
#endif

static int gServerSocket;
static BOOL gIsSocketsOutOfBounds = NO;

@implementation TCPSocket

+ (instancetype)runServerWithAddress:(NSString *)address
{
    struct sockaddr_storage serverAddr;
    [self parseV4Address:address into:&serverAddr];

    gServerSocket = [self newSocket:serverAddr.ss_family];
    if (gServerSocket < 0)
        return nil;

    if (bind(gServerSocket, (struct sockaddr *)&serverAddr, serverAddr.ss_len) < 0) {
        [CocoaSocket printStrerror:@"Could not bind service socket: %s"];
        return nil;
    } else if (listen(gServerSocket, 5) < 0) {
        [CocoaSocket printStrerror:@"Service socket would not listen: %s"];
        return nil;
    } else {
        return [self waitToConnectServer];
    }
}

+ (instancetype)connectToServer:(NSString *)address {
    struct sockaddr_storage serverAddr;
    [self parseV4Address:address into:&serverAddr];
    
    if (gIsSocketsOutOfBounds) {
        return nil;
    }

    int clientSocket = [self newSocket:serverAddr.ss_family];
    if (clientSocket < 0) {
        if (clientSocket == -2) {
            gIsSocketsOutOfBounds = YES;
        }
        return nil;
    }
    
    if (connect(clientSocket, (struct sockaddr *)&serverAddr, serverAddr.ss_len) < 0) {
        close(clientSocket);
        return nil;
    }

    return [[self alloc] initSocket:clientSocket];
}

+ (instancetype)waitToConnectServer
{
    while (gServerSocket) {
        struct sockaddr_storage clientAddr;
        socklen_t addrLen = sizeof clientAddr;

        int _clientSocket = accept(gServerSocket, (struct sockaddr *)&clientAddr, &addrLen);
        if (_clientSocket > 0) {
            @autoreleasepool {
                
                [CocoaSocket showConnectingTipForDevice:YES];   //检测一下真机的连接
                
                struct sockaddr_in *v4Addr = (struct sockaddr_in *)&clientAddr;
                char *address = inet_ntoa(v4Addr->sin_addr);    //adress
                int port = ntohs(v4Addr->sin_port);             //端口
                
                HRLog(@"Connection from %s:%d", address, port);
                return [[self alloc] initSocket:_clientSocket];
            }
        }
        else
            [NSThread sleepForTimeInterval:.5];
    }
    
    return nil;
}

- (int)readInt {
    int32_t anint;
    if (read(_clientSocket, &anint, sizeof anint) != sizeof anint)
        return ~0;
    return anint;
}

- (NSData *_Nullable)readData
{
    uint32_t length = [self readInt];
    if (length == ~0)
        return nil;
    Byte *bytes = (Byte *)malloc(length);
    Byte *tmp = (Byte *)malloc(1024);
    uint32_t readedDataLength = 0;
    while (readedDataLength < length) {
        uint32_t acceptLength = length - readedDataLength;
        if (acceptLength > 1024) {
            acceptLength = 1024;
        }
        
        long revLength = read(_clientSocket, tmp, acceptLength);
        
        if (revLength < 0)
            break;
        for (uint32_t i = 0; i + readedDataLength < length && i < revLength; i++) {
            bytes[i+readedDataLength] = tmp[i];
        }
        readedDataLength += revLength;
    }
    free(tmp);
    if (readedDataLength != length) {
        free(bytes);
        return nil;
    }
    NSData *data = [NSData dataWithBytesNoCopy:bytes length:length freeWhenDone:YES];
    
    return data;
}

- (BOOL)writeData:(NSData *)data
{
    uint32_t length = (uint32_t)data.length;
    uint8_t *cData = (uint8_t *)[data bytes];
    
    if (write(_clientSocket, &length, sizeof length) != sizeof length ||
        write(_clientSocket, cData, length) != length)
        return FALSE;
    return TRUE;
}

- (NSString *)readString {
    uint32_t length = [self readInt];
    if (length == ~0)
        return nil;
    
    char utf8[length + 1];
    uint32_t readedStringLength = 0;
    while (readedStringLength < length) {
        uint32_t acceptLength = length - readedStringLength;
        if (acceptLength > 1024) { // buffer 1024
            acceptLength = 1024;
        }
        char tmp[acceptLength];
        
        size_t revLength = read(_clientSocket, tmp, acceptLength);
        if (revLength < 0) {
            break;
        }
        for (uint32_t i = 0; i + readedStringLength < length && i < revLength; i++) {
            utf8[i+readedStringLength] = tmp[i];
        }
        readedStringLength += revLength;
    }
    if (readedStringLength != length) {
        return nil;
    }
    utf8[length] = '\000';
    return [NSString cocoaHotReload_stringWithUTF8String:utf8];
}

- (BOOL)writeString:(NSString *)string {
    const char *utf8 = string.UTF8String;
    uint32_t length = (uint32_t)strlen(utf8);
    if (write(_clientSocket, &length, sizeof length) != sizeof length ||
        write(_clientSocket, utf8, length) != length)
        return FALSE;
    return TRUE;
}

- (NSDictionary *_Nullable)readDictionary
{
    NSData *jsonData = [self readData];
    NSDictionary *value = [NSDictionary dictionaryWithContentsOfDispatchData:[jsonData createReferencingDispatchData]];
    return value;
}

- (BOOL)writeCommand:(int)command withString:(NSString *)string {
    return write(_clientSocket, &command, sizeof command) == sizeof command &&
        (!string || [self writeString:string]);
}

- (BOOL)writeCommand:(int)command withData:(NSData *_Nullable)data
{
    return write(_clientSocket, &command, sizeof command) == sizeof command &&
        (!data || [self writeData:data]);
}

#pragma - Private

- (void)dealloc
{
    close(_clientSocket);
}

+ (int)newSocket:(sa_family_t)addressFamily {
    int optval = 1, newSocket;
    if ((newSocket = socket(addressFamily, SOCK_STREAM, 0)) < 0){
        [CocoaSocket printStrerror:@"Could not open service socket: %s"];
        return -2;
    }
    else if (setsockopt(newSocket, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof optval) < 0)
        [CocoaSocket printStrerror:@"Could not set SO_REUSEADDR: %s"];
    else if (setsockopt(newSocket, SOL_SOCKET, SO_NOSIGPIPE, (void *)&optval, sizeof(optval)) < 0)
        [CocoaSocket printStrerror:@"Could not set SO_NOSIGPIPE: %s"];
    else if (setsockopt(newSocket, IPPROTO_TCP, TCP_NODELAY, (void *)&optval, sizeof(optval)) < 0)
        [CocoaSocket printStrerror:@"Could not set TCP_NODELAY: %s"];
    else
        return newSocket;
    return -1;
}

/**
 * Available formats
 * @"<host>[:<port>]"
 * where <host> can be NNN.NNN.NNN.NNN or hostname, empty for localhost or * for all interfaces
 * The default port is 80 or a specific number to bind or an empty string to allocate any port
 */
+ (BOOL)parseV4Address:(NSString *)address into:(struct sockaddr_storage *)serverAddr {
    NSArray<NSString *> *parts = [address componentsSeparatedByString:@":"];

    struct sockaddr_in *v4Addr = (struct sockaddr_in *)serverAddr;
    bzero(v4Addr, sizeof *v4Addr);

    v4Addr->sin_family = AF_INET;
    v4Addr->sin_len = sizeof *v4Addr;
    v4Addr->sin_port = htons(parts.count > 1 ? parts[1].intValue : 80);

    const char *host = parts[0].UTF8String;
    struct hostent *hp = gethostbyname2(host, v4Addr->sin_family);
    if (!host[0])
        v4Addr->sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    else if (host[0] == '*')
        v4Addr->sin_addr.s_addr = htonl(INADDR_ANY);
    else if (isdigit(host[0]))
        v4Addr->sin_addr.s_addr = inet_addr(host);
    else if (hp)
        memcpy((void *)&v4Addr->sin_addr, hp->h_addr, hp->h_length);
    else {
        [CocoaSocket printStrerror:[NSString stringWithFormat:@"Unable to look up host for %@", address]];
        return FALSE;
    }

    return TRUE;
}

- (instancetype)initSocket:(int)socket {
    if ((self = [super init])) {
        _clientSocket = socket;
    }
    return self;
}

@end
