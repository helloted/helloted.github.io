//
//  CocoaHotReload.h
//  CocoaHotReload-iOS
//
//  Created by mambaxie on 2020/3/11.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CocoaHotReloadDefine.h"

typedef NS_ENUM(NSUInteger, CocoaHotReloadMode) {
    CocoaHotReloadModeSocket,               // socket通信 与mac端配合使用
    CocoaHotReloadModeHotReloadDylibOnly,   // 只hot reload dylib，服务于cocoahotreload 命令行生成的动态库加载
};

typedef NS_ENUM(NSUInteger, CocoaHotReloadClientStatus) {
    CocoaHotReloadClientStatusDisConnect = 0,
    CocoaHotReloadClientStatusConnected,
};

extern NSString * _Nonnull const kSocketConnectNotification;

NS_ASSUME_NONNULL_BEGIN

@interface CocoaHotReload : NSObject

/// 运行CocoaHotReload，mode为CocoaHotReloadModeSocket
/// scene 自动适配 正常Debug：CocoaHotReloadSceneDefault 测试用例：CocoaHotReloadSceneForTests
+ (void)run;

/// 当前场景
+ (CocoaHotReloadScene)currentScene;

/// 热重载完成的处理操作
+ (void)actionWhenHotReloadDidComplete;

/// 该接口服务于由cocoahotreload 命令行生成的动态库加载，mode为CocoaHotReloadModeHotReloadDylibOnly
/// @param directory cocoahotreload 命令行中output文件夹路径，默认会解析该文件夹下info.plist文件进行热重载
+ (void)hotReloadWithDirectory:(NSString *)directory;

/// 当前模式
+ (CocoaHotReloadMode)currentMode;

/// 设置模式
/// @param mode 模式
+ (void)setMode:(CocoaHotReloadMode)mode;

/// 当前连接状态
+ (CocoaHotReloadClientStatus)socketStatus;

/// 设置状态
/// @param status 状态
+ (void)setSocketStatus:(CocoaHotReloadClientStatus)status;

/// 当前版本
+ (NSString *)currentVersion;

/// 热重载队列
+ (dispatch_queue_t)hotReloadQueue;

@end

NS_ASSUME_NONNULL_END
