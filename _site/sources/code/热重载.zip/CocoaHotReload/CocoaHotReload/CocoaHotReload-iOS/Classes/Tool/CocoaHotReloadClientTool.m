//
//  CocoaHotReloadClientTool.m
//  CocoaHotReloadDemo
//
//  Created by mambaxie on 2019/12/12.
//  Copyright © 2019 tencent. All rights reserved.
//

#if ! __has_feature(objc_arc)
#error This file must be compiled with ARC. Use -fobjc-arc flag (or convert project to ARC).
#endif

#import "CocoaHotReloadClientTool.h"
#import "CocoaHotReloadClientDefine.h"
#import <UIKit/UIKit.h>
#include <mach/mach_host.h>
#import "CocoaHotReload.h"
#import "SocketClient.h"
#import <sys/utsname.h>

static NSString *gDylibFilePath; // 动态库路径
static NSString *gDylibDirectoryPath; // 动态库存储文件夹
static NSString *gLogFilePath; // 日志文件

@implementation CocoaHotReloadClientTool

/// 生成动态库地址
+ (NSString *)generateDylibFilePath
{
    static int dylibIndex = 0;
    NSString *dylibFilePath = [NSString stringWithFormat:@"%@/CocoaHotReload_%d.dylib", gDylibDirectoryPath, dylibIndex];
    dylibIndex++;
    
    return dylibFilePath;
}

/// 动态库存储文件夹
+ (NSString *)getCocoaHotReloadTmpDirectoryPath
{
    if (!gDylibDirectoryPath) {
        NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
        gDylibDirectoryPath = [docDir stringByAppendingPathComponent:@"CocoaHotReload"];
    }
    return gDylibDirectoryPath;
}

+ (void)clearDylibDirectory
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *directoryPath = [self getCocoaHotReloadTmpDirectoryPath];
    NSError *error;
    if ([fileManager fileExistsAtPath:directoryPath]) {
        [fileManager removeItemAtPath:directoryPath error:&error];
    }
    [fileManager createDirectoryAtPath:directoryPath withIntermediateDirectories:YES attributes:nil error:&error];
    if (error) {
        ErrorLog(@"Clear dylib directory error : %@", error);
    }
}

+ (BOOL)isSimulator
{
    return ![[self getArch] hasPrefix:@"arm"];
}

+ (NSString *)getArch
{
    host_basic_info_data_t hostInfo;
    mach_port_msgcount_t infoCount;
    NSString *arch = @"";
    
    infoCount = HOST_BASIC_INFO_COUNT;
    host_info(mach_host_self(), HOST_BASIC_INFO, (host_info_t)&hostInfo, &infoCount);
    switch (hostInfo.cpu_type) {
        case CPU_TYPE_ARM:
        {
            arch = @"arm";
            break;
        }
        case CPU_TYPE_ARM64:
            arch = @"arm64";
            break;
        case CPU_TYPE_X86: {
            if (hostInfo.cpu_subtype == CPU_SUBTYPE_X86_64_H) {
                arch = @"x86_64";
            } else {
                arch = @"i386";
            }
            break;
        }
        case CPU_TYPE_X86_64:
            arch = @"x86_64";
            break;
            
        default:
            break;
    }
    return arch;
}

+ (NSDictionary *)clientInfo
{
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *deviceModel = [NSString stringWithCString:systemInfo.machine
                                                  encoding:NSUTF8StringEncoding];
    
    UIDevice *device = [UIDevice currentDevice];
    return @{
        @"frameworksPath" : [[NSBundle mainBundle] privateFrameworksPath] ?: [[NSBundle mainBundle].bundlePath stringByAppendingPathComponent:@"Frameworks"],
        @"bundleInfo" : [[NSBundle mainBundle] infoDictionary],
        @"arch" : [self getArch],
        @"framewrokVersion" : [CocoaHotReload currentVersion]?:@"Unknow",
        @"deviceName": device.name ?: @"",
        @"deviceModel": deviceModel ? : @"",
    };
}

+ (void)printLog:(NSString *)log
{
    if (!log) {
        return;
    }
    CocoaHotReloadMode currentMode = [CocoaHotReload currentMode];
    switch (currentMode) {
        case CocoaHotReloadModeSocket:
            [[SocketClient currentClient] sendSocketCommand:SocketCommandPrintNormalLog string:log];
            break;
            
        case CocoaHotReloadModeHotReloadDylibOnly:
        {
            if (gLogFilePath) {
                @synchronized (self) {
                    
                    log = [NSString stringWithFormat:@"【CocoaHotReload】%@\n", log];
                    NSFileHandle *fileHandle = [NSFileHandle fileHandleForWritingAtPath:gLogFilePath];
                    [fileHandle seekToEndOfFile];
                    [fileHandle writeData:[log dataUsingEncoding:NSUTF8StringEncoding]];
                    [fileHandle closeFile];
                    printf("%s", log.UTF8String);
                }
            }
            break;
        }
            
        default:
            printf("%s\n", log.UTF8String);
            break;
    }
}

+ (void)setLogFilePath:(NSString *)logFilePath
{
    gLogFilePath = logFilePath;

    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:gLogFilePath]) {
        [fileManager removeItemAtPath:gLogFilePath error:nil];
    }

    [fileManager createFileAtPath:gLogFilePath contents:nil attributes:nil];
}

+ (NSString *)bundleDirForCocoaHotReloadAndCreateIfNeed
{
    NSString *tmpDir = [CocoaHotReloadClientTool getCocoaHotReloadTmpDirectoryPath];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:tmpDir]) {
        NSError *error;
        [fileManager createDirectoryAtPath:tmpDir withIntermediateDirectories:NO attributes:nil error:&error];
        if (error) {
            ErrorLog(@"%@", [error localizedDescription]);
        }
    }
    
    NSString *bundleDir = [tmpDir stringByAppendingPathComponent:@"bundles"];
    if (![fileManager fileExistsAtPath:bundleDir]) {
        NSError *error;
        [fileManager createDirectoryAtPath:bundleDir withIntermediateDirectories:NO attributes:nil error:&error];
        if (error) {
            ErrorLog(@"%@", [error localizedDescription]);
        }
    }
    
    return bundleDir;
}

+ (NSBundle *)bundleForHotReloadWithNibName:(NSString *)nibName
{
    if (!nibName) {
        return nil;
    }
    NSString *bundleDir = [[CocoaHotReloadClientTool bundleDirForCocoaHotReloadAndCreateIfNeed] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_nib", nibName]];
    NSString *nibFilePath = [bundleDir stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.nib", nibName]];
    if ([[NSFileManager defaultManager] fileExistsAtPath:nibFilePath]) {
        return [NSBundle bundleWithPath:bundleDir];
    }
    
    return nil;
}

+ (NSBundle *)bundleForHotrloadWithStoryboardName:(NSString *)storyboardName
{
    NSString *bundleDir = [[CocoaHotReloadClientTool bundleDirForCocoaHotReloadAndCreateIfNeed] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@_storyboardc", storyboardName]];
    NSString *storyboardcFilePath = [bundleDir stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.storyboardc", storyboardName]];
    if ([[NSFileManager defaultManager] fileExistsAtPath:storyboardcFilePath]) {
        return [NSBundle bundleWithPath:bundleDir];
    }
    
    return nil;
}

@end
