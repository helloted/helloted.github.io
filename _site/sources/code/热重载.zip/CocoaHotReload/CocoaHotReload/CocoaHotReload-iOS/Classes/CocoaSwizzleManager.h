//
//  CocoaSwizzleManager.h
//  CocoaHotReload-iOS
//
//  Created by mambaxie on 2020/6/19.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface CocoaSwizzleManager : NSObject

/// hook swizzle funtion
+ (void)hookSwizzleFuntion;

/// 禁止swizzle
+ (void)disallowSwizzle;
/// 允许swizzle
+ (void)allowSwizzle;

/// 处理循环调用问题，如hook操作在非load中执行，可能导致dloen后，不会执行指针交换，导致死循环
/// @param classes 所要解决的类列表
/// @param dylibPath 当前dlopen镜像路径
+ (void)handleCycleInvokeForClassesIfNeed:(NSArray<Class> *)classes dylibPath:(NSString *)dylibPath;

@end

NS_ASSUME_NONNULL_END
