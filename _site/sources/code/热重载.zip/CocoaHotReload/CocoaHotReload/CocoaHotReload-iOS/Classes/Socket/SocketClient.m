//
//  SocketClient.m
//  CocoaHotReload
//
//  Created by mambaxie on 2019/11/19.
//  Copyright © 2019 tencent. All rights reserved.
//

#if ! __has_feature(objc_arc)
#error This file must be compiled with ARC. Use -fobjc-arc flag (or convert project to ARC).
#endif

#import "SocketClient.h"
#import "CocoaHotReloadClientDefine.h"
#import "SocketCommandClientHandler.h"
#import "CocoaHotReloadClientTool.h"
#import "USBSocket.h"
#import <Foundation/Foundation.h>
#import "CocoaHotReload.h"
#import "TCPSocket.h"

static int gRetryCount = 0;
static dispatch_queue_t gConnectQueue;

@interface SocketClient ()

@end

@implementation SocketClient

+ (void)connectAndRunWithCompletion:(void (^)(BOOL))completion 
{
    if (!gConnectQueue) {
        gConnectQueue = dispatch_queue_create("com.tencent.cocoahotreload.connect", DISPATCH_QUEUE_SERIAL);
    }
    
    if ([CocoaHotReloadClientTool isSimulator]) {
        // HRLog(@"Try to connect tcp server");
        /// 连接
        SocketClient *client = [self connectToTCPServer:TCP_ADDRESS];
        if (client) {
            if ([CocoaHotReload currentScene] != CocoaHotReloadSceneForTests) {
                HRLog(@"🎉 Connect tcp succeed!");
            }
            [client run];
            [self setSocketStatus:YES];
            if (completion) {
                completion(YES);
            }
        } else {
            static dispatch_once_t onceToken;
            dispatch_once(&onceToken, ^{
                ErrorLog(@"😵 Connect tcp failed!, Cocoa Hot Reload (Mac app) is running?");
            });
            dispatch_async(gConnectQueue, ^{
                usleep(3000000); // 3s
                [self connectAndRunWithCompletion:completion];
            });
            [self setSocketStatus:NO];
            
            if (completion) {
                completion(NO);
            }
        }
    } else {
        HRLog(@"Try to connect usb server");
        [self connectToUSBServer:USB_SOCKET_PORT completion:^(BOOL connected) {
            if (connected) {
                gRetryCount = 0;
                NSDictionary *info = [CocoaHotReloadClientTool clientInfo];
                NSString *deviceName = info[@"deviceName"];
                
                if ([CocoaHotReload currentScene] != CocoaHotReloadSceneForTests) {
                    HRLog(@"🎉 %@ Connect usb succeed!",deviceName);
                }
                [self setSocketStatus:YES];
                if (completion) {
                    completion(YES);
                }
            } else {
                static dispatch_once_t onceToken;
                dispatch_once(&onceToken, ^{
                    ErrorLog(@"😵 Connect usb failed! Cocoa Hot Reload (Mac app)  is running?");
                });
                dispatch_async(gConnectQueue, ^{
                    usleep(3000000); // 3s
                    [self connectAndRunWithCompletion:completion];
                });
                [self setSocketStatus:NO];
                
                if (completion) {
                    completion(NO);
                }
            }
        }];
    }
}

+ (SocketClient *)currentClient
{
    return (SocketClient *)[super currentSocket];
}

- (void)runInBackground
{
    static dispatch_once_t onceToken;
    static long long version;
    dispatch_once(&onceToken, ^{
       /// clear dylib dir
       [CocoaHotReloadClientTool clearDylibDirectory];
        version = [[NSDate date] timeIntervalSince1970];
    });
    
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithDictionary:[CocoaHotReloadClientTool clientInfo]];
    dict[@"random"] = @(version);
    dict[@"scene"] = @([CocoaHotReload currentScene]);
#if TARGET_OS_MACCATALYST
    dict[@"isMacCatalyst"] = @(1);
#endif
    [self sendSocketCommand:SocketCommandClientInfo dictionary:dict];

    if ([self isUSBConnected]) {// usb
        [self usbSocket].didReciveCommandBlock = ^(int cmd, id  _Nonnull value) {
            [self postNotificationForSocketCommand:cmd value:value];
        };
        __weak typeof(self)weakSelf = self;
        [self usbSocket].didDisconnectBlock = ^(NSError *error){
            [weakSelf reconnectIfNeed:error];
            ErrorLog(@"Clitent app usb disconnected");
        };
        
    } else if ([self isTCPConnected]) { // tcp
        SocketCommand command;
        TCPSocket *tcpSocket = self.tcpSocket;
        while ((command = (SocketCommand)[tcpSocket readInt]) != SocketCommandEOF) {
            id value = nil;
            switch (command) {
                case SocketCommandSentData:
                case SocketCommandReloadDylib:
                case SocketCommandProjectSwiftSymbols: {
                    value = [tcpSocket readDictionary];
                    break;
                }
                     
                default:
                    break;
            }

            [self postNotificationForSocketCommand:command value:value];
        }
        ErrorLog(@"Clitent app tcp disconnected");
        [self.class connectAndRunWithCompletion:^(BOOL isSuccess) {
            ;
        }];
    }
}

- (void)reconnectIfNeed:(NSError *)error {
    int maxCount = 5;
    if (error.code == 57 && [error.domain isEqualToString:NSPOSIXErrorDomain]) {
        if ([self usbSocket] && gRetryCount <= maxCount) {
            gRetryCount = gRetryCount + 1;
            [[self usbSocket] connectToServerWithPort:USB_SOCKET_PORT];
        }
    }
}

+ (void)setSocketStatus:(BOOL)isConnect {
    [CocoaHotReload setSocketStatus:isConnect ? CocoaHotReloadClientStatusConnected : CocoaHotReloadClientStatusDisConnect];
}

@end

