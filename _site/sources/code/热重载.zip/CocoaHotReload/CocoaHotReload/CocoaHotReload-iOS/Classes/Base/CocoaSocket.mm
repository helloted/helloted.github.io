//
//  CocoaSocket.m
//  CocoaHotReload-iOS
//
//  Created by mamabxie on 2019/12/08.
//  Copyright © 2020 tencent. All rights reserved.
//

#if ! __has_feature(objc_arc)
#error This file must be compiled with ARC. Use -fobjc-arc flag (or convert project to ARC).
#endif

#import "CocoaSocket.h"
#import "TCPSocket.h"
#import "CHRChannel.h"
#import "USBSocket.h"

#if TARGET_OS_IPHONE
#import "CocoaHotReloadClientDefine.h"
#import "CocoaHotReload.h"
#else
#import "CocoaHotReloadServerDefine.h"
#endif

#import "NSString+CocoaHotReload.h"

static CocoaSocket *gCurrentSocket;

@implementation CocoaSocket

+ (CocoaSocket *)currentSocket
{
    return gCurrentSocket;
}

+ (int)printStrerror:(NSString *)message
{
    NSLog(message, strerror(errno));
    return -1;
}

+ (void)startTCPServer:(NSString *)address
{
    [self performSelectorInBackground:@selector(runTCPServer:) withObject:address];
}

+ (void)startTCPServer:(NSString *_Nonnull)address completion:(void(^)(CocoaSocket *socket))completion
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        [self runTCPServer:address];
        if (completion) {
            completion(gCurrentSocket);
        }
    });
}

+ (instancetype)runTCPServer:(NSString *)address
{
    TCPSocket *tcpSocket = [TCPSocket runServerWithAddress:address];
    if (!gCurrentSocket) {
        gCurrentSocket = [[self alloc] init];
    }
    gCurrentSocket.tcpSocket = tcpSocket;
    [gCurrentSocket run];
    
    return gCurrentSocket;
}

+ (void)waitToConnectTCPServer
{
    TCPSocket *tcpSocket = [TCPSocket waitToConnectServer];
    gCurrentSocket.tcpSocket = tcpSocket;
    
    [gCurrentSocket run];
}

+ (void)showConnectingTipForDevice:(BOOL)isDevice {
    if (gCurrentSocket) {
        if (!isDevice && [gCurrentSocket isTCPConnected]) {
            ErrorLog(@"有其他模拟器连接，请手动断开");
        }
        if(isDevice && [gCurrentSocket isUSBConnected]){
            ErrorLog(@"有其他真机连接，请手动断开");
        }
    }
}

+ (instancetype _Nullable)connectToTCPServer:(NSString *)address {
    TCPSocket *tcpSocket = [TCPSocket connectToServer:address];
    if (!gCurrentSocket) {
        gCurrentSocket = [[self alloc] init];
    }
    if (tcpSocket) {
        gCurrentSocket.tcpSocket = tcpSocket;
        return gCurrentSocket;
    }
    
    return nil;
}

+ (void)startUSBServer:(int)port
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
         [self runUSBServer:port];
    });
}

+ (void)startUSBServer:(int)port completion:(void(^_Nullable)(CocoaSocket * _Nullable socket))completion
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self runUSBServer:port];
        if (completion) {
            completion(gCurrentSocket);
        }
    });
}

+ (instancetype _Nullable )runUSBServer:(int)port {
    
    USBSocket *usbServer = [USBSocket new];
    if (!gCurrentSocket) {
        gCurrentSocket = [[self alloc] init];
    }
    gCurrentSocket.usbSocket = usbServer;
    usbServer.didConnectBlock = ^(BOOL result) {
        [self showConnectingTipForDevice:NO];   //检测一下模拟器的连接
        if (result) {
            [gCurrentSocket run];
        }
    };
    [usbServer runServerWithPort:port];
    return gCurrentSocket;
}

+ (void)connectToUSBServer:(int)port completion:(void (^ _Nullable)(BOOL))completion {
    USBSocket *usbServer = [USBSocket new];
    if (!gCurrentSocket) {
        gCurrentSocket = [[self alloc] init];
    }
    gCurrentSocket.usbSocket = usbServer;
    usbServer.didConnectBlock = ^(BOOL result) {
        if (result) {
            [gCurrentSocket run];
        }
        
        if (completion) {
            completion(result);
        }
    };
    
    [usbServer connectToServerWithPort:port];
    
    if (usbServer.error) {
        ErrorLog(@"Connect to usb server fail : %@", usbServer.error);
        gCurrentSocket.usbSocket = nil;
    }
}

- (void)run {
    [self performSelectorInBackground:@selector(runInBackground) withObject:nil];
}

- (void)runInBackground {
    [[self class] printStrerror:@"-[CocoaSocket run] not implemented in subclass"];
}

- (BOOL)isConnected
{
    return [self isUSBConnected] || [self isTCPConnected];
}

- (BOOL)isTCPConnected
{
    return self.tcpSocket.clientSocket > 0;
}

- (BOOL)isUSBConnected
{
    return [self.usbSocket.clientChannel isConnected];
}

/// 发送指令
- (void)sendSocketCommand:(SocketCommand)cmd
{
    [self sendSocketCommand:cmd string:nil];
}

/// 字符串
- (void)sendSocketCommand:(SocketCommand)cmd string:(NSString *__nullable)string
{
    if ([self isUSBConnected]) {
        [[self usbSocket] sendCommand:cmd string:string];
    } else {
        [[self tcpSocket] writeCommand:cmd withString:string];
    }
}

/// 二进制数据
- (void)sendSocketCommand:(SocketCommand)cmd data:(NSData *__nullable)data
{
    if ([self isUSBConnected]) {
        [[self usbSocket] sendCommand:cmd data:data];
    } else {
        [[self tcpSocket] writeCommand:cmd withData:data];
    }
}

/// json 数据
- (void)sendSocketCommand:(SocketCommand)cmd dictionary:(NSDictionary * _Nullable)dictionary
{
#if TARGET_OS_IPHONE
    if (cmd == SocketCommandReloadComplete && [CocoaHotReload currentScene] == CocoaHotReloadSceneForTests) {
        [CocoaHotReload actionWhenHotReloadDidComplete];
    }
#endif
    if ([self isUSBConnected]) {
        [[self usbSocket] sendCommand:cmd dictionary:dictionary];
    } else {
        dispatch_data_t payload = [dictionary createReferencingDispatchData];
        [[self tcpSocket] writeCommand:cmd withData:[NSData dataWithContentsOfDispatchData:payload]];
    }
}

/// 通知指令
- (void)postNotificationForSocketCommand:(SocketCommand)cmd value:(id __nullable)value
{
    NSMutableDictionary *userInfo = [@{
                                        kSocketReceiveCommandKey : @(cmd),
                                    } mutableCopy];
    if (value) {
        userInfo[kSocketReceiveValueKey] = value;
    }
    
    [[NSNotificationCenter defaultCenter] postNotificationName:SocketDidReceiveCommandNotification object:nil userInfo:userInfo];
}

- (void)postNotificationForSocketCommand:(SocketCommand)cmd
{
    [self postNotificationForSocketCommand:cmd value:nil];
}

@end
