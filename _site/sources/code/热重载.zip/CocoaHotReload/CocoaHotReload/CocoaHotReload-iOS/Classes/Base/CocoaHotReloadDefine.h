//
//  CocoaHotReloadDefine.h
//  CocoaHotReload
//
//  Created by mambaxie on 2020/8/27.
//  Copyright © 2020 tencent. All rights reserved.
//

#ifndef CocoaHotReloadDefine_h
#define CocoaHotReloadDefine_h

// 热重载返回码
typedef NS_ENUM(int, CocoaHotReloadCode) {
    CocoaHotReloadCodeSuccess = 0, // success
    // Error
    CocoaHotReloadCodeErrorCompileFailed = -1,  // 编译失败
    CocoaHotReloadCodeErrorDlopenError = -2,    // dlopen错误
    
    CocoaHotReloadCodeErrorUnknow = -499,       // 未知错误
};

typedef NS_ENUM(NSUInteger, CocoaHotReloadScene) {
    CocoaHotReloadSceneDefault,  // 默认场景
    CocoaHotReloadSceneForTests, // 单元测试用例
};

#endif /* CocoaHotReloadDefine_h */
