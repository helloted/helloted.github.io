//
//  SocketClient.h
//  CocoaHotReloadTool
//
//  Created by mambaxie on 2019/11/20.
//  Copyright © 2019 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CocoaSocket.h"

NS_ASSUME_NONNULL_BEGIN
@interface SocketClient : CocoaSocket

/// 当前客户端
+ (SocketClient *)currentClient;

/// 连接和运行
/// @param completion 完成时回调
+ (void)connectAndRunWithCompletion:(void(^)(BOOL isSuccess))completion;

@end

NS_ASSUME_NONNULL_END
