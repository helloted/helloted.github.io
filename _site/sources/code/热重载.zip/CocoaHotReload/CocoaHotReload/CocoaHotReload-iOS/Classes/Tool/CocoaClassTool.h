//
//  CocoaClassTool.h
//  FrameworkDemo
//
//  Created by mambaxie on 2019/9/10.
//  Copyright © 2019 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Objc/runtime.h>

NS_ASSUME_NONNULL_BEGIN

@interface CocoaClassImpInfo : NSObject

/// 全类名 eg: CocoaClassImpInfo or CocoaClassImpInfo(Tool)
@property (nonatomic, copy) NSString *fullClassName;

/// 类名 eg: CocoaClassImpInfo
@property (nonatomic, copy) NSString *className;

/// 函数名
@property (nonatomic, copy) NSString *methodName;

/// 是否是分类函数
@property (nonatomic, assign) BOOL isCategory;

/// 是否是类函数
@property (nonatomic, assign) BOOL isClassMethod;

/// 镜像路径
@property (nonatomic, copy) NSString *imagePath;

@end

@interface CocoaClassTool : NSObject

/// 更新所有类名相同的类的实现
/// @param newClass 新类（dlopen镜像中的类）
/// @param dylibHandle dlopen的镜像路径
/// @param classSym 类符号名 __OBJC_CLASS_$_NSObject
/// @param ignoreClassMethodNames 需要忽略的函数名列表
+ (BOOL)updateAllShouldBeReplaceClassWithNewClass:(Class)newClass
                                      dylibHandle:(const void *)dylibHandle
                                         classSym:(const char *)classSym
                           ignoreClassMethodNames:(NSArray<NSString *> *)ignoreClassMethodNames;

/// 同步originClass到所有类，分类添加以后 需要做此处理，这里只做函数处理
/// @param classNames 需要同步的类名数组
/// @param oFileClassNames o file文件中的类名（即recompile的类）
/// @param libHandle dlopen返回的指针
+ (void)synchronizeOrginClassToAllClassWithClassNames:(NSArray<NSString *> *)classNames
                                      oFileClassNames:(nullable NSArray<NSString *> *)oFileClassNames
                                      ignoreLibHandle:(nullable void *)libHandle;
/// 添加分类信息到各个类中
/// @param newClass 新类（dlopen镜像中的类）
/// @param originClass 原生类（即源码所在镜像中的类）
+ (void)addCategoryClassInfoToNewClass:(Class)newClass originClass:(Class)originClass;

/// 预更新基础类的函数
+ (void)preupdateCategoryMethodForBasicClasses;

/// 更新某个类的分类函数
/// @param aClass 所要更新的类
/// @param isForce 是否强制更新，如果为YES，则强制更新；如果为NO，则先判断是否有更新过，如果没有，再更新
+ (void)updateCategoryMethodForClassIfNeed:(Class)aClass isForce:(BOOL)isForce;

/// 更新传入类名的分类函数列表
/// @param classNames 所要更新的类名数组
+ (void)updateCategoryMethodForClassNames:(NSArray<NSString *> *)classNames;

/// 判断分类函数是否被hook
/// @param method 所要判断的method
/// @param aClass 所要判断的类
+ (BOOL)isCategoryInstanceMethodHookedWithMethod:(Method)method aClass:(Class)aClass;

/// 初始化
+ (void)setup;

/// 根据method判断是否是分类函数
/// @param method 所要判断的method
+ (BOOL)isCategoryMethod:(Method)method;

/// 根据类名获取原始类
/// @param className 类名
/// eg. @"TestClass" -> TestClass
/// eg. @"TestClass(Category)" -> TestClass
+ (Class)orginClassForClassName:(NSString *)className;

/// 根据类符号获取类名
/// @param classSymbol 类符号
/// eg. @"OBJC_CLASS_$_TestClass"且TestClass存在 -> @"TestClass"
/// eg. @"_OBJC_$_CATEGORY_TestClass_$_Category"且TestClass存在 -> @"TestClass(Category)"
/// 如果类不存在，返回nil
+ (NSString *)classNameForClassSymbol:(NSString *)classSymbol;

/// 打印类instance method信息
/// @param aClass 所要打印的类
+ (void)printClassInstanceMethodInfo:(Class)aClass;

/// 根据imp获取函数名
/// @param imp impletion指针
+ (NSString *)methodNameForImp:(IMP)imp;

/// 根据imp获取类名
/// @param imp impletion指针
/// 普通类函数 返回类名 如：TestClass -> @"TestClass"
/// 分类函数 返回带有分类的名称 如: TestClass (Category) -> @"TestClass(Category)"
+ (NSString *)classNameForImp:(IMP)imp;

/// 根据分类名获取类名
/// @param categoryClassName 分类名字
/// 如：@"TestClass(Category)" -> @"TestClass"
+ (NSString *)classNameForCategoryClassName:(NSString *)categoryClassName;

/// 获取imp信息
/// @param imp impletion指针
+ (CocoaClassImpInfo *)impInfoForImp:(IMP)imp;

/// 实例函数交换 如果是类函数 aClass 传入metaClass，如object_getClass(class)
/// @param sel 原始函数
/// @param swizzleSel 交换的函数
/// @param aClass 类
+ (void)swizzleInstanceMethodWithSel:(SEL)sel swizzleSel:(SEL)swizzleSel forClass:(Class)aClass;

/// 处理所有镜像
/// @param action 处理逻辑放在action，如果需要退出循环，直接在block内return YES.
+ (void)handleAllImagesWithAction:(BOOL(^)(void *handle, BOOL isSystemLib))action;

@end

NS_ASSUME_NONNULL_END
