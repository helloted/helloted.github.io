//
//  UINib+CocoaHotReload.m
//  CocoaHotReload
//
//  Created by mambaxie on 2020/8/4.
//

#if ! __has_feature(objc_arc)
#error This file must be compiled with ARC. Use -fobjc-arc flag (or convert project to ARC).
#endif

#import "UINib+CocoaHotReload.h"
#import <Objc/runtime.h>
#import "CocoaHotReloadClientTool.h"
#import "CocoaClassTool.h"

@implementation UINib (CocoaHotReload)

+ (void)load
{
    [CocoaClassTool swizzleInstanceMethodWithSel:@selector(nibWithNibName:bundle:)
                                      swizzleSel:@selector(cocoaHotReload_nibWithNibName:bundle:)
                                        forClass:object_getClass(self)];
}

+ (UINib *)cocoaHotReload_nibWithNibName:(NSString *)name bundle:(nullable NSBundle *)bundleOrNil
{
    NSBundle *bundle = [CocoaHotReloadClientTool bundleForHotReloadWithNibName:name];
    if (bundle) {
        return [self cocoaHotReload_nibWithNibName:name bundle:bundle];
    }
    
    return [self cocoaHotReload_nibWithNibName:name bundle:bundleOrNil];
}

@end
