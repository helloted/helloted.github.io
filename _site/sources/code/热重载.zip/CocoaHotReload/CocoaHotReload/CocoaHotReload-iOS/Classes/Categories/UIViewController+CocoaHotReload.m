//
//  UIViewController+CocoaHotReload.m
//  CocoaHotReload
//
//  Created by mambaxie on 2020/8/3.
//

#if ! __has_feature(objc_arc)
#error This file must be compiled with ARC. Use -fobjc-arc flag (or convert project to ARC).
#endif

#import "UIViewController+CocoaHotReload.h"
#import <Objc/runtime.h>
#import "CocoaHotReloadClientTool.h"
#import "CocoaClassTool.h"

@implementation UIViewController (CocoaHotReload)

+ (void)load
{
    [CocoaClassTool swizzleInstanceMethodWithSel:@selector(initWithNibName:bundle:)
                                      swizzleSel:@selector(cocoaHotReload_initWithNibName:bundle:)
                                        forClass:self];
}

- (instancetype)cocoaHotReload_initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{
    NSBundle *bundle = [CocoaHotReloadClientTool bundleForHotReloadWithNibName:nibNameOrNil];
    if (bundle) {
        return [self cocoaHotReload_initWithNibName:nibNameOrNil bundle:bundle];
    }
    
    // 走原始逻辑
    return [self cocoaHotReload_initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
}

@end
