//
//  CocoaHotReload.m
//  CocoaHotReload-iOS
//
//  Created by mambaxie on 2020/3/11.
//  Copyright © 2020 tencent. All rights reserved.
//

#if ! __has_feature(objc_arc)
#error This file must be compiled with ARC. Use -fobjc-arc flag (or convert project to ARC).
#endif

#import "CocoaHotReload.h"
#import "SocketClient.h"
#import "CocoaClassTool.h"
#import "SocketCommandClientHandler.h"
#import <Objc/runtime.h>
#import "CocoaSwizzleManager.h"
#import <dlfcn.h>
#import "XCTestHookTool.h"

static NSString * const kCurrentVersion = @"0.4.4";

static CocoaHotReloadScene gCurrentScene; // 当前运行的场景
static CocoaHotReloadMode gCurrentMode; // 当前运行的模式
static CocoaHotReloadClientStatus gClientSocketStatus; // socket刘安

NSString * const kSocketConnectNotification = @"kSocketConnectNotification";

@interface CocoaHotReload()

@property (nonatomic, copy) void(^hotReloadCompletion)(void);

@end

@implementation CocoaHotReload

+ (instancetype)sharedInstance
{
    static dispatch_once_t onceToken;
    static CocoaHotReload *hotReload;
    dispatch_once(&onceToken, ^{
        hotReload = [CocoaHotReload new];
    });
    
    return hotReload;
}

+ (void)run
{
    id xctestClass = NSClassFromString(@"XCTest");
    if (xctestClass) {
        // Unit Tests时屏蔽CocoaHotReload运行
        return;
    }
//    NSDictionary *environment = [[NSProcessInfo processInfo] environment];
//    // environment[@"XCTestBundlePath"] 代表使用 Unit Tests
//    if (environment[@"XCTestBundlePath"]) { // Unit tests
//        [self runWithScene:CocoaHotReloadSceneForTests];
//        return;
//    }

    [self runWithScene:CocoaHotReloadSceneDefault];
}

+ (void)runWithScene:(CocoaHotReloadScene)scene
{
    gCurrentMode = CocoaHotReloadModeSocket;
    gCurrentScene = scene;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        NSLog(@"-------- CocoaHotReload(v%@) run --------", [self currentVersion]);
        dispatch_semaphore_t sema;
        if (scene == CocoaHotReloadSceneForTests) {
            sema = dispatch_semaphore_create(0);
            [XCTestHookTool hookXCTestFunctions];
        }
        // Socket 连接
        [SocketClient connectAndRunWithCompletion:^(BOOL isSuccess) {
            if (isSuccess) {
                dispatch_async([self hotReloadQueue], ^{
                    // 初始化
                    [self setupIfNeed];
                    if (scene == CocoaHotReloadSceneDefault) {
                        // 预加载基础类的分类信息
                        [CocoaClassTool preupdateCategoryMethodForBasicClasses];
                    } else if (scene == CocoaHotReloadSceneForTests) {
                        // 等待hot reload完成
                        [[self sharedInstance] setHotReloadCompletion:^{
                            dispatch_semaphore_signal(sema);
                        }];
                    }
                });
            } else if (sema) {
                dispatch_semaphore_signal(sema);
            }
        }];
        
        if (sema) {
            dispatch_semaphore_wait(sema, DISPATCH_TIME_FOREVER);
        }
    });
}

+ (void)actionWhenHotReloadDidComplete
{
    if ([CocoaHotReload sharedInstance].hotReloadCompletion) {
        [CocoaHotReload sharedInstance].hotReloadCompletion();
    }
}

+ (CocoaHotReloadScene)currentScene
{
    return  gCurrentScene;
}

+ (void)setupIfNeed
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        // 初始化
        [[SocketCommandClientHandler shareInstance] setup];
        // 初始化
        [CocoaClassTool setup];
    });
}

+ (void)hotReloadWithDirectory:(NSString *)directory
{
    gCurrentMode = CocoaHotReloadModeHotReloadDylibOnly;
    
    // 优先初始化
    [self setupIfNeed];
    
    [[SocketCommandClientHandler shareInstance] hotReloadWithDirectory:directory];
}

+ (CocoaHotReloadMode)currentMode
{
    return gCurrentMode;
}

+ (void)setMode:(CocoaHotReloadMode)mode
{
    gCurrentMode = mode;
}

+ (CocoaHotReloadClientStatus)socketStatus
{
    return gClientSocketStatus;
}

+ (void)setSocketStatus:(CocoaHotReloadClientStatus)status
{
    if (gClientSocketStatus != status) {
        [[NSNotificationCenter defaultCenter] postNotificationName:kSocketConnectNotification object:@{@"status":@(status)}];
    }
    gClientSocketStatus = status;
}

+ (NSString *)currentVersion
{
    return kCurrentVersion;
}

/// 热重载队列
+ (dispatch_queue_t)hotReloadQueue
{
    static dispatch_once_t onceToken;
    static dispatch_queue_t hotReloadQueue;
    dispatch_once(&onceToken, ^{
        hotReloadQueue = dispatch_queue_create("com.tencent.cocoahotreload.hotreload", DISPATCH_QUEUE_SERIAL);
    });
    return hotReloadQueue;
}

@end

