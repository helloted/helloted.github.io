//
//  DobbyTool.h
//  CocoaHotReload-iOS
//
//  Created by mambaxie on 2020/12/7.
//  Copyright © 2020 tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DobbyTool : NSObject

/// 替换函数实现
/// @param libHandle dlopen返回的指针
/// @param functionSymbols 函数符号列表
+ (void)replaceFunctionImplementationWithLibHandle:(void *)libHandle functionSymbols:(NSArray<NSString *> *)functionSymbols;

@end

NS_ASSUME_NONNULL_END
