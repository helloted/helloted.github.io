//
//  CocoaClassTool.m
//  FrameworkDemo
//
//  Created by mambaxie on 2019/9/10.
//  Copyright © 2019 tencent. All rights reserved.
//

#if ! __has_feature(objc_arc)
#error This file must be compiled with ARC. Use -fobjc-arc flag (or convert project to ARC).
#endif

#import "CocoaHotReloadClientDefine.h"
#import "CocoaClassTool.h"
#import <dlfcn.h>
#import <mach-o/dyld.h>
#import <mach-o/ldsyms.h>
#import <UIKit/UIKit.h>
#import "NSString+CocoaHotReload.h"

@interface NSObject (CocoaClassTool)
// hook 函数
+ (void)cocoaHotReload_hookFunctions;

@end

@class CocoaClassInfo;

// 这里是为了适配手Q qlvr hook 操作
static NSString * const kQLVRObjectHookSubClassSuffix = @"_qlvr_obj_hook_";
static NSString * const kQLVRObjectHookActionPrefix = @"qlvr_action_";

// 记录分类类方法 以className作为key 分类的类函数数组作为value
static NSMutableDictionary<NSString *, NSArray<NSString *>*> *gCategoryClassMethodsDicM;
// 记录实例方法 以className作为key 分类的实例函数数组作为value
static NSMutableDictionary<NSString *, NSArray<NSString *>*> *gCategoryInstanceMethodsDicM;

// 记录分类类方法 以className作为key 分类被hook的类函数数组作为value
static NSMutableDictionary<NSString *, NSArray<NSString *>*> *gHookedCategoryClassMethodsDicM;
// 记录实例方法 以className作为key 分类被hook的实例函数数组作为value
static NSMutableDictionary<NSString *, NSArray<NSString *>*> *gHookedCategoryInstanceMethodsDicM;

// 记录已删除的属性 以className作为key 已删除的Property数组作为value
static NSMutableDictionary<NSString *, NSArray<NSString *>*> *gRemovedPropertyNamesDicM;
// 记录已删除的属性函数 以className作为key 已删除Property的get和set函数数组作为value
static NSMutableDictionary<NSString *, NSArray<NSString *>*> *gRemovedMethodNamesForPropertyDicM;

// 记录已删除的ivar 以className作为key 已删除的Ivar数组作为value
static NSMutableDictionary<NSString *, NSArray<NSString *>*> *gRemovedIvarsDicM;
// 记录已删除的Property 以className作为key 已删除Property的Ivar数组作为value
static NSMutableDictionary<NSString *, NSArray<NSString *>*> *gRemovedIvarsForPropertyDicM;

// 记录实例函数 以className作为key 已删除的Protocol数组作为Value
static NSMutableDictionary<NSString *, NSArray<NSString *>*> *gRemovedProtocolsDicM;

// 记录热重载过的类名
static NSMutableSet<NSString *> *gDidHotReloadClassNameSetM;

// 记录原始类信息 以className作为key，CocoaClassInfo类信息作为value
static NSMutableDictionary<NSString *, CocoaClassInfo *> *gOriginClassInfoDicM;

@interface CocoaClassInfo : NSObject

/// 是否为系统类
@property (nonatomic, assign) BOOL isSystemClass;

/// 类
@property (nonatomic, strong) Class class;

/// 类symbol
@property (nonatomic, copy) NSString *symbol;

@end

@implementation CocoaClassInfo

@end

@implementation CocoaClassImpInfo

@end

@implementation CocoaClassTool

+ (void)setup
{
    gCategoryClassMethodsDicM = [NSMutableDictionary dictionary];
    gCategoryInstanceMethodsDicM = [NSMutableDictionary dictionary];
    gHookedCategoryClassMethodsDicM = [NSMutableDictionary dictionary];
    gHookedCategoryInstanceMethodsDicM = [NSMutableDictionary dictionary];
    gRemovedPropertyNamesDicM = [NSMutableDictionary dictionary];
    gRemovedMethodNamesForPropertyDicM = [NSMutableDictionary dictionary];
    gRemovedIvarsDicM = [NSMutableDictionary dictionary];
    gRemovedIvarsForPropertyDicM = [NSMutableDictionary dictionary];
    gRemovedProtocolsDicM = [NSMutableDictionary dictionary];
    gDidHotReloadClassNameSetM = [NSMutableSet set];
    gOriginClassInfoDicM = [NSMutableDictionary dictionary];
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        // 使用CocoaHotReload才hook函数
        [NSObject cocoaHotReload_hookFunctions];
    });
}

// 预更新基础类的函数
+ (void)preupdateCategoryMethodForBasicClasses
{
//    HRLog(@"Pre-update category method for basic classes");
    NSArray *baseClassNames = @[
        @"NSString",
        @"NSObject",
        @"UIView",
        @"NSDictionary",
        @"UIImage",
        @"UIViewController",
        @"NSDate",
        @"NSData",
        @"UIColor",
        @"UIImageView",
        @"UITableView",
        @"UIFont",
        @"UIDevice"
    ];
    
    [self updateCategoryMethodForClassNames:baseClassNames];
}

+ (BOOL)updateAllShouldBeReplaceClassWithNewClass:(Class)newClass
                                      dylibHandle:(const void *)dylibHandle
                                         classSym:(const char *)classSym
                           ignoreClassMethodNames:(NSArray<NSString *> *)ignoreClassMethodNames
{
    CocoaClassInfo *originClassInfo = [self originClassInfoForClassName:NSStringFromClass(newClass)];
    if (!originClassInfo.class || originClassInfo.isSystemClass) {
        return NO;
    }
    
    NSMutableSet<Class> *shouldBeReplaceClassesSet = [NSMutableSet set];
    Class originClass = originClassInfo.class;
    // 添加分类信息到新类中
    [self addCategoryClassInfoToNewClass:newClass originClass:originClass];
    
    // 需要更新原始类
    [shouldBeReplaceClassesSet addObject:originClass];
    
    // 处理CocoaHotReload dylib中的类
    [self handleAllImagesWithAction:^BOOL(void *handle, BOOL isSystemLib) {
        if (handle == dylibHandle || isSystemLib) { // 系统库不处理
            return NO;
        }
        id oldSym = (__bridge id)(dlsym(handle, classSym));
        Class oldClass = [oldSym class];
        if (oldClass) {
            [shouldBeReplaceClassesSet addObject:oldClass];
        }
        return NO;
    }];
    for (int i = 0; i < shouldBeReplaceClassesSet.count; i++) { // 遍历替换所有类
        Class shouldBeReplaceClass = shouldBeReplaceClassesSet.allObjects[i];
        [self replaceClassWithOldClass:shouldBeReplaceClass
                              newClass:newClass
                           isLastClass:i == shouldBeReplaceClassesSet.count - 1
                ignoreClassMethodNames:ignoreClassMethodNames];
    
        [gDidHotReloadClassNameSetM addObject:NSStringFromClass(shouldBeReplaceClass)];
    }
    
    return YES;
}

+ (void)printClassInstanceMethodInfo:(Class)aClass
{
    printf("\n------------- %p's Instance Method -------------\n", aClass);
    unsigned int instanceMethodCount = 0;
    Method *instanceMethods = class_copyMethodList(aClass, &instanceMethodCount);

    for (int i = 0; i < instanceMethodCount; i++) {
        Method method = instanceMethods[i];
        const char *methodName = sel_getName(method_getName(method));
        Dl_info info;
        IMP imp = method_getImplementation(method);
        int result = dladdr(imp, &info);
        
        if (result != 0 && info.dli_saddr) {
            printf("method name :%s, impAddress: %p impInfo name : %s from: %s \n",  methodName, imp, info.dli_sname, info.dli_fname);
        } else {
            printf("method name :%s, impAddress: %p ",  methodName, imp);
        }
        
    }

    free(instanceMethods);
}

+ (void)addCategoryClassInfoToNewClass:(Class)newClass originClass:(Class)originClass
{
    // 更新分类函数
    [self updateCategoryMethodForClassIfNeed:originClass isForce:YES];
    
    // add category class methods
    [self addCategoryInstanceMethodsToNewClass:object_getClass(newClass) originClass:object_getClass(originClass) isClassMethod:YES];
    // add category instance methods
    [self addCategoryInstanceMethodsToNewClass:newClass originClass:originClass isClassMethod:NO];
}

// category method 是否被hook
+ (BOOL)isCategoryInstanceMethodHookedWithMethod:(Method)method aClass:(Class)aClass
{
    if (!aClass) {
        return NO;
    }
    
    // 更新分类函数
    [self updateCategoryMethodForClassIfNeed:aClass isForce:NO];

    BOOL isMetaClass = class_isMetaClass(aClass);
    NSString *className = NSStringFromClass(aClass);
    NSArray *hookedMethodNames = isMetaClass ? gHookedCategoryClassMethodsDicM[className] : gHookedCategoryInstanceMethodsDicM[className];
    NSString *methodName = [NSString cocoaHotReload_stringWithUTF8String:sel_getName(method_getName(method))];
    BOOL isHooked = [hookedMethodNames containsObject:methodName];
    
    return isHooked;
}

// 根据类名获取原始类
+ (Class)orginClassForClassName:(NSString *)className
{
    return [self originClassInfoForClassName:className].class;
}

+ (CocoaClassInfo *)originClassInfoForClassName:(NSString *)className
{
    className = [self classNameForCategoryClassName:className];
    
    __block CocoaClassInfo *classInfo = gOriginClassInfoDicM[className];
    if (classInfo) {
        return classInfo;
    }
    Class class = NSClassFromString(className);
    Dl_info info;
    int result = dladdr((__bridge const void *)(class), &info);
    const char *sym = info.dli_sname;
    if (result == 0 || !sym || !className) {
        return nil;
    }
    
    [self handleAllImagesWithAction:^BOOL(void *handle, BOOL isSystemLib) {
        id classSym = (__bridge id)(dlsym(handle, sym));
        if (classSym) {
            Class class = [classSym class];
            if (class) {
                classInfo = [[CocoaClassInfo alloc] init];
                classInfo.class = class;
                classInfo.symbol = [NSString stringWithUTF8String:sym];
                NSBundle *bundle = [NSBundle bundleForClass:class];
                // 非/Users/开头的库即视为系统库
                classInfo.isSystemClass = [self isSystemLibWithImagePath:bundle.bundlePath];
                gOriginClassInfoDicM[className] = classInfo;
                return YES;
            }
        }
        return NO;
    }];
    
    return classInfo;
}

+ (NSString *)classNameForClassSymbol:(NSString *)classSymbol
{
    if (!classSymbol) {
        return classSymbol;
    }
    // OBJC_CLASS_$_TestClass -> TestClass
    if ([classSymbol hasPrefix:@"OBJC_CLASS_$_"]) {
        NSString *className = [classSymbol stringByReplacingOccurrencesOfString:@"OBJC_CLASS_$_" withString:@""];
        if (NSClassFromString(className)) {
            return className;
        }
    }
    
    // _OBJC_$_CATEGORY_TestClass_$_Category -> TestClass(Category)
    if ([classSymbol hasPrefix:@"_OBJC_$_CATEGORY_"]) {
        classSymbol = [classSymbol stringByReplacingOccurrencesOfString:@"_OBJC_$_CATEGORY_" withString:@""];
        NSArray<NSString *> *results = [classSymbol componentsSeparatedByString:@"_$_"];
        if (results.count == 2) {
            NSString *className = results[0];
            NSString *categoryName = results[1];
            if (NSClassFromString(className)) {
                return [NSString stringWithFormat:@"%@(%@)", className, categoryName];
            }
        }
    }
    
    __block NSString *className;
    [self handleAllImagesWithAction:^BOOL(void *handle, BOOL isSystemLib) {
        id classSym = (__bridge id)(dlsym(handle, classSymbol.UTF8String));
        Class orginClass = [classSym class];
        if (orginClass) {
            className = NSStringFromClass(orginClass);
            return YES;
        }
        return NO;
    }];
       
    return className;
}

+ (void)synchronizeOrginClassToAllClassWithClassNames:(NSArray<NSString *> *)classNames
                                      oFileClassNames:(NSArray<NSString *> *)oFileClassNames
                                      ignoreLibHandle:(void *)libHandle
{
    for (NSString *className in classNames) {
        CocoaClassInfo *classInfo = [self originClassInfoForClassName:className];
        if (!classInfo.class) {
            continue;
        }
        Class originClass = classInfo.class;
        
        // 强制更新category信息
        [self updateCategoryMethodForClassIfNeed:originClass isForce:YES];
        
        if (classInfo.isSystemClass) { // 系统类的category无需同步到其他镜像
            return;
        }
        
        // 处理所有镜像
        [self handleAllImagesWithAction:^BOOL(void *handle, BOOL isSystemLib) {
            if (!classInfo.isSystemClass && isSystemLib) { // 非系统类且系统库直接不处理
                return NO;
            }
            id classSym = (__bridge id)(dlsym(handle, classInfo.symbol.UTF8String));
            if (!classSym || (handle == libHandle && [oFileClassNames containsObject:className])) { // 类已经进行hot reload 忽略即 同时修改了类和category 如 修改了 TestClass和TestClass+helper 文件
                return NO;
            }
            Class class = [classSym class];
            if (class == originClass) {
                return NO;
            }
            // synchronize class
            // meta class
            [self synchronizeOrginClassMethodToClassWithOriginClass:object_getClass(originClass) class:object_getClass(class)];
            // class
            [self synchronizeOrginClassMethodToClassWithOriginClass:originClass class:class];

            return NO;
        }];
    }
}

+ (BOOL)isCategoryMethod:(Method)method
{
    CocoaClassImpInfo *impInfo = [self impInfoForImp:method_getImplementation(method)];
    
    if (!impInfo) {
        return NO;
    }
    
    Class class = NSClassFromString(impInfo.className);
    
    // 更新分类函数
    [self updateCategoryMethodForClassIfNeed:class isForce:NO];

    NSString *selName = [NSString cocoaHotReload_stringWithUTF8String:sel_getName(method_getName(method))];
    
    if (impInfo.isClassMethod) {
        BOOL isCategoryMethod = [gCategoryClassMethodsDicM[impInfo.className] containsObject:selName];
        return isCategoryMethod;
    }
    
    BOOL isCategoryMethod = [gCategoryInstanceMethodsDicM[impInfo.className] containsObject:selName];
    return isCategoryMethod;
}

// 判断imp的函数名
+ (NSString *)methodNameForImp:(IMP)imp
{
    return [self impInfoForImp:imp].methodName;
}

// full class name for imp
+ (NSString *)classNameForImp:(IMP)imp
{
    return [self impInfoForImp:imp].fullClassName;
}

+ (CocoaClassImpInfo *)impInfoForImp:(IMP)imp
{
    if (!imp) {
        return nil;
    }
    Dl_info info;
    int result = dladdr(imp, &info);
    if (result != 0 && info.dli_sname) {
        NSString *sname = [NSString cocoaHotReload_stringWithUTF8String:info.dli_sname];
        if (([sname hasPrefix:@"+"] || [sname hasPrefix:@"-"])
            && [sname containsString:@"["]
            && [sname hasSuffix:@"]"]
            && [sname containsString:@" "]) {
            NSRange spaceRange = [sname rangeOfString:@" " options:NSBackwardsSearch range:NSMakeRange(0, sname.length)];
            NSRange startRange = NSMakeRange(1, 1); // @"["
            NSRange endRange = NSMakeRange(sname.length - 1, 1); // @"]"
            if (spaceRange.location != NSNotFound
                && startRange.location != NSNotFound
                && spaceRange.location > startRange.location
                && spaceRange.location != NSNotFound) {
                
                CocoaClassImpInfo *impInfo = [CocoaClassImpInfo new];
                NSInteger location = startRange.location + startRange.length;
                NSString *fullClassName = [sname substringWithRange:NSMakeRange(location, spaceRange.location - location)];
                impInfo.fullClassName = fullClassName;
                impInfo.className = [self classNameForCategoryClassName:fullClassName];
                NSString *selName = [sname substringWithRange:NSMakeRange(spaceRange.location + 1, endRange.location - (spaceRange.location + 1))];
                impInfo.methodName = selName;
                impInfo.isCategory = [fullClassName hasSuffix:@")"];
                impInfo.isClassMethod = [sname hasPrefix:@"+"];
                impInfo.imagePath = [NSString cocoaHotReload_stringWithUTF8String:info.dli_fname];
                
                return impInfo;
            }
        }
    }
       
    return nil;
}

+ (NSString *)classNameForCategoryClassName:(NSString *)categoryClassName
{
    NSRange separateRange = [categoryClassName rangeOfString:@"("];
    if (separateRange.location != NSNotFound) {
        return [categoryClassName substringToIndex:separateRange.location];
    }
    
    return categoryClassName ?: @"";
}

+ (void)swizzleInstanceMethodWithSel:(SEL)sel swizzleSel:(SEL)swizzleSel forClass:(Class)aClass
{
    Method oldMethod = class_getInstanceMethod(aClass, sel);
    Method swizzleMethod = class_getInstanceMethod(aClass, swizzleSel);
    method_exchangeImplementations(oldMethod, swizzleMethod);
}

/// 处理所有镜像
+ (void)handleAllImagesWithAction:(BOOL(^)(void *handle, BOOL isSystemLib))action
{
    uint32_t count = _dyld_image_count();
    
    for (uint32_t i = 0; i < count; i++) {
        const char *imageName = _dyld_get_image_name(i);
        void *dHandle = dlopen(imageName, RTLD_NOW);
        if (action) {
            BOOL shouldStop = action(dHandle, [self isSystemLibWithImagePath:[NSString cocoaHotReload_stringWithUTF8String:imageName]]);
            dlclose(dHandle);
            if (shouldStop) { // 停止
                return;
            }
        } else {
            dlclose(dHandle);
        }
    }
}

#pragma mark - Pravite
+ (BOOL)isSystemLibWithImagePath:(NSString *)imagePath
{
    // 模拟器 非/Users/和非/Volumes/开头的库即视为系统库
    // 真机 非/private/var/containers/Bundle/Application/ 或者 /var/containers/Bundle/Application/开头的库即视为系统库
    return ![imagePath hasPrefix:@"/Users/"] && ![imagePath hasPrefix:@"/Volumes/"] && ![imagePath hasPrefix:@"/private/var/containers/Bundle/Application/"] && ![imagePath hasPrefix:@"/var/containers/Bundle/Application/"];
}

+ (void)synchronizeOrginClassMethodToClassWithOriginClass:(Class)originClass class:(Class)class
{
    if (!originClass || !class || (originClass == class)) {
        return;
    }
    
    unsigned int originMethodCount = 0;
    Method *originMethods = class_copyMethodList(originClass, &originMethodCount);
    NSMutableSet<NSString *> *handledMethodNamesSet = [NSMutableSet set];
    for (int i = 0; i < originMethodCount; i++) {
        Method originMethod = originMethods[i];
        if (![self isCategoryMethod:originMethod]) { // 只更新category函数
            continue;
        }
        SEL sel = method_getName(originMethod);
        const char *methodNameCString = sel_getName(sel);
        NSString *methodName = [NSString cocoaHotReload_stringWithUTF8String:methodNameCString];
        if (methodName.length == 0 || [handledMethodNamesSet containsObject:methodName]) {
            continue;
        }
        
        [handledMethodNamesSet addObject:methodName];
        
        if (!class_respondsToSelector(class, sel)) { // add
            class_addMethod(class, method_getName(originMethod), method_getImplementation(originMethod), method_getTypeEncoding(originMethod));
        } else { // replace
            Method shouldReplaceMethod = class_getInstanceMethod(class, method_getName(originMethod));
            method_setImplementation(shouldReplaceMethod, method_getImplementation(originMethod));
        }
    }
    
    free(originMethods);
}

+ (void)addCategoryInstanceMethodsToNewClass:(Class)newClass originClass:(Class)originClass isClassMethod:(BOOL)isClassMethod
{
    if (!newClass || !originClass) {
        return;
    }
    
    NSString *className = NSStringFromClass(originClass);
    NSArray <NSString *> *methodNames = isClassMethod ? gCategoryClassMethodsDicM[className] : gCategoryInstanceMethodsDicM[className];
    
    for (NSString *methodName in methodNames) {
        SEL sel = NSSelectorFromString(methodName);
        Method method = class_getInstanceMethod(originClass, sel);
        if (method) {
            class_replaceMethod(newClass, sel, method_getImplementation(method), method_getTypeEncoding(method));
        }
    }
}

+ (void)updateCategoryMethodForClassNames:(NSArray<NSString *> *)classNames
{
    if (classNames.count <= 0) {
        return;
    }
    HRLog(@"🚧 Updating category method for classes...");
    __block int handleIndex = -1;

    dispatch_group_t group = dispatch_group_create();
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0);

    void(^updateCategoryMethod)(dispatch_queue_t) = ^(dispatch_queue_t queue) {
        dispatch_group_enter(group);
        dispatch_group_async(group, queue, ^{
            while (handleIndex + 1 < classNames.count) {
                NSString *className;
                @synchronized (self) {
                    handleIndex++;
                    if (handleIndex < classNames.count) {
                        className = [CocoaClassTool classNameForCategoryClassName:classNames[handleIndex]];
                    } else {
                        break;
                    }
                }
                
                [CocoaClassTool updateCategoryMethodForClassIfNeed:NSClassFromString(className) isForce:NO];
            }
            dispatch_group_leave(group);
        });
    };

    NSTimeInterval begin = [[NSDate date] timeIntervalSince1970];

    // 开4个任务
    updateCategoryMethod(queue);
    updateCategoryMethod(queue);
    updateCategoryMethod(queue);
    updateCategoryMethod(queue);

    dispatch_semaphore_t semaphore = dispatch_semaphore_create(0);
    dispatch_group_notify(group, queue, ^{
        dispatch_semaphore_signal(semaphore);
    });
    dispatch_semaphore_wait(semaphore, DISPATCH_TIME_FOREVER);

    NSTimeInterval end = [[NSDate date] timeIntervalSince1970];
    HRLog(@"👏 Update category method for classes success! %.2f seconds", end - begin);
}

// 更新分类函数
+ (void)updateCategoryMethodForClassIfNeed:(Class)class isForce:(BOOL)isForce
{
    if (!class) {
        return;
    }
    
    if (!gCategoryClassMethodsDicM) {
        [self setup];
    }
    
    NSString *className = NSStringFromClass(class);
    NSArray *classMethodNames = gCategoryClassMethodsDicM[className];
    NSArray *instanceMethodNames = gCategoryInstanceMethodsDicM[className];
    
    BOOL isNeedUpdate = isForce || !classMethodNames || !instanceMethodNames;
    
    if (isNeedUpdate) { // 需要更新category 函数
//        NSTimeInterval begin = [[NSDate date] timeIntervalSince1970];
//        HRLog(@"🚧 Updating category method for class \"%@\" ...", className);
        Class originClass = [self orginClassForClassName:className];
        if (class != originClass) { // 需要先更新orginalClass
            // update meta class
            [self updateCategoryInstanceMethodForClass:object_getClass(originClass)];
            // update class
            [self updateCategoryInstanceMethodForClass:originClass];
        }
        // update meta class
        [self updateCategoryInstanceMethodForClass:object_getClass(class)];
        // update class
        [self updateCategoryInstanceMethodForClass:class];
//        NSTimeInterval end = [[NSDate date] timeIntervalSince1970];
//        HRLog(@"👏Update category method for class \"%@\" success! %.2f seconds", className, end - begin);
    }
}

+ (void)updateCategoryInstanceMethodForClass:(Class)class
{
    if (!class) {
        return;
    }
    BOOL isClassMethod = class_isMetaClass(class);
    NSString *className = NSStringFromClass(class);
    NSArray *catetoryMethodNames = isClassMethod ? gCategoryClassMethodsDicM[className] : gCategoryInstanceMethodsDicM[className];
    NSArray *hookedCatetoryMethodNames = isClassMethod ? gHookedCategoryClassMethodsDicM[className] : gHookedCategoryInstanceMethodsDicM[className];
    
    NSMutableSet<NSString *> *methodNameSetM = [NSMutableSet setWithArray:catetoryMethodNames];
    NSMutableSet<NSString *> *hookedMethodNameSetM = [NSMutableSet setWithArray:hookedCatetoryMethodNames];
    NSMutableSet<NSString *> *handledMethodNameSetM = [NSMutableSet set];

    unsigned int methodCount = 0;
    Method *methods = class_copyMethodList(class, &methodCount);

    for (int i = 0; i < methodCount; i++) {
        Method method = methods[i];
        IMP imp = method_getImplementation(method);
        CocoaClassImpInfo *impInfo = [self impInfoForImp:imp];
        
        NSString *methodName = impInfo.methodName;
        if (methodName.length == 0
           || [handledMethodNameSetM containsObject:methodName]) {
            continue;
        }
        
        [handledMethodNameSetM addObject:methodName];
        
        if (impInfo.isCategory) { // category
           [methodNameSetM addObject:methodName];
           BOOL isHooked = ![[NSString cocoaHotReload_stringWithUTF8String:sel_getName(method_getName(method))] isEqualToString:methodName];
           if (isHooked) {
               [hookedMethodNameSetM addObject:impInfo.methodName];
           }
        }
    }
    
    if (isClassMethod) {
        gCategoryClassMethodsDicM[className] = methodNameSetM.allObjects;
        gHookedCategoryClassMethodsDicM[className] = hookedMethodNameSetM.allObjects;
    } else {
        gCategoryInstanceMethodsDicM[className] = methodNameSetM.allObjects;
        gHookedCategoryInstanceMethodsDicM[className] = hookedMethodNameSetM.allObjects;
    }
    
    free(methods);
}

// 原始实现所在的method
+ (Method)methodWithOrigImpForOriginClass:(Class)originClass
                                originSel:(SEL)originSel
                                baseClass:(Class)baseClass
                                  baseSel:(SEL)baseSel
                            isClassMethod:(BOOL)isClassMethod
{
    if (!originClass || !originSel)
    {
       return NULL;
    }
    
    NSString *baseClassName = NSStringFromClass(baseClass);
    NSString *baseSelName = NSStringFromSelector(baseSel);
    
    NSString *originClassName = NSStringFromClass(originClass);
    NSString *originSelName = NSStringFromSelector(originSel);
    
    Method originMethod = class_getInstanceMethod(originClass, originSel);
    IMP orginSelImp = method_getImplementation(originMethod);
    
    NSString *orginSelImpClassName = [self classNameForCategoryClassName:[self classNameForImp:orginSelImp]];
    NSString *orginSelImpMethodName = [self methodNameForImp:orginSelImp];
    
    if ([originClassName isEqualToString:orginSelImpClassName] &&
        [originSelName isEqualToString:orginSelImpMethodName]) { // 没有被hook或者hook出现异常，返回base
        return class_getInstanceMethod(baseClass, baseSel);
    }
    if (([baseClassName isEqualToString:orginSelImpClassName] &&
         [baseSelName isEqualToString:orginSelImpMethodName])) { // 递归结束
//        [self printClassInstanceMethodInfo:originClass];
        // 返回需要baseClass类需要替换的函数
        return class_getInstanceMethod(baseClass, originSel);
    } else {
        Class class = NSClassFromString(orginSelImpClassName);
        if (isClassMethod) {
            class = object_getClass(class);
        }
        SEL sel = sel_registerName(orginSelImpMethodName.UTF8String);
        if (class && sel) { // 递归查找
            return [self methodWithOrigImpForOriginClass:class originSel:sel baseClass:baseClass baseSel:baseSel isClassMethod:isClassMethod];
        } else { // 失败 返回base
            return class_getInstanceMethod(baseClass, baseSel);
        }
    }
}

// 打印类信息
+ (void)printClassInfoWithClass:(Class)class
{
    const char *classNameCString = object_getClassName(class);
    NSString *className = NSStringFromClass(class);
    
    NSArray *removedProtertyNames = [gRemovedPropertyNamesDicM valueForKey:className];
    
    DebugLog(@"------------- %s's address : %p", classNameCString, class);
    
    // Ivars
    DebugLog(@"------------- %s's Ivars ------------\n", classNameCString);
    unsigned int ivarCount = 0;
    Ivar *ivars = class_copyIvarList(class, &ivarCount);
    NSMutableArray *removedIvars = [NSMutableArray array];
    // add remove ivars
    [removedIvars addObjectsFromArray:[gRemovedIvarsDicM valueForKey:className]];
    // add remove property
    [removedIvars addObjectsFromArray:[gRemovedIvarsForPropertyDicM valueForKey:className]];

    for (int i = 0; i < ivarCount; i++) {
        const char *ivarName = ivar_getName(ivars[i]);
        BOOL isIvarRemoved = [removedIvars containsObject:[NSString cocoaHotReload_stringWithUTF8String:ivarName]];
        DebugLog(@"    %@ %@ \n", [NSString cocoaHotReload_stringWithUTF8String:ivarName], isIvarRemoved ? @"(Removed)" : @"");
    }
    free(ivars);
    
    // Properties
    DebugLog(@"------------- %s's Properties ------------\n", classNameCString);
    unsigned int propertyCount = 0;
    objc_property_t *properties = class_copyPropertyList(class, &propertyCount);
    for (int i = 0; i < propertyCount; i++) {
        const char *propertyName = property_getName(properties[i]);
        BOOL isPropertyRemoved = [removedProtertyNames containsObject:[NSString cocoaHotReload_stringWithUTF8String:propertyName]];
        DebugLog(@"    %s %s\n", propertyName, isPropertyRemoved ? "(Removed)" : "");
    }
    free(properties);
    
    // Protocol
    DebugLog(@"------------- %s's Protocols ------------\n", classNameCString);
    unsigned int protocolCount = 0;
    Protocol * __unsafe_unretained *protocols = class_copyProtocolList(class, &protocolCount);
    NSArray *removedProtocolNames = [gRemovedProtocolsDicM valueForKey:className];
    for (int i = 0; i < protocolCount; i++) {
        const char *protocolName = protocol_getName(protocols[i]);
        BOOL isProtocolRemoved = [removedProtocolNames containsObject:[NSString cocoaHotReload_stringWithUTF8String:protocolName]];
        DebugLog(@"    %s %s\n", protocolName, isProtocolRemoved ? "(Removed)" : "");
    }
    free(protocols);
    
    // Class Method
    DebugLog(@"------------- %s's Class Method -------------\n", classNameCString);
    unsigned int classMethodCount = 0;
    Method *classMethods = class_copyMethodList(object_getClass(class), &classMethodCount);
    for (int i = 0; i < classMethodCount; i++) {
        const char *methodName = sel_getName(method_getName(classMethods[i]));
        DebugLog(@"    %s\n", methodName);
    }
    free(classMethods);
    
    // Instance Method
    DebugLog(@"------------- %s's Instance Method -------------\n", classNameCString);
    unsigned int instanceMethodCount = 0;
    Method *instanceMethods = class_copyMethodList(class, &instanceMethodCount);
    
    for (int i = 0; i < instanceMethodCount; i++) {
      const char *methodName = sel_getName(method_getName(instanceMethods[i]));
      DebugLog(@"    %s\n",  methodName);
    }
    
    free(instanceMethods);
}

// Update Protocols
+ (void)updateProtocolsWithOldClass:(Class)oldClass newClass:(Class)newClass
{
    unsigned int oldProtocolCount = 0;
    Protocol * __unsafe_unretained *oldProtocols = class_copyProtocolList(oldClass, &oldProtocolCount);

    unsigned int newProtocolCount = 0;
    Protocol * __unsafe_unretained *newProtocols = class_copyProtocolList(newClass, &newProtocolCount);
    
    NSMutableArray *oldProtoclNames = [NSMutableArray array];
    for (int i = 0; i < oldProtocolCount; i++) {
        NSString *protocolName = [NSString cocoaHotReload_stringWithUTF8String:protocol_getName(oldProtocols[i])];
        if (protocolName) {
            [oldProtoclNames addObject:protocolName];
        }
    }
    
    NSMutableArray *newProtocolNames = [NSMutableArray array];
    for (int i = 0; i < newProtocolCount; i++) {
        Protocol *newProtocol = newProtocols[i];
        const char *protocolNameCString = protocol_getName(newProtocol);
        NSString *newProtocolName = [NSString cocoaHotReload_stringWithUTF8String:protocolNameCString];
        if (!newProtocolName)
            continue;
        [newProtocolNames addObject:newProtocolName];
        if (![oldProtoclNames containsObject:newProtocolName]) { // Need add
            // add protocol
            class_addProtocol(oldClass, newProtocol);
        } else {
            [oldProtoclNames removeObject:newProtocolName];
        }
    }
    
    [gRemovedProtocolsDicM setValue:oldProtoclNames forKey:NSStringFromClass(oldClass)];
    
    free(oldProtocols);
    free(newProtocols);
}

// Update Ivars
+ (void)updateIvarsWithOldClass:(Class)oldClass newClass:(Class)newClass
{
    unsigned int oldIvarCount = 0;
    Ivar *oldIvars = class_copyIvarList(oldClass, &oldIvarCount);

    unsigned int newIvarCount = 0;
    Ivar *newIvars = class_copyIvarList(newClass, &newIvarCount);
    
    NSMutableArray *oldIvarNames = [NSMutableArray array];
    for (int i = 0; i < oldIvarCount; i++) {
        NSString *ivarName = [NSString cocoaHotReload_stringWithUTF8String:ivar_getName(oldIvars[i])];
        if (ivarName) {
            [oldIvarNames addObject:ivarName];
        }
    }
    
    NSMutableArray *newIvarNames = [NSMutableArray array];
    for (int i = 0; i < newIvarCount; i++) {
        Ivar newIvar = newIvars[i];
        const char *ivarNameCString = ivar_getName(newIvar);
        NSString *newIvarName = [NSString cocoaHotReload_stringWithUTF8String:ivarNameCString];
        if (!newIvarName)
            continue;
        [newIvarNames addObject:newIvarName];
        if (![oldIvarNames containsObject:newIvarName]) { // Need add
            // 已创建的类不支持添加Add
            HRLog(@"⚠️ %s Add '%@' ivar failed:  Adding an instance variable to an existing class is not supported.", __func__, newIvarName);
        }
    }
    
    NSMutableArray *removedIvarNames = [NSMutableArray array];
    for (int i = 0; i < oldIvarCount; i++) {
        Ivar oldIvar = oldIvars[i];
        const char *ivarNameCString = ivar_getName(oldIvar);
        NSString *oldIvarName = [NSString cocoaHotReload_stringWithUTF8String:ivarNameCString];
        if (oldIvarName && ![newIvarNames containsObject:oldIvarName]) { // Need remove
            [removedIvarNames addObject:oldIvarName];
        }
    }
    
    [gRemovedIvarsDicM setValue:[removedIvarNames copy] forKey:NSStringFromClass(oldClass)];
    
    free(newIvars);
    free(oldIvars);
}

// Update Properties
+ (void)updatePropertiesWithOldClass:(Class)oldClass newClass:(Class)newClass
{
    unsigned int oldPropertyCount = 0;
    objc_property_t *oldPropertirs = class_copyPropertyList(oldClass, &oldPropertyCount);

    unsigned int newPropertyCount = 0;
    objc_property_t *newProperties = class_copyPropertyList(newClass, &newPropertyCount);
    
    NSMutableArray *oldPropertyNames = [NSMutableArray array];
    for (int i = 0; i < oldPropertyCount; i++) {
        [oldPropertyNames addObject:[NSString cocoaHotReload_stringWithUTF8String:property_getName(oldPropertirs[i])]];
    }

    for (int i = 0; i < newPropertyCount; i++) {
        objc_property_t newProperty = newProperties[i];
        const char *newPropertyName = property_getName(newProperty);
        if (![oldPropertyNames containsObject:[NSString cocoaHotReload_stringWithUTF8String:newPropertyName]]) { // Need add
            unsigned int attributeCount = 0;
            objc_property_attribute_t *attributes = property_copyAttributeList(newProperty, &attributeCount);
            class_addProperty(oldClass, newPropertyName, attributes, attributeCount);
            free(attributes);
        } else { // Need replace
            unsigned int attributeCount = 0;
            objc_property_attribute_t *attributes = property_copyAttributeList(newProperty, &attributeCount);
            class_replaceProperty(oldClass, newPropertyName, attributes, attributeCount);
            free(attributes);
        }
        
        // 处理过的移除
        [oldPropertyNames removeObject:[NSString cocoaHotReload_stringWithUTF8String:newPropertyName]];
    }
    
    unsigned int oldMethodCount = 0;
    Method *oldMethods = class_copyMethodList(oldClass, &oldMethodCount);
    
    NSMutableArray *removedMethodsForProperty = [NSMutableArray array];
    
    unsigned int newMethodCount = 0;
    Method *newMethods = class_copyMethodList(newClass, &newMethodCount);
    NSMutableArray *newInstanceMethodNames = [NSMutableArray array];
    for (int i = 0; i < newMethodCount; i++) {
        NSString *methodName = [NSString cocoaHotReload_stringWithUTF8String:sel_getName(method_getName(newMethods[i]))];
        if (methodName) {
            [newInstanceMethodNames addObject:methodName];
        }
    }
    
    unsigned int newIvarCount = 0;
    Ivar *newIvars = class_copyIvarList(newClass, &newIvarCount);
    NSMutableArray *newIvarNames = [NSMutableArray array];
    for (int i = 0; i < newIvarCount; i++) {
        NSString *ivarName = [NSString cocoaHotReload_stringWithUTF8String:ivar_getName(newIvars[i])];
        if (ivarName) {
            [newIvarNames addObject:ivarName];
        }
    }
    
    NSMutableArray *removedIvarsForProperty = [NSMutableArray array];
    
    // Need Remove
    for (NSString *propertyName in oldPropertyNames) {
        if (propertyName.length < 1)
            continue;
        // set method
        NSString *setMethodName = [self methodNameForPropertyName:propertyName isSetMethod:YES];
        // get method
        NSString *getMethodName = [self methodNameForPropertyName:propertyName isSetMethod:NO];
        BOOL removedSetMethod = NO;
        BOOL removedGetMethod = NO;
        for (int i = 0; i < oldMethodCount; i++) {
            Method oldMethod = oldMethods[i];
            SEL oldSel = method_getName(oldMethod);
            NSString *oldSelString = [NSString cocoaHotReload_stringWithUTF8String:sel_getName(oldSel)];
            if ([newInstanceMethodNames containsObject:oldSelString]) {
                // 类型函数手动创建 不删除
                continue;
            }
            if ([oldSelString isEqualToString:setMethodName]) {
                [self removeMethod:oldSel class:oldClass];
                removedSetMethod = YES;
                [removedMethodsForProperty addObject:oldSelString];
            } else if ([oldSelString isEqualToString:getMethodName]) {
                [self removeMethod:oldSel class:oldClass];
                removedGetMethod = YES;
                [removedMethodsForProperty addObject:oldSelString];
            }
            if (removedSetMethod && removedGetMethod) {
                break;
            }
        }
        NSString *ivarNameForProperty = [NSString stringWithFormat:@"_%@", propertyName];
        if (![newIvarNames containsObject:ivarNameForProperty]) { // Need remove ivar
            [removedIvarsForProperty addObject:ivarNameForProperty];
        }
    }
    
    NSString *className = NSStringFromClass(oldClass);
    [gRemovedPropertyNamesDicM setValue:[oldPropertyNames copy] forKey:className];
    [gRemovedIvarsForPropertyDicM setValue:[removedIvarsForProperty copy] forKey:className];
    [gRemovedMethodNamesForPropertyDicM setValue:[removedMethodsForProperty copy] forKey:className];
    
    free(oldPropertirs);
    free(newProperties);
    free(oldMethods);
    free(newMethods);
    free(newIvars);
}

// 返回属性的set函数
+ (NSString *)methodNameForPropertyName:(NSString *)propertyName isSetMethod:(BOOL)isSetMethod {
    
    if (propertyName.length == 0)
        return nil;
    if (!isSetMethod) {
        // get method name
        return propertyName;
    }
    
    // set method name
    return [NSString stringWithFormat:@"set%@%@", [[propertyName substringToIndex:1] uppercaseString], [propertyName substringFromIndex:1] ];
    
}

// Update Methods
+ (void)updateMethodsWithOldClass:(Class)oldClass
                         newClass:(Class)newClass
                    isClassMethod:(BOOL)isClassMethod
                      isLastClass:(BOOL)isLastClass
           ignoreClassMethodNames:(NSArray<NSString *> *)ignoreClassMethodNames
{
    NSMutableArray *ignoreClassMethodNamesM = [NSMutableArray array];
    for (NSString *ignoreClassMethodName in ignoreClassMethodNames) {
        [ignoreClassMethodNamesM addObject:[ignoreClassMethodName lowercaseString]];
    }
    char *methodType = isClassMethod ? "class" : "instance";
    // printf("【CocoaHotReload】Update %s method -------- old class : %p, new class : %p --------\n", methodType, oldClass, newClass);
    NSString *className = NSStringFromClass(newClass);
    NSArray *categoryMethodNames;
    if (isClassMethod) {
        categoryMethodNames = gCategoryClassMethodsDicM[className];
    } else {
        categoryMethodNames = gCategoryInstanceMethodsDicM[className];
    }
    
    unsigned int oldMethodCount = 0;
    Method *oldMethods = class_copyMethodList(oldClass, &oldMethodCount);
    
    unsigned int newMethodCount = 0;
    Method *newMethods = class_copyMethodList(newClass, &newMethodCount);
    
    NSMutableArray *newMethodNames = [NSMutableArray array];
    for (int i = 0; i < newMethodCount; i++) {
        Method newMethod = newMethods[i];
        NSString *newMethodName = [NSString cocoaHotReload_stringWithUTF8String:sel_getName(method_getName(newMethod))];
        
        if (isClassMethod
            && [ignoreClassMethodNamesM containsObject:[newMethodName lowercaseString]]) { // 最新类中，如果类函数(不区分大小写)需要忽略热重载，即用老类的实现替换新类的实现
            if (isLastClass) {
                Method oldMethod = class_getInstanceMethod(oldClass, NSSelectorFromString(newMethodName));
                IMP oldImp = method_getImplementation(oldMethod);
                if (oldImp) {
                    method_setImplementation(newMethod, oldImp);
                    [newMethodNames addObject:newMethodName];
                    continue;
                }
            } else { // 老类不需要替换
                [newMethodNames addObject:newMethodName];
                continue;
            }
        }
        
        if ([categoryMethodNames containsObject:newMethodName]) { // 分类函数不处理
            continue;
        }
        // 如果added为YES，表示新增函数成功(包括父类函数)，失败代表已存在函数(非父类函数)，使用更新
        BOOL added = class_addMethod(oldClass, method_getName(newMethod), method_getImplementation(newMethod), method_getTypeEncoding(newMethod));
        if (!added) { // 函数更新
            Method oldMethod = class_getInstanceMethod(oldClass, NSSelectorFromString(newMethodName));
            SEL oldSel = method_getName(oldMethod);
            Method shouldReplaceMethod = [self methodWithOrigImpForOriginClass:oldClass originSel:oldSel baseClass:oldClass baseSel:oldSel isClassMethod:isClassMethod];
            IMP newMethodImp = method_getImplementation(newMethod);
            const char *shouldReplaceMethodName = sel_getName(method_getName(shouldReplaceMethod));
            const char *shouldReplaceImpMethodName = [self methodNameForImp:method_getImplementation(shouldReplaceMethod)].UTF8String;
            
            if (shouldReplaceMethodName) {
                BOOL isCategory = [categoryMethodNames containsObject:[NSString stringWithUTF8String:shouldReplaceMethodName]];
                if (isCategory) { // 分类处理
                    // 这里需要最后一次替换再指向链表头部 否则会造成死循环
                    BOOL isHooked = shouldReplaceMethodName && shouldReplaceImpMethodName && strcmp(shouldReplaceMethodName, shouldReplaceImpMethodName) != 0;
                    if (isHooked && isLastClass) {  // hooked
                        Method needReplaceNewMethod = class_getInstanceMethod(newClass, sel_registerName(shouldReplaceMethodName));
                        // 新类替换原始函数实现指针
                        method_setImplementation(needReplaceNewMethod, newMethodImp);
                        
                        IMP oldMethodImp = method_getImplementation(oldMethod);
                        // newMethod -> 老函数实现 即指向hook函数链表头部
                        method_setImplementation(newMethod, oldMethodImp);
                    }
                }
                // 老类替换原始函数实现指针
                method_setImplementation(shouldReplaceMethod, newMethodImp);
            }
            
            // 兼容手Q qlvr hook处理
            NSString *qlvrSubClassName = [className stringByAppendingString:kQLVRObjectHookSubClassSuffix];
            Class qlvrSubClass = NSClassFromString(qlvrSubClassName);
            NSString *qlvrMethodName = [NSString stringWithFormat:@"%@%s", kQLVRObjectHookActionPrefix, shouldReplaceMethodName];
            Method qlvrMethod = class_getInstanceMethod(qlvrSubClass, NSSelectorFromString(qlvrMethodName));
            if (qlvrMethod) { // 存在对应的subClass，更新函数
                IMP imp = method_getImplementation(qlvrMethod);
                NSString *impClassName = [self classNameForImp:imp];
                // sub class -> origin imp
                Method originMethod = class_getInstanceMethod(newClass, method_getName(shouldReplaceMethod));
                IMP originImp = method_getImplementation(originMethod);
                if (originImp) {
                    method_setImplementation(qlvrMethod, originImp);
                }

                Method oldMethod = class_getInstanceMethod(oldClass, sel_registerName(shouldReplaceMethodName));
                IMP oldImp = method_getImplementation(oldMethod);

                NSString *oldImpMethodName = [self methodNameForImp:oldImp];

                if (![oldImpMethodName hasPrefix:kQLVRObjectHookActionPrefix]) { // no qlvr_action_xxx
                   // old class -> QLVRObjectHook qlvr_action_xxx
                   Class impClass = NSClassFromString(impClassName);
                   Method qlvrActionMethod = class_getInstanceMethod(impClass, NSSelectorFromString([NSString stringWithFormat:@"%@%@", kQLVRObjectHookActionPrefix, oldImpMethodName]));
                   IMP qlvrActionImp = method_getImplementation(qlvrActionMethod);
                   if (qlvrActionImp) {
                       method_setImplementation(oldMethod, qlvrActionImp);
                       if (isLastClass) { // 最后一次new class类也要替换下
                           Method newMethod = class_getInstanceMethod(newClass, sel_registerName(shouldReplaceMethodName));
                           method_setImplementation(newMethod, qlvrActionImp);
                       }
                   }
                }
            }
        }
        [newMethodNames addObject:newMethodName];
    }
    
    // 函数删除
    for (int i = 0; i < oldMethodCount; i++) {
        Method oldMethod = oldMethods[i];
        const char *oldMethodName = sel_getName(method_getName(oldMethod));
        if (oldMethodName && [categoryMethodNames containsObject:[NSString cocoaHotReload_stringWithUTF8String:oldMethodName]]) { // 不处理分类
            continue;
        }
        
        BOOL methodShouldRemove = ![newMethodNames containsObject:[NSString cocoaHotReload_stringWithUTF8String:oldMethodName]];
        if (methodShouldRemove) { // 函数移除
            // 兼容手Q qlvr hook处理 这里比较鸡肋 手Q qlvr做了特殊hook操作
            NSString *qlvrSubClassName = [className stringByAppendingString:kQLVRObjectHookSubClassSuffix];
            Class qlvrSubClass = NSClassFromString(qlvrSubClassName);
            if (qlvrSubClass) { // 存在对应的subClass，更新函数
                Method method = class_getInstanceMethod(qlvrSubClass, NSSelectorFromString([NSString stringWithFormat:@"%@%s", kQLVRObjectHookActionPrefix, oldMethodName]));
                if (method) { // qlvr sub class 存在该函数 不需要删除
                    continue;
                }
            }
            
            // 函数不需要删除，调用父类函数接口
            [self removeMethod: method_getName(oldMethod) class:oldClass];
        }
    }

    free(oldMethods);
    free(newMethods);
}

+ (void)replaceClassWithOldClass:(Class)oldClass
                        newClass:(Class)newClass
                     isLastClass:(BOOL)isLastClass
          ignoreClassMethodNames:(NSArray<NSString *> *)ignoreClassMethodNames
{
    if (oldClass == newClass)
        return;
    DebugLog(@"【Cocoa Hot Reload】Replace class --------  Old class's address : %p,  new class's address : %p -------- \n", oldClass, newClass);
    
    // Update Ivar
    [self updateIvarsWithOldClass:oldClass newClass:newClass];
    
    // Update Property
    [self updatePropertiesWithOldClass:oldClass newClass:newClass];
    
    // Update Protocol
    [self updateProtocolsWithOldClass:oldClass newClass:newClass];
    
    // Update Class Method
    [self updateMethodsWithOldClass:object_getClass(oldClass)
                           newClass:object_getClass(newClass)
                      isClassMethod:YES
                        isLastClass:isLastClass
             ignoreClassMethodNames:ignoreClassMethodNames];
    
    // Update Instance Method
    [self updateMethodsWithOldClass:oldClass
                           newClass:newClass
                      isClassMethod:NO
                        isLastClass:isLastClass
             ignoreClassMethodNames:ignoreClassMethodNames];
    
    DebugLog(@"【CocoaHotReload】Old class's updated info\n");
    [self printClassInfoWithClass:oldClass];
    
    DebugLog(@"【CocoaHotReload】New class's updated info\n");
    [self printClassInfoWithClass:newClass];
}

// 移除函数
+ (void)removeMethod:(SEL)sel class:(Class)class
{
    // 函数不需要删除，调用父类函数接口
    Method oldMethod = class_getInstanceMethod(class, sel);
    IMP superImp = class_getMethodImplementation([class superclass], sel);
    if (superImp) {
        // 调用父类的函数实现
        class_replaceMethod(class, sel, superImp, method_getTypeEncoding(oldMethod));
    }
}

@end


@implementation NSObject (CocoaClassTool)

+ (void)cocoaHotReload_hookFunctions
{
    // hook
    NSArray *hookInstanceMethodNames = @[
        NSStringFromSelector(@selector(valueForKey:)),
        NSStringFromSelector(@selector(valueForKeyPath:)),
        NSStringFromSelector(@selector(setValue:forKey:)),
        NSStringFromSelector(@selector(setValue:forKeyPath:)),
        NSStringFromSelector(@selector(isKindOfClass:)),
        NSStringFromSelector(@selector(isMemberOfClass:)),
    ];
    
    for (NSString *methodName in hookInstanceMethodNames) {
        [self cocoaHotReload_swizzleWithMethodName:methodName isClassMethod:NO];
    }
    
    NSArray *hookClassMethodNames = @[
        NSStringFromSelector(@selector(isSubclassOfClass:)),
    ];
    for (NSString *methodName in hookClassMethodNames) {
        [self cocoaHotReload_swizzleWithMethodName:methodName isClassMethod:YES];
    }
}

+ (void)cocoaHotReload_swizzleWithMethodName:(NSString *)methodName isClassMethod:(BOOL)isClassMethod
{
    Class class = isClassMethod ? object_getClass([NSObject class]) : [NSObject class];
    
    [CocoaClassTool swizzleInstanceMethodWithSel:NSSelectorFromString(methodName)
                                      swizzleSel:NSSelectorFromString([NSString stringWithFormat:@"cocoaHotReload_%@", methodName])
                                        forClass:class];
}


#pragma mark - NSObject method hook
#pragma mark - class method
+ (BOOL)cocoaHotReload_isSubclassOfClass:(Class)aClass
{
    NSString *className = NSStringFromClass(aClass);
    BOOL isHotReloaded = [gDidHotReloadClassNameSetM containsObject:className];
    if (!isHotReloaded) {
        //执行原始实现
        return [self cocoaHotReload_isSubclassOfClass:aClass];
    }
    // 都取原始类比较
    Class originClass = [CocoaClassTool orginClassForClassName:className];
    Class originAClass = [CocoaClassTool orginClassForClassName:NSStringFromClass(aClass)];
    return [originClass cocoaHotReload_isSubclassOfClass:originAClass];
}

#pragma mark - instance method
- (BOOL)cocoaHotReload_isKindOfClass:(Class)aClass
{
    NSString *className = NSStringFromClass(aClass);
    BOOL isHotReloaded = [gDidHotReloadClassNameSetM containsObject:className];
    if (!isHotReloaded) {
       //执行原始实现
       return [self cocoaHotReload_isKindOfClass:aClass];
    }
    
    BOOL isSubClass = [self.class isSubclassOfClass:aClass];
    BOOL isMember = [self isMemberOfClass:aClass];
    
    return isSubClass || isMember;
}

- (BOOL)cocoaHotReload_isMemberOfClass:(Class)aClass
{
    NSString *className = NSStringFromClass(aClass);
    BOOL isHotReloaded = [gDidHotReloadClassNameSetM containsObject:className];
    if (!isHotReloaded) {
       //执行原始实现
       return [self cocoaHotReload_isMemberOfClass:aClass];
    }
    
    BOOL isSameClass = [NSStringFromClass(self.class) isEqualToString:className];
    
    return isSameClass;
}

- (nullable id)cocoaHotReload_valueForKey:(NSString *)key
{
    NSString *className = NSStringFromClass(self.class);
    BOOL isHotReloaded = [gDidHotReloadClassNameSetM containsObject:className];
     if (!isHotReloaded) { // 执行原始实现
        return [self cocoaHotReload_valueForKey:key];
     }
    
    NSMutableArray *removedIvarNames = [NSMutableArray array];
    [removedIvarNames addObjectsFromArray:[gRemovedIvarsDicM valueForKey:className]];
    [removedIvarNames addObjectsFromArray:[gRemovedIvarsForPropertyDicM valueForKey:className]];
    
    if ([removedIvarNames containsObject:key] || [removedIvarNames containsObject:[NSString stringWithFormat:@"_%@", key]]) { // 变量被移除
        // 未找到该key
        // [<ClientViewController 0x104f0a3a0> valueForUndefinedKey:]: this class is not key value coding-compliant for the key intProperty.
        NSAssert(0, @"【Cocoa Hot Reload】 [<%@ %p> valueForUndefinedKey:]: this class is not key value coding-compliant for the key %@.", NSStringFromClass(self.class), self, key);
        return nil;
    } else {
       return [self cocoaHotReload_valueForKey:key]; // 执行原始实现
    }
}

- (void)cocoaHotReload_setValue:(nullable id)value forKey:(NSString *)key
{
    NSString *className = NSStringFromClass(self.class);
    
    BOOL isHotReloaded = [gDidHotReloadClassNameSetM containsObject:className];
    if (!isHotReloaded) {
        [self cocoaHotReload_setValue:value forKey:key]; // 执行原始实现
        return;
    }
    NSMutableArray *removedIvarNames = [NSMutableArray array];
    [removedIvarNames addObjectsFromArray:[gRemovedIvarsDicM valueForKey:className]];
    [removedIvarNames addObjectsFromArray:[gRemovedIvarsForPropertyDicM valueForKey:className]];
  
    if ([removedIvarNames containsObject:key] || [removedIvarNames containsObject:[NSString stringWithFormat:@"_%@", key]]) { // 变量被移除
        // 未找到该key
        // [<ClientViewController 0x10340a3e0> setValue:forUndefinedKey:]: this class is not key value coding-compliant for the key intProperty.
        NSAssert(0, @"【Cocoa Hot Reload】 [<%@ %p> setValue:forUndefinedKey:]: this class is not key value coding-compliant for the key %@.", NSStringFromClass(self.class), self, key);
    } else {
        [self cocoaHotReload_setValue:value forKey:key]; // 执行原始实现
    }
}

- (nullable id)cocoaHotReload_valueForKeyPath:(NSString *)keyPath
{
    NSString *className = NSStringFromClass(self.class);
    
    BOOL isHotReloaded = [gDidHotReloadClassNameSetM containsObject:className];
    if (!isHotReloaded) {
        return [self cocoaHotReload_valueForKeyPath:keyPath]; // 执行原始实现
    }
    
    NSRange firstPointRange = [keyPath rangeOfString:@"."];
    if (firstPointRange.location < keyPath.length) { // 有小数点 取第一个
        NSString *firstKey = [keyPath substringToIndex:firstPointRange.location];
        id firstValue = [self valueForKey:firstKey];
        NSString *subKeyPath = [keyPath substringFromIndex:firstPointRange.location + firstPointRange.length];
        return [firstValue valueForKeyPath:subKeyPath];
    }
    
    return [self valueForKey:keyPath];
}

- (void)cocoaHotReload_setValue:(nullable id)value forKeyPath:(NSString *)keyPath
{
    NSString *className = NSStringFromClass(self.class);
     
     BOOL isHotReloaded = [gDidHotReloadClassNameSetM containsObject:className];
     if (!isHotReloaded) {
         [self cocoaHotReload_setValue:value forKeyPath:keyPath]; // 执行原始实现
         return;
     }
    // 取小数点第一个
    NSRange firstPointRange = [keyPath rangeOfString:@"."];
    if (firstPointRange.location < keyPath.length) { // 有小数点 取第一个
        NSString *firstKey = [keyPath substringToIndex:firstPointRange.location];
        id firstValue = [self valueForKey:firstKey];
        NSString *subKeyPath = [keyPath substringFromIndex:firstPointRange.location + firstPointRange.length];
        [firstValue setValue:value forKeyPath:subKeyPath];
        return;
    }
    
    [self setValue:value forKey:keyPath];
}

@end

