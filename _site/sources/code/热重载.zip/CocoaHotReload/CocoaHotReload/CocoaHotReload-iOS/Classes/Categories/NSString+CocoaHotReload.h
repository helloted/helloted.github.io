//
//  NSString+CocoaHotReload.h
//  CocoaHotReload
//
//  Created by mambaxie on 2020/8/4.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (CocoaHotReload)

/// 根据cstring生成NSString
/// @param nullableCString 运行为nil的cstring，如果为nil 返回@""
+ (NSString *)cocoaHotReload_stringWithUTF8String:(const char *)nullableCString;

/// 获取设备型号
/// @param model 设备model
+ (NSString *)cocoaHotReload_deviceNameWithModel:(NSString *)model;

@end

NS_ASSUME_NONNULL_END
