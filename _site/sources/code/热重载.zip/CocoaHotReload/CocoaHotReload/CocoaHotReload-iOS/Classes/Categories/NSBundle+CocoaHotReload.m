//
//  NSBundle+CocoaHotReload.m
//  CocoaHotReload
//
//  Created by mambaxie on 2020/8/4.
//

#if ! __has_feature(objc_arc)
#error This file must be compiled with ARC. Use -fobjc-arc flag (or convert project to ARC).
#endif

#import "NSBundle+CocoaHotReload.h"
#import <Objc/runtime.h>
#import "CocoaHotReloadClientTool.h"
#import "CocoaClassTool.h"
#import <UIKit/UINibLoading.h>

@implementation NSBundle (CocoaHotReload)

+ (void)load
{
    [CocoaClassTool swizzleInstanceMethodWithSel:@selector(loadNibNamed:owner:options:)
                                      swizzleSel:@selector(cocoaHotReload_loadNibNamed:owner:options:)
                                        forClass:self];
}

- (nullable NSArray *)cocoaHotReload_loadNibNamed:(NSString *)name owner:(nullable id)owner options:(nullable NSDictionary<UINibOptionsKey, id> *)options
{
    NSBundle *bundle = [CocoaHotReloadClientTool bundleForHotReloadWithNibName:name];
    if (bundle) {
        return [bundle cocoaHotReload_loadNibNamed:name owner:owner options:options];
    }
    
    return [self cocoaHotReload_loadNibNamed:name owner:owner options:options];
}

@end
