//
//  USBSocketManager.m
//  CocoaHotReload-iOS
//
//  Created by guoyanshi on 2020/8/5.
//  Copyright © 2020 tencent. All rights reserved.
//

#if ! __has_feature(objc_arc)
#error This file must be compiled with ARC. Use -fobjc-arc flag (or convert project to ARC).
#endif

#import "USBDeviceSocketManager.h"
#import "CHRChannel.h"
#import <objc/runtime.h>
#import "NSString+CocoaHotReload.h"

NSString * const kChangeDeviceNotification = @"kChangeDeviceNotification";

@implementation USBSocketConnectInfo
- (void)setTargetModel:(NSString *)targetModel {
    _targetModel = [NSString cocoaHotReload_deviceNameWithModel:targetModel];
}


@end

@interface USBDeviceSocketManager ()
@property (nonatomic, strong)NSMutableArray *usbSocketAry;
@property (nonatomic, assign)NSString *currentUuid;

@end

@implementation USBDeviceSocketManager

+ (USBDeviceSocketManager *)shareInstance {
    static USBDeviceSocketManager *manager = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        manager = [USBDeviceSocketManager new];
    });
    return manager;
}

- (instancetype)init {
    if (self = [super init]) {
        _usbSocketAry = [NSMutableArray array];
    }
    return self;
}

- (void)addSocketConnectInfo:(USBSocketConnectInfo *)info {
    @synchronized (_usbSocketAry) {
        if (info) {        
            [_usbSocketAry addObject:info];
        }
    }
}

- (USBSocketConnectInfo *)getInfoWithDeviceID:(NSNumber *)deviceID {
    USBSocketConnectInfo *targetInfo = nil;
    @synchronized (_usbSocketAry) {
       for (USBSocketConnectInfo *info in _usbSocketAry) {
           if ([info.deviceID intValue] == [deviceID intValue]) {
               targetInfo = info;
               break;
           }
       }
    }
    return targetInfo;
}

- (USBSocketConnectInfo *)removeInfoWithDeviceID:(NSNumber *)deviceID {
    USBSocketConnectInfo *targetInfo = nil;
    @synchronized (_usbSocketAry) {
        NSArray *ary = [_usbSocketAry copy];
        for (USBSocketConnectInfo *info in ary) {
            if ([info.deviceID intValue] == [deviceID intValue]) {
                [_usbSocketAry removeObject:info];
                targetInfo = info;
            }
        }
    }
    return targetInfo;
}

- (BOOL)hasSocketConnectInfoWithDeviceID:(NSNumber *)deviceID {
    @synchronized (_usbSocketAry) {
        for (USBSocketConnectInfo *info in _usbSocketAry) {
            if ([info.deviceID intValue] == [deviceID intValue]) {
                return YES;
            }
        }
    }

    return NO;
}

#pragma mark - 设置真机设备
- (void)selectDeviceUuid:(NSString *)uuid notify:(BOOL)notify {
    if(![uuid isEqualToString:self.currentUuid]) {
        self.currentUuid = uuid;
        if (notify) {
            [[NSNotificationCenter defaultCenter] postNotificationName:kChangeDeviceNotification object:nil];
        }
    }
}

- (CHRChannel *)getCurrentConnectingChannel {
    CHRChannel *channel = nil;
    @synchronized (_usbSocketAry) {

       for (USBSocketConnectInfo *info in _usbSocketAry) {
           if ([info.uuid isEqualToString:self.currentUuid] && self.currentUuid) {
               channel = info.connectChannel;
           }
       }

    }
    return channel;
}

- (NSArray *)getAllConnetingSocketInfos {
    NSMutableArray *array = [NSMutableArray array];
    @synchronized (_usbSocketAry) {
        for (USBSocketConnectInfo *info in _usbSocketAry) {
            if (info.connectChannel) {
                [array addObject:info];
            }
        }
    }
    return [array copy];
}

@end
