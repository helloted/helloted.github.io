# Cocoa Hot Reload

[![market][market]][market-url] [![ci][oci]][oci-url] [![qcoverage][qcoverage]][qcoverage-url] ![MR][mr]

<!-- refers -->

[market]:http://market.raft.oa.com/badge/v?name=CocoaHotReload
[market-url]:http://market.raft.oa.com/project/CocoaHotReload
[oci]:http://badge.orange-ci.oa.com/QQWallet-OpenSource-iOS/CocoaHotReload.svg
[oci-url]:http://orange-ci.oa.com/build/log/latest?slug=QQWallet-OpenSource-iOS/CocoaHotReload
[qcoverage]:http://qcoverage.oa.com/badge/QQWallet-OpenSource-iOS/CocoaHotReload
[qcoverage-url]:http://qcoverage.oa.com/#/project/QQWallet-OpenSource-iOS/CocoaHotReload
[mr]:http://badge.orange-ci.oa.com/static/v1.svg?label=MR&message=welcome

## 项目介绍
通过动态库(.dylib)注入原理，实现iOS热重载功能。**(Tips：真机调试仅支持`iOS 13+`的设备)**

## 使用效果

<img src="./ReadMeResource/qq_demo.gif" width="1024">

## Features
- [x] 支持模拟器&真机(iOS 13+)
- [x] 支持ObjC属性和方法多种操作(增加|删除|修改)
- [x] 支持第三方库设置Symbol hidden by Default为YES
- [x] 支持修改多种文件类型(.h|.m|.mm|.swift|.storyboard|.xib)
- [x] 支持新增的文件进行hot reload
- [x] 支持通过命令行工具生成dylib
- [x] 支持Swift(仅支持函数替换)
- [x] 支持Storyboard&xib
- [x] 支持Unit Tests
- [x] 支持C函数
- [ ] 支持C++

## 应用接入

<a href="https://im.qq.com/mobileqq/" target="_blank"><img src="http://km.oa.com/files/photos/pictures/202012/1607589535_58_w364_h408.png" width="200"></a><a href="https://weixin.qq.com/" target="_blank"><img src="http://km.oa.com/files/photos/pictures/202012/1607569282_15_w364_h408.png" width="200"></a><a href="https://weread.qq.com/" target="_blank"><img src="http://km.oa.com/files/photos/pictures/202012/1607569282_33_w366_h408.png" width="200"></a><a href="https://browser.qq.com/" target="_blank"><img src="http://km.oa.com/files/photos/pictures/202012/1607569282_33_w364_h410.png" width="200"></a><a href="https://kg.qq.com/index-pc.html" target="_blank"><img src="http://km.oa.com/files/photos/pictures/202012/1607569281_42_w364_h400.png" width="200"></a><a href="https://wesingapp.com/" target="_blank"><img src="http://km.oa.com/files/photos/pictures/202012/1607569282_95_w364_h400.png" width="200"></a><a href="https://apps.apple.com/cn/app/%E7%9C%8B%E7%82%B9%E5%BF%AB%E6%8A%A5-%E8%85%BE%E8%AE%AF%E7%9C%8B%E7%82%B9%E5%85%B4%E8%B6%A3%E9%98%85%E8%AF%BB%E5%B9%B3%E5%8F%B0/id996866372" target="_blank"><img src="http://km.oa.com/files/photos/pictures/202012/1607569281_36_w366_h404.png" width="200"></a><a href="https://apps.apple.com/cn/app/%E6%8E%8C%E4%B8%8A%E9%81%93%E8%81%9A%E5%9F%8E/id919503025" target="_blank"><img src="http://km.oa.com/files/photos/pictures/202012/1607569281_24_w364_h400.png" width="200"></a><a href="http://mutation.oa.com/" target="_blank"><img src="http://km.oa.com/files/photos/pictures/202012/1607569281_30_w420_h424.png" width="220"></a>

## 快速上手

### 本工程主要分为两部分： 
- **Mac App** (Cocoa Hot Reload.app)
- **iOS framework** (CocoaHotReload.framework)，手Q工程已集成，其他项目如需使用，需将CocoaHotReload.framework导入工程

### 工作原理
<img src="./ReadMeResource/yuanli.png" width="1024">

### 项目架构

<img src="./ReadMeResource/framework_design.png" width="1024">

### 集成CocoaHotReload.framework （目前手Q已集成）
- #### 使用CocoaPods集成（建议）

在`Podfile`中添加如下配置

```shell
# 只在Debug模式下生效 configurations => ['Debug'] 请勿修改该项配置！！！
pod 'CocoaHotReload', :git => 'http://git.code.oa.com/QQWallet-OpenSource-iOS/CocoaHotReload.git', :configurations => ['Debug']

# 【可选】在Swift或混编工程中如果需要支持Swift热重载
pod 'SwiftHotReload', :git => 'http://git.code.oa.com/QQWallet-OpenSource-iOS/SwiftHotReload.git', :configurations => ['Debug']
```

##### 适配Mac Catalyst（参考CocoaHotReloadExample-CocoaPods）
在`Podfile`最后面添加如下配置
```shell
post_install do |installer|
    installer.pods_project.targets.each do |target|
        # Fix bundle targets' 'Signing Certificate' to 'Sign to Run Locally'
        if target.respond_to?(:product_type) and target.product_type == "com.apple.product-type.bundle"
            target.build_configurations.each do |config|
                config.build_settings['CODE_SIGN_IDENTITY[sdk=macosx*]'] = '-'
            end
        end
    end
end
```

- #### 手动集成

1、在工程根目录下创建`CocoaHotReload`文件夹，将`Products`文件夹中的`CocoaHotReload.framework` 拷贝到`CocoaHotReload`文件夹下

2、在工程中的`Build Settings -> Other Linker Flags -> Debug`添加如下配置，**切记这里只在Debug模式下添加**

##### 参考CocoaHotReloadExample
```shell
-l"c++" -force_load $(SRCROOT)/CocoaHotReload/CocoaHotReload.framework/CocoaHotReload 
```

其中-force_load 后面为`CocoaHotReload.framework/CocoaHotReload`路径，最终如下：
<img src="./ReadMeResource/build_settings_other_linker_flags_debug.png" width="666">

工程中的`Build Settings -> Header Search Paths -> Debug` 设置如下：
```shell
$(SRCROOT)/CocoaHotReload/CocoaHotReload.framework/Headers
```

##### 适配Mac Catalyst（参考CocoaHotReloadExample-MacCatalyst）
```shell
# Debug下配置多个架构对应的Other Link Flags
# Any iOS Simulator SDK
-l"c++" -force_load $(SRCROOT)/CocoaHotReload/CocoaHotReload.xcframework/ios-i386_x86_64-simulator/CocoaHotReload.framework/CocoaHotReload 
# Any macOS SDK
-l"c++" -force_load $(SRCROOT)/CocoaHotReload/CocoaHotReload.xcframework/ios-arm64_x86_64-maccatalyst/CocoaHotReload.framework/CocoaHotReload
# Any iOS SDK
-l"c++" -force_load $(SRCROOT)/CocoaHotReload/CocoaHotReload.xcframework/ios-arm64_arm64e_armv7_armv7s/CocoaHotReload.framework/CocoaHotReload
```
其中-force_load 后面为`CocoaHotReload.xcframework/${对应架构}/CocoaHotReload.framework/CocoaHotReload`路径，最终如下：
<img src="./ReadMeResource/build_settings_other_linker_flags_debug_maccatalyst.png" width="666">

工程中的`Build Settings -> Header Search Paths -> Debug` 设置如下：
```shell
$(SRCROOT)/CocoaHotReload/CocoaHotReload.xcframework/ios-arm64_x86_64-maccatalyst/CocoaHotReload.framework/Headers
```

3、【可选】在Swift或混编工程中如果需要支持Swift热重载，请先`git clone http://git.code.oa.com/QQWallet-OpenSource-iOS/SwiftHotReload.git`；
然后将`Products`文件夹中的`SwiftHotReloadTool.framework` 拷贝到`CocoaHotReload`文件夹下；
然后在工程中`Build Phases -> New Run Script Phase`添加如下脚本：
```shell
if [ ! -d $BUILT_PRODUCTS_DIR/$FRAMEWORKS_FOLDER_PATH ]; then
    mkdir $BUILT_PRODUCTS_DIR/$FRAMEWORKS_FOLDER_PATH
fi
if [ -d $BUILT_PRODUCTS_DIR/$FRAMEWORKS_FOLDER_PATH ]; then
    rm -rf $BUILT_PRODUCTS_DIR/$FRAMEWORKS_FOLDER_PATH/SwiftHotReload.framework 
fi

if [[ "${CONFIGURATION}" == "Debug" ]]; then

    echo "begin copy SwiftHotReload.framework into product"
    cp -R $PROJECT_DIR/CocoaHotReload/SwiftHotReload.framework $BUILT_PRODUCTS_DIR/$FRAMEWORKS_FOLDER_PATH

    if [ "${CODE_SIGNING_REQUIRED:-}" != "NO" ]; then
        /usr/bin/codesign --force --sign "${EXPANDED_CODE_SIGN_IDENTITY}" "$BUILT_PRODUCTS_DIR/$FRAMEWORKS_FOLDER_PATH/SwiftHotReload.framework"
    fi
fi

```

- #### RAFT集成

1. 安装环境前请将网络切换为：Tencent-OfficeWiFi

2. 安装 `fef flow`，`fef` 为我们的 RAFT 必要的工具链，请至官网下载[离线安装包](http://feflow.oa.com/download/)

3. 安装 `fef` 插件 `@tencent/feflow-plugin-raft` 和 `@tencent/generator-raft-universal`

```bash
# 这一步请在公司内网（有线网络、office-wifi、iOA VPN模式下执行）
fef install @tencent/feflow-plugin-raft
fef install @tencent/generator-raft-universal
```

安装后，执行 `fef doctor`，能看到 `@tencent/feflow-plugin-raft` 和 `@tencent/generator-raft-universal` 版本号，则安装成功，
更详细的 `fef` 相关内容请参考请参考 [fef 环境配置](http://raft.oa.com/guide/start-up.html#安装-cli)

4. 导入热加载组件

```
fef i CocoaHotReload
```

剩下的初始化步骤交给 RAFT 即可。


### 运行CocoaHotReload.framework
建议在`- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions`时执行，
**切记要用`#if DEBUG ... #endif` DEBUG宏**
1、导入CocoaHotReload.h

```ObjC
#if DEBUG
#import <CocoaHotReload.h>
#endif 
```

2、运行CocoaHotReload

```ObjC
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
#ifdef DEBUG
    [CocoaHotReload run];
#endif
    return YES;
}
```

### 手Q快速使用指引（以macOS Mojave(10.14.16) Xcode 11.3 为例）
1、使用以下终端命令，下载本仓库

  `git clone http://git.code.oa.com/QQWallet-OpenSource-iOS/CocoaHotReload.git`
  
2、双击运行根目录下`Products`文件夹中的`Cocoa Hot Reload` app，在状态栏上出现`⚡️`图标和`Cocoa Hot Reload Log`窗口即运行成功！

<img src="./ReadMeResource/start_log.png" width="666">

**Note:** 如出现如下错误提示：
<img src="./ReadMeResource/cannot_run.png" width="666">

请在终端（Terminal）上执行以下命令：
``` sudo xattr -rd com.apple.quarantine ./Products/Cocoa\ Hot\ Reload.app ```

如问题仍未解决，可参考：https://www.macwk.com/article/mac-catalina-1015-file-damage

3、点击状态栏`⚡️`图标， 选中`Select Project`，弹出文件选择，选择`QQMSFContact.xcworkspace`文件，如下：

<img src="./ReadMeResource/select_qq_project.png" width="666">

4、双击`QQMSFContact.xcworkspace`文件，`Command+R`运行手Q项目。

5、当`Cocoa Hot Reload Log`窗口出现 `🎉 项目初始化完成！` 表示开启热重载成功！如下：

<img src="./ReadMeResource/project_init_finished.png" width="666">

6、编辑项目文件，然后使用`Command+S`保存文件，然后点击状态栏(Status bar)中的`Hot Reload`按钮，或者使用默认快捷键`Command+Shift+H`触发热重载，当`Cocoa Hot Reload Log`窗口出现 `🎉 Reload success ...` 表示成功注入动态库并实现热重载！

<img src="./ReadMeResource/reload_success_log.png" width="666">

### Tips
1、状态栏图片颜色含义
 - 绿色 : 成功(空闲)
 - 黄色 : 执行中...
 - 红色 : 错误
 
2、项目路径 **不支持中文！不支持中文！不支持中文！** 如有路径为中文请调整为英文

3、如果需要默认选择指定工程，则可通过` “⚡” > “Preferences” > “Auto Select Project” `勾选即可。

4、如果Xcode自定义了`Derived Data`路径，请通过` “⚡” > “Preferences” > “Derived Data” `设置与Xcode配置一致即可。

5、如果涉及到单例问题，单例获取函数如果热重载后不想重新初始化，` “⚡” > “Preferences” > “热重载时，忽略类方法列表” `中添加指定函数，默认忽略的`类方法`如下：

``` 
// 热重载时，忽略类方法列表(用"|"分隔&不区分大小写)
GetInstance|shareInstance|sharedInstance|shareManager|sharedManager|defaultManager
```
 
6、本工具是依赖编译日志&编译产物，如出现```❌ Recompile command no found for xxx```表示未找到编译日志，请检查最近是否全量编译过，如无，可全量编译一次即可。

7、如果修改的是子工程的代码，请确保子工程代码有编译过，或者设置主工程依赖子工程，在编译主工程时就自动编译子工程代码。
 
8、当出现项目文件新增时，会使用`Apple Script`控制Xcode编译新增文件，此时会弹出“Cocoa Hot Relod”想使用辅助功能来控制这台电脑。授权弹框，点击`打开系统偏好设置`进行授权，如下：
 
<img src="./ReadMeResource/can_control.png" width="666">

## 行为准则
+ ##### 许可证
通过为 `CocoaHotReload` 做出贡献，代表您同意将其版权归为 `CocoaHotReload` 所有，开源协议为 [MIT LICENSE](./LICENSE)

+ ##### 分支规范
`feature/${userID}_${issueID}`
`bugfix/${userID}_${issueID}`

+ ##### issue
如果您在组件上架或者使用组件市场过程中发现 `Bug`，请通过 [issues](https://git.code.oa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues) 来提交并描述相关的问题，您也可以在这里查看其它的 [issue]((https://git.code.oa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues))，通过解决这些 `issue` 来贡献代码。特别的，标记为 `PR Welcome` 的 `issue` 是目前没有人解决，而且亟需大家群策群力来解决的，可以从这些 `issue` 下手贡献代码。

## 如何加入
请阅读[CONTRIBUTING.md](./CONTRIBUTING.md)了解我们的贡献流程，如果您在组件上架或者使用组件市场过程中有什么好的想法，我们十分期待您的任何贡献，欢迎提交 Merge Request 给我们。

## 团队介绍
iOS QQ支付开发团队
