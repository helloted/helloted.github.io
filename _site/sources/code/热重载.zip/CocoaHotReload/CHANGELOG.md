# ChangeLog (QQWallet-OpenSource-iOS/CocoaHotReload)

## [2020-12-15, Version  0.4.3](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.4.3)


### Bug fixes

 - [[```3a9a890d```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/3a9a890d6118607bc86793c68e638a1c3f9fe722)] __-__ #78 iPhone模拟器 x86_64出现 DobbyHook Crash (mambaxie) [#78](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/78)




## [2020-12-10, Version  mac-0.2.1](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/mac-0.2.1)



### Features

 - [[```4d5ac057```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/4d5ac057b59b662dd3c87aa4b608d4d7a56e3ad5)] __-__ #74 支持C函数热重载能力 (mambaxie) [#74](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/74)

### Bug fixes

 - [[```23aaee55```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/23aaee552fd9d171186b233032db56c30ebf30f2)] __-__ #77 swift类名移除targetName前缀标识 (mambaxie) [#77](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/77)
 - [[```5bbc9b95```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/5bbc9b95b4e70bf7c4f45206b9284f883f8650df)] __-__ #77 Swift热重载不生效 (mambaxie) [#77](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/77)
 - [[```9b598477```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/9b5984776ee844eb62826d3202d7b659749d51f9)] __-__ #77 Swift热重载不生效 (mambaxie) [#77](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/77)
 - [[```b8464b39```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/b8464b39c3aeae28acacd29b98caee3760c64b43)] __-__ #76 【命令行工具】修改swift文件，生成动态库时报错：unable to load standard library for target &#39;x86_64-apple-macosx10.15&#39; (mambaxie) [#76](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/76)
 - [[```e4a4267a```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/e4a4267af49e0987a39c0675dcd9455923ae124f)] __-__ #75 Swift进行热重载后，出现Crash (mambaxie) [#75](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/75)




## [2020-11-27, Version  0.4.2](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.4.2)



### Features

 - [[```3144f599```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/3144f599203d81b927d2afe716f8d753d83f0fd8)] __-__ #72 代码圈复杂度处理 (mambaxie) [#72](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/72)
 - [[```2afb755b```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/2afb755b84d16cda83520f86fefb5c823eaf056e)] __-__ #69 适配Mac Catalyst (mambaxie) [#69](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/69)
 - [[```c8f38f6e```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/c8f38f6e0ed48d50c8124c5f05db0a9716ae7922)] __-__ 增加leadtime自动任务 #71 (youkunhuang) [#71](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/71)
 - [[```303a021f```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/303a021f4dfdc74e11f40e1a0d28d53aa02702f9)] __-__ #69 适配Mac Catalyst - mac app端适配 (mambaxie) [#69](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/69)
 - [[```adb7b958```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/adb7b9583e12d2dba723bf431973b25db5d11e93)] __-__ #64 支持自定义Watching目录路径 (mambaxie) [#64](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/64)
 - [[```a1c64da7```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/a1c64da7f9b6fdeec01900549aa285ee3bf59201)] __-__ #64 支持自定义Watching目录路径 (mambaxie) [#64](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/64)

### Bug fixes

 - [[```2399de5e```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/2399de5e69409628257895ca9a5fbbe0b71c1908)] __-__ #66 子工程化代码，进行热重载，dlopen时，Symbol not found xxx错误 (mambaxie) [#66](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/66)
 - [[```5caca869```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/5caca8690d021f916e7a3136a576807087c7e489)] __-__ #65 热重载命令行工具build_dylib及reload均显示正常，但并未执行修改后代码 (mambaxie) [#65](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/65)




## [2020-11-19, Version  mac-0.2.0](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/mac-0.2.0)



### Features

 - [[```a4eb6dbb```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/a4eb6dbb96ac5e74e8f0ad31fe5938a01b140d93)] __-__ #64 支持自定义Watching目录路径 (mambaxie) [#64](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/64)
 - [[```82b687f2```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/82b687f23cbaab1db57dfd8150b8b16519bfc0f7)] __-__ #64 支持自定义Watching目录路径 (mambaxie) [#64](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/64)

### Bug fixes

 - [[```b6be000b```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/b6be000b09b774383085f9d8356537418011a88a)] __-__ #66 子工程化代码，进行热重载，dlopen时，Symbol not found xxx错误 (mambaxie) [#66](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/66)
 - [[```f9e14418```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/f9e14418c5b88592192ac5f5bb3b074f587ebd3f)] __-__ #65 热重载命令行工具build_dylib及reload均显示正常，但并未执行修改后代码 (mambaxie) [#65](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/65)




## [2020-11-03, Version  0.4.1](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.4.1)



### Features

 - [[```489c0d94```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/489c0d949b13b3d6c2aeff0219e10a376b529c6b)] __-__ #56 支持Unit Tests热重载 (mambaxie) [#56](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/56)
 - [[```260fc3a6```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/260fc3a68e07f338b09a828e599ace91186f398d)] __-__ #56 支持Unit Tests热重载 (mambaxie) [#56](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/56)
 - [[```ad26734a```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/ad26734a70d0e59689ff433e19e6f8772513d128)] __-__ #58 适配移动硬盘 (mambaxie) [#58](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/58)
 - [[```ffdf26fb```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/ffdf26fbfdeae864e627f798e2f653e9e95cd1d5)] __-__ #58 适配移动硬盘 (mambaxie) [#58](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/58)
 - [[```12d7c58a```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/12d7c58ac7f488e1458bdbfe4ecd89932322cb1c)] __-__ #57 适配Xcode12 Swift热重载 (mambaxie) [#57](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/57)
 - [[```e6b95a13```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/e6b95a139d3f25f37932fd17fa27099e1cd64938)] __-__ #57 适配Xcode12 Swift热重载 (qingyuanyu) [#57](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/57)
 - [[```cd4022b9```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/cd4022b98cfcdf0ffcf41511114ad56105ba8b25)] __-__ #57 适配Xcode12 Swift热重载 (qingyuanyu) [#57](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/57)

### Bug fixes

 - [[```8b3dd16d```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/8b3dd16d9d90b076a1b157c5036fb0f8e6aee7f0)] __-__ #59 .o依赖的私有符号库依赖其他私有符号库时，dlopen error: Symbol not found: xxx (mambaxie) [#59](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/59)




## [2020-10-14, Version  mac-0.1.9](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/mac-0.1.9)


### Bug fixes

 - [[```265dba43```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/265dba43295d5370d1a247a25b5ab8d27f950b36)] __-__ #23 dlopen时，出现Symbol not found: _OBJC_xxx问题 (mambaxie) [#23](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/23)




## [2020-09-27, Version  0.4.0](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.4.0)





## [2020-09-13, Version  mac-0.1.8](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/mac-0.1.8)



### Features

 - [[```775fe52a```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/775fe52a00ee2f88556b38f037d3d41c9c2ebef1)] __-__ #48 支持自定义DerivedData路径 (mambaxie) [#48](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/48)

### Bug fixes

 - [[```0bb1ee98```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/0bb1ee9815d86f614f936b0e8fbcfb637408d2d4)] __-__ 修复抽离tcp导致连接问题 (mambaxie) 
 - [[```f6e7db2d```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/f6e7db2d043391bd0d334cd34187223de5f22fd2)] __-__ #55 修改Category文件后，dlopen error: Symbol not found: _OBJC_IVAR_$_xx (mambaxie) [#55](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/55)




## [2020-09-05, Version  0.3.9](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.3.9)





## [2020-08-27, Version  mac-0.1.7](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/mac-0.1.7)



### Features

 - [[```4a8732be```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/4a8732be6dbd2b6f60f7ff4fdfb4cf3bb3044362)] __-__ #52 接入atta数据上报 (mambaxie) [#52](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/52)
 - [[```d5edce55```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/d5edce550c8dcbae0d5c76a735039d16ad7cf0c5)] __-__ #52 接入atta数据上报 (mambaxie) [#52](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/52)
 - [[```12746f11```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/12746f1139d313b7e777c87533db542c085b7767)] __-__ __epc__: 完善工作流相关构建能力 #51 (zoeyi) [#51](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/51)

### Bug fixes

 - [[```837d3342```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/837d3342bd0989c7b75a34baac013411503e18ac)] __-__ #49 优化真机连接提示 (guoyanshi) [#49](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/49)
 - [[```06638c15```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/06638c1521c9b2c76943ccff7bb5104aa72701ff)] __-__ #49 真机链接提示优化 (guoyanshi) [#49](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/49)
 - [[```8557e8f4```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/8557e8f430249ce26610d7af3939200165a94d96)] __-__ #47 依赖了C++或者C符号的库，dlopen报Symbol not found (mambaxie) [#47](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/47)




## [2020-08-11, Version  0.3.8](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.3.8)



### Features

 - [[```4bfa6097```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/4bfa6097f05d48877890cd54e2ee07f9d5496d25)] __-__ #49 支持选择某一真机设备连接 (guoyanshi) [#49](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/49)
 - [[```b62bc93e```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/b62bc93e0ac2e1b4a526cd84f17200b086e4737b)] __-__ #49 支持选择某一真机设备连接 (guoyanshi) [#49](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/49)

### Bug fixes

 - [[```3059e4a6```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/3059e4a6f632791a8fa3699e4eb7f0f3720da059)] __-__ #50 fishhook与其他业务冲突，导致duplicate symbols (mambaxie) [#50](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/50)
 - [[```6bde64ce```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/6bde64cea9bb22c61fd395560ee0f747679d316f)] __-__ #49 整理socket连接代码 (guoyanshi) [#49](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/49)
 - [[```3c798d09```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/3c798d09b61ac566e0e566d834fa3a5e02ae3046)] __-__ #49 修改通知没有移除 (guoyanshi) [#49](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/49)
 - [[```ef7ce570```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/ef7ce570d7ecabb5914146ac1415560a638702c9)] __-__ #47 依赖了C++或者C符号的库，dlopen报Symbol not found (mambaxie) [#47](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/47)




## [2020-08-05, Version  0.3.7](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.3.7)





## [2020-08-04, Version  0.3.6](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.3.6)



### Features

 - [[```c400c094```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/c400c0946c43d93a21daa19f6d7e131a6ef34031)] __-__ #44 支持Storyboard&amp;xib文件的热重载 (mambaxie) [#44](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/44)




## [2020-08-04, Version  mac-0.1.6](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/mac-0.1.6)



### Features

 - [[```64663aba```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/64663aba70795e051062ca97d2fc767dd412c5f0)] __-__ #44 支持Storyboard&amp;xib文件的热重载 (mambaxie) [#44](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/44)
 - [[```518c5799```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/518c5799bc58d37d032d9e7b8ea60b82b26b1eb1)] __-__ #41 参数遗漏提交 (qingyuanyu) [#41](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/41)
 - [[```314d59c2```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/314d59c23617beeb78ccc40a85d14ad857f6fd64)] __-__ #41 Swift热重载动态库更新 (qingyuanyu) [#41](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/41)
 - [[```09d42be4```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/09d42be48e1fadbb01a3453bce823f6581a72752)] __-__ #24 cmdTool支持自定义derivedData路径处理 (mambaxie) [#24](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/24)
 - [[```12d9fc15```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/12d9fc156a3cbe3924c47ca3d4830a23f24142e8)] __-__ #41 更新example (mambaxie) [#41](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/41)
 - [[```1fa8592c```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/1fa8592c9e47d3d795c044ad38832499d6b6f6d6)] __-__ #37 解析日志时，编译指令查找支持Swift (mambaxie) [#37](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/37)
 - [[```76b17a80```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/76b17a80d25ad5102c64dca5edc52fdb4bc08c36)] __-__ #41 调整swift热重载类获取方式 (mambaxie) [#41](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/41)
 - [[```1ccfbd8c```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/1ccfbd8ce7516812b6944da29b7dc4d3966495e8)] __-__ #41 demo更新 (qingyuanyu) [#41](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/41)
 - [[```6024ece4```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/6024ece40754179348bcc8580f9e87ee1647457d)] __-__ #41 更新demo，readme (qingyuanyu) [#41](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/41)

### Bug fixes

 - [[```d3855b2b```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/d3855b2bac46545ec36b23d9bc32b5cf699a9d94)] __-__ #42 命令行工具生成动态库时，Xcode 11.2报错dyld: Symbol not found: _objc_opt_new (mambaxie) [#42](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/42)
 - [[```66779a01```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/66779a0123ee8b7908ef7a2007e617f0e2095ff7)] __-__ #43 热重载时，dlopen报错：Symbol not found: ___llvm_profile_runtime (mambaxie) [#43](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/43)




## [2020-07-30, Version  0.3.5](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.3.5)



### Features

 - [[```7350be58```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/7350be585e3f847dea2901c0a57bd7dc58d46268)] __-__ #41 支持Swift热重载，提交Product (qingyuanyu) [#41](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/41)
 - [[```4f772863```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/4f772863447950987ddf7b4290ef99fbe353a1ea)] __-__ #41 支持对Swift代码热重载 (qingyuanyu) [#41](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/41)

### Bug fixes

 - [[```ec3ab3ac```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/ec3ab3ac8ea388f73808df28a989196f2dd59b8e)] __-__ #40 热重载后，isKindOfClass: 函数判断异常 (mambaxie) [#40](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/40)
 - [[```08e3b2f2```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/08e3b2f22f4c589123633a07777b5beba3bde3a3)] __-__ #29 修改socket连接失败后，没有close (guoyanshi) [#29](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/29)




## [2020-07-30, Version  mac-0.1.5](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/mac-0.1.5)



### Features

 - [[```01b36770```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/01b36770b130a2bfc2053f45530401120f399840)] __-__ #24 CMDTOOL=1 宏只在CocoaHotReload-cmdTool设置 (mambaxie) [#24](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/24)
 - [[```405205e9```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/405205e981600840b85f937a54b1930f60819171)] __-__ #24 新增CocoaHotReloadExample-cmdTool (mambaxie) [#24](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/24)
 - [[```80db1960```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/80db19603d4dacad64ddc20773f2a2834ce1bfba)] __-__ #24 mac端支持命令行工具 (mambaxie) [#24](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/24)
 - [[```c8331451```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/c8331451177975b438fac2c2a69cd18e0f9361ae)] __-__ #37 解析日志时，编译指令查找支持Swift (mambaxie) [#37](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/37)

### Bug fixes

 - [[```19c6715e```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/19c6715ec8610fcb4ecf154c80b23c74a039387e)] __-__ #39 修复Xcode Build 出现error，程序正常运行时，导致热重载获取签名失败问题 (mambaxie) [#39](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/39)
 - [[```b0716075```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/b0716075c0e114b330625d5a9a583b6650d32e52)] __-__ #38 修复自定义Configuration时，导致编译产物查找失败问题 (mambaxie) [#38](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/38)
 - [[```00cec7c7```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/00cec7c729bffce75645371f3f9958dc8f4734e3)] __-__ #35 代码整理 (mambaxie) [#35](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/35)
 - [[```81d4d827```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/81d4d82727567d64c8cd102d8d7c1b2947e4debb)] __-__ #35 整理代码 (mambaxie) [#35](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/35)
 - [[```6e957ef2```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/6e957ef2962aac3f67af2991f16b09d9b0723393)] __-__ #35 修改方法名 (guoyanshi) [#35](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/35)
 - [[```2426575d```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/2426575d5b96bd56abbd2179834e267fd1ef76e0)] __-__ #36 更新组件Demo预览 (guoyanshi) [#36](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/36)
 - [[```f5301abd```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/f5301abd5abd8f2489147632a25473a5052704cd)] __-__ #35 整理mac端tool相关代码 (mambaxie) [#35](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/35)




## [2020-07-24, Version  0.3.4](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.3.4)


### Bug fixes

 - [[```e108472a```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/e108472a4bc926d8ae083291ea14e8a4216f848e)] __-__ #12 bumped version to 0.3.4 (mambaxie) [#12](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/12)
 - [[```23025fca```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/23025fca82a66e0589043c651bd3d3bff2b914d0)] __-__ #1 整理自动选择路径代码 (guoyanshi) [#1](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/1)
 - [[```f36c1f2b```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/f36c1f2b66b7a3a72f719031e1e40f6a97b478be)] __-__ #12 bumped version to 0.3.4 (mambaxie) [#12](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/12)
 - [[```dcc67d96```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/dcc67d968f88fa1745c2fe4875dfefdf8856fa85)] __-__ #33 修复重写父类函数，执行hot reload导致死循环问题 (mambaxie) [#33](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/33)
 - [[```076c6173```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/076c61738f94b27a6c4645ff563db7f64742feed)] __-__ #4 优化签名方式 (mambaxie) [#4](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/4)
 - [[```5e6d72b9```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/5e6d72b9e8668c0483b205d1f376dedc846fc724)] __-__ #4 优化签名方式 (mambaxie) [#4](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/4)
 - [[```0f4b879d```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/0f4b879d89ea02ef54c6e46f61f22fba839b0aa8)] __-__ #4 新增Category method预更新及优化更新速度 (mambaxie) [#4](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/4)
 - [[```7d74e3ae```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/7d74e3aea156e7fd475b23d3f7e323ee89c5b0a4)] __-__ #2 优化开机自启动功能 (guoyanshi) [#2](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/2)
 - [[```ee287b13```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/ee287b131536fa00a8bf43d432b025efa36112cc)] __-__ #34 修改Mac端socket 连接时野指针crash (guoyanshi) [#34](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/34)
 - [[```1871a451```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/1871a4512d138d45d1b85d906108fbd40d23b142)] __-__ #14 增加设备连接提示 (guoyanshi) [#14](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/14)
 - [[```99279cf9```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/99279cf9ced9ad14dce2213113a1cbd7cf00c5ed)] __-__ #4 优化Handle invoke cycle 处理 (mambaxie) [#4](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/4)
 - [[```3e444376```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/3e4443765b2e879d2afe58f6323f60f0385bccdc)] __-__ #18 更新demo使用说明 (guoyanshi) [#18](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/18)
 - [[```21f1e243```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/21f1e243a68f7d96e884b64a7ac253e598f1a711)] __-__ #34 修复Category Method 判断方式错误，导致热重载异常问题 (mambaxie) [#34](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/34)




## [2020-07-20, Version  0.3.3](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.3.3)


### Bug fixes

 - [[```03b88403```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/03b884034066e81e1940ecc26cc6ec3d9d150275)] __-__ #30 修改fishhook冲突 (guoyanshi) [#30](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/30)
 - [[```4de2cff1```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/4de2cff1f9a9451c2713f06fe61bc430068d3bc3)] __-__ #18 更新Demo 连接状态 (guoyanshi) [#18](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/18)
 - [[```6f8a66f2```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/6f8a66f2c73d51156577af176abbfb97844ce94d)] __-__ #29 修复 socket 频繁创建导致crash (guoyanshi) [#29](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/29)
 - [[```cdb85133```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/cdb851339d85a9e8dff507fea37d633067ddc6a5)] __-__ #10 完善文档说明 (guoyanshi) [#10](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/10)
 - [[```8ed94192```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/8ed9419294b508a208997ee871293eba10b860bb)] __-__ #10 完善文档说明 (guoyanshi) [#10](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/10)
 - [[```bf8e7c0d```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/bf8e7c0d3b0074e47b7b94b8d6ab6d2f5569dfb6)] __-__ #10 完善文档说明 (guoyanshi) [#10](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/10)
 - [[```79b7eee8```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/79b7eee80381d35539e01f6aab3ef079fcbce638)] __-__ #10 完善文档说明 (guoyanshi) [#10](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/10)
 - [[```2f50e8b1```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/2f50e8b181f60868a199c3cdbf2d959ed9282c6e)] __-__ #10 完善文档说明 (guoyanshi) [#10](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/10)
 - [[```dbe5dc98```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/dbe5dc98f495c6797a5338dfcbc75394a288cd4b)] __-__ #10 完善文档说明 (guoyanshi) [#10](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/10)
 - [[```2119999c```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/2119999c5cb0be3c042bdfd6739517b4e6e6eec8)] __-__ #12 更新com_raft文件 (guoyanshi) [#12](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/12)
 - [[```08703dfe```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/08703dfe8509717c031735644cb933b743a4873a)] __-__ #12 增加config文件 (guoyanshi) [#12](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/12)
 - [[```68415d6e```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/68415d6ea0020064fa1cb242c179cb56d673e078)] __-__ #12 版本更新 修改编译报错 (guoyanshi) [#12](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/12)
 - [[```05a9bbc4```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/05a9bbc4e688f92382fb50b6d2566b46c3ac8f4a)] __-__ #12 更新podspec (guoyanshi) [#12](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/12)
 - [[```9f814682```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/9f8146825f70f7bb0123608c822b2bea44180525)] __-__ #12 更新podspec (guoyanshi) [#12](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/12)




## [2020-07-16, Version  mac-0.1.4](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/mac-0.1.4)



### Features

 - [[```8c2a1adf```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/8c2a1adfe117de415b703ee5659680e4fa966cb5)] __-__ #28 mac端支持忽略指定类函数的热重载 (mambaxie) [#28](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/28)

### Bug fixes

 - [[```1768238f```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/1768238fac618d6873280b7cdf41efdaa041c28a)] __-__ #12 bumped version to 0.3.2 (mambaxie) [#12](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/12)




## [2020-07-16, Version  0.3.2](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.3.2)


### Bug fixes

 - [[```643b5487```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/643b54873d58172db60a3b8e2da5c7a623e0a357)] __-__ #27 修复当修改单例&amp;执行热重载后，产生了新的对象问题 (mambaxie) [#27](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/27)
 - [[```97d5c639```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/97d5c6392b3f6ea9969a33b3641a18157212a001)] __-__ #12 bumped version to 0.3.1 (mambaxie) [#12](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/12)




## [2020-07-16, Version  0.3.1](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.3.1)



### Features

 - [[```87223504```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/87223504bc8c005875a48604fd4b48487ce37d83)] __-__ #25 CocoaHotReload.framework 支持通过cocoahotreload 命令行工具产生的dylib进行热重载 (mambaxie) [#25](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/25)

### Bug fixes

 - [[```548dc1c0```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/548dc1c0011ec86867f81e51ecb42d67e6cc33d9)] __-__ #26 修复修改单例代码后导致crash问题 (mambaxie) [#26](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/26)
 - [[```c05a06bb```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/c05a06bbaae6a53489129afdac3ae4ffaa1b5dbf)] __-__ #2 整理代码 (guoyanshi) [#2](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/2)
 - [[```c6a2f69f```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/c6a2f69f1d17cee4e1879a779511928fb06e2048)] __-__ #15 真机获取签名失败兼容性处理&amp;优化签名获取和项目初始化 (mambaxie) [#15](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/15)
 - [[```4b1b4b2f```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/4b1b4b2f8afca639cebcfaa9a95985b9a2900313)] __-__ #2 mac端工具支持开机自启动 (guoyanshi) [#2](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/2)
 - [[```863a3a1f```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/863a3a1f63dcc95219cff3eeab52d2e56d6ef0e1)] __-__ #10 上传文档插图 (holyli-mcbook) [#10](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/10)
 - [[```4b0b9332```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/4b0b9332e2f5ec226d0d78e0e1310806c7c8c717)] __-__ #10 更新项目文档 (holyli) [#10](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/10)




## [2020-07-09, Version  mac-0.1.3](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/mac-0.1.3)


### Bug fixes

 - [[```8138b525```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/8138b5255dd634461c6f5994184b8a44064e5916)] __-__ #23 修复部分库路径查找失败问题，导致.o link不到出现symbol not found问题 (mambaxie) [#23](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/23)




## [2020-07-08, Version  mac-0.1.2](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/mac-0.1.2)





## [2020-07-08, Version  0.2.9](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.2.9)


### Bug fixes

 - [[```9f98feed```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/9f98feed25314c350f51f94cdf4de62bcb7e68c2)] __-__ #12 bumped version to 0.2.9 (mambaxie) [#12](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/12)
 - [[```34d3e8a8```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/34d3e8a8cd183ee2a5dd7b48b22353cb1318eb85)] __-__ #22 修复UITest耗时过长问题，tcp重连间隔改为3s，并在子队列连接 (mambaxie) [#22](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/22)
 - [[```262067d8```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/262067d8df3667f2af86fb24eb7c44f96d0618bf)] __-__ #20 修复查找.o库，出现相互依赖时导致递归死循环问题 (mambaxie) [#20](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/20)




## [2020-07-03, Version  mac-0.1.1](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/mac-0.1.1)


### Bug fixes

 - [[```239ec62f```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/239ec62fa05a5a64b54d8c3d6a7e64f70f2b663f)] __-__ #19 优化unzip log存储，清空多余log文件 (mambaxie) [#19](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/19)




## [2020-07-03, Version  mac-0.1.0](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/mac-0.1.0)


### Bug fixes

 - [[```44a1ebc1```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/44a1ebc18c891b3dcc5f0e47be89f1cd2113fb2f)] __-__ #12 Update mac app to version 0.1.0 (mambaxie) [#12](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/12)
 - [[```005abbca```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/005abbcac2ef783c64dd0d28c51b830ddf1dd06c)] __-__ #12 Update mac app to version 0.1.0 (mambaxie) [#12](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/12)
 - [[```11d6dcf7```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/11d6dcf70f1d8de0a96998c4d04b2580519f1b26)] __-__ #17 优化exported symbol 依赖库的加载 (mambaxie) [#17](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/17)
 - [[```e8c03daa```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/e8c03daa917e8a582e359a3f5688650236b91f12)] __-__ #12 update mac app to version 0.0.9 (mambaxie) [#12](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/12)
 - [[```a59c1819```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/a59c1819729da17b03596206da7660927ddd9f06)] __-__ #12 update mac app to version 0.0.9 (mambaxie) [#12](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/12)
 - [[```fbff9ef2```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/fbff9ef275237f3ce995667bf8616abbaab23c37)] __-__ #19 处理Mac日志未及时清除问题，设置上限20G (mambaxie) [#19](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/19)




## [2020-07-03, Version  0.2.8](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.2.8)


### Bug fixes

 - [[```832abb33```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/832abb33589924c928d20ca95ecba65006615eb5)] __-__ #18 update CocoaHotReloadExample-CocoaPods (mambaxie) [#18](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/18)
 - [[```db7b0617```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/db7b0617e0d7d79194acb8da8ea5972dc197a4f1)] __-__ #12 update CocoaHotReload.framework to version 0.2.8 (mambaxie) [#12](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/12)
 - [[```4ff71e19```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/4ff71e199077fafb5bf8e10ef484065ed72a3f24)] __-__ #14 增加安全检验 (guoyanshi) [#14](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/14)




## [2020-07-02, Version  0.2.7](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.2.7)


### Bug fixes

 - [[```8f24083b```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/8f24083bf1ef631ac9e459156fc2e6d425a25244)] __-__ #12 Bumped version to 0.2.7 (mambaxie) [#12](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/12)
 - [[```b1e0517f```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/b1e0517fe3a5e6f68bfb5d639bb7b3875ff47d1f)] __-__ #12 Update CocoaHotReload.framework to version 0.2.7 (mambaxie) [#12](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/12)
 - [[```066ae942```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/066ae942ea483c1eb7fdc308df6755ebb457afd0)] __-__ #4 优化replace class &amp; 兼容手Q qlvr 处理 (mambaxie) [#4](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/4)
 - [[```1eba2572```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/1eba25727636fdfbb758f6f15b5d61f48a08ce3b)] __-__ #6 处理hook函数导致死循环问题 (mambaxie) [#6](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/6)
 - [[```57898a59```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/57898a599198d257f08fe190385768bf2ae4b0fb)] __-__ #16 日志输出窗口支持清理导出操作 (guoyanshi) [#16](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/16)
 - [[```423f27ba```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/423f27baf1e6c96f27fb2d9ebe5b21323404d5d8)] __-__ #14 支持链接时，对设备的校验 (guoyanshi) [#14](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/14)
 - [[```e00944f7```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/e00944f704bd304eaf85a207da0dac8ed2b77e8d)] __-__ #13  修复hot reload 后，出现死循环问题 (mambaxie) [#13](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/13)
 - [[```ca4c32b6```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/ca4c32b6666db7460bea7d584bf46f2356514c55)] __-__ #11 修复hot reload后函数不生效问题 (mambaxie) [#11](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/11)




## [2020-06-29, Version  0.2.5](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.2.5)


### Bug fixes

 - [[```13b880fa```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/13b880fa92c2afe82ba299236f6290acb37eae82)] __-__ #6 优化category 中hook函数处理 (mambaxie) [#6](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/6)
 - [[```1e89282c```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/1e89282c0ae20cf4927ec3d973f7c0563c948326)] __-__ #4 优化私有符号库查找方式&amp;日志解析后的存储清理 (mambaxie) [#4](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/4)
 - [[```00e0511e```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/00e0511edcccd33858130496f943919c3da6b9dd)] __-__ #4 修复方法无限递归异常 (guoyanshi) [#4](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/4)
 - [[```25ed31ab```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/25ed31ab515ecd1986adb12e9a34fea62d85c335)] __-__ #6 修复hook方法的热重载问题-优化hook函数替换方式 (mambaxie) [#6](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/6)
 - [[```1437e92f```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/1437e92f756c28966e9deb7a1c60327dcfb4d232)] __-__ #6 修复hook方法的热重载问题-兼容手Q qlvr hook处理 (mambaxie) [#6](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/6)
 - [[```904bffc6```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/904bffc68fdb03a5681b1b8eadb8a87cf26615ae)] __-__ #2 支持开机自启动 (guoyanshi) [#2](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/2)
 - [[```4fc381ca```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/4fc381ca264e0042ab280f9dd9ad737b9fd25097)] __-__ #6 修复category中hook函数时，导致死循环问题 (mambaxie) [#6](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/6)
 - [[```7aec78f2```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/7aec78f250098e030aa55a30156c0873f8311b0d)] __-__ #1 支持选择最近使用工程 (guoyanshi) [#1](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/1)
 - [[```2460141a```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/2460141aec3acc9808b7a067e3f24c874e54310c)] __-__ #10 调整描述文案 (holyli) [#10](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/10)
 - [[```3d6f2cf0```](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/commit/3d6f2cf0980e9833aa4030115e8d25a36dcc4acb)] __-__ #10 更新文档描述 (holyli) [#10](https://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/issues/10)




## [2020-06-18, Version  mac-0.0.7](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/mac-0.0.7)





## [2020-06-12, Version  mac-0.0.5](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/mac-0.0.5)





## [2020-06-08, Version  0.2.2](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.2.2)





## [2020-06-06, Version  0.2.1](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.2.1)





## [2020-06-03, Version  0.2.0](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.2.0)





## [2020-06-02, Version  0.1.9](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.1.9)





## [2020-06-01, Version  0.1.8](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.1.8)





## [2020-05-29, Version  0.1.7](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.1.7)





## [2020-05-29, Version  0.1.6](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.1.6)





## [2020-05-29, Version  0.1.5](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.1.5)





## [2020-03-25, Version  0.1.4](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.1.4)





## [2020-03-18, Version  0.1.3](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.1.3)





## [2020-03-18, Version  0.1.2](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.1.2)





## [2020-03-13, Version  0.1.1](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.1.1)





## [2020-03-13, Version  0.1.0](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.1.0)





## [2020-03-13, Version  0.0.9](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.0.9)





## [2020-03-13, Version  0.0.8](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.0.8)





## [2020-03-01, Version  0.0.7](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.0.7)





## [2020-03-01, Version  0.0.6](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.0.6)





## [2020-03-01, Version  0.0.5](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.0.5)





## [2020-01-19, Version  0.0.4](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.0.4)





## [2020-01-19, Version  0.0.3](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.0.3)





## [2020-01-19, Version  0.0.2](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.0.2)





## [2020-01-19, Version  0.0.1](http://git.woa.com/QQWallet-OpenSource-iOS/CocoaHotReload/-/tags/0.0.1)





